%% VihaanProject1 — Robust Preview (NO onCleanup; NO OOM)
clc; clear;

finalFolder = 'D:\VihaanProject1\final_retained_dataset';
assert(exist(finalFolder,'dir')==7, 'Folder not found:\n%s', finalFolder);

files = dir(finalFolder);
files = files(~[files.isdir]);
assert(~isempty(files), 'No files found in: %s', finalFolder);

fprintf('Previewing first five lines/rows from files in:\n%s\n\n', finalFolder);

for i = 1:numel(files)
    fname = files(i).name;
    fpath = fullfile(files(i).folder, fname);

    fprintf('\n==================================================\n');
    fprintf('FILE: %s\n', fname);
    fprintf('--------------------------------------------------\n');

    [~,~,ext] = fileparts(fname);
    ext = lower(ext);

    try
        switch ext
            case '.csv'
                % print 1 header + 5 data rows
                printFirstNLines_NoCleanup(fpath, 6);

            case '.txt'
                printFirstNLines_NoCleanup(fpath, 5);

            case '.mat'
                vars = whos('-file', fpath);
                fprintf('Variables in MAT file:\n');
                for v = 1:numel(vars)
                    fprintf('  %s (%s)\n', vars(v).name, vars(v).class);
                end

                S = load(fpath);
                if isfield(S,'RunMeta')
                    fprintf('\nPreview: RunMeta\n');
                    disp(S.RunMeta);
                else
                    fn = fieldnames(S);
                    if ~isempty(fn)
                        fprintf('\nPreview of first variable: %s\n', fn{1});
                        disp(S.(fn{1}));
                    end
                end

            otherwise
                fprintf('Unsupported file type: %s\n', ext);
        end
    catch ME
        fprintf('ERROR reading file: %s\n', ME.message);
    end
end

fprintf('\nDONE. Preview completed for all files.\n');

%% ---------------- local helper ----------------
function printFirstNLines_NoCleanup(fpath, nLines)
    fid = fopen(fpath, 'r');
    if fid < 0
        error('Unable to open file:\n%s', fpath);
    end

    try
        for k = 1:nLines
            ln = fgetl(fid);
            if ~ischar(ln), break; end

            % Strip UTF-8 BOM only if it appears at start of first line
            if k == 1 && ~isempty(ln) && ln(1) == char(65279)
                ln = ln(2:end);
            end

            fprintf('%s\n', ln);
        end
    catch
        fclose(fid);
        rethrow(lasterror); %#ok<LERR>
    end

    fclose(fid);
end
