function Results=RevisedCodes_13_14_RunAll(settings)
if nargin<1,settings=struct;end
if isfield(settings,'Step13')||isfield(settings,'Step14')
 s13=struct;s14=struct;if isfield(settings,'Step13'),s13=settings.Step13;end;if isfield(settings,'Step14'),s14=settings.Step14;end
else
 s13=settings;s14=settings;
end
Results=struct;Results.Step13=RevisedCodes_13_RunAll(s13);Results.Step14=RevisedCodes_14_RunAll(s14);
Checks=[Results.Step13.SelfTests;Results.Step13.Diagnostics.Checks; ...
 Results.Step14.SelfTests;Results.Step14.Engine.Checks];
assert(all(Checks.Passed),'Combined Step13-14 run incomplete.');
fprintf('\nSTEPS 13-14 COMPLETE. Upload RevisedCodes_13_Checks.zip and RevisedCodes_14_Checks.zip.\n');
fprintf('No model/policy has been selected or frozen; no reserved real case was opened.\n');
end
