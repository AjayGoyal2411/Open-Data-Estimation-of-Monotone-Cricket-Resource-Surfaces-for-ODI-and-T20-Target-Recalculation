function Checks=RevisedCodes_13_SelfTests
U=RevisedCodes_13_Utils;H=120;[u,w]=ndgrid(0:H,0:10);R=(u/H).*(w/10);
assert(istable(U.SubgroupReadiness())&&istable(U.Coverage()),'Step13 report factories must return tables.');
M=struct('Resource',R,'Horizon',H,'SourceReferenceID',"ref",'FitBasis',"toy");
row=table("FULL_TRAIN_T20","T20","candidate",'VariableNames',{'PackageID','Format','CandidateID'});
P=struct('Index',table("FULL_TRAIN_T20","ref",'VariableNames',{'PackageID','CandidateID'}), ...
 'Models',{{struct('Resource',R,'Supported',true(size(R)),'DataWeights',ones(size(R))/numel(R))}});
assert(abs(U.Resource(M,60.5,10)-60.5/H)<1e-12,'Linear interpolation failed.');
assert(abs(U.Resource(M,H,10)-1)<1e-12&&U.Resource(M,0,7)==0,'Boundary evaluation failed.');
[S,C,G]=U.Metrics(M,row,"Toy",P);
assert(S.WeightedRMSESupported==0&&all(C.SignedResidual==0)&&all(G.WeightedRMSE==0),'Zero-residual metrics failed.');
assert(isscalar(S.WholeGridMAE)&&isscalar(S.WholeGridRMSE)&&isscalar(S.MaximumWholeGridDeviation), ...
 'Whole-grid metrics must contain one scalar per model.');
N=M;N.Resource(end,11)=N.Resource(end,11)+.1;
A=U.Metrics(N,row,"Toy",P);
assert(abs(A.WholeGridMAE-.1/numel(R))<1e-12&& ...
 abs(A.WholeGridRMSE-.1/sqrt(numel(R)))<1e-12&& ...
 abs(A.MaximumWholeGridDeviation-.1)<1e-12,'Nonzero whole-grid aggregation failed.');
a=U.Scenario(M,"Second innings: 10-ball prestart loss");
assert(abs(a.A2-(H-10)/H)<1e-12&&a.SameWicketOnly,'Ball-loss scenario failed.');
b=U.Scenario(M,"Distinct histories: first w8/10, second w5/20");
assert(b.A1>0&&b.A2>0&&~b.SameWicketOnly,'Cross-wicket scenario failed.');
Checks=table(["Resource boundaries";"Linear interpolation";"Supported/whole-grid metrics"; ...
 "Wicket/phase stratification";"10-ball scenario";"Cross-wicket history"; ...
 "Subgroup non-fabrication";"Approximation terminology"],true(8,1), ...
 'VariableNames',{'Check','Passed'});
disp(Checks);fprintf('Step13 support self-tests passed.\n');
end
