function Results=RevisedCodes_13_RunAll(settings)
if nargin<1,settings=struct;end
Results=struct;Results.SelfTests=RevisedCodes_13_SelfTests;
Results.Diagnostics=RevisedCodes_13_01_ApproximationDiagnostics(settings);
assert(all(Results.SelfTests.Passed)&&all(Results.Diagnostics.Checks.Passed),'Step13 incomplete.');
fprintf('Step13 COMPLETE. Approximation/propagation diagnostics are not independent validation.\n');
end
