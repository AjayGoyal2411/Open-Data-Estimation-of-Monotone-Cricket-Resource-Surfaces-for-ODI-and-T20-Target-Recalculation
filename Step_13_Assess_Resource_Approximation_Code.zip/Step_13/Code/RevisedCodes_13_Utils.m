function U=RevisedCodes_13_Utils
U.Inputs=@inputs;U.Signature=@signature;U.Reference=@reference;U.Metrics=@metrics;
U.ScoreInventory=@scoreInventory;U.DisplayModels=@displayModels;U.Resource=@resource;
U.Scenario=@scenario;U.Coverage=@coverage;U.SubgroupReadiness=@subgroupReadiness;
end

function [cfg,C,F,P,E,paths]=inputs
W=RevisedCodes_12_Utils;[cfg,P,E,base]=W.Inputs();
root=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step12');
cp=fullfile(root,'RevisedCodes_12_01_Result.mat');fp=fullfile(root,'RevisedCodes_12_02_Result.mat');
assert(isfile(cp)&&isfile(fp),'Completed Step12 compact and Bernstein results are required.');
z=load(cp,'Compact');C=z.Compact;z=load(fp,'Flexible');F=z.Flexible;
validateStep12(C);validateStep12(F);
z=load(C.ResourcePackagePath,'ReferencePackage');C.Package=z.ReferencePackage;
z=load(F.ResourcePackagePath,'ReferencePackage');F.Package=z.ReferencePackage;
assert(~C.Package.ModelSelected&&~F.Package.ModelSelected&&~C.Package.PolicyFrozen&&~F.Package.PolicyFrozen, ...
 'Step13 requires unfrozen development candidates.');
paths=unique([base;string(cp);string(fp);C.ResourcePackagePath;F.ResourcePackagePath],'stable');
end

function validateStep12(D)
V=RevisedCodes_10_Utils;
assert(all(D.Checks.Passed)&&all(isfile(D.ArtifactPaths))&&isfile(D.ReportZIP),'Step12 result is incomplete.');
assert(isequal(D.Signature.Sources,V.Stamps(D.Signature.Sources.Path)),'Step12 source changed.');
for j=1:height(D.Signature.CodeFiles)
 assert(D.Signature.CodeFiles.Content(j)==string(fileread(D.Signature.CodeFiles.Path(j))), ...
  'Step12 code changed after its result was generated.');
end
end

function S=signature(stage,c,paths)
V=RevisedCodes_10_Utils;
S=struct('Stage',stage,'Settings',c,'Sources',V.Stamps(paths),'CodeFiles',table);
names=["RevisedCodes_13_00_Config","RevisedCodes_13_Utils", ...
 "RevisedCodes_13_01_ApproximationDiagnostics","RevisedCodes_13_SelfTests", ...
 "RevisedCodes_13_RunAll","RevisedCodes_13_14_RunAll"];
for n=names
 p=which(char(n));assert(~isempty(p),'Missing Step13 code %s.',n);
 S.CodeFiles=[S.CodeFiles;table(string(p),string(fileread(p)),'VariableNames',{'Path','Content'})]; %#ok<AGROW>
end
end

function [R,support,weights,refID]=reference(M,row,P)
refID=string(M.SourceReferenceID);
j=find(P.Index.PackageID==row.PackageID&P.Index.CandidateID==refID);
assert(isscalar(j),'Source reference is not uniquely registered.');
R=P.Models{j}.Resource;support=P.Models{j}.Supported;weights=P.Models{j}.DataWeights;
end

function [summary,cells,groups]=metrics(M,row,family,P)
[ref,support,weights,refID]=reference(M,row,P);fit=M.Resource;delta=fit-ref;
assert(isequal(size(fit),size(ref))&&all(isfinite(fit(:))),'Invalid approximation grid.');
weights=weights(:);support=support(:);weights(~support)=0;
if sum(weights)>0,weights=weights/sum(weights);end
u=repmat((0:M.Horizon)',11,1);w=kron((0:10)',ones(M.Horizon+1,1));
phase=repmat("Middle innings",numel(u),1);x=u/M.Horizon;
phase(x<=1/3)="Late innings";phase(x>2/3)="Early innings";
fitBasis="compact_reference";if isfield(M,'FitBasis'),fitBasis=string(M.FitBasis);end
cells=table(repmat(row.PackageID,numel(u),1),repmat(row.Format,numel(u),1), ...
 repmat(string(family),numel(u),1),repmat(row.CandidateID,numel(u),1), ...
 repmat(fitBasis,numel(u),1),repmat(refID,numel(u),1), ...
 u,w,phase,fit(:),ref(:),delta(:),support,weights, ...
 'VariableNames',{'PackageID','Format','Family','ModelID','FitBasis','ReferenceCandidate', ...
 'BallsRemaining','WicketsInHand','Phase','FittedResource','ReferenceResource', ...
 'SignedResidual','ReferenceSupported','ReferenceWeight'});
valid=support&weights>0;assert(any(valid),'No supported comparison cells.');
summary=table(row.PackageID,row.Format,string(family),row.CandidateID,fitBasis,refID, ...
 nnz(valid),sum(weights(valid).*delta(valid)),sum(weights(valid).*abs(delta(valid))), ...
 sqrt(sum(weights(valid).*delta(valid).^2)),mean(abs(delta(valid))), ...
 sqrt(mean(delta(valid).^2)),max(abs(delta(valid))),mean(abs(delta(:))), ...
 sqrt(mean(delta(:).^2)),max(abs(delta(:))), ...
 'VariableNames',{'PackageID','Format','Family','ModelID','FitBasis','ReferenceCandidate', ...
 'SupportedCells','WeightedBiasSupported','WeightedMAESupported','WeightedRMSESupported', ...
 'UnweightedMAESupported','UnweightedRMSESupported','MaximumSupportedDeviation', ...
 'WholeGridMAE','WholeGridRMSE','MaximumWholeGridDeviation'});
groups=table;
for wi=0:10
 for ph=["Early innings","Middle innings","Late innings"]
  ix=valid&w==wi&phase==ph;if ~any(ix),continue;end
  ww=weights(ix);ww=ww/sum(ww);d=delta(ix);
  groups=[groups;table(row.PackageID,row.Format,string(family),row.CandidateID, ...
   fitBasis,refID,wi,ph,nnz(ix),sum(ww.*d),sum(ww.*abs(d)), ...
   sqrt(sum(ww.*d.^2)),max(abs(d)), ...
   'VariableNames',{'PackageID','Format','Family','ModelID','FitBasis', ...
   'ReferenceCandidate','WicketsInHand','Phase','Cells','WeightedBias', ...
   'WeightedMAE','WeightedRMSE','MaximumDeviation'})]; %#ok<AGROW>
 end
end
end

function T=scoreInventory(E,c)
T=table;
for j=1:height(E.Packages)
 if E.Packages.Cohort(j)~="FULL_TRAIN",continue;end
 z=load(E.Packages.Path(j),'Surface');S=z.Surface;
 if S.Format=="ODI",illustrative=c.IllustrativeScoresODI;else,illustrative=c.IllustrativeScoresT20;end
 q=quantile(double(S.TrainingLedger.DeliveryRuns),c.ScoreQuantiles);
 labels="TrainingQuantile_"+string(round(100*c.ScoreQuantiles));
 values=round(q);source=repmat("Training delivery-run total",numel(q),1);
 labels=[labels(:);"IllustrativePlanScore"];values=[values(:);illustrative];source=[source;"Prespecified illustrative score; not a data quantile"];
 B=table(repmat(S.Format,numel(values),1),repmat(S.TrainingInnings,numel(values),1), ...
 labels,values,source,'VariableNames',{'Format','TrainingInnings','ScoreLabel','FirstInningsScore','Source'});
 T=[T;B]; %#ok<AGROW>
end
end

function T=displayModels(C,F,c)
T=table;
for format=["ODI","T20"]
 j=find(C.Package.Index.Cohort=="FULL_TRAIN"&C.Package.Index.Format==format& ...
  C.Package.Index.CandidateID=="compact__"+string(c.DisplayReference));
 assert(isscalar(j),'Compact display model missing.');
 T=[T;table(format,"Compact",C.Package.Index.CandidateID(j),j, ...
  'VariableNames',{'Format','Family','ModelID','Index'})]; %#ok<AGROW>
 bases=["reference__"+string(c.DisplayReference),"direct_state","direct_innings"];
 for b=bases
  id=string(sprintf('bern_d%d_l%g_',c.DisplayDegree,c.DisplaySmoothing))+b;
  j=find(F.Package.Index.Cohort=="FULL_TRAIN"&F.Package.Index.Format==format&F.Package.Index.CandidateID==id);
  assert(isscalar(j),'Bernstein display model missing: %s.',id);
  T=[T;table(format,"Bernstein",id,j,'VariableNames',{'Format','Family','ModelID','Index'})]; %#ok<AGROW>
 end
end
end

function r=resource(M,u,w)
validateattributes(u,{'numeric'},{'real','finite','nonnegative','<=',M.Horizon});
validateattributes(w,{'numeric'},{'real','finite','scalar','integer','>=',0,'<=',10});
lo=floor(u);hi=ceil(u);a=u-lo;
r=(1-a).*M.Resource(lo+1,w+1)+a.*M.Resource(hi+1,w+1);
end

function S=scenario(M,name)
U=M.Horizon;
switch string(name)
 case "Second innings: 10-ball prestart loss"
  A1=1;A2=resource(M,U-10,10);same=true;
 case "Second innings: 20-ball prestart loss"
  A1=1;A2=resource(M,U-20,10);same=true;
 case "Distinct histories: first w8/10, second w5/20"
  p1=round(.60*U);p2=round(.45*U);
  A1=1-(resource(M,p1,8)-resource(M,p1-10,8));
  A2=1-(resource(M,p2,5)-resource(M,p2-20,5));same=false;
 case "Cross-wicket termination history"
  p1=round(.50*U);p2=round(.35*U);
  A1=1-(resource(M,p1,7)-resource(M,p1-10,7));
  A2=1-(resource(M,p2,3)-0);same=false;
 otherwise,error('Unknown propagation scenario.');
end
assert(A1>0&&A2>=0,'Scenario produced invalid allocated resources.');
S=struct('A1',A1,'A2',A2,'SameWicketOnly',same);
end

function T=subgroupReadiness
T=table(["T20 full-wicket aggregate";"T20 domestic/international"; ...
 "T20 competition";"T20 era";"ODI era"], ...
 ["AVAILABLE_STEP13";"NOT_IDENTIFIED_IN_AGGREGATED_STEP12"; ...
 "NOT_IDENTIFIED_IN_AGGREGATED_STEP12";"NOT_IDENTIFIED_IN_AGGREGATED_STEP12"; ...
 "NOT_IDENTIFIED_IN_AGGREGATED_STEP12"], ...
 ["Full-wicket residuals are reported for every candidate and phase"; ...
 "Requires a prespecified subgroup refit on training innings; planned Step16"; ...
 "Requires competition labels and support thresholds; planned Step16"; ...
 "Requires chronological era definitions and sufficient support; planned Step16"; ...
 "Requires chronological era definitions and sufficient support; planned Step16"], ...
 'VariableNames',{'RequestedAnalysis','Status','RequiredAction'});
end

function T=coverage
T=table(["Approximation is not validation";"Supported and whole-grid errors"; ...
 "Wicket/phase diagnostics";"Same-wicket cancellation";"Cross-wicket histories"; ...
 "10/20-ball losses";"Illustrative scores";"Training-derived score range"; ...
 "T20 full-wicket residuals";"Competition/era claims"], ...
 ["Explicit in every output";"Implemented separately";"Implemented"; ...
 "Flagged in scenario output";"Implemented";"Implemented"; ...
 "Retained and labeled";"Five quantiles implemented";"Implemented"; ...
 "Deferred without fabrication"], ...
 'VariableNames',{'Requirement','Step13Treatment'});
end
