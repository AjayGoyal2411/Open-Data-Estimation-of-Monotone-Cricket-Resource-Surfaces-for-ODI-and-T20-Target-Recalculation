function c=RevisedCodes_13_00_Config(settings)
if nargin<1,settings=struct;end
c=struct('Version','13.1.0','ForceRebuild',false, ...
 'DisplayReference','mean_state_n30_count_l0','DisplayDegree',5, ...
 'DisplaySmoothing',.01,'IllustrativeScoresODI',275, ...
 'IllustrativeScoresT20',160,'ScoreQuantiles',[.10 .25 .50 .75 .90], ...
 'BallLosses',[10 20],'ConstraintTolerance',2e-7);
assert(isstruct(settings)&&isscalar(settings),'Settings must be a scalar struct.');
for n=fieldnames(settings)'
 assert(isfield(c,n{1}),'Unknown Step13 setting %s.',n{1});c.(n{1})=settings.(n{1});
end
validateattributes(c.ForceRebuild,{'logical'},{'scalar'});
validateattributes(c.DisplayDegree,{'numeric'},{'scalar','integer','positive'});
validateattributes(c.DisplaySmoothing,{'numeric'},{'scalar','nonnegative','finite'});
validateattributes(c.ScoreQuantiles,{'numeric'},{'vector','>',0,'<',1,'finite'});
validateattributes(c.BallLosses,{'numeric'},{'vector','integer','positive'});
validateattributes(c.ConstraintTolerance,{'numeric'},{'scalar','positive','finite'});
c.ScoreQuantiles=unique(c.ScoreQuantiles(:)');c.BallLosses=unique(c.BallLosses(:)');
end
