function V=RevisedCodes_11_02_Evaluate(P,format,cohort,candidate,u,w,allocation,options)
% Resource-only API. P is the serialized ReferencePackage struct or MAT path.
% Scalar inputs broadcast to the common vector length. No score labels accepted.
if nargin<8,options=struct;end
if ischar(P)||isstring(P)
 z=load(P,'ReferencePackage');P=z.ReferencePackage;
end
assert(isstruct(P)&&isfield(P,'SchemaVersion')&&P.SchemaVersion=="11.1.0",'Unknown package schema.');
assert(isstruct(options)&&isscalar(options),'Options must be a scalar struct.');
o=struct('Interpolation','linear','CohortClass','primary','Purpose','diagnostic','PredictionDate',[]);
for n=fieldnames(options)'
 assert(isfield(o,n{1}),'Unknown option %s; outcomes are not evaluator inputs.',n{1});o.(n{1})=options.(n{1});
end
assert(ismember(string(o.Interpolation),["linear","integer"]),'Interpolation must be linear or integer.');
assert(ismember(string(o.CohortClass),["primary","fold","auxiliary","case","sensitivity"]),'Unknown cohort class.');
assert(ismember(string(o.Purpose),["diagnostic","fit","assessment","case","sensitivity"]), ...
 'Target policy is not frozen; use the later interruption engine.');
format=upper(string(format));cohort=string(cohort);candidate=string(candidate);
assert(isscalar(format)&&ismember(format,["ODI","T20"])&&isscalar(cohort)&&isscalar(candidate),'Format/cohort/candidate must be scalar.');
sel=find(P.Index.Format==format&P.Index.Cohort==cohort&P.Index.CandidateID==candidate);
assert(numel(sel)==1,'Requested resource model not present.');
I=P.Index(sel,:);M=P.Models{sel};
assert(M.Certified,'Reference is not certified.');
if string(o.CohortClass)=="fold",assert(cohort~="FULL_TRAIN",'Fold requests require a fold model.');end
if string(o.Purpose)=="fit"
 if cohort=="FULL_TRAIN",assert(string(o.CohortClass)=="primary",'Original-training fitting requires primary class.');
 else,assert(string(o.CohortClass)=="fold",'Fold fitting requires fold class.');end
end
if string(o.Purpose)=="case",assert(string(o.CohortClass)=="case",'Case queries require case class.');end
if string(o.Purpose)=="sensitivity",assert(string(o.CohortClass)=="sensitivity",'Sensitivity queries require sensitivity class.');end
if string(o.Purpose)=="assessment"
 assert(cohort~="FULL_TRAIN"&&string(o.CohortClass)=="fold",'Assessment requires explicit fold model/class.');
 assert(isdatetime(o.PredictionDate)&&~isempty(o.PredictionDate)&&all(~isnat(o.PredictionDate(:))), ...
  'Assessment requires observed prediction dates.');
 assert(all(o.PredictionDate(:)>=I.TrainingCutoffExclusive),'Assessment date precedes training cutoff.');
end
validateattributes(u,{'numeric'},{'real','finite','vector','nonempty'});
validateattributes(w,{'numeric'},{'real','finite','vector','nonempty'});
validateattributes(allocation,{'numeric'},{'real','finite','vector','nonempty'});
n=max([numel(u),numel(w),numel(allocation)]);u=expand(u,n);w=expand(w,n);a=expand(allocation,n);
if string(o.Purpose)=="assessment",assert(isscalar(o.PredictionDate)||numel(o.PredictionDate)==n,'Prediction dates must be scalar or one per query.');end
assert(all(w==fix(w)&w>=0&w<=10),'Wickets in hand must be integer 0..10.');
assert(all(a==fix(a)&a>=0&a<=M.Horizon),'Allocation must be an integer within nominal horizon; oversized horizons need a separate audited model.');
assert(all(u>=0&u<=a),'Remaining balls must satisfy 0<=u<=allocation.');
if string(o.Interpolation)=="integer",assert(all(u==fix(u)),'Integer policy rejects fractional remaining balls.');end
lo=floor(u);hi=ceil(u);alpha=u-lo;
i0=sub2ind(size(M.Resource),lo+1,w+1);i1=sub2ind(size(M.Resource),hi+1,w+1);
r=(1-alpha).*M.Resource(i0)+alpha.*M.Resource(i1);
nodeSupport=M.Supported(i0)&M.Supported(i1);interp=lo~=hi;
boundary=u==0|w==0|(u==M.Horizon&w==10);
status=repmat("supported_grid",n,1);status(~nodeSupport)="unsupported_completion";
status(interp&nodeSupport)="interpolated_supported";
status(interp&~nodeSupport)="interpolated_completion";status(boundary)="boundary_anchor";
count=M.MatchCount;if startsWith(I.Estimand,"Fraction"),count=M.FractionCount;end
% Count of union/intersection of endpoint matches is not known: return counts
% for individual nodes only, without inventing a fractional-query count.
node0=count(i0);node1=count(i1);
role=repmat("original_training_reference",n,1);if cohort~="FULL_TRAIN",role(:)="fold_fitting_reference";end
scaleRuns=NaN(n,1);
if ismember(I.Estimand,["RunMeanState","RunMeanInnings"]),scaleRuns=r*M.FullStartMean;end
V=table(u,w,a,repmat(M.Horizon,n,1),r,status,nodeSupport,interp,~nodeSupport&~boundary, ...
 boundary,false(n,1),node0,node1,repmat(I.MinMatches,n,1),scaleRuns, ...
 repmat(format,n,1),repmat(cohort,n,1),repmat(candidate,n,1),repmat(I.Estimand,n,1), ...
 repmat(I.ModelVersion,n,1),repmat(I.TrainingCutoffExclusive,n,1),role, ...
 repmat(string(o.CohortClass),n,1),repmat(string(o.Purpose),n,1),false(n,1),false(n,1), ...
 'VariableNames',{'BallsRemaining','WicketsInHand','AllocatedBalls','NominalBalls','Resource', ...
 'SupportStatus','AllContributingNodesSupported','Interpolated','UsesUnsupportedCompletion', ...
 'BoundaryAnchor','Extrapolated','LowerNodeSupportCount','UpperNodeSupportCount', ...
 'RequiredSupportCount','MeanEstimandScaleRuns','Format','Cohort','CandidateID','Estimand', ...
 'ModelVersion','TrainingCutoffExclusive','ReferenceRole','QueryCohortClass','Purpose', ...
 'OfficialTable','TargetPolicyFrozen'});
end
function x=expand(x,n)
x=double(x(:));assert(numel(x)==1||numel(x)==n,'Input lengths are incompatible.');
if numel(x)==1,x=repmat(x,n,1);end
end
