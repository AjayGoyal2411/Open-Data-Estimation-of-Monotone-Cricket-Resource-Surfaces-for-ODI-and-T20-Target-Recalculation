function Results11=RevisedCodes_11_RunAll(settings)
% Run support tests, saved-grid numerical repair, serialization and API audits.
if nargin<1,settings=struct;end
Checks=RevisedCodes_11_SelfTests(settings);
Interface=RevisedCodes_11_01_ResourceInterface(settings);
r=char(Interface.ReportDirectory);writetable(Checks,fullfile(r,'11_AlgorithmSelfTests.csv'));
cfg=RevisedCodes_09_00_Config;files=dir(fullfile(r,'*'));files=files(~[files.isdir]);
p=fullfile(cfg.ProjectRoot,'RevisedCodes_11_Checks.zip');zip(p,{files.name},r);
Results11=struct('SelfTests',Checks,'Interface',Interface,'CombinedChecks',string(p));
fprintf('STEP11 COMPLETE. Upload %s\n',p);
fprintf('Next after audit: Step12 compact baseline and Bernstein constrained models.\n');
end
