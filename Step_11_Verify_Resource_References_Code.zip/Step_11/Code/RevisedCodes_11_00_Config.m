function c=RevisedCodes_11_00_Config(settings)
% Only Step11 settings. Original Step09/10 files remain untouched.
if nargin<1,settings=struct;end
c=struct('Version','11.1.2','ForceRebuild',false,'SolverTolerance',1e-10, ...
 'MaxIterations',3000,'MaxSolverAttempts',3,'ConstraintTolerance',2e-8,'CertificateTolerance',1e-6, ...
 'WitnessTolerance',1e-8,'DisplayCandidate','mean_state_n30_count_l0');
assert(isstruct(settings)&&isscalar(settings),'Settings must be a scalar struct.');
for n=fieldnames(settings)'
 assert(isfield(c,n{1}),'Unknown Step11 setting %s.',n{1});c.(n{1})=settings.(n{1});
end
validateattributes(c.ForceRebuild,{'logical'},{'scalar'});
for n={'SolverTolerance','ConstraintTolerance','CertificateTolerance','WitnessTolerance'}
 validateattributes(c.(n{1}),{'numeric'},{'scalar','finite','positive'});
end
validateattributes(c.MaxIterations,{'numeric'},{'scalar','integer','positive'});
validateattributes(c.MaxSolverAttempts,{'numeric'},{'scalar','integer','>=',1,'<=',4});
end
