function Interface=RevisedCodes_11_01_ResourceInterface(settings)
% Audit/repair Step10 references, serialize a shared resource-only API package.
if nargin<1,settings=struct;end
c=RevisedCodes_11_00_Config(settings);U=RevisedCodes_11_Utils;V=RevisedCodes_10_Utils;
[cfg,~,~,~,~]=V.Inputs();
root10=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step10');
ep=fullfile(root10,'RevisedCodes_10_01_Result.mat');rp=fullfile(root10,'RevisedCodes_10_02_Result.mat');
z=load(ep,'Empirical');E=z.Empirical;z=load(rp,'References');R=z.References;
c10=R.Signature.Settings;
assert(isequaln(E.Signature,V.Signature("10_01",E.Signature.Settings,E.Signature.Sources.Path)), ...
 'Step10 empirical sources/config/code changed. Restore the code used by your successful run.');
assert(isequaln(R.Signature,V.Signature("10_02",c10,R.Signature.Sources.Path)), ...
 'Step10 references sources/config/code changed. Restore the code used by your successful run.');
assert(all(E.Checks.Passed)&&all(R.Checks.Passed)&&height(E.Packages)==height(R.Packages), ...
 'Step10 prerequisites incomplete.');
assert(all(ismember(E.Packages.PackageID,R.Packages.PackageID)),'Empirical/reference populations differ.');
paths=unique([string(ep);string(rp);E.Packages.Path;R.Packages.Path; ...
 E.Signature.Sources.Path;R.Signature.Sources.Path; ...
 E.Signature.CodeFiles.Path;R.Signature.CodeFiles.Path],'stable');
S=struct('Settings',c,'Sources',V.Stamps(paths),'Code',table);
for name=["RevisedCodes_11_00_Config","RevisedCodes_11_Utils","RevisedCodes_11_01_ResourceInterface", ...
 "RevisedCodes_11_02_Evaluate","RevisedCodes_11_SelfTests","RevisedCodes_11_RunAll"]
 p=which(char(name));assert(~isempty(p),'Missing Step11 code.');
 S.Code=[S.Code;table(string(p),string(fileread(p)),'VariableNames',{'Path','Content'})]; %#ok<AGROW>
end
root=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step11');out=fullfile(root,'RevisedCodes_11_01_Result.mat');
if isfile(out)&&~c.ForceRebuild
 z=load(out,'Interface');I=z.Interface;
 if isequaln(I.Signature,S)&&all(isfile(I.ArtifactPaths))&&isfile(I.ReferencePackagePath)
  Interface=I;fprintf('Valid Step11 cache reused.\n');return;
 end
end
[g,report]=V.Generation(root);Index=table;Models=cell(0,1);Diagnostics=table;GridAudit=table;SolverAttempts=table;
Publication= strings(0,1);display=table;cohortAudit=table;
sd=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady','SourceData');
if ~isfolder(sd),mkdir(sd);end
for j=1:height(E.Packages)
 z=load(E.Packages.Path(j),'Surface');T=z.Surface;
 k=find(R.Packages.PackageID==T.PackageID);z=load(R.Packages.Path(k),'Bundle');old=z.Bundle;
 assert(isequal(T.TrainingInnings,old.TrainingInnings)&&T.FullStartMean==old.FullStartMean, ...
  'Reference/empirical training basis differs.');
 C=old.Candidates;assert(any(C.CandidateID==string(c.DisplayCandidate)),'Unknown display candidate.');
 for k=1:height(C)
  [M,Q]=U.Solve(T,C(k,:),c,c10,old.Models{k});
  version=U.Fingerprint([M.Resource(:);double(M.Supported(:));M.DataWeights(:);M.MatchCount(:);M.FractionCount(:)],T.PackageID+"|"+C.CandidateID(k)+"|"+string(T.TrainingCutoffExclusive)+ ...
   "|"+string(T.FullStartMean)+"|"+string(c.Version));
  M.ModelVersion=version;M.Cohort=T.Cohort;M.TrainingCutoffExclusive=T.TrainingCutoffExclusive;
  M.TrainingInnings=T.TrainingInnings;M.TrainingStates=T.TrainingStates;
  M.PopulationBasis="Step09 audited primary completed first innings; original training or fold fitting only";
  Models{end+1,1}=M; %#ok<AGROW>
  row=table(T.PackageID,T.Cohort,T.Format,C.CandidateID(k),C.Estimand(k),C.MinMatches(k), ...
   T.TrainingCutoffExclusive,version, ...
   'VariableNames',{'PackageID','Cohort','Format','CandidateID','Estimand','MinMatches','TrainingCutoffExclusive','ModelVersion'});
  Index=[Index;row];Diagnostics=[Diagnostics;Q];SolverAttempts=[SolverAttempts;M.OptimizerAttempts]; %#ok<AGROW>
  P=struct('SchemaVersion',"11.1.0",'Index',row,'Models',{{M}});
  [u,w]=ndgrid(0:M.Horizon,0:10);
  options=struct('Interpolation','integer');if T.Cohort~="FULL_TRAIN",options.CohortClass='fold';end
  A=RevisedCodes_11_02_Evaluate(P,T.Format,T.Cohort,C.CandidateID(k),u(:),w(:),M.Horizon,options);
  assert(max(abs(A.Resource-M.Resource(:)))<1e-13,'Integer interface/grid disagreement.');
  B=RevisedCodes_11_02_Evaluate(P,T.Format,T.Cohort,C.CandidateID(k), ...
   ((0:M.Horizon-1)'+.5),10,M.Horizon,struct('Interpolation','linear'));
  assert(all(diff(B.Resource)>=-c.ConstraintTolerance),'Fractional interpolation violates order.');
  Audit=table(T.PackageID,C.CandidateID(k),height(A),nnz(A.AllContributingNodesSupported), ...
   nnz(A.UsesUnsupportedCompletion),nnz(A.BoundaryAnchor),max(abs(A.Resource-M.Resource(:))), ...
   V.Residual(A.Resource,M.Horizon),min(diff(B.Resource)), ...
   'VariableNames',{'PackageID','CandidateID','GridQueries','SupportedQueries', ...
   'UnsupportedCompletionQueries','BoundaryQueries','LookupError','GridConstraintResidual','MinimumHalfBallDifference'});
  GridAudit=[GridAudit;Audit]; %#ok<AGROW>
  if T.Cohort=="FULL_TRAIN"&&C.CandidateID(k)==string(c.DisplayCandidate)
   A.PreviousResource=old.Models{k}.Resource(:);A.ResourceChange=A.Resource-A.PreviousResource;
   A.DataWeight=M.DataWeights(:);A.EmpiricalEstimand=T.Grid.(char(C.Estimand(k)));
   display=[display;A]; %#ok<AGROW>
  end
  % All corrected numeric grids are publication source data, retained locally.
  p=fullfile(sd,char("11_01_"+T.PackageID+"_"+C.CandidateID(k)+".csv"));writetable(A,p);
  Publication(end+1,1)=string(p); %#ok<AGROW>
  fprintf('Step11 %s %d/%d certified; objective gap bound %.3g\n',T.PackageID,k,height(C),Q.ObjectiveGapBound);
 end
 cohortAudit=[cohortAudit;E.Packages(j,{'PackageID','Cohort','Format','TrainingCutoffExclusive','Innings','States','FullStartMean'})]; %#ok<AGROW>
end
ReferencePackage=struct('SchemaVersion',"11.1.0",'Index',Index,'Models',{Models}, ...
 'Dictionary',U.Dictionary(),'Candidates',R.Candidates,'Created',datetime('now'), ...
 'Status',"CERTIFIED_REFERENCE_CANDIDATES_SELECTION_PENDING", ...
 'OfficialTable',false,'ModelSelected',false,'PolicyFrozen',false, ...
 'PrimaryPopulationBasis',"Audited completed primary first innings; six-ball ODI/T20; delivery-run labels", ...
 'AllocationPolicy',"Use nominal-horizon R(u,w) with 0<=u<=allocated<=nominal; never renormalize by shortened allocation", ...
 'UnsupportedPolicy',"Zero-weight constrained completion; lambda=0 may be nonunique; disclose all contributing-node support", ...
 'Signature',S);
packagePath=fullfile(g,'RevisedCodes_11_ReferencePackage.mat');save(packagePath,'ReferencePackage','-v7.3');
% Actual serialize/load round trip checked for every candidate at the start node.
z=load(packagePath,'ReferencePackage');
for j=1:height(Index)
 A=RevisedCodes_11_02_Evaluate(z.ReferencePackage,Index.Format(j),Index.Cohort(j), ...
  Index.CandidateID(j),Models{j}.Horizon,10,Models{j}.Horizon);
 assert(abs(A.Resource-1)<c.ConstraintTolerance&&A.ModelVersion==Index.ModelVersion(j),'Serialization round trip failed.');
end
Dictionary=U.Dictionary();Coverage=U.Coverage();
Checks=table(["Current saved Step10 provenance";"Repaired convex objective certified"; ...
 "Feasible witness gap within certified numerical allowance";"All integer lookup values match grids"; ...
 "Boundary/order/range and half-ball interpolation";"Support and constrained fill distinguished"; ...
 "All candidate serialized round trips";"Fold normalization/populations preserved"; ...
 "Resource/output and nonofficial terminology";"No final selection, freeze or independent accuracy claim"], ...
 true(10,1),'VariableNames',{'Check','Passed'});
for item={ {'11_01_CertificationDiagnostics',Diagnostics},{'11_01_InterfaceGridAudit',GridAudit},{'11_01_SolverAttempts',SolverAttempts}, ...
 {'11_01_ModelIndex',Index},{'11_01_CohortAudit',cohortAudit},{'11_01_Dictionary',Dictionary}, ...
 {'11_01_ReviewerEditorCoverage',Coverage},{'11_01_GateChecks',Checks}, ...
 {'11_01_ReferenceRepairSourceData',display}}
 pair=item{1};writetable(pair{2},fullfile(report,[pair{1} '.csv']));
end
Publication=[Publication;V.TableExport(cfg,"Methodology","T_M17_ResourceNotationAndInterface",Dictionary); ...
 V.TableExport(cfg,"Supplementary","T_S11_01_ReferenceCertification",Diagnostics); ...
 V.TableExport(cfg,"Supplementary","T_S11_04_SolverAttempts",SolverAttempts); ...
 V.TableExport(cfg,"Supplementary","T_S11_02_InterfaceAudit",GridAudit); ...
 V.TableExport(cfg,"Supplementary","T_S11_03_ReviewerEditorCoverage",Coverage)];
% Corrected projection figure supersedes the unverified Step10 projection panel.
fig=figure('Visible','off','Color','w','Position',[80 80 1300 820]);clean=onCleanup(@()close(fig)); %#ok<NASGU>
tiledlayout(2,3,'TileSpacing','compact','Padding','compact');
formats=["ODI","T20"];maxChange=max(1e-6,max(abs(display.ResourceChange)));
for f=1:2
 B=display(display.Format==formats(f),:);h=max(B.NominalBalls);
 fields={B.PreviousResource,B.Resource,B.ResourceChange};labels={'Previous unverified reference','Certified reference','Certified minus previous'};
 for k=1:3
  nexttile;imagesc((0:h)/h,0:10,reshape(fields{k},h+1,11)');set(gca,'YDir','normal');
  xlabel('Remaining legal-ball fraction');ylabel('Wickets in hand');colorbar;
  if k<3,clim([0 1]);else,clim([-maxChange maxChange]);end
  title(sprintf('(%c) %s: %s',64+(f-1)*3+k,formats(f),labels{k}));set(gca,'FontName','Times New Roman','FontSize',10);
 end
end
Publication=[Publication;V.FigureExport(cfg,"F_M11_01_ReferenceCertification",fig,display, ...
 "Previous Step10 references and repaired, numerically certified convex-QP candidates, plus signed changes. ODI/T20 share color scales. Display candidate is provisional, not selected. Unsupported cells are constrained completions; support is recorded in source data. This numerical audit is not independent prediction or policy validation.",report)];
clear clean;
fig=figure('Visible','off','Color','w','Position',[80 80 1100 760]);clean=onCleanup(@()close(fig)); %#ok<NASGU>
tiledlayout(2,2,'TileSpacing','compact','Padding','compact');
for f=1:2
 B=display(display.Format==formats(f),:);h=max(B.NominalBalls);nexttile;hold on;
 for wi=[2 5 8 10]
  K=B(B.WicketsInHand==wi,:);plot(K.BallsRemaining/h,K.Resource,'LineWidth',1.3,'DisplayName',sprintf('w=%d',wi));
 end
 xlabel('Remaining legal-ball fraction');ylabel('Normalized scoring capacity');ylim([0 1]);title(formats(f)+": nominal reference slices");legend('Location','northwest');set(gca,'FontName','Times New Roman','FontSize',10);
 nexttile;K=B(B.WicketsInHand==10,:);plot(K.BallsRemaining/h,K.Resource,'k-','LineWidth',1.3);hold on;
 scatter(K.BallsRemaining(K.AllContributingNodesSupported)/h,K.Resource(K.AllContributingNodesSupported),9,[0 .4 .7],'filled');
 scatter(K.BallsRemaining(K.UsesUnsupportedCompletion)/h,K.Resource(K.UsesUnsupportedCompletion),12,[.8 .3 .1],'x');
 xlabel('Remaining legal-ball fraction');ylabel('Normalized scoring capacity');ylim([0 1]);
 title(formats(f)+": w=10 support disclosure");legend('Reference','Supported nodes','Unsupported completion','Location','northwest');set(gca,'FontName','Times New Roman','FontSize',10);
end
Publication=[Publication;V.FigureExport(cfg,"F_M11_02_ResourceInterface",fig,display, ...
 "Certified nominal-horizon scoring-capacity slices and full-wicket support disclosure. Linear interpolation is an interface assumption between adjacent legal-ball nodes; it is not an observation. Shortened allocation does not renormalize the nominal reference. These resource values are dimensionless inputs, not par/target output scores. Candidate remains provisional.",report)];
clear clean;
fig=figure('Visible','off','Color','w','Position',[80 80 1300 820]);clean=onCleanup(@()close(fig)); %#ok<NASGU>
tiledlayout(2,3,'TileSpacing','compact','Padding','compact');
mask=display.AllContributingNodesSupported;
capacityLimit=max(1,max(display.EmpiricalEstimand(mask)));
adjustment=display.Resource-display.EmpiricalEstimand;
deltaLimit=max(1e-6,max(abs(adjustment(mask))));
for f=1:2
 B=display(display.Format==formats(f),:);h=max(B.NominalBalls);
 raw=B.EmpiricalEstimand;raw(~B.AllContributingNodesSupported)=NaN;
 delta=B.Resource-B.EmpiricalEstimand;delta(~B.AllContributingNodesSupported)=NaN;
 fields={raw,B.Resource,delta};labels={'Supported empirical input','Certified reference','Supported-cell adjustment'};
 for k=1:3
  nexttile;im=imagesc((0:h)/h,0:10,reshape(fields{k},h+1,11)');im.AlphaData=isfinite(im.CData);
  set(gca,'YDir','normal','Color',[.95 .95 .95]);xlabel('Remaining legal-ball fraction');ylabel('Wickets in hand');colorbar;
  if k<3,clim([0 capacityLimit]);else,clim([-deltaLimit deltaLimit]);end
  title(sprintf('(%c) %s: %s',64+(f-1)*3+k,formats(f),labels{k}));set(gca,'FontName','Times New Roman','FontSize',10);
 end
end
Publication=[Publication;V.FigureExport(cfg,"F_M11_03_EmpiricalCertifiedReference",fig,display, ...
 "Supported empirical estimand, numerically certified constrained reference and signed supported-cell adjustment. This panel supersedes the unverified Step10 projection figure. ODI/T20 share color scales. Gray empirical/adjustment cells lack candidate support; filled reference cells there are constrained completions, not data. Candidate is provisional. Boundary/order assumptions and numerical certification do not establish independent prediction or target-policy accuracy.",report)];
flow=join(["```mermaid";"flowchart TD"; ...
 'A["Audited primary training and fold membership"] --> B["Empirical estimands and support"]'; ...
 'B --> C["Certified constrained references"]'; ...
 'C --> D["Validate format, balls, wickets and allocation"]'; ...
 'D --> E["Resource lookup and support disclosure"]'; ...
 'E --> F["Model fitting and approximation diagnostics"]'; ...
 'E --> G["Later declared interruption engine"]'; ...
 'G --> H["Verified frozen case evaluation"]';"```"],newline);
p=fullfile(report,'11_01_ComputationDiagram.md');fid=fopen(p,'w');assert(fid~=-1);fprintf(fid,'%s\n',flow);fclose(fid);
assert(isequal(S.Sources,V.Stamps(paths)),'Sources changed during Step11.');
for j=1:height(S.Code),assert(S.Code.Content(j)==string(fileread(S.Code.Path(j))),'Step11 code changed during run.');end
files=dir(fullfile(report,'*'));files=files(~[files.isdir]);names={files.name};
Interface=struct('Stage',"11_01",'Status',"INTERFACE_READY_SELECTION_PENDING", ...
 'Signature',S,'ReferencePackagePath',string(packagePath),'ModelIndex',Index, ...
 'Diagnostics',Diagnostics,'Checks',Checks,'ReportDirectory',string(report), ...
 'ArtifactPaths',[Publication;string(fullfile(report,names))']);
save(out,'Interface','-v7.3');
fprintf('Step11 resource interface ready; candidates remain unselected.\n');
end
