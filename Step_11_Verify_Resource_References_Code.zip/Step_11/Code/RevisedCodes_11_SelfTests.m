function Checks=RevisedCodes_11_SelfTests(settings)
if nargin<1,settings=struct;end
c=RevisedCodes_11_00_Config(settings);U=RevisedCodes_11_Utils;
R=((0:120)'/120)*((0:10)/10);M=struct('Resource',R,'Supported',true(size(R)), ...
 'Certified',true,'Horizon',120,'FullStartMean',160,'MatchCount',100*ones(size(R)), ...
 'FractionCount',100*ones(size(R)));
M.Supported(51,9)=false;
Index=table("Toy_T20","FULL_TRAIN","T20","toy","RunMeanState",30, ...
 datetime(2023,1,1),"toy-1",'VariableNames', ...
 {'PackageID','Cohort','Format','CandidateID','Estimand','MinMatches','TrainingCutoffExclusive','ModelVersion'});
P=struct('SchemaVersion',"11.1.0",'Index',Index,'Models',{{M}});
V=RevisedCodes_11_02_Evaluate(P,"T20","FULL_TRAIN","toy",[0;120;60],[10;10;0],120);
assert(isequal(V.Resource,[0;1;0])&&all(V.BoundaryAnchor),'Boundary test failed.');
V=RevisedCodes_11_02_Evaluate(P,"T20","FULL_TRAIN","toy",[49;49.5;50],8,120);
assert(abs(V.Resource(2)-49.5/120*.8)<1e-14&&V.SupportStatus(2)=="interpolated_completion",'Interpolation/support failed.');
assert(V.UsesUnsupportedCompletion(3)&&~any(V.Extrapolated),'Unsupported completion must be disclosed.');
reject(@()RevisedCodes_11_02_Evaluate(P,"T20","FULL_TRAIN","toy",-1,10,120));
reject(@()RevisedCodes_11_02_Evaluate(P,"T20","FULL_TRAIN","toy",NaN,10,120));
reject(@()RevisedCodes_11_02_Evaluate(P,"T20","FULL_TRAIN","toy",[20;30],[8;9;10],120));
reject(@()RevisedCodes_11_02_Evaluate(P,"T20","FULL_TRAIN","toy",20,8,120,struct('Purpose','fit','CohortClass','case')));

reject(@()RevisedCodes_11_02_Evaluate(P,"T20","FULL_TRAIN","toy",121,10,121));
reject(@()RevisedCodes_11_02_Evaluate(P,"T20","FULL_TRAIN","toy",20,2.5,120));
reject(@()RevisedCodes_11_02_Evaluate(P,"T20","FULL_TRAIN","toy",61,8,60));
reject(@()RevisedCodes_11_02_Evaluate(P,"T20","FULL_TRAIN","toy",20.5,8,120,struct('Interpolation','integer')));
reject(@()RevisedCodes_11_02_Evaluate(P,"T20","FULL_TRAIN","toy",20,8,120,struct('FinalTotal',160)));
reject(@()RevisedCodes_11_02_Evaluate(P,"T20","FULL_TRAIN","toy",20,8,120,struct('Purpose','assessment','CohortClass','fold','PredictionDate',datetime(2024,1,1))));
V=RevisedCodes_11_02_Evaluate(P,"T20","FULL_TRAIN","toy",60,10,60);
assert(V.Resource==.5&&~V.TargetPolicyFrozen&&~V.OfficialTable,'Allocation must not renormalize reference.');
V=RevisedCodes_11_02_Evaluate(P,"T20","FULL_TRAIN","toy",(0:.5:120)',8,120);
assert(all(diff(V.Resource)>=-1e-14),'Continuous balls order failed.');
P.Index.Cohort="Fold_2022";P.Index.TrainingCutoffExclusive=datetime(2022,1,1);
V=RevisedCodes_11_02_Evaluate(P,"T20","Fold_2022","toy",20,8,120,struct('Purpose','assessment','CohortClass','fold','PredictionDate',datetime(2022,1,1)));
assert(V.ReferenceRole=="fold_fitting_reference",'Fold chronology test failed.');
reject(@()RevisedCodes_11_02_Evaluate(P,"T20","Fold_2022","toy",20,8,120,struct('Purpose','assessment','CohortClass','fold','PredictionDate',datetime(2021,1,1))));
% Sparse QP toy checks certification and feasible-witness comparison.
% Regression fixture for the reported 2.1e-8 gap; material failures still stop.
cgate=RevisedCodes_11_00_Config;
assert(~U.CertificationGate(1,0,1.04e-6,cgate),'Reported failed bound must remain rejected.');
assert(U.CertificationGate(1,0,1e-7,cgate),'Improved retry bound must pass.');
assert(~U.CertificationGate(0,0,1e-7,cgate)&& ...
 ~U.CertificationGate(1,2*cgate.ConstraintTolerance,1e-7,cgate),'Exit/primal checks must remain enforced.');
[allowed,strict]=U.WitnessGate(2.1e-8,3e-8,cgate);
assert(allowed==cgate.WitnessTolerance+3e-8&&~strict,'Certificate-aware allowance failed.');
reject(@()U.WitnessGate(2e-5,3e-8,cgate));
reject(@()U.WitnessGate(2.1e-8,2*cgate.CertificateTolerance,cgate));
assert(license('test','Optimization_Toolbox')&&exist('quadprog','file')==2,'Optimization Toolbox required.');
c10=RevisedCodes_10_00_Config;V10=RevisedCodes_10_Utils;C=V10.Candidates();C=C(1,:);
Utoy=6;[u,w]=ndgrid(0:Utoy,0:10);target=(u/Utoy).*(w/10);target(20)=1.3;target(40)=-.1;
G=table(target(:),100*ones(numel(target),1),100*ones(numel(target),1), ...
 ones(numel(target),1),'VariableNames',{'RunMeanState','MatchCount','FractionCount','InningsWeightSum'});
G.MatchCount(25)=0;G.FractionCount(25)=0;
S=struct('Grid',G,'Horizon',Utoy,'Format',"T20",'FullStartMean',100,'PackageID',"ToyQP");
[M,Q]=U.Solve(S,C,c,c10);assert(height(M.OptimizerAttempts)==Q.SolverAttempts&&M.OptimizerAttempts.Certified(end)&&M.DataWeights(25)==0&&Q.ObjectiveGapBound<=c.CertificateTolerance&&Q.GapVsWitness<=Q.WitnessAllowance);
C.Lambda=.01;[~,Q]=U.Solve(S,C,c,c10);assert(Q.ObjectiveGapBound<=c.CertificateTolerance);
Checks=table(["Boundary anchors";"Linear interpolation";"Unsupported completion disclosure"; ...
 "Invalid inputs rejected";"Fractional wickets rejected";"Integer query policy"; ...
 "Outcome labels rejected";"Assessment cohort/chronology";"Allocation without renormalization"; ...
 "Continuous balls order";"Resource/output terminology";"Certificate-aware witness gate";"Unchanged certificate acceptance gate";"Certified unregularized QP";"Certified regularized QP"], ...
 true(15,1),'VariableNames',{'Check','Passed'});disp(Checks);
end
function reject(f)
failed=false;try,f();catch,failed=true;end
assert(failed,'Expected rejection did not occur.');
end
