function Results = RevisedCodes_21_RunAll(settings)
if nargin<1, settings=struct; end
C=RevisedCodes_21_Config(settings); U=RevisedCodes_21_Utils; here=fileparts(mfilename('fullpath'));
base=fullfile(C.ProjectRoot,'paper_outputs_revisedcodes','step21_publication_evidence'); if ~isfolder(base), mkdir(base); end
report=string(tempname(base)); mkdir(report); work=string(tempname); mkdir(work); cw=onCleanup(@()safeRemove(work)); %#ok<NASGU>
diary(fullfile(report,'RunLog.txt')); cdia=onCleanup(@()diary('off')); %#ok<NASGU>
try
 Tests=RevisedCodes_21_SelfTests; U.Write(Tests,fullfile(report,'Step21_SelfTests.csv'));
 D=RevisedCodes_21_Load(C,U,work); R=RevisedCodes_21_Analyse(D,C,U);
 U.Write(R.Summary,fullfile(report,'Step21_AgreementSummary.csv')); U.Write(R.Bootstrap,fullfile(report,'Step21_Bootstrap95CI.csv'));
 U.Write(R.Heterogeneity,fullfile(report,'Step21_FormatHeterogeneity.csv')); U.Write(R.Influence,fullfile(report,'Step21_LeaveOneOutInfluence.csv'));
 U.Write(R.Outliers,fullfile(report,'Step21_OutlierRegister.csv')); U.Write(R.OutlierSensitivity,fullfile(report,'Step21_OutlierSensitivity.csv'));
 U.Write(R.ComparatorProvenance,fullfile(report,'Step21_ComparatorProvenance.csv')); U.Write(R.EvidenceAccounting,fullfile(report,'Step21_EvidenceAccounting.csv'));
 U.Write(R.ClaimMatrix,fullfile(report,'Step21_ClaimMatrix.csv')); U.Write(R.PlosReadiness,fullfile(report,'Step21_PLOS_Readiness.csv'));
 U.Write(R.Descriptive,fullfile(report,'Step21_SourceData_Descriptive.csv')); U.Write(R.Strict,fullfile(report,'Step21_SourceData_Strict.csv')); U.Write(R.Operational,fullfile(report,'Step21_SourceData_OperationalSensitivity.csv'));
 Figures=RevisedCodes_21_Figures(R,report,C); U.Write(Figures,fullfile(report,'Step21_FigureManifest.csv'));
 Gate=["Successful Step20 archive verified";"Step20 cohort arithmetic independently reconciled";"Frozen 94-file verification inherited and checked"; ...
  "Case-level source data exported";"Uncertainty and influence diagnostics exported";"Comparator edition-specific claim authorized";"Independent validation claim authorized";"Fairness or superiority claim authorized"];
 Passed=[true;true;true;true;true;false;false;false]; Gates=table(Gate,Passed); U.Write(Gates,fullfile(report,'Step21_ExecutionGates.csv'));
 writeNarrative(fullfile(report,'Step21_RESULTS_INTERPRETATION.md'),R,D,C);
 InputArchive=table(D.ZipPath,D.ZipSHA256,'VariableNames',{'Step20ChecksZip','SHA256'}); U.Write(InputArchive,fullfile(report,'Step21_InputArchive.csv'));
 code=dir(fullfile(here,'*.m')); H=table; for k=1:numel(code), H=[H;table(string(code(k).name),U.Hash(fullfile(code(k).folder,code(k).name)),'VariableNames',{'File','SHA256'})]; end %#ok<AGROW>
 U.Write(H,fullfile(report,'Step21_CodeHashes.csv'));
 Results=struct('Status',"STEP21_COMPLETE_PUBLICATION_EVIDENCE",'Settings',C,'InputArchive',InputArchive,'AgreementSummary',R.Summary,'Gates',Gates,'ClaimBoundary',"HISTORICAL_TARGET_AGREEMENT_NOT_INDEPENDENT");
 save(fullfile(report,'RevisedCodes_Step21_Result.mat'),'Results'); disp(R.Summary); disp(R.Heterogeneity); disp(Gates);
 diary off; zip(report+"_Checks.zip",{'*'},report); fprintf('Upload %s\n',report+"_Checks.zip");
catch err
 diary off; writeFailure(fullfile(report,'Step21_FAILURE.txt'),err,C); zip(report+"_FAILED_Checks.zip",{'*'},report); fprintf('Upload %s\n',report+"_FAILED_Checks.zip"); rethrow(err);
end
end

function writeNarrative(path,R,D,C)
f=fopen(path,'wt'); assert(f>=0); c=onCleanup(@()fclose(f));
a=R.Summary(R.Summary.Cohort=="DESCRIPTIVE_ALL"&R.Summary.Format=="ALL",:); s=R.Summary(R.Summary.Cohort=="DESCRIPTIVE_STRICT"&R.Summary.Format=="ALL",:);
o=R.Summary(R.Summary.Cohort=="OPERATIONAL_SENSITIVITY"&R.Summary.Format=="ALL",:); h=R.Heterogeneity;
fprintf(f,'# Step 21 publication-evidence interpretation\n\n');
fprintf(f,'Step 21 consumed the successful Step 20 archive with SHA-256 `%s`. No model fitting, tuning, case deletion or comparator reconstruction occurred.\n\n',D.ZipSHA256);
fprintf(f,'## Main numerical findings\n\n');
fprintf(f,'- Descriptive cohort (n=%d): bias %.3f, MAE %.3f, RMSE %.3f runs.\n',a.N,a.Bias,a.MAE,a.RMSE);
fprintf(f,'- Strict final-state subset (n=%d): bias %.3f, MAE %.3f, RMSE %.3f runs.\n',s.N,s.Bias,s.MAE,s.RMSE);
fprintf(f,'- Operational subset (n=%d): bias %.3f, MAE %.3f, RMSE %.3f runs; every case is assumption-bound, so this is sensitivity analysis only.\n',o.N,o.Bias,o.MAE,o.RMSE);
fprintf(f,'- In strict cases, the ODI-minus-T20 bias contrast is %.3f runs (match-bootstrap 95%% CI %.3f to %.3f). This is exploratory heterogeneity, not a confirmatory interaction test.\n',h.Estimate,h.Lower95,h.Upper95);
fprintf(f,'\n## Interpretation boundary\n\nThese results measure agreement with recorded historical targets. They do not establish a specified professional DLS edition, independent validation, fairness, counterfactual match outcomes or population-wide superiority. Pearson correlation is supplied only as association; Bland-Altman limits, signed bias, absolute error and case-level differences are the agreement diagnostics. Threshold analyses are descriptive and are not equivalence tests.\n');
fprintf(f,'\n## Reproducibility\n\nBootstrap resampling uses whole matches, %d replicates and fixed seed %d. Full case data, outlier thresholds, leave-one-out influence, comparator provenance and plot source data are exported.\n',C.BootstrapReplicates,C.RandomSeed); clear c
end

function writeFailure(path,err,C)
f=fopen(path,'wt'); if f<0, return; end; c=onCleanup(@()fclose(f)); fprintf(f,'Message: %s\nIdentifier: %s\nProjectRoot: %s\n\nStack:\n',err.message,err.identifier,C.ProjectRoot);
for k=1:numel(err.stack), fprintf(f,'%s line %d\n',err.stack(k).name,err.stack(k).line); end; clear c
end
function safeRemove(p), if isfolder(p), rmdir(p,'s'); end, end

