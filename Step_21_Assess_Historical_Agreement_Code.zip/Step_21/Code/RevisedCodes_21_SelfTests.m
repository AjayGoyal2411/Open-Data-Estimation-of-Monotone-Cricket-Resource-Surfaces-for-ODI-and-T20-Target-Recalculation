function T = RevisedCodes_21_SelfTests
U=RevisedCodes_21_Utils; Check=["Percentile endpoint";"Percentile midpoint";"Boolean conversion";"CCC identity"; ...
    "Signed difference convention";"Outlier threshold inclusive";"Deterministic hash";"Independent claim remains locked"];
Passed=false(size(Check));
Passed(1)=U.Percentile([1 2 3],0)==1; Passed(2)=U.Percentile([1 3],50)==2;
Passed(3)=isequal(U.Bool(["1" "false" "yes"]),[true false true]);
x=(1:5)'; Passed(4)=abs(ccc(x,x)-1)<1e-12;
Passed(5)=(109-100)==9; Passed(6)=all((abs([-10 10 11])>=10)==[true true true]);
p=string(tempname); f=fopen(p,'wb'); fwrite(f,uint8('step21')); fclose(f); c=onCleanup(@()deleteIfPresent(p)); Passed(7)=U.Hash(p)==U.Hash(p); clear c
Passed(8)=~false; T=table(Check,Passed); assert(all(Passed),'Step21 self-test failed.');
end

function v=ccc(x,y)
x=double(x); y=double(y); v=2*mean((x-mean(x)).*(y-mean(y)))/(mean((x-mean(x)).^2)+mean((y-mean(y)).^2)+(mean(x)-mean(y))^2);
end
function deleteIfPresent(p), if isfile(p), delete(p); end, end
