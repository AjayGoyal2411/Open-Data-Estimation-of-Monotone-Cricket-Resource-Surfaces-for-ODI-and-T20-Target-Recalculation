function D = RevisedCodes_21_Load(C,U,work)
zipPath=C.Step20ChecksZip;
if zipPath==""
    root=fullfile(C.ProjectRoot,'paper_outputs_revisedcodes','step20_complete');
    z=dir(fullfile(root,'**','*_Checks.zip')); z=z(~contains(string({z.name}),'FAILED','IgnoreCase',true));
    assert(~isempty(z),'No successful Step20 *_Checks.zip found under %s.',root);
    [~,ord]=sort([z.datenum],'descend'); z=z(ord); zipPath=string(fullfile(z(1).folder,z(1).name));
end
assert(isfile(zipPath),'Step20ChecksZip not found: %s',zipPath); unzip(zipPath,work);
names=["Step20_Descriptive_CaseResults.csv","Step20_Operational_CaseResults.csv","Step20_PerformanceSummary.csv", ...
    "Step20_Bootstrap95CI.csv","Step20_CohortSummary.csv","Step20_ExecutionGates.csv","Step20_FrozenVerification.csv", ...
    "Step20_SelfTests.csv","Step20_FrozenSelfTests.csv","Step20_CodeHashes.csv"];
for n=names, p=U.FindUnique(work,n); D.(erase(n,["Step20_",".csv"]))=U.Read(p); end
D.ZipPath=zipPath; D.ZipSHA256=U.Hash(zipPath);
validate(D,U);
end

function validate(D,U)
req=["MatchID","Format","Method","EvidenceTier","DirectDevelopmentOverlap","IndependenceStatus","AllowedUse", ...
 "PublishedTargetRunsNumeric","ModelTargetRuns","SignedDifference","AbsoluteDifference","ExactAgreement","WithinFiveRuns", ...
 "WithinTenRuns","AllResourceStatesEmpiricallySupported","CalculationTier","AnalysisClaim"];
U.Require(D.Descriptive_CaseResults,req); U.Require(D.Operational_CaseResults,req);
A=D.Descriptive_CaseResults; O=D.Operational_CaseResults;
assert(height(A)==29&&height(O)==15,'Step20 cohort sizes changed.');
assert(numel(unique(A.MatchID))==29&&numel(unique(O.MatchID))==15,'Duplicate match IDs.');
assert(all(ismember(O.MatchID,A.MatchID)),'Operational cohort is not a descriptive subset.');
for X={A,O}
    X=X{1}; m=U.Num(X.ModelTargetRuns,'ModelTargetRuns'); p=U.Num(X.PublishedTargetRunsNumeric,'PublishedTargetRunsNumeric');
    e=U.Num(X.SignedDifference,'SignedDifference'); a=U.Num(X.AbsoluteDifference,'AbsoluteDifference');
    assert(all(e==m-p)&&all(a==abs(e)),'Step20 case arithmetic failed.');
    assert(all(U.Bool(X.ExactAgreement)==(a==0))&&all(U.Bool(X.WithinFiveRuns)==(a<=5))&&all(U.Bool(X.WithinTenRuns)==(a<=10)),'Step20 agreement flags failed.');
    assert(~any(contains(upper(X.IndependenceStatus),'INDEPENDENT') & ~contains(upper(X.IndependenceStatus),'NOT_')),'Independent status unexpectedly present.');
end
G=D.ExecutionGates; U.Require(G,["Gate","Passed"]); gp=U.Bool(G.Passed);
assert(height(G)==8&&all(gp(1:7))&&~gp(8),'Step20 gates do not match accepted state.');
F=D.FrozenVerification; U.Require(F,"Step20HashMatched"); assert(height(F)==94&&all(U.Bool(F.Step20HashMatched)),'Frozen 94-file verification failed.');
S=D.SelfTests; FS=D.FrozenSelfTests; assert(all(U.Bool(S.Passed))&&all(U.Bool(FS.Passed)),'Step20 tests not all passed.');
H=D.CodeHashes; U.Require(H,["File","SHA256"]); assert(height(H)==10&&numel(unique(H.File))==10&&all(strlength(H.SHA256)==64),'Step20 code manifest invalid.');
end

