function C = RevisedCodes_21_Config(settings)
if nargin < 1, settings=struct; end
assert(isstruct(settings)&&isscalar(settings),'settings must be a scalar struct.');
allowed=["ProjectRoot","Step20ChecksZip","BootstrapReplicates","RandomSeed","FigureVisible"];
assert(all(ismember(string(fieldnames(settings)),allowed)),'Unknown setting supplied.');
C.ProjectRoot="D:\VihaanProject1";
C.Step20ChecksZip="";
C.BootstrapReplicates=10000;
C.RandomSeed=20260921;
C.FigureVisible=false;
for n=reshape(string(fieldnames(settings)),1,[]), C.(n)=settings.(n); end
C.ProjectRoot=string(C.ProjectRoot); C.Step20ChecksZip=string(C.Step20ChecksZip);
assert(isfolder(C.ProjectRoot),'ProjectRoot not found: %s',C.ProjectRoot);
assert(isnumeric(C.BootstrapReplicates)&&isscalar(C.BootstrapReplicates)&&C.BootstrapReplicates>=1000&&fix(C.BootstrapReplicates)==C.BootstrapReplicates);
assert(isnumeric(C.RandomSeed)&&isscalar(C.RandomSeed)&&isfinite(C.RandomSeed));
assert(islogical(C.FigureVisible)&&isscalar(C.FigureVisible));
end

