function R = RevisedCodes_21_Analyse(D,C,U)
A=numericise(D.Descriptive_CaseResults,U); O=numericise(D.Operational_CaseResults,U);
S=A(A.CalculationTier=="STRICT_FINAL_STATE_RECONSTRUCTION",:);
cohorts={A,"DESCRIPTIVE_ALL";S,"DESCRIPTIVE_STRICT";O,"OPERATIONAL_SENSITIVITY"};
summary=cell(0,1); ci=cell(0,1);
for c=1:size(cohorts,1)
    X=cohorts{c,1}; label=cohorts{c,2};
    for f=["ALL","ODI","T20"]
        if f=="ALL", Y=X; else, Y=X(strcmpi(X.Format,f),:); end
        if ~isempty(Y), summary{end+1,1}=summarise(Y,label,f); ci{end+1,1}=bootstrap(Y,label,f,C,U); end %#ok<AGROW>
    end
end
R.Summary=vertcat(summary{:}); R.Bootstrap=vertcat(ci{:});
R.Heterogeneity=heterogeneity(S,C,U);
R.Influence=buildInfluence(cohorts);
R.Outliers=buildOutliers(cohorts);
R.OutlierSensitivity=outlierSensitivity(cohorts);
R.ComparatorProvenance=provenance(A,D.ZipSHA256);
R.EvidenceAccounting=evidenceAccounting(cohorts);
R.ClaimMatrix=claims(A,S,O);
R.PlosReadiness=readiness();
R.Descriptive=A; R.Strict=S; R.Operational=O;
end

function X=numericise(X,U)
vars=["PublishedTargetRunsNumeric","ModelTargetRuns","SignedDifference","AbsoluteDifference"];
for v=vars, X.(v)=U.Num(X.(v),v); end
X.DirectDevelopmentOverlap=U.Bool(X.DirectDevelopmentOverlap);
X.AllResourceStatesEmpiricallySupported=U.Bool(X.AllResourceStatesEmpiricallySupported);
end

function T=summarise(X,cohort,format)
x=X.PublishedTargetRunsNumeric; y=X.ModelTargetRuns; e=y-x; a=abs(e); n=numel(e);
r=NaN; if n>=3&&std(x)>0&&std(y)>0, q=corrcoef(x,y); r=q(1,2); end
cc=ccc(x,y); sd=std(e,0); loaLow=mean(e)-1.96*sd; loaHigh=mean(e)+1.96*sd;
T=table(string(cohort),string(format),n,mean(x),mean(y),mean(e),median(e),sd,mean(a),sqrt(mean(e.^2)),median(a), ...
    r,cc,loaLow,loaHigh,100*mean(a==0),100*mean(a<=1),100*mean(a<=2),100*mean(a<=5),100*mean(a<=10), ...
    100*mean(X.AllResourceStatesEmpiricallySupported),100*mean(X.CalculationTier~="STRICT_FINAL_STATE_RECONSTRUCTION"), ...
    'VariableNames',{'Cohort','Format','N','MeanPublishedTarget','MeanModelTarget','Bias','MedianBias','SDDifference','MAE','RMSE', ...
    'MedianAbsoluteError','PearsonR','LinCCC','BlandAltmanLower95','BlandAltmanUpper95','ExactPercent','WithinOnePercent','WithinTwoPercent', ...
    'WithinFivePercent','WithinTenPercent','AllStatesSupportedPercent','AssumptionBoundPercent'});
end

function T=bootstrap(X,cohort,format,C,U)
x=X.PublishedTargetRunsNumeric; y=X.ModelTargetRuns; e=y-x; n=numel(e); B=C.BootstrapReplicates;
stream=RandStream('mt19937ar','Seed',C.RandomSeed+sum(double(char(cohort+format)))); out=nan(B,5); chunk=1000;
for lo=1:chunk:B
    hi=min(B,lo+chunk-1); idx=randi(stream,n,n,hi-lo+1);
    for j=1:(hi-lo+1), z=e(idx(:,j)); xx=x(idx(:,j)); yy=y(idx(:,j)); out(lo+j-1,:)=[mean(z),mean(abs(z)),sqrt(mean(z.^2)),median(z),ccc(xx,yy)]; end
end
Metric=["Bias";"MAE";"RMSE";"MedianBias";"LinCCC"]; est=[mean(e);mean(abs(e));sqrt(mean(e.^2));median(e);ccc(x,y)];
low=nan(5,1); high=low; for k=1:5, v=out(:,k); if any(isfinite(v)), low(k)=U.Percentile(v,2.5); high(k)=U.Percentile(v,97.5); end, end
T=table(repmat(string(cohort),5,1),repmat(string(format),5,1),Metric,repmat(n,5,1),est,low,high,repmat(B,5,1), ...
 'VariableNames',{'Cohort','Format','Metric','N','Estimate','Lower95','Upper95','BootstrapReplicates'});
end

function T=heterogeneity(S,C,U)
o=S(strcmpi(S.Format,'ODI'),:); t=S(strcmpi(S.Format,'T20'),:); delta=mean(o.SignedDifference)-mean(t.SignedDifference); B=C.BootstrapReplicates;
stream=RandStream('mt19937ar','Seed',C.RandomSeed+771); z=zeros(B,1);
for b=1:B, z(b)=mean(o.SignedDifference(randi(stream,height(o),height(o),1)))-mean(t.SignedDifference(randi(stream,height(t),height(t),1))); end
T=table("DESCRIPTIVE_STRICT","Bias_ODI_minus_T20",height(o),height(t),delta,U.Percentile(z,2.5),U.Percentile(z,97.5),B, ...
 'VariableNames',{'Cohort','Contrast','N_ODI','N_T20','Estimate','Lower95','Upper95','BootstrapReplicates'});
end

function T=buildInfluence(cohorts)
rows=cell(0,1);
for c=1:size(cohorts,1)
 X=cohorts{c,1}; lab=cohorts{c,2}; e=X.SignedDifference; fb=mean(e); fm=mean(abs(e)); fr=sqrt(mean(e.^2));
 for i=1:height(X), keep=true(height(X),1); keep(i)=false; z=e(keep); rows{end+1,1}=table(string(lab),X.MatchID(i),X.Format(i),height(X),fb,fm,fr,mean(z),mean(abs(z)),sqrt(mean(z.^2)),mean(z)-fb,mean(abs(z))-fm, ...
  'VariableNames',{'Cohort','OmittedMatchID','Format','FullN','FullBias','FullMAE','FullRMSE','LeaveOneOutBias','LeaveOneOutMAE','LeaveOneOutRMSE','BiasChange','MAEChange'}); end %#ok<AGROW>
end
T=vertcat(rows{:}); T.Influential=abs(T.BiasChange)>=5|abs(T.MAEChange)>=3;
end

function T=buildOutliers(cohorts)
rows=cell(0,1);
for c=1:size(cohorts,1), X=cohorts{c,1}; j=X.AbsoluteDifference>10; Y=X(j,:); if ~isempty(Y)
 rows{end+1,1}=table(repmat(string(cohorts{c,2}),height(Y),1),Y.MatchID,Y.Format,Y.PublishedTargetRunsNumeric,Y.ModelTargetRuns,Y.SignedDifference,Y.AbsoluteDifference,Y.CalculationTier, ...
  Y.AbsoluteDifference>20,'VariableNames',{'Cohort','MatchID','Format','PublishedTarget','ModelTarget','SignedDifference','AbsoluteDifference','CalculationTier','AboveTwentyRuns'}); end, end
T=vertcat(rows{:});
end

function T=outlierSensitivity(cohorts)
rows=cell(0,1);
for c=1:size(cohorts,1), X=cohorts{c,1}; e=X.SignedDifference;
 for th=[Inf 20 10], keep=abs(e)<=th; if isinf(th), label="FULL"; else, label="ABS_DIFF_LE_"+string(th); end
  z=e(keep); rows{end+1,1}=table(string(cohorts{c,2}),label,numel(e),nnz(keep),mean(z),mean(abs(z)),sqrt(mean(z.^2)), ...
   'VariableNames',{'Cohort','Analysis','OriginalN','RetainedN','Bias','MAE','RMSE'}); end, end %#ok<AGROW>
T=vertcat(rows{:});
end

function T=provenance(A,zipHash)
n=height(A); ComparatorFamily=repmat("D_L_FAMILY_AS_RECORDED",n,1); ComparatorVersion=repmat("VERSION_NOT_IDENTIFIED_IN_SOURCE_RECORD",n,1);
BenchmarkNature=repmat("VERIFIED_PUBLISHED_OPERATIONAL_TARGET",n,1); EquationReproduced=false(n,1); ProfessionalAlgorithmAccess=false(n,1);
VersionSpecificComparisonAuthorized=false(n,1); Step20ArchiveSHA256=repmat(zipHash,n,1);
T=table(A.MatchID,A.Format,A.Method,ComparatorFamily,ComparatorVersion,BenchmarkNature,A.EvidenceTier,EquationReproduced,ProfessionalAlgorithmAccess,VersionSpecificComparisonAuthorized,Step20ArchiveSHA256, ...
 'VariableNames',{'MatchID','Format','MethodAsRecorded','ComparatorFamily','ComparatorVersion','BenchmarkNature','TargetEvidenceTier','EquationReproduced','ProfessionalAlgorithmAccess','VersionSpecificComparisonAuthorized','Step20ArchiveSHA256'});
end

function T=evidenceAccounting(cohorts)
rows=cell(0,1); for c=1:size(cohorts,1), X=cohorts{c,1}; rows{end+1}=table(string(cohorts{c,2}),height(X),nnz(X.CalculationTier=="STRICT_FINAL_STATE_RECONSTRUCTION"),nnz(X.CalculationTier~="STRICT_FINAL_STATE_RECONSTRUCTION"),nnz(X.AllResourceStatesEmpiricallySupported),nnz(X.DirectDevelopmentOverlap),0, ...
 'VariableNames',{'Cohort','N','StrictN','AssumptionBoundN','AllStatesSupportedN','DirectDevelopmentOverlapN','IndependentN'}); end; T=vertcat(rows{:});
end

function T=claims(A,S,O) %#ok<INUSD>
Claim=["Historical target agreement in the 29-case descriptive cohort";"Strict final-state historical agreement in 13 cases"; ...
 "T20 strict-case agreement is closer than ODI strict-case agreement in this sample";"Operational-subset comparison"; ...
 "Independent external validation";"Equivalence to a specified professional DLS edition";"Superior fairness";"Counterfactual outcome validity";"Population-wide superiority"];
Status=["SUPPORTED_DESCRIPTIVELY";"SUPPORTED_DESCRIPTIVELY";"SUPPORTED_AS_EXPLORATORY_HETEROGENEITY";"SENSITIVITY_ONLY"; ...
 "NOT_SUPPORTED";"NOT_SUPPORTED";"NOT_SUPPORTED";"NOT_SUPPORTED";"NOT_SUPPORTED"];
Reason=["Published targets and frozen-model targets are paired case by case";"Timeline-complete final-state subset is isolated";"Small subgroups and bootstrap uncertainty must be shown"; ...
 "All operational cases are assumption-bound";"Zero independent cases";"Recorded method is D/L family but edition and proprietary algorithm are unavailable"; ...
 "Target agreement is not fairness";"Observed winners do not identify uninterrupted counterfactuals";"Purposive small case series"];
T=table(Claim,Status,Reason);
end

function T=readiness
Criterion=["Original research contribution";"High technical standard";"Conclusions supported by data";"Statistical reproducibility";"Outlier reporting";"Data availability";"Code availability";"Independent validation claim"];
Status=["MANUSCRIPT_DEPENDENT";"PARTIALLY_READY";"READY_IF_CLAIMS_RESTRICTED";"READY_AFTER_PUBLIC_ARCHIVE";"READY";"ACTION_REQUIRED";"ACTION_REQUIRED";"PROHIBITED"];
Action=["Explain novelty beyond applying a target formula";"Report cohort construction, assumptions and small-n uncertainty";"Use agreement language only";"Archive case-level data and exact software/version details"; ...
 "Report full data and threshold sensitivity; do not delete cases";"Deposit minimal data and metadata with a persistent identifier";"Deposit documented code, tests and test data";"Use Step22 for untouched temporal predictive evaluation"];
T=table(Criterion,Status,Action);
end

function v=ccc(x,y)
x=double(x); y=double(y); if numel(x)<2, v=NaN; return; end
v=2*mean((x-mean(x)).*(y-mean(y)))/(mean((x-mean(x)).^2)+mean((y-mean(y)).^2)+(mean(x)-mean(y))^2);
end

