function U = RevisedCodes_21_Utils
U.Hash=@hashFile; U.Read=@readCSV; U.Write=@writeCSV; U.Require=@requireColumns;
U.Bool=@toLogical; U.Num=@toNumeric; U.Percentile=@percentile; U.FindUnique=@findUnique;
end

function T=readCSV(path)
assert(isfile(path),'Required file missing: %s',path);
f=fopen(path,'rt','n','UTF-8'); assert(f>=0); c=onCleanup(@()fclose(f)); h=fgetl(f); clear c
assert(ischar(h),'Empty CSV: %s',path); h=strrep(h,char(65279),''); names=strip(erase(split(string(h),','),'"'))';
o=delimitedTextImportOptions('NumVariables',numel(names)); o.Delimiter=','; o.DataLines=[2 Inf];
o.VariableNames=cellstr(names); o.VariableTypes=repmat({'string'},1,numel(names)); o.ExtraColumnsRule='error'; o.EmptyLineRule='skip';
T=readtable(path,o); assert(isequal(string(T.Properties.VariableNames),names),'Header changed: %s',path);
for k=1:width(T), n=T.Properties.VariableNames{k}; T.(n)=strtrim(string(T.(n))); T.(n)(ismissing(T.(n)))=""; end
end

function writeCSV(T,path), assert(istable(T)); writetable(T,path); end

function h=hashFile(path)
f=fopen(path,'rb'); assert(f>=0,'Cannot hash %s',path); c=onCleanup(@()fclose(f)); md=java.security.MessageDigest.getInstance('SHA-256');
while ~feof(f), b=fread(f,1048576,'*uint8'); md.update(typecast(b,'int8')); end
h=lower(string(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[]))); clear c
end

function requireColumns(T,names)
m=setdiff(string(names),string(T.Properties.VariableNames)); assert(isempty(m),'Missing columns: %s',strjoin(m,', '));
end

function x=toLogical(v)
if islogical(v), x=v; return; end
s=lower(strtrim(string(v))); assert(all(ismember(s,["0","1","false","true","yes","no"])),'Invalid logical value.'); x=ismember(s,["1","true","yes"]);
end

function x=toNumeric(v,label)
x=str2double(string(v)); assert(all(isfinite(x)),'Non-finite numeric value in %s.',label);
end

function q=percentile(x,p)
x=sort(double(x(isfinite(x)))); assert(~isempty(x));
if numel(x)==1, q=x; return; end
t=1+(numel(x)-1)*double(p)/100; lo=floor(t); hi=ceil(t); q=x(lo)+(t-lo)*(x(hi)-x(lo));
end

function path=findUnique(root,name)
d=dir(fullfile(root,'**',name)); assert(numel(d)==1,'Expected exactly one %s; found %d.',name,numel(d)); path=string(fullfile(d(1).folder,d(1).name));
end

