clearvars; clc;
thisFile = mfilename('fullpath');
addpath(fileparts(thisFile));
Results = RevisedCodes_21_RunAll(); %#ok<NASGU>

