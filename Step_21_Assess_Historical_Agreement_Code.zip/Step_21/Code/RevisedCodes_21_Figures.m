function Files = RevisedCodes_21_Figures(R,out,C)
vis='off'; if C.FigureVisible, vis='on'; end
name=strings(0,1); png=strings(0,1); pdf=strings(0,1);

f=figure('Visible',vis,'Color','w','Position',[80 80 1120 500]); t=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');
sets={R.Descriptive,'All descriptive cases';R.Strict,'Strict final-state cases'};
for k=1:2, X=sets{k,1}; nexttile; avg=(X.ModelTargetRuns+X.PublishedTargetRunsNumeric)/2; d=X.SignedDifference; scatter(avg,d,55,formatColour(X.Format),'filled'); hold on;
 m=mean(d); s=std(d); yline(m,'k-','Mean'); yline(m+1.96*s,'k--','+1.96 SD'); yline(m-1.96*s,'k--','-1.96 SD'); yline(0,':','Color',[.4 .4 .4]);
 grid on; xlabel('Mean of model and published target (runs)'); ylabel('Model - published (runs)'); title(sprintf('%s (n=%d)',sets{k,2},height(X))); end
title(t,'Bland-Altman target-agreement diagnostics'); [n,p,q]=saveFigure(f,out,'Step21_Figure1_BlandAltman'); name(end+1)=n; png(end+1)=p; pdf(end+1)=q; close(f);

f=figure('Visible',vis,'Color','w','Position',[80 80 780 520]); hold on; grid on;
sets={R.Descriptive,'Descriptive all';R.Strict,'Descriptive strict';R.Operational,'Operational sensitivity'}; styles={'-','-','--'};
for k=1:3, a=sort(sets{k,1}.AbsoluteDifference); stairs([0;a],[0;(1:numel(a))'/numel(a)],styles{k},'LineWidth',1.8); end
xlabel('Absolute target difference (runs)'); ylabel('Empirical cumulative proportion'); title('Absolute target-difference distributions'); legend(sets(:,2),'Location','southeast');
[n,p,q]=saveFigure(f,out,'Step21_Figure2_AbsoluteDifferenceECDF'); name(end+1)=n; png(end+1)=p; pdf(end+1)=q; close(f);

B=R.Bootstrap; B=B(ismember(B.Cohort,["DESCRIPTIVE_ALL","DESCRIPTIVE_STRICT"])&ismember(B.Metric,["Bias","MAE"]),:);
f=figure('Visible',vis,'Color','w','Position',[80 80 1020 620]); t=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');
for m=["Bias","MAE"], nexttile; X=B(B.Metric==m,:); y=(1:height(X))'; errorbar(X.Estimate,y,X.Estimate-X.Lower95,X.Upper95-X.Estimate,'horizontal','o','LineWidth',1.3,'MarkerFaceColor',[.2 .5 .75]); grid on;
 yticks(y); yticklabels(X.Cohort+" / "+X.Format); set(gca,'YDir','reverse'); xlabel(m+" (runs), bootstrap 95% CI"); if m=="Bias", xline(0,'k--'); end; title(m); end
title(t,'Agreement estimates and match-level bootstrap uncertainty'); [n,p,q]=saveFigure(f,out,'Step21_Figure3_AgreementForest'); name(end+1)=n; png(end+1)=p; pdf(end+1)=q; close(f);

X=R.Descriptive; [~,ord]=sort(X.AbsoluteDifference,'descend'); X=X(ord,:);
f=figure('Visible',vis,'Color','w','Position',[80 80 1120 540]); b=bar(X.SignedDifference,'FaceColor','flat'); b.CData=formatColour(X.Format); hold on; yline(0,'k-'); yline(10,'k:'); yline(-10,'k:'); grid on;
xticks(1:height(X)); xticklabels(X.MatchID); xtickangle(60); xlabel('Match ID, ordered by absolute difference'); ylabel('Model - published target (runs)'); title('Case-level differences; dotted lines mark |difference| = 10 runs');
[n,p,q]=saveFigure(f,out,'Step21_Figure4_CaseInfluence'); name(end+1)=n; png(end+1)=p; pdf(end+1)=q; close(f);
Files=table(name,png,pdf,'VariableNames',{'Figure','PNG','PDF'});
end

function c=formatColour(fmt)
c=repmat([0.20 0.48 0.72],numel(fmt),1); j=strcmpi(fmt,'T20'); c(j,:)=repmat([0.90 0.42 0.16],nnz(j),1);
end
function [n,png,pdf]=saveFigure(f,out,name)
n=string(name); png=string(fullfile(out,char(n+".png"))); pdf=string(fullfile(out,char(n+".pdf")));
exportgraphics(f,char(png),'Resolution',600); exportgraphics(f,char(pdf),'ContentType','vector');
end
