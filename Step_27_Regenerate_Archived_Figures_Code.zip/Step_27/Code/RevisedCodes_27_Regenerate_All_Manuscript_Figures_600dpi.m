function M = RevisedCodes_27_Regenerate_All_Manuscript_Figures_600dpi(root,out)
% Regenerates all figures in ManuscriptmainFigures.docx,
% Supplementary_Methodology_Figures.docx, and
% Supplementary_Results_Figures.docx.
% Final Word figures came from CSV/XLSX evidence, not MAT files.
% All visible text is Times New Roman, 12 pt; PNG output is 600 dpi.
if nargin<1||strlength(string(root))==0, root='D:\VihaanProject1'; end
if nargin<2||strlength(string(out))==0
    out=fullfile(root,'paper_outputs_revisedcodes','step27_figures_600dpi');
end
assert(isfolder(root),'Project root not found: %s',root); mk(out);
mo=fullfile(out,'MainPaper'); sm=fullfile(out,'Supplementary_Methodology');
sr=fullfile(out,'Supplementary_Results'); mk(mo);mk(sm);mk(sr);
set(groot,'defaultAxesFontName','Times New Roman','defaultTextFontName','Times New Roman', ...
 'defaultLegendFontName','Times New Roman','defaultColorbarFontName','Times New Roman', ...
 'defaultAxesFontSize',12,'defaultTextFontSize',12,'defaultLegendFontSize',12, ...
 'defaultAxesColorOrder',palette(7),'defaultLineLineWidth',1.6);
mb=one(root,'Step25_MainPaperTables.xlsx'); sb=one(root,'Step25_SupplementaryTables.xlsx');
R={}; R(end+1,:)=fig2(mb,mo); R(end+1,:)=fig4(root,mb,mo); R(end+1,:)=fig5(mb,sb,mo);
R(end+1,:)=fig6(mb,mo); R(end+1,:)=figS2(sb,sm); R(end+1,:)=figS1(root,mb,sr);
R(end+1,:)=figS3(sb,sr); R(end+1,:)=figS4(sb,sr); R(end+1,:)=figS5(sb,sr);
M=cell2table(R,'VariableNames',{'Document','Figure','OriginalCode','DataSource','OriginalFile','PNG600dpi','PDFVector'});
writetable(M,fullfile(out,'Step27_Figure_Source_Map.xlsx')); writetable(M,fullfile(out,'Step27_Figure_Source_Map.csv'));
fprintf('Created %d figures in %s\n',height(M),out);
end

function r=fig2(book,out)
T=readtable(book,'Sheet','DatasetFlow'); F=["ODI","T20"]; Y=zeros(2,3);
for i=1:2,Y(i,1)=getn(T,F(i),"train");Y(i,2)=getn(T,F(i),"validation");Y(i,3)=getn(T,F(i),"test");end
f=nf([1500 560]);t=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');
ax=nexttile(t);v=[12545 3073 888 4160];b=bar(ax,v,'FaceColor','flat','EdgeColor',[.15 .15 .15],'LineWidth',1.3);b.CData=[.30 .47 .66;.45 .72 .70;.72 .72 .72;.82 .82 .82];
ax.XTick=1:4;ax.XTickLabel={'T20 retained','ODI retained','Test excluded','Other excluded'};ax.XTickLabelRotation=23;ylabel(ax,'Records');title(ax,'A  Format screening pool');grid(ax,'on');
for i=1:4,text(ax,i,v(i)+250,sprintf('%,d',v(i)),'HorizontalAlignment','center');end
ax=nexttile(t);b=barh(ax,Y,'stacked');setBarColors(b,[.30 .47 .66;.95 .81 .36;.89 .34 .34]);
ax.YTick=1:2;ax.YTickLabel=F;xlabel(ax,'Primary-cohort matches');title(ax,'B  Final primary cohorts and split');legend(ax,{'Training','Validation','Temporal test'},'Location','southeast');grid(ax,'on');
for i=1:2,c=0;for j=1:3,val=Y(i,j);if val>=500,text(ax,c+val/2,i,sprintf('%,d',val),'HorizontalAlignment','center','FontWeight','bold','Color',tern(j==1,'w','k'));else,text(ax,sum(Y(i,:))+120,i+.13*(j-2),sprintf('%s %,d',tern(j==2,'Validation','Temporal test'),val),'HorizontalAlignment','left');end;c=c+val;end,end
superTitle(t,'Screening and analytical allocation');[p,q]=ex(f,out,'Figure2_Screening_and_Analytical_Allocation');close(f);
r={"ManuscriptmainFigures.docx","Figure 2","build_final_methodology.py",book+" [DatasetFlow] + screening constants","methodology_figures/Figure2_Cohorts.png",p,q};
end

function r=fig4(root,book,out)
P=readtable(book,'Sheet','CompactParameters'); gp=opt(root,'19_02_ResourceGrid.csv');
if strlength(gp)>0,Gall=readtable(gp,'VariableNamingRule','preserve');else,Gall=table;end
assert(~isempty(Gall),'Reference Figure 4 requires 19_02_ResourceGrid.csv.');
gfv=pv(Gall,{'Format','MatchFormat'});gbv=pv(Gall,{'BallsRemaining','Balls','u'});gwv=pv(Gall,{'WicketsInHand','Wickets','w'});
grv=pv(Gall,{'BernsteinResource','FlexibleResource','ReferenceResource','MonotoneResource','BernsteinEstimate','FlexibleEstimate','ReferenceEstimate','Bernstein','Flexible'});
gmv=pv(Gall,{'Model','ModelType','Surface','Estimator','Role'});gvv=pv(Gall,{'NormalisedResource','NormalizedResource','ResourceValue','Resource','Capacity','Estimate','Prediction','Value'});
wideGrid=strlength(grv)>0&&isnumeric(Gall.(grv));longGrid=all(strlength([gmv gvv])>0)&&isnumeric(Gall.(gvv));
assert(all(strlength([gfv gbv gwv])>0)&&(wideGrid||longGrid), ...
 '19_02_ResourceGrid.csv must contain format, balls, wickets, and either a flexible/Bernstein column or a model-type plus resource-value pair.');
f=nf([1900 1200]);t=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');F=["ODI","T20"];pc=palette(7);
for k=1:2
 q=P(string(P.Format)==F(k),:);B=300;if F(k)=="T20",B=120;end;u=0:B;ax=nexttile(t);hold(ax,'on');
 wi=[3 5 7 10];mk={'o','s','^','d'};
 for j=1:numel(wi),w=wi(j);plot(ax,u,compact(u,w,B,q),'Color',pc(j,:),'LineStyle','-','Marker',mk{j},'MarkerIndices',1:max(1,round(B/5)):numel(u),'MarkerSize',4.5,'LineWidth',1.8,'DisplayName',sprintf('Compact, w=%d',w));end
 if ~isempty(Gall)
  fv=gfv;bv=gbv;wv=gwv;
  for j=1:numel(wi)
   z=Gall(string(Gall.(fv))==F(k)&double(Gall.(wv))==wi(j),:);
   if longGrid,m=lower(string(z.(gmv)));z=z(contains(m,'flex')|contains(m,'bernstein')|contains(m,'reference')|contains(m,'monotone'),:);rv=gvv;else,rv=grv;end
   z=sortrows(z,bv);assert(~isempty(z),'Missing %s flexible/Bernstein resource curve for w=%d.',char(F(k)),wi(j));
   plot(ax,double(z.(bv)),double(z.(rv)),'Color',pc(j,:),'LineStyle','--','Marker',mk{j},'MarkerIndices',1:max(1,round(height(z)/5)):height(z),'MarkerSize',4.5,'LineWidth',1.6,'DisplayName',sprintf('Flexible, w=%d',wi(j)));
  end
 end
 xlabel(ax,'Balls remaining');ylabel(ax,'Normalised resource');ylim(ax,[0 1.03]);title(ax,char(64+k)+"  "+F(k)+" frozen resource curves");legend(ax,'Location','eastoutside','NumColumns',1);grid(ax,'on');
end
for k=1:2
 ax=nexttile(t);ok=false;
 if strlength(gp)>0
  G=Gall;fv=pv(G,{'Format'});bv=pv(G,{'BallsRemaining','Balls','u'});wv=pv(G,{'WicketsInHand','Wickets','w'});sv=pv(G,{'Supported','Support','MatchCount','Matches','Count'});
  if all(strlength([fv bv wv sv])>0)
   G=G(string(G.(fv))==F(k),:);bb=double(G.(bv));ww=double(G.(wv));ss=double(G.(sv));if contains(lower(sv),'count')||contains(lower(sv),'match'),ss=ss>=30;else,ss=ss>0;end
   bu=unique(bb);wu=unique(ww);A=nan(numel(wu),numel(bu));for i=1:height(G),A(wu==ww(i),bu==bb(i))=ss(i);end
   imagesc(ax,bu,wu,A);axis(ax,'xy');colormap(ax,[.18 .15 .48;.95 .91 .15]);caxis(ax,[0 1]);xlabel(ax,'Balls remaining');ylabel(ax,'Wickets in hand');cb=colorbar(ax,'Ticks',[0 1],'TickLabels',{'Unsupported','Supported'});cb.FontSize=12;ok=true;
  end
 end
 if ~ok,off(ax,'19_02_ResourceGrid.csv or required columns unavailable');end
 title(ax,char(66+k)+"  "+F(k)+" supported-state mask");
end
superTitle(t,'Frozen format-specific resource functions and development support');[p,q]=ex(f,out,'Figure4_Frozen_Resource_and_Support');close(f);
r={"ManuscriptmainFigures.docx","Figure 4","RevisedCodes_25_Figures.m plus build_final_results.py",book+" [CompactParameters]; "+gp,"results_figures/Figure4_FrozenResourceAndSupport.png",p,q};
end

function r=fig5(mb,sb,out)
P=readtable(mb,'Sheet','FrozenPerformance');C=readtable(mb,'Sheet','PairedComparisons');S=readtable(sb,'Sheet','Subgroups');
f=nf([1600 1120]);t=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');F=["ODI","T20"];roles=["PrimaryResource","PrimaryForecast","FlexibleComparator","LiveScoreComparator"];labs=["Resource","Forecast","Flexible","Recent-score"];
errStyles={'o','s','^','d'};
for k=1:2
 ax=nexttile(t);hold(ax,'on');Q=C(string(C.Format)==F(k)&string(C.Comparator)=="Baseline",:);yy=4:-1:1;
 for j=1:4,z=Q(string(Q.Role)==roles(j),:);if ~isempty(z),errorbar(ax,z.RMSEGain,yy(j),z.RMSEGain-z.GainLower95,z.GainUpper95-z.RMSEGain,'horizontal',errStyles{j},'Color',palette(7,j),'MarkerFaceColor','w','LineWidth',1.7,'HandleVisibility','off');end,end
	 % MATLAB requires tick values to be strictly increasing.  The estimates
	 % are intentionally drawn at 4:-1:1 so that Resource appears at the top;
	 % assign increasing ticks and reverse only the corresponding labels.
	 xline(ax,0,'k-','HandleVisibility','off');ax.YTick=1:4;ax.YTickLabel=fliplr(labs);xlabel(ax,'RMSE reduction versus linear-balls baseline (runs)');title(ax,char(64+k)+"  "+F(k)+" paired temporal-test gain");grid(ax,'on');
end
ax=nexttile(t);hold(ax,'on');calMk={'o','s','^','d'};calC=palette(7);kk=0;for k=1:2,for j=1:2,kk=kk+1;z=P(string(P.Format)==F(k)&string(P.Role)==roles(j),:);scatter(ax,z.CalibrationIntercept,z.CalibrationSlope,72,calMk{kk},'MarkerEdgeColor',calC(kk,:),'MarkerFaceColor','w','LineWidth',1.6,'DisplayName',F(k)+" "+labs(j));end,end
xline(ax,0,'k--','HandleVisibility','off');yline(ax,1,'k--','HandleVisibility','off');xlabel(ax,'Calibration intercept (runs)');ylabel(ax,'Calibration slope');title(ax,'C  Calibration of frozen predictions');legend(ax,'Location','best');grid(ax,'on');
ax=nexttile(t);ph=["EARLY","MIDDLE","LATE"];Y=nan(3,4);ser={"ODI","Baseline";"ODI","PrimaryResource";"T20","Baseline";"T20","PrimaryResource"};
for j=1:4,for i=1:3,z=S(string(S.Format)==ser{j,1}&string(S.Role)==ser{j,2}&string(S.GroupType)=="Phase"&string(S.Group)==ph(i),:);if ~isempty(z),Y(i,j)=z.EqualInningsRMSE(1);end,end,end
b=bar(ax,Y,'grouped');setBarColors(b,[.62 .75 .86;.18 .45 .70;.96 .70 .42;.90 .38 .08]);ax.XTick=1:3;ax.XTickLabel={'Early','Middle','Late'};ylabel(ax,'Equal-innings RMSE (runs)');title(ax,'D  Error by innings phase');legend(ax,{'ODI baseline','ODI resource','T20 baseline','T20 resource'},'Location','northeast');grid(ax,'on');
superTitle(t,'Locked temporal-test performance');[p,q]=ex(f,out,'Figure5_Locked_Temporal_Test_Performance');close(f);
r={"ManuscriptmainFigures.docx","Figure 5","build_final_results.py",mb+" [FrozenPerformance, PairedComparisons]; "+sb+" [Subgroups]","results_figures/Figure5_TemporalPerformance.png",p,q};
end

function r=fig6(book,out)
T=readtable(book,'Sheet','CaseStudies');ord=["LARGEST_PRIMARY_RESOURCE_IMPROVEMENT","NEAREST_MEDIAN_PRIMARY_RESOURCE_GAIN","LARGEST_PRIMARY_RESOURCE_DETERIORATION"];lab={'Largest improvement','Nearest median','Largest deterioration'};F=["ODI","T20"];
f=nf([1500 590]);t=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');
for k=1:2,Q=T(string(T.Format)==F(k),:);v=nan(3,1);for i=1:3,z=Q(string(Q.SelectionRule)==ord(i),:);v(i)=z.RMSEGain(1);end
 ax=nexttile(t);b=bar(ax,v,'FaceColor','none','EdgeColor','flat','LineWidth',1.8);b.CData=[.22 .56 .34;.22 .56 .34;.78 .25 .25];for i=1:3,text(ax,i,v(i)+sign(v(i))*1.2,sprintf('%+.2f',v(i)),'HorizontalAlignment','center','VerticalAlignment',tern(v(i)>=0,'bottom','top'),'FontWeight','bold');end
 yline(ax,0);ax.XTick=1:3;ax.XTickLabel=lab;ax.XTickLabelRotation=18;title(ax,char(64+k)+"  "+F(k)+" rule-selected cases");grid(ax,'on');end
ylabel(t,'Case-level RMSE gain (runs)');superTitle(t,'Rule-selected real-match examples from the frozen temporal test');[p,q]=ex(f,out,'Figure6_Rule_Selected_Match_Heterogeneity');close(f);
r={"ManuscriptmainFigures.docx","Figure 6","build_final_results.py",book+" [CaseStudies]","results_figures/Figure6_RealMatchCases.png",p,q};
end

function r=figS2(book,out)
S=readtable(book,'Sheet','Subgroups');C=readtable(book,'Sheet','ContextAblations');f=nf([1650 1280]);t=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');
ax=nexttile(t);Q=S(string(S.Format)=="T20"&contains(string(S.GroupType),"FullWicket",'IgnoreCase',true),:);fullRoles=["Baseline","PrimaryResource","FlexibleComparator"];fullGroups=["EARLY","MIDDLE","LATE"];Y=nan(3,3);for j=1:3,for i=1:3,z=Q(string(Q.Role)==fullRoles(j)&upper(string(Q.Group))==fullGroups(i),:);if ~isempty(z),Y(i,j)=z.EqualInningsRMSE(1);end,end,end;if all(isnan(Y),'all'),off(ax,'Exact full-wicket role-by-phase evidence unavailable');else,b=bar(ax,Y,'grouped');setBarColors(b,[.18 .45 .70;.90 .38 .08;.93 .69 .13]);ax.XTick=1:3;ax.XTickLabel={'Early','Middle','Late'};ylabel(ax,'Equal-innings RMSE (runs)');legend(ax,{'Baseline','Primary resource','Flexible comparator'},'Location','best');grid(ax,'on');end;title(ax,'A  Full-wicket T20 sensitivity');
ax=nexttile(t);Q=S(string(S.Role)=="PrimaryResource"&ismember(string(S.GroupType),["Phase","WicketsInHand"])&logical(S.SufficientGroup),:);phaseWicketPanel(ax,Q);title(ax,'B  Phase and wicket-state performance');
ax=nexttile(t,[1 2]);Q=C(contains(string(C.Candidate),'lambda0.0001'),:);hold(ax,'on');stages=["Core","Partnership","ScoreRecentRate","TeamOpponentHistory","VenueEvent"];
fm=["ODI","T20"];cc=[.18 .45 .70;.90 .38 .08];for ii=1:2,z=Q(string(Q.Format)==fm(ii),:);yv=nan(1,numel(stages));lo=yv;hi=yv;for jj=1:numel(stages),zz=z(contains(string(z.Candidate),stages(jj)),:);if ~isempty(zz),yv(jj)=zz.RMSEGain(1);lo(jj)=zz.GainLower95(1);hi(jj)=zz.GainUpper95(1);end,end;errorbar(ax,1:numel(stages),yv,yv-lo,hi-yv,tern(ii==1,'o-','s--'),'Color',cc(ii,:),'MarkerFaceColor','w','LineWidth',1.8,'DisplayName',fm(ii));end;yline(ax,0,'k-','HandleVisibility','off');ax.XTick=1:numel(stages);ax.XTickLabel={'Core','Partnership','Recent score','Team/opponent','Venue/event'};ax.XTickLabelRotation=20;xlabel(ax,'Adjacent context addition');ylabel(ax,'Incremental RMSE reduction (runs)');legend(ax,'Location','best');grid(ax,'on');title(ax,'C  Context interpretation');
superTitle(t,'Diagnostics for critical modelling assumptions');[p,q]=ex(f,out,'Supplementary_Figure_S2_Critical_Modelling_Assumptions');close(f);
r={"Supplementary_Methodology_Figures.docx","Figure S2","RevisedCodes_25_Figures.m makeComposite",book+" [Subgroups, ContextAblations]","step25.../S25_Figure2_CriticalAssumptions.png",p,q};
end

function r=figS1(root,book,out)
src=one(root,'Step20_Descriptive_CaseResults.csv');T=readtable(src,'VariableNamingRule','preserve');
mid=pv(T,{'MatchID','CaseID'});fmt=pv(T,{'Format'});pub=pv(T,{'PublishedTarget','PublishedTargetRuns','Published'});mdl=pv(T,{'FrozenModelTarget','ModelTarget','PredictedTarget','RecalculatedTarget'});
assert(all(strlength([mid fmt pub mdl])>0),'Step20 case table lacks MatchID, Format, published-target, or model-target columns required by reference Figure S1.');
x=double(T.(pub));y=double(T.(mdl));d=y-x;ids=string(T.(mid));fm=string(T.(fmt));
[keep,hasOp]=operationalMask(T);f=nf([1900 1250]);if hasOp,t=tiledlayout(f,2,3,'Padding','compact','TileSpacing','compact');else,t=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');end
ax=nexttile(t);caseScatter(ax,x,y,fm);title(ax,sprintf('A%s  Descriptive cohort (n=%d)',tern(hasOp,'1',''),height(T)));
if hasOp,ax=nexttile(t);caseScatter(ax,x(keep),y(keep),fm(keep));title(ax,sprintf('A2  Operational subset (n=%d)',sum(keep)));end
ax=nexttile(t);[ds,ix]=sort(d);caseBars(ax,ds,fm(ix));sparseTicks(ax,ids(ix),6);yline(ax,0,'k-','HandleVisibility','off');ylabel(ax,'Model target - published target (runs)');title(ax,'B  Ordered case differences');grid(ax,'on');
if hasOp,ax=nexttile(t,[1 3]);else,ax=nexttile(t,[1 2]);end;[~,ix]=sort(abs(d),'descend');di=d(ix);caseBars(ax,di,fm(ix));sparseTicks(ax,ids(ix),9);yline(ax,0,'k-','HandleVisibility','off');yline(ax,[-10 10],'k:','HandleVisibility','off');xlabel(ax,'Match ID ordered by absolute difference');ylabel(ax,'Model target - published target (runs)');title(ax,'C  Case influence and failure visibility');grid(ax,'on');
superTitle(t,'Frozen case and influence diagnostics');[p,q]=ex(f,out,'Supplementary_Figure_S1_Case_and_Influence_Diagnostics');close(f);
r={"Supplementary_Results_Figures.docx","Figure S1","Step20 case-evidence regeneration",src,"step25.../S25_Figure1_CaseDiagnostics.png",p,q};
end

function r=figS3(book,out)
A=readtable(book,'Sheet','GenderSummary');B=readtable(book,'Sheet','GenderEquivalence');D=readtable(book,'Sheet','GenderPoolingGate');f=nf([1650 1060]);t=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');gb(nexttile(t),A,'mean_FinalRuns','Mean final runs');gb(nexttile(t),A,'mean_RunsPerLegalBall','Runs per legal ball');
ax=nexttile(t);e=B.AdjustedWomenMinusMen;l=B.Lower95;u=B.Upper95;errorbar(ax,1:height(B),e,e-l,u-e,'o','Color',[.18 .45 .70],'MarkerFaceColor','w','LineWidth',1.7);yline(ax,0,'k--','HandleVisibility','off');ax.XTick=1:height(B);ax.XTickLabel=string(B.Format)+" "+string(B.Metric);ax.XTickLabelRotation=20;ylabel(ax,'Adjusted women-minus-men difference');title(ax,'C  Adjusted women-minus-men differences');grid(ax,'on');
ax=nexttile(t);gate=[double(D.OutcomeEquivalence) double(D.SurfaceWithinMargin) double(D.PoolingSupported)];imagesc(ax,gate,[0 1]);colormap(ax,[.80 .25 .25;.28 .62 .38]);ax.XTick=1:3;ax.XTickLabel={'Outcome equivalence','Surface within margin','Pooling supported'};ax.XTickLabelRotation=18;ax.YTick=1:height(D);ax.YTickLabel=string(D.Format);for rr=1:size(gate,1),for cc=1:3,text(ax,cc,rr,tern(gate(rr,cc)>0.5,'Yes','No'),'HorizontalAlignment','center','Color','w','FontWeight','bold');end,end;title(ax,'D  Prespecified pooling gate');
superTitle(t,'Gender-specific evidence and pooling decision');[p,q]=ex(f,out,'Supplementary_Figure_S3_Gender_Evidence');close(f);
r={"Supplementary_Results_Figures.docx","Figure S3","RevisedCodes_25_Figures.m saveGenderEvidence",book+" [GenderSummary, GenderEquivalence, GenderSurfaces, GenderPoolingGate]","step25.../S25_Figure3_GenderEvidence.png",p,q};
end

function r=figS4(book,out)
T=readtable(book,'Sheet','Subgroups');T=T(logical(T.SufficientGroup),:);if any(string(T.Role)=="PrimaryForecast"),T=T(string(T.Role)=="PrimaryForecast",:);else,T=T(string(T.Role)=="PrimaryResource",:);end;P={"ODI","Phase";"T20","Phase";"ODI","Year";"T20","Year"};
f=nf([1650 1100]);t=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');pc=palette(7);for i=1:4,ax=nexttile(t);Q=T(string(T.Format)==P{i,1}&string(T.GroupType)==P{i,2},:);if isempty(Q),off(ax,'No sufficient group');else,b=bar(ax,Q.EqualInningsRMSE,'FaceColor',pc(i,:),'EdgeColor',[.15 .15 .15],'LineWidth',1.4);ax.XTick=1:height(Q);ax.XTickLabel=clean(Q.Group);ax.XTickLabelRotation=18;ylabel(ax,'Equal-innings RMSE');grid(ax,'on');end;title(ax,char(64+i)+"  "+P{i,1}+" by "+lower(P{i,2}));end
superTitle(t,'Frozen-model performance across innings phase and test year');[p,q]=ex(f,out,'Supplementary_Figure_S4_Subgroup_Performance');close(f);r={"Supplementary_Results_Figures.docx","Figure S4","RevisedCodes_25_Figures.m saveSubgroups",book+" [Subgroups]","step25.../S25_Figure4_SubgroupPerformance.png",p,q};
end

function r=figS5(book,out)
T=readtable(book,'Sheet','Subgroups');T=T(logical(T.SufficientGroup),:);if any(string(T.Role)=="PrimaryForecast"),T=T(string(T.Role)=="PrimaryForecast",:);else,T=T(string(T.Role)=="PrimaryResource",:);end;F=["ODI","T20"];
f=nf([1950 1400]);t=tiledlayout(f,2,2,'Padding','loose','TileSpacing','compact');pc=[.18 .45 .70;.90 .38 .08];for k=1:2,ax=nexttile(t);Q=T(string(T.Format)==F(k)&string(T.GroupType)=="EventNameAsRecorded",:);Q=sortrows(Q,'Matches','descend');Q=flipud(Q(1:min(10,height(Q)),:));if isempty(Q),off(ax,'No sufficient event group');else,b=barh(ax,Q.EqualInningsRMSE,'FaceColor',pc(k,:),'EdgeColor',[.15 .15 .15],'LineWidth',1.3);ax.YTick=1:height(Q);ax.YTickLabel=string(Q.Group);xlabel(ax,'Equal-innings RMSE');grid(ax,'on');end;title(ax,F(k)+" recorded events with greatest support");ax=nexttile(t);Q=T(string(T.Format)==F(k)&string(T.GroupType)=="Year",:);b=bar(ax,Q.EqualInningsRMSE,'FaceColor',pc(k,:),'EdgeColor',[.15 .15 .15],'LineWidth',1.3);ax.XTick=1:height(Q);ax.XTickLabel=string(Q.Group);ylabel(ax,'Equal-innings RMSE');title(ax,F(k)+" temporal test year");grid(ax,'on');end
superTitle(t,'Recorded-event and temporal diagnostics for the frozen model');[p,q]=ex(f,out,'Supplementary_Figure_S5_Recorded_Event_and_Temporal_Diagnostics');close(f);r={"Supplementary_Results_Figures.docx","Figure S5","RevisedCodes_25_Figures.m saveCompetitionEra",book+" [Subgroups]","step25.../S25_Figure5_CompetitionAndEra.png",p,q};
end

function n=getn(T,f,s),n=T.GroupCount(string(T.Format)==f&string(T.Split)==s);end
function R=compact(u,w,B,q),v=w/10;sg=@(x)1./(1+exp(-x));Z=(sg(q.a+q.b*v+q.c*v^2)-sg(q.a))/(sg(q.a+q.b+q.c)-sg(q.a));k=exp(q.d+q.e*v+q.f*v^2);x=u/B;R=Z*(1-exp(-k*x))/(1-exp(-k));end
function f=nf(z),f=figure('Visible','off','Color','w','Position',[100 100 z]);end
function superTitle(t,s),title(t,s,'FontName','Times New Roman','FontSize',12,'FontWeight','bold');end
function [p,q]=ex(f,o,n)
set(findall(f,'-property','FontName'),'FontName','Times New Roman');set(findall(f,'-property','FontSize'),'FontSize',12);
axs=findall(f,'Type','axes');set(axs,'LineWidth',1,'TickDir','out','Box','off');for i=1:numel(axs),axs(i).Title.FontName='Times New Roman';axs(i).Title.FontSize=12;axs(i).Title.FontWeight='bold';end
% Export through MATLAB's short local temporary path.  On Windows the PNG
% library can fail to open a long/synchronised destination path even when
% MATLAB itself can create the directory.  Staging also prevents a failed
% render from leaving a truncated manuscript figure in the output folder.
mk(o);drawnow;
p=string(fullfile(o,[n '.png']));q=string(fullfile(o,[n '.pdf']));
tp=[tempname '.png'];tq=[tempname '.pdf'];
try
 exportgraphics(f,tp,'Resolution',600,'BackgroundColor','white');
 [ok,msg]=copyfile(tp,char(p),'f');assert(ok,'Could not copy PNG to %s: %s',char(p),msg);
 exportgraphics(f,tq,'ContentType','vector','BackgroundColor','white');
 [ok,msg]=copyfile(tq,char(q),'f');assert(ok,'Could not copy PDF to %s: %s',char(q),msg);
catch ME
 if isfile(tp),delete(tp);end;if isfile(tq),delete(tq);end
 rethrow(ME)
end
if isfile(tp),delete(tp);end;if isfile(tq),delete(tq);end
end
function mk(p),if ~isfolder(p),mkdir(p);end,end
function p=one(r,n),p=opt(r,n);assert(strlength(p)>0,'Missing %s',n);end
function p=opt(r,n),d=dir(fullfile(r,'**',n));if isempty(d),p="";else,[~,i]=max([d.datenum]);p=string(fullfile(d(i).folder,d(i).name));end,end
function v=pv(T,c),v="";a=string(T.Properties.VariableNames);for x=string(c),i=find(strcmpi(a,x),1);if ~isempty(i),v=a(i);return,end,end;for x=string(c),i=find(contains(lower(a),lower(x)),1);if ~isempty(i),v=a(i);return,end,end;end
function off(ax,s),axis(ax,'off');text(ax,.5,.5,s,'HorizontalAlignment','center','FontAngle','italic');end
function y=clean(x),y=lower(replace(string(x),'_',' '));end
function grp(ax,Q),if isempty(Q),off(ax,'No subgroup data');return,end;F=unique(string(Q.Format),'stable');G=unique(string(Q.Group),'stable');Y=nan(numel(G),numel(F));for i=1:numel(G),for j=1:numel(F),z=Q(string(Q.Group)==G(i)&string(Q.Format)==F(j),:);if ~isempty(z),Y(i,j)=z.EqualInningsRMSE(1);end,end,end;b=bar(ax,Y,'grouped');setBarColors(b,[.18 .45 .70;.90 .38 .08]);ax.XTick=1:numel(G);ax.XTickLabel=clean(G);legend(ax,F,'Location','best');ylabel(ax,'Equal-innings RMSE');grid(ax,'on');end
function phaseWicketPanel(ax,Q)
if isempty(Q),off(ax,'No phase or wicket-state data');return,end
F=["ODI","T20"];types=["Phase","WicketsInHand"];G=strings(0);Y=zeros(0,2);
for tt=1:2
 u=unique(string(Q.Group(string(Q.GroupType)==types(tt))),'stable');
 for ii=1:numel(u),G(end+1)=tern(tt==1,"Phase: "+clean(u(ii)),"Wickets: "+clean(u(ii)));Y(end+1,:)=nan;for j=1:2,z=Q(string(Q.GroupType)==types(tt)&string(Q.Group)==u(ii)&string(Q.Format)==F(j),:);if ~isempty(z),Y(end,j)=z.EqualInningsRMSE(1);end,end,end
end
b=bar(ax,Y,'grouped');setBarColors(b,[.18 .45 .70;.90 .38 .08]);ax.XTick=1:numel(G);ax.XTickLabel=G;ax.XTickLabelRotation=28;legend(ax,F,'Location','best');ylabel(ax,'Equal-innings RMSE (runs)');grid(ax,'on');
end
function gb(ax,T,v,y),F=["ODI","T20"];G=["men","women"];Y=nan(2);for i=1:2,for j=1:2,z=T(string(T.Format)==F(i)&lower(string(T.Gender))==G(j),:);tmp=z.(v);Y(i,j)=tmp(1);end,end;b=bar(ax,Y,'grouped');setBarColors(b,[.18 .45 .70;.90 .38 .08]);ax.XTick=1:2;ax.XTickLabel=F;ylabel(ax,y);legend(ax,{'Men','Women'},'Location','best');grid(ax,'on');title(ax,string(y)+" by format");end

function setBarColors(b,C)
for j=1:numel(b),b(j).FaceColor=C(min(j,size(C,1)),:);b(j).EdgeColor=[.15 .15 .15];b(j).LineWidth=1.3;end
end

function C=palette(n,j)
base=[.18 .45 .70;.90 .38 .08;.93 .69 .13;.49 .18 .56;.28 .62 .38;.20 .62 .67;.78 .25 .25];C=base(1:min(n,size(base,1)),:);if nargin>1,C=C(j,:);end
end

function [keep,ok]=operationalMask(T)
names=string(T.Properties.VariableNames);keep=false(height(T),1);ok=false;
aliases=["OperationalSubset","OperationalEligible","OperationalComparisonEligible","OperationalCase","VerifiedOperational","IncludeOperational","OperationalReady"];
for a=aliases,i=find(strcmpi(names,a),1);if ~isempty(i),keep=toLogical(T.(names(i)));ok=any(keep)&~all(keep);if ok,return,end,end,end
for i=1:numel(names),nm=lower(names(i));if contains(nm,'operational')||contains(nm,'verified')||contains(nm,'eligible'),v=T.(names(i));if isstring(v)||iscellstr(v)||iscategorical(v),s=lower(string(v));keep=contains(s,'operational')|contains(s,'eligible')|contains(s,'verified')|s=="yes"|s=="true";else,keep=toLogical(v);end;ok=any(keep)&~all(keep);if ok,return,end,end,end
end

function y=toLogical(v)
if islogical(v),y=v;elseif isnumeric(v),y=isfinite(v)&v~=0;else,s=lower(string(v));y=s=="1"|s=="true"|s=="yes"|s=="included"|s=="eligible";end;y=y(:);
end

function caseBars(ax,v,fm)
pc=[.18 .45 .70;.90 .38 .08];b=bar(ax,v,'FaceColor','flat','EdgeColor',[.15 .15 .15],'LineWidth',1.3);for i=1:numel(v),if upper(fm(i))=="ODI",b.CData(i,:)=pc(1,:);else,b.CData(i,:)=pc(2,:);end,end
end

function sparseTicks(ax,labels,maxTicks)
n=numel(labels);idx=unique(round(linspace(1,n,min(maxTicks,n))));ax.XTick=idx;ax.XTickLabel=labels(idx);ax.XTickLabelRotation=35;
end

function setBarSeries(b)
g=[.25 .70 .88 .98];
for j=1:numel(b),b(j).FaceColor=[g(min(j,numel(g))) g(min(j,numel(g))) g(min(j,numel(g)))];b(j).EdgeColor='k';b(j).LineWidth=.9;end
end

function hatchV(ax,b,Y,styles)
if isvector(Y),Y=Y(:);end;hold(ax,'on');drawnow;nb=numel(b);
for j=1:nb
 x=b(j).XEndPoints;w=.72/max(1,nb);st=styles{min(j,numel(styles))};
 for i=1:min(numel(x),size(Y,1)),hatchRect(ax,x(i)-w/2,x(i)+w/2,min(0,Y(i,j)),max(0,Y(i,j)),st);end
end
end

function hatchHStacked(ax,b,Y,styles)
hold(ax,'on');drawnow;base=zeros(size(Y,1),1);h=.58;
for j=1:numel(b),st=styles{min(j,numel(styles))};for i=1:size(Y,1),hatchRect(ax,base(i),base(i)+Y(i,j),i-h/2,i+h/2,st);base(i)=base(i)+Y(i,j);end,end
end

function hatchHSimple(ax,b,V,style)
hold(ax,'on');drawnow;y=b.YEndPoints;for i=1:numel(V),hatchRect(ax,min(0,V(i)),max(0,V(i)),y(i)-.32,y(i)+.32,style);end
end

function hatchRect(ax,x1,x2,y1,y2,style)
if strcmp(style,'none')||~isfinite(x1+x2+y1+y2)||x1==x2||y1==y2,return,end
n=7;c=[.25 .25 .25];
if any(strcmp(style,{'vertical','cross'})),xx=linspace(x1,x2,n+2);xx=xx(2:end-1);for x=xx,line(ax,[x x],[y1 y2],'Color',c,'LineWidth',.35,'HandleVisibility','off');end,end
if any(strcmp(style,{'horizontal','cross'})),yy=linspace(y1,y2,n+2);yy=yy(2:end-1);for y=yy,line(ax,[x1 x2],[y y],'Color',c,'LineWidth',.35,'HandleVisibility','off');end,end
end

function [x,y]=influenceColumns(T)
names=string(T.Properties.VariableNames);iy=find(contains(lower(names),'influence')|contains(lower(names),'delta')|contains(lower(names),'difference'),1,'last');
if isempty(iy),error('Step21 outlier table has no explicitly named influence/delta/difference column.');end
y=double(T.(names(iy)));ix=find(strcmpi(names,'MatchID')|strcmpi(names,'CaseID')|strcmpi(names,'Index'),1);if isempty(ix),x=(1:height(T))';else,x=T.(names(ix));if ~isnumeric(x),x=(1:height(T))';end,end
end

function caseScatter(ax,x,y,fm)
hold(ax,'on');forms=unique(fm,'stable');marks={'o','s','^','d'};
pc=palette(7);for j=1:numel(forms),q=fm==forms(j);scatter(ax,x(q),y(q),52,marks{min(j,numel(marks))},'MarkerEdgeColor',pc(j,:),'MarkerFaceColor','w','LineWidth',1.5,'DisplayName',forms(j));end
m=max([x(:);y(:)],[],'omitnan');lo=min([x(:);y(:)],[],'omitnan');plot(ax,[lo m],[lo m],'k--','HandleVisibility','off');xlabel(ax,'Published target (runs)');ylabel(ax,'Frozen-model target (runs)');legend(ax,'Location','best');grid(ax,'on');axis(ax,'square');
end

function y=wrapLabels(x,n)
y=string(x);for i=1:numel(y),if strlength(y(i))>n,y(i)=replace(y(i),' ',newline);end,end
end

function z=tern(c,a,b),if c,z=a;else,z=b;end,end
