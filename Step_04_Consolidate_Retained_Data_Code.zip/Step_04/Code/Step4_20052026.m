%% Step 4 it is
%% VihaanProject1 — Final Retained Files Consolidation
clc; clear;

% ---------------- USER SETTINGS ----------------
workRoot = 'D:\VihaanProject1';

srcLossless = fullfile(workRoot, 'clean_from_yaml_lossless_all');
srcJson     = fullfile(workRoot, 'clean_from_json');

destFolder  = fullfile(workRoot, 'final_retained_dataset');

% ---------------- CREATE DESTINATION ----------------
if ~exist(destFolder, 'dir')
    mkdir(destFolder);
end

% ---------------- FILE LIST (AUTHORITATIVE) ----------------
filesToCopy = {
    fullfile(srcLossless, 'ball_by_ball_all.csv')
    fullfile(srcLossless, 'match_info_all_noCompetition.csv')
    fullfile(srcLossless, 'delivery_kv_long_all.csv')
    fullfile(srcLossless, 'parse_meta_all.mat')
    fullfile(srcLossless, 'parse_report_all.txt')

    fullfile(srcJson,     'JSON_EventMaster_FromMatchIDs.csv')
    fullfile(srcJson,     'JSON_EventCounts_FromMatchIDs.csv')
    fullfile(srcJson,     'JSON_FromMatchIDs_RunReport.txt')
};

% ---------------- COPY PROCESS ----------------
fprintf('Copying final retained files to:\n%s\n\n', destFolder);

copied = 0;
missing = 0;

for i = 1:numel(filesToCopy)
    src = filesToCopy{i};

    if isfile(src)
        [~, name, ext] = fileparts(src);
        dest = fullfile(destFolder, [name ext]);

        copyfile(src, dest);
        fprintf('✓ Copied: %s\n', [name ext]);
        copied = copied + 1;
    else
        fprintf('✗ Missing: %s\n', src);
        missing = missing + 1;
    end
end

% ---------------- SUMMARY ----------------
fprintf('\nDONE.\n');
fprintf('Files copied : %d\n', copied);
fprintf('Files missing: %d\n', missing);
fprintf('Final folder : %s\n', destFolder);
