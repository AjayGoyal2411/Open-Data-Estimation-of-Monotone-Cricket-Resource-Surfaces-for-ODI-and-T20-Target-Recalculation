%% This is step 1
%% VihaanProject1 — Step 1_0 (COMPLETE / LOSSLESS) — ALL YAML FILES — ALL MATCH TYPES
% Parses ALL Cricsheet YAMLs and writes three outputs (lossless):
%   1) match_info_all.csv
%   2) ball_by_ball_all.csv
%   3) delivery_kv_long_all.csv   (guarantees no nested/rare delivery fields are lost)
%
% Key idea:
%   - ball_by_ball_all.csv has standard columns + DeliveryJSON (full delivery struct JSON)
%   - delivery_kv_long_all.csv is a long key-value table for every delivery leaf path/value
%     so you can later “promote” any rare field into a proper column.
%
% Streaming + batching (no huge in-memory tables).
%
% YOU SET:
%   yamlFolder = 'D:\VihaanProject1\YAMLfiles\ALLYAML';
%   workRoot   = 'D:\VihaanProject1';
%   lib jar in  D:\VihaanProject1\lib\snakeyaml-*.jar

clc; clear;

%% -------------------- USER SETTINGS --------------------
yamlFolder = 'D:\VihaanProject1\YAMLfiles\ALLYAML';
workRoot   = 'D:\VihaanProject1';

assert(exist(yamlFolder,'dir')==7, 'YAML folder not found: %s', yamlFolder);

outFolder  = fullfile(workRoot, 'clean_from_yaml_lossless_all');
if ~exist(outFolder,'dir'), mkdir(outFolder); end

matchOut   = fullfile(outFolder, 'match_info_all.csv');
ballOut    = fullfile(outFolder, 'ball_by_ball_all.csv');
kvOut      = fullfile(outFolder, 'delivery_kv_long_all.csv');
reportOut  = fullfile(outFolder, 'parse_report_all.txt');
metaOut    = fullfile(outFolder, 'parse_meta_all.mat');

% Batching: tune based on RAM and disk speed
BATCH_MATCHES = 50;          % write every N matches
KV_ROW_LIMIT  = 500000;      % flush KV long table when it grows to this many rows (safety)

%% -------------------- LOAD SNAKEYAML JAR --------------------
libFolder = fullfile(workRoot, 'lib');
assert(exist(libFolder,'dir')==7, 'Missing lib folder: %s', libFolder);

jarList = dir(fullfile(libFolder, '*.jar'));
assert(~isempty(jarList), 'No .jar found in %s. Put snakeyaml-*.jar there.', libFolder);

dynCP = javaclasspath('-dynamic');
for k = 1:numel(jarList)
    jarPath = fullfile(jarList(k).folder, jarList(k).name);
    if ~any(strcmpi(dynCP, jarPath))
        javaaddpath(jarPath);
    end
end

try
    yamlObj = org.yaml.snakeyaml.Yaml(); %#ok<NASGU>
catch
    error('SnakeYAML class not found. Restart MATLAB after adding jar(s) in %s.', libFolder);
end

%% -------------------- GATHER YAML FILES --------------------
files = [dir(fullfile(yamlFolder,'*.yaml')); dir(fullfile(yamlFolder,'*.yml'))];
assert(~isempty(files), 'No YAML files found in: %s', yamlFolder);

fprintf('Found YAML files: %d\n', numel(files));
fprintf('Output folder   : %s\n\n', outFolder);

%% -------------------- RESET OUTPUTS --------------------
if isfile(matchOut), delete(matchOut); end
if isfile(ballOut),  delete(ballOut);  end
if isfile(kvOut),    delete(kvOut);    end
if isfile(reportOut),delete(reportOut);end
if isfile(metaOut),  delete(metaOut);  end

% Write headers once (empty tables)
matchHeader = { ...
    'MatchID','FileName','Format','Competition','Gender','Season', ...
    'Team1','Team2','Winner','ResultMethod','Result', ...
    'Venue','City','StartDate','OversPerInnings','BallsPerOver', ...
    'TossWinner','TossDecision','RegistryJSON','InfoJSON' ...
};
writetable(cell2table(cell(0,numel(matchHeader)),'VariableNames',matchHeader), matchOut);

ballHeader = { ...
    'MatchID','InningsIndex','InningsName','BallKey','DeliverySeqInInnings', ...
    'BattingTeam','Batter','NonStriker','Bowler', ...
    'OverNumber','BallIndexRaw','BallNumberLegal','IsLegalBall', ...
    'RunsOffBat','ExtrasRuns','TotalRuns', ...
    'ExtrasTypePrimary','ExtrasDetailJSON', ...
    'IsWicket','WicketTypePrimary','PlayerOutPrimary','FieldersPrimary','WicketsLost', ...
    'ReviewJSON','ReplacementsJSON','WicketsJSON','DeliveryJSON' ...
};
writetable(cell2table(cell(0,numel(ballHeader)),'VariableNames',ballHeader), ballOut);

kvHeader = {'MatchID','InningsIndex','InningsName','BallKey','Path','Value'};
writetable(cell2table(cell(0,numel(kvHeader)),'VariableNames',kvHeader), kvOut);

%% -------------------- OPEN REPORT --------------------
fid = fopen(reportOut,'w');
cleanupObj = onCleanup(@() fclose(fid));
fprintf(fid, 'Vihaan Step 1_0 Lossless Parse — ALL YAMLs (ALL match types)\n');
fprintf(fid, 'Timestamp   : %s\n', datestr(now));
fprintf(fid, 'YAML folder  : %s\n', yamlFolder);
fprintf(fid, 'Output folder: %s\n', outFolder);
fprintf(fid, 'BATCH_MATCHES: %d\n', BATCH_MATCHES);
fprintf(fid, 'KV_ROW_LIMIT : %d\n\n', KV_ROW_LIMIT);

%% -------------------- STREAMING MAIN LOOP --------------------
matchBatch = table();
ballBatch  = table();
kvBatch    = table();  % can be large; we flush by row count too

keptMatches = 0;
parseErrors = 0;

tStart = tic;

for i = 1:numel(files)
    fpath   = fullfile(files(i).folder, files(i).name);
    matchID = string(erase(files(i).name, [".yaml",".yml"]));

    try
        S = readCricsheetYAML(fpath);

        % Match info row
        M = buildMatchInfoRow(S, matchID, files(i).name);

        % Ball-by-ball + KV long for deliveries
        [B, K] = buildBallByBallRows(S, matchID);

        matchBatch = [matchBatch; M]; %#ok<AGROW>
        ballBatch  = [ballBatch;  B]; %#ok<AGROW>
        kvBatch    = [kvBatch;    K]; %#ok<AGROW>

        keptMatches = keptMatches + 1;

        % periodic progress
        if mod(keptMatches, 100) == 0
            fprintf('Parsed %d/%d matches | ballBatch=%d | kvBatch=%d | elapsed=%.1fs\n', ...
                keptMatches, numel(files), height(ballBatch), height(kvBatch), toc(tStart));
        end

        % Flush by match count
        if mod(keptMatches, BATCH_MATCHES) == 0
            appendTable(matchOut, matchBatch);
            appendTable(ballOut,  ballBatch);
            matchBatch = table();
            ballBatch  = table();
        end

        % Flush KV by size (to avoid RAM blow-up)
        if height(kvBatch) >= KV_ROW_LIMIT
            appendTable(kvOut, kvBatch);
            kvBatch = table();
        end

    catch ME
        parseErrors = parseErrors + 1;
        fprintf(fid, 'ERROR [%s]\n%s\n\n', fpath, getReport(ME,'extended','hyperlinks','off'));
        if parseErrors <= 10
            fprintf('Parse error (%d): %s\n', parseErrors, ME.message);
        end
    end
end

% Final flush
if ~isempty(matchBatch), appendTable(matchOut, matchBatch); end
if ~isempty(ballBatch),  appendTable(ballOut,  ballBatch);  end
if ~isempty(kvBatch),    appendTable(kvOut,    kvBatch);    end

%% -------------------- SUMMARY + META --------------------
elapsed = toc(tStart);

fprintf('\nDONE.\nParsed matches: %d\nParse errors : %d\nElapsed      : %.1fs\n', ...
    keptMatches, parseErrors, elapsed);

fprintf(fid, '\nSUMMARY\n');
fprintf(fid, 'Parsed matches: %d\n', keptMatches);
fprintf(fid, 'Parse errors : %d\n', parseErrors);
fprintf(fid, 'Elapsed (s)  : %.1f\n', elapsed);

RunMeta = struct();
RunMeta.Timestamp   = datestr(now);
RunMeta.yamlFolder  = yamlFolder;
RunMeta.workRoot    = workRoot;
RunMeta.outFolder   = outFolder;
RunMeta.matchOut    = matchOut;
RunMeta.ballOut     = ballOut;
RunMeta.kvOut       = kvOut;
RunMeta.reportOut   = reportOut;
RunMeta.totalYAMLs  = numel(files);
RunMeta.parsed      = keptMatches;
RunMeta.parseErrors = parseErrors;
RunMeta.BATCH_MATCHES = BATCH_MATCHES;
RunMeta.KV_ROW_LIMIT  = KV_ROW_LIMIT;
RunMeta.elapsed_s     = elapsed;
save(metaOut, 'RunMeta');

fprintf('\nOutputs:\n  %s\n  %s\n  %s\n  %s\n  %s\n', ...
    matchOut, ballOut, kvOut, reportOut, metaOut);

%% ========================== LOCAL FUNCTIONS ==========================

function S = readCricsheetYAML(filePath)
    txt  = fileread(filePath);
    yaml = org.yaml.snakeyaml.Yaml();
    jObj = yaml.load(java.io.StringReader(txt));
    S    = javaToMatlab(jObj);
end

function out = javaToMatlab(x)
    if isempty(x), out = []; return; end

    if isa(x,'java.util.Map')
        it = x.entrySet().iterator();
        out = struct();
        while it.hasNext()
            e = it.next();
            k = string(e.getKey());
            v = javaToMatlab(e.getValue());
            out.(makeValidField(k)) = v;
        end

    elseif isa(x,'java.util.List')
        n = x.size();
        c = cell(n,1);
        for i = 1:n
            c{i} = javaToMatlab(x.get(i-1));
        end
        out = c;

    elseif isa(x,'java.lang.String')
        out = string(x);

    elseif isa(x,'java.lang.Integer') || isa(x,'java.lang.Long') || ...
           isa(x,'java.lang.Double')  || isa(x,'java.lang.Float')
        out = double(x);

    elseif ischar(x)
        out = string(x);

    else
        try, out = string(x); catch, out = x; end
    end
end

function f = makeValidField(s)
    s = char(s);
    s = strrep(s, '.', '_');
    s = regexprep(s, '[^a-zA-Z0-9_]', '_');
    if isempty(s) || ~isletter(s(1))
        s = ['f_' s];
    end
    f = s;
end

function M = buildMatchInfoRow(S, matchID, fileName)
    info = mustGet(S, "info");

    format      = lower(string(getOr(info,"match_type","")));
    gender      = string(getOr(info,"gender",""));
    venue       = string(getOr(info,"venue",""));
    city        = string(getOr(info,"city",""));
    season      = string(getOr(info,"season",""));
    ballsPerOver= toDouble(getOr(info,"balls_per_over",NaN));
    overs       = toDouble(getOr(info,"overs",NaN));

    team1 = ""; team2 = "";
    teams = getOr(info,"teams",[]);
    if iscell(teams) && numel(teams)>=2
        team1 = string(teams{1});
        team2 = string(teams{2});
    end

    startDate = "";
    if isfield(info,'dates')
        d = info.dates;
        if iscell(d) && ~isempty(d), startDate = string(d{1}); end
    end

    winner = ""; method = ""; result = "";
    if isfield(info,'outcome')
        oc = info.outcome;
        winner = string(getOr(oc,"winner",""));
        method = string(getOr(oc,"method",""));
        result = string(getOr(oc,"result",""));
    end

    tossWinner = ""; tossDecision = "";
    if isfield(info,'toss')
        ts = info.toss;
        tossWinner   = string(getOr(ts,"winner",""));
        tossDecision = string(getOr(ts,"decision",""));
    end

    competition = "";
    if isfield(info,'event')
        ev = info.event;
        n1 = string(getOr(ev,"name",""));
        st = string(getOr(ev,"stage",""));
        if strtrim(n1)~="" && strtrim(st)~=""
            competition = strtrim(n1) + " - " + strtrim(st);
        else
            competition = strtrim(n1);
        end
    end
    if strtrim(competition)=="", competition = string(getOr(info,"competition","")); end
    if strtrim(competition)=="", competition = string(getOr(info,"series","")); end

    registryJSON = "";
    if isfield(info,'registry')
        registryJSON = safeJson(info.registry);
    end

    infoJSON = safeJson(info);

    M = table( ...
        matchID, string(fileName), format, competition, gender, season, ...
        team1, team2, winner, method, result, ...
        venue, city, startDate, overs, ballsPerOver, ...
        tossWinner, tossDecision, registryJSON, infoJSON, ...
        'VariableNames', { ...
            'MatchID','FileName','Format','Competition','Gender','Season', ...
            'Team1','Team2','Winner','ResultMethod','Result', ...
            'Venue','City','StartDate','OversPerInnings','BallsPerOver', ...
            'TossWinner','TossDecision','RegistryJSON','InfoJSON' ...
        } );
end

function [B, KV] = buildBallByBallRows(S, matchID)
    innings = mustGet(S, "innings");

    rows = cell(0, 27);  % must match ballHeader count
    kvAll = cell(0, 6);

    for innIdx = 1:numel(innings)
        blk = innings{innIdx};
        blkFields = fieldnames(blk);
        innKey = blkFields{1};
        inn = blk.(innKey);

        battingTeam = string(getOr(inn,"team",""));
        delivs = mustGet(inn, "deliveries");

        currentOver = NaN;
        legalCountInOver = 0;
        deliverySeq = 0;
        wicketsLost = 0;

        for d = 1:numel(delivs)
            entry = delivs{d};
            deliverySeq = deliverySeq + 1;

            fn = fieldnames(entry); fn = fn{1};
            delivery = entry.(fn);

            ballKey = recoverOverBallKey(fn);
            [overNum, ballRaw] = parseOverBallKey(ballKey);

            if isnan(currentOver) || overNum ~= currentOver
                currentOver = overNum;
                legalCountInOver = 0;
            end

            batter     = string(getOr(delivery,"batter", getOr(delivery,"batsman","")));
            nonStriker = string(getOr(delivery,"non_striker", getOr(delivery,"nonStriker","")));
            bowler     = string(getOr(delivery,"bowler",""));

            runs = getOr(delivery, "runs", struct());
            runsBat = toDouble(getOr(runs, "batter", getOr(runs,"batsman",NaN)));
            runsExt = toDouble(getOr(runs, "extras", 0));
            runsTot = toDouble(getOr(runs, "total", NaN));

            extrasJSON = "";
            extrasType = "none";
            isLegal    = 1;
            if isfield(delivery,'extras')
                extrasJSON = safeJson(delivery.extras);
                [extrasType, isLegal] = detectExtrasTypeAndLegality(delivery.extras);
            end
            if isLegal
                legalCountInOver = legalCountInOver + 1;
            end

            [isW, wicketJSON, wType, pOut, fieldersStr] = parseWickets(delivery);
            if isW, wicketsLost = wicketsLost + 1; end

            reviewJSON       = "";
            replacementsJSON = "";
            if isfield(delivery,'review'),        reviewJSON = safeJson(delivery.review); end
            if isfield(delivery,'replacements'),  replacementsJSON = safeJson(delivery.replacements); end

            deliveryJSON = safeJson(delivery);

            rows(end+1,:) = { ...
                matchID, double(innIdx), string(innKey), string(ballKey), double(deliverySeq), ...
                battingTeam, batter, nonStriker, bowler, ...
                double(overNum), double(ballRaw), double(legalCountInOver), double(isLegal), ...
                double(runsBat), double(runsExt), double(runsTot), ...
                string(extrasType), string(extrasJSON), ...
                double(isW), string(wType), string(pOut), string(fieldersStr), double(wicketsLost), ...
                string(reviewJSON), string(replacementsJSON), string(wicketJSON), string(deliveryJSON) ...
            }; %#ok<AGROW>

            kvDel = flattenToKV(delivery, "innings(" + innIdx + ").deliveries(" + ballKey + ")");
            for kk = 1:height(kvDel)
                kvAll(end+1,:) = { ...
                    matchID, double(innIdx), string(innKey), string(ballKey), ...
                    kvDel.Path(kk), kvDel.Value(kk) ...
                }; %#ok<AGROW>
            end
        end
    end

    B = cell2table(rows, 'VariableNames', { ...
        'MatchID','InningsIndex','InningsName','BallKey','DeliverySeqInInnings', ...
        'BattingTeam','Batter','NonStriker','Bowler', ...
        'OverNumber','BallIndexRaw','BallNumberLegal','IsLegalBall', ...
        'RunsOffBat','ExtrasRuns','TotalRuns', ...
        'ExtrasTypePrimary','ExtrasDetailJSON', ...
        'IsWicket','WicketTypePrimary','PlayerOutPrimary','FieldersPrimary','WicketsLost', ...
        'ReviewJSON','ReplacementsJSON','WicketsJSON','DeliveryJSON' ...
    });

    KV = cell2table(kvAll, 'VariableNames', ...
        {'MatchID','InningsIndex','InningsName','BallKey','Path','Value'});
end

function kv = flattenToKV(x, root)
    paths = strings(0,1);
    vals  = strings(0,1);

    function walk(v, p)
        if isstruct(v)
            f = fieldnames(v);
            for i = 1:numel(f)
                walk(v.(f{i}), p + "." + string(f{i}));
            end
        elseif iscell(v)
            for i = 1:numel(v)
                walk(v{i}, p + "{" + string(i) + "}");
            end
        else
            paths(end+1,1) = p; %#ok<AGROW>
            vals(end+1,1)  = scalarToString(v); %#ok<AGROW>
        end
    end

    walk(x, string(root));
    kv = table(paths, vals, 'VariableNames', {'Path','Value'});
end

function s = scalarToString(v)
    if isempty(v)
        s = "";
    elseif isstring(v)
        if numel(v)==1, s = v; else, s = strjoin(v(:), "|"); end
    elseif ischar(v)
        s = string(v);
    elseif isnumeric(v)
        if numel(v)==1, s = string(v); else, s = strjoin(string(v(:)),"|"); end
    elseif islogical(v)
        if numel(v)==1, s = string(v); else, s = strjoin(string(v(:)),"|"); end
    else
        s = safeJson(v);
    end
end

function json = safeJson(v)
    try
        json = string(jsonencode(v));
    catch
        try
            json = string(v);
        catch
            json = "";
        end
    end
end

function k = recoverOverBallKey(fn)
    fn = string(fn);
    if startsWith(fn, "f_"), fn = extractAfter(fn, "f_"); end
    fn = strrep(fn, "_", ".");
    k = fn;
end

function [overNum, ballRaw] = parseOverBallKey(k)
    ks = string(k);
    parts = split(ks, ".");
    overNum = str2double(parts(1));
    if numel(parts) >= 2
        ballRaw = str2double(parts(2));
    else
        ballRaw = NaN;
    end
end

function [etype, isLegal] = detectExtrasTypeAndLegality(extrasStruct)
    etype  = "none";
    isLegal = 1;
    if ~isstruct(extrasStruct), return; end
    f = fieldnames(extrasStruct);
    if isempty(f), return; end
    fLow = lower(string(f));

    if any(fLow=="wides")
        etype = "wides";  isLegal = 0;
    elseif any(fLow=="noballs") || any(fLow=="no_balls") || any(fLow=="no-balls")
        etype = "noballs"; isLegal = 0;
    elseif any(fLow=="byes")
        etype = "byes";   isLegal = 1;
    elseif any(fLow=="legbyes") || any(fLow=="leg_byes")
        etype = "legbyes"; isLegal = 1;
    elseif any(fLow=="penalty")
        etype = "penalty"; isLegal = 1;
    else
        etype = fLow(1);
        isLegal = 1;
    end
end

function [isW, wicketJSON, wType, pOut, fieldersStr] = parseWickets(delivery)
    isW = 0; wicketJSON = ""; wType = ""; pOut = ""; fieldersStr = "";

    if isfield(delivery,'wickets')
        W = delivery.wickets;
        if iscell(W) && ~isempty(W)
            isW = 1;
            wicketJSON = safeJson(W);
            wType = string(getOr(W{1},"kind",""));
            pOut  = string(getOr(W{1},"player_out",""));
            fieldersStr = stringifyFielders(getOr(W{1},"fielders",[]));
        end
    elseif isfield(delivery,'wicket')
        W = delivery.wicket;
        isW = 1;
        wicketJSON = safeJson(W);
        wType = string(getOr(W,"kind",""));
        pOut  = string(getOr(W,"player_out",""));
        fieldersStr = stringifyFielders(getOr(W,"fielders",[]));
    end
end

function s = stringifyFielders(v)
    if isempty(v), s = ""; return; end
    if iscell(v)
        try
            s = strjoin(string(cellfun(@string, v, 'UniformOutput', false)), ";");
        catch
            s = "";
        end
    else
        s = string(v);
    end
end

function v = getOr(S, field, default)
    field = char(field);
    if isstruct(S) && isfield(S, field)
        v = S.(field);
    else
        v = default;
    end
end

function v = mustGet(S, field)
    field = char(field);
    assert(isstruct(S) && isfield(S, field), 'Missing required YAML field: %s', field);
    v = S.(field);
end

function appendTable(outCsv, T)
    if isempty(T), return; end
    writetable(T, outCsv, 'WriteMode','append');
end

function x = toDouble(v)
    if isempty(v), x = NaN; return; end
    if isstring(v)
        vv = strtrim(v);
        if vv=="", x = NaN; else, x = str2double(vv); end
        return
    end
    if ischar(v)
        vv = strtrim(string(v));
        if vv=="", x = NaN; else, x = str2double(vv); end
        return
    end
    if isnumeric(v), x = double(v); return; end
    if iscell(v) && numel(v)==1, x = toDouble(v{1}); return; end
    try, x = double(v); catch, x = NaN; end
end
