function RevisedCodes_17D_Figures(C,S,P,A,c)
% Editable FIG, vector PDF, and 400-dpi PNG. Compact four-panel research figures.
f=figure('Visible','off','Color','w','Position',[50 50 1350 850]);tiledlayout(2,2,'TileSpacing','compact','Padding','compact');
colors=lines(2);
for fmt=["ODI","T20"]
 nexttile;hold on;
 for gi=1:2
  gs=["men","women"];g=gs(gi);
  for wi=1:2
   wickets=[10 5];w=wickets(wi);q=C.Format==fmt&C.Gender==g&C.Model=="Partial"&C.WicketsInHand==w;
   styles={'-','--'};y=C.NormalizedCapacity(q);support=C.DirectGenderStateCount(q);
   y(support<30)=NaN;plot(C.BallsRemaining(q),y,'Color',colors(gi,:), ...
    'LineStyle',styles{wi},'LineWidth',1.5,'DisplayName',char(g+", "+string(w)+" wickets"));
  end
 end
 grid on;xlabel('Balls remaining');ylabel('Normalized capacity');title(fmt+": partial curves, direct support >=30");legend('Location','northwest');
end
for fmt=["ODI","T20"]
 nexttile;q=S.Format==fmt&S.Scope=="AllEligible"&S.Fold=="Pooled2020_2022";
 T=S(q,:);names=["Pooled","PooledShape","Separate","Partial"];v=nan(4,2);
 for j=1:4,for k=1:2,gs=["men","women"];a=T.Model==names(j)&T.Gender==gs(k);if any(a),v(j,k)=T.RMSE(a);end,end,end
 bar(v);xticks(1:4);xticklabels({'Shared scale','Shared shape','Separate','Partial'});xtickangle(15);ylabel('Equal-innings RMSE (runs)');
 title(fmt+": held-out development performance");legend('Men','Women','Location','best');grid on;
end
saveFigure(f,'F17D_GenderModels',c);
f=figure('Visible','off','Color','w','Position',[50 50 1350 850]);tiledlayout(2,2,'TileSpacing','compact','Padding','compact');
for fmt=["ODI","T20"]
 nexttile;T=P(P.Format==fmt&P.Scope=="AllEligible"&P.Fold=="Pooled2020_2022"&P.Reference=="Separate",:);
 if ~isempty(T)
  xx=(1:height(T))';errorbar(xx,T.RMSEGain,T.RMSEGain-T.CI95Low,T.CI95High-T.RMSEGain,'o','LineWidth',1.3);
  xlim([0.5 height(T)+0.5]);xticks(xx);xticklabels(T.Gender+" "+T.Candidate);xtickangle(25);
 end
 yline(0,':');grid on;ylabel('RMSE reduction versus separate fit (runs)');title(fmt+": paired 95% match-bootstrap intervals");
end
nexttile;bar([A.CanonicalStates,A.RemovedInitial+A.RemovedTerminal+A.RemovedIllegal+A.OtherRemoved],'stacked');
xticks(1:height(A));xticklabels(A.Format+" "+A.Gender);ylabel('State rows');legend('Retained','Removed','Location','best');title('Observation-unit correction');grid on;
nexttile;axis off;text(0,1,{'Interpretation boundaries','', ...
 'Shared scale: one pooled surface and one scoring mean.', ...
 'Shared shape: pooled surface, gender-specific means.', ...
 'Positive paired gain favors the candidate.', ...
 'Within-class fits require verified labels and common support.', ...
 'Equivalence assessment is exploratory (90% interval).', ...
 'Curves do not establish target fairness or a causal effect.', ...
 'Curve gaps mark fewer than 30 direct gender observations.'}, ...
 'Units','normalized','VerticalAlignment','top','FontSize',11,'Interpreter','none');
saveFigure(f,'F17D_PairedEvidenceAndAudit',c);
f=figure('Visible','off','Color','w','Position',[50 50 1350 850]);tiledlayout(2,2,'TileSpacing','compact','Padding','compact');
for fmt=["ODI","T20"],for gender=["men","women"]
 nexttile;T=C(C.Format==fmt&C.Gender==gender&C.Model=="Partial",:);
 if ~isempty(T)
  T=sortrows(T,{'WicketsInHand','BallsRemaining'});H=max(T.BallsRemaining);
  count=reshape(T.DirectGenderStateCount,H+1,11);
  imagesc(0:H,0:10,log10(1+count'));set(gca,'YDir','normal');
  cb=colorbar;cb.Label.String='log10(1 + direct observations)';
 end
 xlabel('Balls remaining');ylabel('Wickets in hand');title(fmt+" "+gender+": direct support");
end,end
saveFigure(f,'F17D_DirectSupport',c);
end
function saveFigure(f,name,c)
set(findall(f,'Type','axes'),'FontName','Times New Roman','FontSize',11);
savefig(f,fullfile(c.Figures,[name '.fig']));
exportgraphics(f,fullfile(c.Figures,[name '.pdf']),'ContentType','vector');
exportgraphics(f,fullfile(c.Figures,[name '.png']),'Resolution',400);close(f);
end
