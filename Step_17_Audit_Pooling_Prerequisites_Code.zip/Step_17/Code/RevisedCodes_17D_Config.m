function c=RevisedCodes_17D_Config(settings)
if nargin<1,settings=struct;end
b=RevisedCodes_09_00_Config;
c=struct('ProjectRoot',string(b.ProjectRoot),'StateManifest',string(fullfile(b.OutputRoot,'RevisedCodes_09_Result.mat')), ...
 'EligibilityFile',"",'ClassificationFile',"",'Step19AuditFile',"",'BootstrapReplicates',2000, ...
 'Seed',170019,'Roughness',1e-4,'LambdaCandidates',[0.01 0.1 1 10], ...
 'FallbackLambda',0.1,'EquivalenceMarginRuns',1);
for f=fieldnames(settings)',assert(isfield(c,f{1}),'Unknown setting %s.',f{1});c.(f{1})=settings.(f{1});end
assert(string(c.ProjectRoot)==string(b.ProjectRoot),'Use existing project root.');
validateattributes(c.BootstrapReplicates,{'numeric'},{'scalar','integer','>=',500});
validateattributes(c.Seed,{'numeric'},{'scalar','integer','nonnegative'});
validateattributes(c.Roughness,{'numeric'},{'scalar','finite','positive'});
validateattributes(c.LambdaCandidates,{'numeric'},{'vector','nonempty','finite','nonnegative'});
validateattributes(c.FallbackLambda,{'numeric'},{'scalar','finite','nonnegative'});
validateattributes(c.EquivalenceMarginRuns,{'numeric'},{'scalar','finite','positive'});
if strlength(c.EligibilityFile)==0,c.EligibilityFile=findFile(c,'09_04_SensitivityEligibility.csv',true);end
if strlength(c.ClassificationFile)==0,c.ClassificationFile=findFile(c,'17_00_InningsInventory.csv',false);end
if strlength(c.Step19AuditFile)==0,c.Step19AuditFile=findFile(c,'19_00_GenderObservationUnitAudit.csv',false);end
% Unique run folders preserve earlier results and never overwrite Step19 artifacts.
c.Root=string(fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','step17_gender_competition', ...
 ['run_' char(datetime('now','Format','yyyyMMdd_HHmmss_SSS'))]));
c.Report=fullfile(c.Root,'reports');c.Figures=fullfile(c.Root,'figures');mkdir(c.Report);mkdir(c.Figures);
end
function p=findFile(c,name,required)
d=dir(fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','**',name));
if isempty(d),assert(~required,'Missing %s. Keep previous stage output folders.',name);p="";return;end
% Multiple copies accepted only if byte-identical; otherwise require explicit input.
U=RevisedCodes_17D_Utils;p=string(fullfile(d(1).folder,d(1).name));h=U.Hash(p);
for k=2:numel(d),q=string(fullfile(d(k).folder,d(k).name));assert(U.Hash(q)==h,'Conflicting copies of %s; set its input path explicitly.',name);end
end
