function [C,M,Audit,Sources]=RevisedCodes_17D_Data(c)
% Rebuild from source states, never from the legacy 17_19 cache.
U=RevisedCodes_17D_Utils;
opts=detectImportOptions(c.EligibilityFile,'TextType','string');
opts=setvartype(opts,'MatchID','string');M=readtable(c.EligibilityFile,opts);
required=["MatchID","InningsIndex","Format","Gender","Date","Split","RecordIntegrityOK", ...
 "CachedStateAvailable","CachedReconstructionPassed","CaseStudyReserved","ResponseEligible", ...
 "InitialAllocatedBalls","BallsPerOver","DeliveryRuns"];
assert(all(ismember(required,string(M.Properties.VariableNames))),'Eligibility schema mismatch.');
M.MatchID=string(M.MatchID);M.Format=upper(strtrim(string(M.Format)));M.Gender=U.Gender(M.Gender);M.Date=U.Date(M.Date);
M.Key=M.MatchID+"|"+string(U.Number(M.InningsIndex));assert(numel(unique(M.Key))==height(M),'Duplicate innings keys.');
h=120*ones(height(M),1);h(M.Format=="ODI")=300;
M.CacheEligible=U.Logical(M.RecordIntegrityOK)&U.Logical(M.CachedStateAvailable)&U.Logical(M.CachedReconstructionPassed)& ...
 ~U.Logical(M.CaseStudyReserved)&U.Logical(M.ResponseEligible)&U.Number(M.InningsIndex)==1& ...
 U.Number(M.InitialAllocatedBalls)==h&U.Number(M.BallsPerOver)==6&ismember(M.Format,["ODI","T20"])& ...
 ismember(M.Gender,["men","women"])&~isnat(M.Date)&M.Date<datetime(2023,1,1);
assert(all(lower(string(M.Split(M.CacheEligible)))=="train"),'Pre-2023 split conflict.');
M.CompetitionClass=repmat("unclassified",height(M),1);M.ClassVerified=false(height(M),1);
if strlength(c.ClassificationFile)>0
 opts=detectImportOptions(c.ClassificationFile,'TextType','string');opts=setvartype(opts,'MatchID','string');I=readtable(c.ClassificationFile,opts);
 assert(all(ismember(["Key","CompetitionClass","EventClassificationStatus"],string(I.Properties.VariableNames))),'Classification inventory schema mismatch.');
 assert(numel(unique(string(I.Key)))==height(I),'Duplicate classification keys.');
 [ok,k]=ismember(M.Key,string(I.Key));ix=find(ok);cls=lower(strtrim(string(I.CompetitionClass(k(ok)))));
 verified=lower(strtrim(string(I.EventClassificationStatus(k(ok)))))=="verified"& ...
  ismember(cls,["international","club","domestic_franchise","domestic_other","other"]);
 M.CompetitionClass(ix(verified))=cls(verified);M.ClassVerified(ix(verified))=true;
end
z=load(c.StateManifest,'Result');P=z.Result.Partitions;assert(ismember('Path',P.Properties.VariableNames));
Sources=table(string(c.EligibilityFile),U.Hash(c.EligibilityFile),'VariableNames',{'Path','SHA256'});
Sources=[Sources;table(string(c.StateManifest),U.Hash(c.StateManifest),'VariableNames',Sources.Properties.VariableNames)];
if strlength(c.ClassificationFile)>0,Sources=[Sources;table(string(c.ClassificationFile),U.Hash(c.ClassificationFile),'VariableNames',Sources.Properties.VariableNames)];end
meta=cell(height(P),1);uu=meta;ww=meta;yy=meta;seq=meta;
counts=zeros(height(M),5);
for part=1:height(P)
 p=string(P.Path(part));z=load(p,'States');S=z.States;
 assert(all(ismember(["DeliverySeq","StateType","CorrectedIsLegalBall"],string(S.Properties.VariableNames))),'Source state schema missing.');
 key=string(S.MatchID)+"|"+string(U.Number(S.InningsIndex));[ok,j]=ismember(key,M.Key);q=ok;q(ok)=M.CacheEligible(j(ok));
 y=U.Number(S.FinalDeliveryRuns)-U.Number(S.DeliveryScoreBefore);
 legacy=q&isfinite(y)&y>=0&U.Number(S.BallsRemaining)>=0&U.Number(S.WicketsInHand)>=0&U.Number(S.WicketsInHand)<=10;
 keep=q&U.Canonical(S);
 assert(all(U.Number(S.BallsRemaining(keep))<=h(j(keep))),'Balls exceed scheduled horizon.');
 assert(all(U.Number(S.FinalDeliveryRuns(keep))==U.Number(M.DeliveryRuns(j(keep)))),'Outcome differs from innings ledger.');
 if ismember('CaseReserved',S.Properties.VariableNames),assert(~any(U.Logical(S.CaseReserved(keep))),'Reserved case reached analysis.');end
 if ismember('MatchDate',S.Properties.VariableNames),assert(all(U.Date(S.MatchDate(keep))==M.Date(j(keep))),'State/ledger dates differ.');end
 masks={legacy,keep,legacy&string(S.StateType)=="initial",legacy&string(S.StateType)=="terminal", ...
  legacy&string(S.StateType)=="delivery"&U.Number(S.CorrectedIsLegalBall)==0};
 for k=1:5,counts(:,k)=counts(:,k)+accumarray(j(masks{k}),1,[height(M),1]);end
 meta{part}=uint32(j(keep));uu{part}=uint16(U.Number(S.BallsRemaining(keep)));ww{part}=uint8(U.Number(S.WicketsInHand(keep)));
 yy{part}=double(y(keep));seq{part}=double(S.DeliverySeq(keep));
 Sources=[Sources;table(p,U.Hash(p),'VariableNames',Sources.Properties.VariableNames)]; %#ok<AGROW>
 fprintf('Corrected Step17 source states %d/%d\n',part,height(P));
end
C=struct('MetaRow',vertcat(meta{:}),'U',vertcat(uu{:}),'W',vertcat(ww{:}),'Outcome',vertcat(yy{:}));
delivery=vertcat(seq{:});assert(all(isfinite(delivery)&delivery==floor(delivery)),'Invalid delivery keys.');
assert(size(unique([double(C.MetaRow),delivery],'rows'),1)==numel(delivery),'Duplicate legal pre-states.');
assert(all(counts(M.CacheEligible,2)>0),'Eligible innings has no canonical source states.');
M.CanonicalStates=counts(:,2);Audit=table;
for fmt=["ODI","T20"],for g=["men","women"]
 q=M.CacheEligible&M.Format==fmt&M.Gender==g;n=sum(counts(q,:),1);
 a=table(fmt,g,nnz(q),n(1),n(2),n(3),n(4),n(5),n(1)-n(2)-sum(n(3:5)), ...
  nnz(q&M.ClassVerified),'VariableNames',{'Format','Gender','Innings','LegacyStates','CanonicalStates', ...
  'RemovedInitial','RemovedTerminal','RemovedIllegal','OtherRemoved','VerifiedClassInnings'});Audit=[Audit;a]; %#ok<AGROW>
end,end
if strlength(c.Step19AuditFile)>0
 A=readtable(c.Step19AuditFile,'TextType','string');
 for j=1:height(Audit)
  k=find(A.Format==Audit.Format(j)&A.Gender==Audit.Gender(j));assert(isscalar(k),'Step19 audit grouping differs.');
  assert(A.CanonicalLegalPreStates(k)==Audit.CanonicalStates(j)&&A.Innings(k)==Audit.Innings(j),'Canonical inventory differs from Step19. Investigate changed inputs.');
 end
 Sources=[Sources;table(string(c.Step19AuditFile),U.Hash(c.Step19AuditFile),'VariableNames',Sources.Properties.VariableNames)];
end
end
