function Results=RevisedCodes_17_19_RunAll(settings)
% Runs development-only Steps 17, 18 and 19_01 in sequence.
% It intentionally does not run 2023 confirmation, freeze, cases or test.
if nargin<1,settings=struct;end
Results=struct;Results.SelfTests=RevisedCodes_17_19_SelfTests;
s17=stageSettings(settings,'Step17');s18=stageSettings(settings,'Step18');s19=stageSettings(settings,'Step19');
Results.Step17=RevisedCodes_17_01_GenderPooling(s17);
Results.Step18=RevisedCodes_18_01_InningsSelection(s18);
if startsWith(string(Results.Step18.Status),"BLOCKED")
 Results.Step19=struct('Status','NOT_RUN_STEP18_BLOCKED');
 fprintf('Step19 withheld: review the Step18 prerequisite report before interpreting/finalizing scope.\n');
 return;
end
Results.Step19=RevisedCodes_19_01_ContextInterpretation(s19);
fprintf('\nSteps 17-19 development analyses completed.\n');
fprintf('Step17: %s\n',Results.Step17.Status);fprintf('Step18: %s\n',Results.Step18.Status);fprintf('Step19: %s\n',Results.Step19.Status);
end
function s=stageSettings(all,name)
s=struct;if isfield(all,name),s=all.(name);end
allowed=["Step17","Step18","Step19"];unknown=setdiff(string(fieldnames(all)),allowed);
assert(isempty(unknown),'Unknown RunAll setting: %s',strjoin(unknown,', '));
end
