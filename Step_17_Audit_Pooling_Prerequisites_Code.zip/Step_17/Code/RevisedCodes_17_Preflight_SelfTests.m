function Checks = RevisedCodes_17_Preflight_SelfTests
% Lightweight package-level tests that do not require project caches.
names=["Cricket over notation";"Canonical source status";"Par versus target"; ...
    "Event allocation reduction";"Integer wickets";"No automatic evidence promotion"];
passed=false(6,1);
passed(1)=isequal([21 19 0]*6+[3 5 0],[129 119 0]);
passed(2)=lower("VERIFIED")=="verified";
passed(3)=floor(159.7)+1==160;
passed(4)=120>=90 && (120-30)>=(90-30);
passed(5)=all(mod(0:10,1)==0);
passed(6)=~ismember("pending",["verified","not_applicable"]);
Checks=table(names,passed,'VariableNames',{'Check','Passed'});
disp(Checks);assert(all(Checks.Passed),'Preflight self-test failed.');
fprintf('Step17 evidence-preflight self-tests passed.\n');
end
