function Result=RevisedCodes_17D_RunAll(settings)
% Run only this corrected auxiliary stage. Never invoke the old 17--19 runner.
if nargin<1,settings=struct;end
c=RevisedCodes_17D_Config(settings);U=RevisedCodes_17D_Utils;
Checks=RevisedCodes_17D_SelfTests;U.Write(Checks,fullfile(c.Report,'17D_SelfTests.csv'));
Guard=freezeHashes(c);U.Write(Guard,fullfile(c.Report,'17D_FrozenFilesBefore.csv'));
[C,M,Audit,Sources]=RevisedCodes_17D_Data(c);
U.Write(Audit,fullfile(c.Report,'17D_ObservationAudit.csv'));U.Write(Sources,fullfile(c.Report,'17D_SourceHashes.csv'));
Code=table;files=dir(fullfile(fileparts(mfilename('fullpath')),'RevisedCodes_17D_*.m'));
for k=1:numel(files),p=string(fullfile(files(k).folder,files(k).name));Code=[Code;table(p,U.Hash(p),'VariableNames',{'Path','SHA256'})];end %#ok<AGROW>
U.Write(table(string(version),string(computer),'VariableNames',{'MATLABVersion','Platform'}),fullfile(c.Report,'17D_Environment.csv'));
U.Write(Code,fullfile(c.Report,'17D_CodeHashes.csv'));save(fullfile(c.Root,'17D_Protocol.mat'),'c','Sources','Code','-v7.3');
Errors=table;Tuning=table;Coverage=table;Curves=table;Support=table;Models=struct;
for fmt=["ODI","T20"]
 base=M.CacheEligible&M.Format==fmt;
 classes=unique(M.CompetitionClass(base&M.ClassVerified));scopes=["AllEligible";"Class:"+classes(:)];
 for scope=scopes'
  cohort=base;if scope~="AllEligible",cohort=cohort&M.ClassVerified&M.CompetitionClass==extractAfter(scope,"Class:");end
  innerFit=cohort&M.Date<datetime(2019,1,1);innerTest=cohort&year(M.Date)==2019;
  lambda=c.FallbackLambda;mode="Fixed fallback: insufficient 2019 support";best=inf;
  if fitReady(M,innerFit)&&assessmentReady(M,innerTest,10)
   for lam=c.LambdaCandidates(:)'
    model=U.Fit(C,M,innerFit,fmt,lam,c);E=U.Errors(C,M,innerTest,fmt,model,"Inner2019",scope);
    % Tune partial pooling alone, with equal importance for the two genders.
    v=mean([sqrt(mean(E.MSE(E.Model=="Partial"&E.Gender=="men"))),sqrt(mean(E.MSE(E.Model=="Partial"&E.Gender=="women")))]);
    row=table(fmt,scope,lam,v,"2019 partial-only equal-gender RMSE",'VariableNames',{'Format','Scope','Lambda','Criterion','Rule'});Tuning=[Tuning;row]; %#ok<AGROW>
    if v<best,best=v;lambda=lam;end
   end
   mode="Selected using 2019 only";
  else
   row=table(fmt,scope,lambda,NaN,mode,'VariableNames',{'Format','Scope','Lambda','Criterion','Rule'});Tuning=[Tuning;row]; %#ok<AGROW>
  end
  for yr=2020:2022
   fit=cohort&M.Date<datetime(yr,1,1);test=cohort&year(M.Date)==yr;
   ready=fitReady(M,fit)&&assessmentReady(M,test,2);
   row=table(fmt,scope,yr,nnz(fit&M.Gender=="men"),nnz(fit&M.Gender=="women"), ...
    nnz(test&M.Gender=="men"),nnz(test&M.Gender=="women"),ready,lambda,mode, ...
    'VariableNames',{'Format','Scope','Year','FitMen','FitWomen','AssessmentMen','AssessmentWomen','Fitted','Lambda','LambdaRule'});
   Coverage=[Coverage;row]; %#ok<AGROW>
   if ~ready,fprintf('Step17 corrected %s %s %d: insufficient common support; recorded.\n',fmt,scope,yr);continue;end
   assert(max(M.Date(fit))<min(M.Date(test)),'Chronology failure.');
   assert(~any(ismember(M.MatchID(fit),M.MatchID(test))),'Fit/assessment match overlap.');
   fprintf('Step17 corrected %s %s %d: fitting pooled, separate and partial surfaces.\n',fmt,scope,yr);
   model=U.Fit(C,M,fit,fmt,lambda,c);fold="Fold_"+string(yr);
   Errors=[Errors;U.Errors(C,M,test,fmt,model,fold,scope)]; %#ok<AGROW>
   s=model.Support;s.Format=repmat(fmt,height(s),1);s.Scope=repmat(scope,height(s),1);s.Fold=repmat(fold,height(s),1);Support=[Support;s]; %#ok<AGROW>
   Models.(char(fmt)).(matlab.lang.makeValidName(char(scope))).(char(fold))=model;
  end
  if scope=="AllEligible"&&fitReady(M,cohort)
   model=U.Fit(C,M,cohort,fmt,lambda,c);Models.(char(fmt)).DescriptivePre2023=model;
   H=120;if fmt=="ODI",H=300;end
   [u,w]=ndgrid(0:H,0:10);D=struct('U',u(:),'W',w(:));
   for g=["men","women"],for name=["Pooled","PooledShape","Separate","Partial"]
    pred=U.Predict(D,true(numel(u),1),model,name,g);scale=model.PooledScale;
    if name~="Pooled",if g=="men",scale=model.MenScale;else,scale=model.WomenScale;end,end
    q=table(repmat(fmt,numel(u),1),repmat(g,numel(u),1),repmat(name,numel(u),1),u(:),w(:),pred/scale,pred, ...
     'VariableNames',{'Format','Gender','Model','BallsRemaining','WicketsInHand','NormalizedCapacity','ExpectedRemainingRuns'});
    rows=cohort(double(C.MetaRow));ix=double(C.U(rows))+1+(H+1)*double(C.W(rows));
    q.PooledStateCount=accumarray(ix,1,[(H+1)*11,1]);
    rows=rows&M.Gender(double(C.MetaRow))==g;ix=double(C.U(rows))+1+(H+1)*double(C.W(rows));
    q.DirectGenderStateCount=accumarray(ix,1,[(H+1)*11,1]);
    q.NoDirectGenderSupport=q.DirectGenderStateCount==0;Curves=[Curves;q]; %#ok<AGROW>
   end,end
  end
 end
end
U.Write(Coverage,fullfile(c.Report,'17D_FoldCoverage.csv'));
assert(~isempty(Errors),'No evaluable gender folds. Inspect coverage and source eligibility.');
[Scores,Paired]=U.Summarize(Errors,c);
% Coverage is the denominator for interpreting competition-specific results.
ClassCoverage=groupsummary(M(M.CacheEligible,:),{'Format','Gender','CompetitionClass','ClassVerified'});
GenderGaps=genderGaps(Errors,c);
allReady=height(Coverage(Coverage.Scope=="AllEligible",:))==6&&all(Coverage.Fitted(Coverage.Scope=="AllEligible"));
classAny=any(Coverage.Fitted&Coverage.Scope~="AllEligible");
classLabelsComplete=all(M.ClassVerified(M.CacheEligible));
classFoldsComplete=classAny&&all(Coverage.Fitted(Coverage.Scope~="AllEligible"));
After=freezeHashes(c);assert(isequal(Guard,After),'Frozen Step19 files changed during auxiliary run.');
Gates=table(["Canonical pre-states only";"Pre-2023 nonreserved first innings only";"All six overall folds evaluated"; ...
 "At least one within-class comparison available";"All eligible competition labels verified"; ...
 "Step19 frozen file bytes unchanged";"Independent test evaluated by this stage"], ...
 [true;true;allReady;classAny;classLabelsComplete;true;false], ...
 'VariableNames',{'Check','Passed'});
Status="CORRECTED_AUXILIARY_COMPLETE";
if ~allReady,Status="CORRECTED_AUXILIARY_PARTIAL_FOLD_COVERAGE";elseif ~classFoldsComplete||~classLabelsComplete,Status="CORRECTED_AUXILIARY_COMPLETE_COMPETITION_LIMITATIONS";end
notes=["Auxiliary analysis only. Primary Step19 choices and frozen files unchanged."; ...
 "Equivalence margin is exploratory and declared for this correction, not retrospectively preregistered."; ...
 "Within-class comparisons adjust by stratification only; they do not identify a causal gender effect."; ...
 "No 2023 or 2024+ observations used for fitting, tuning, or scoring here."; ...
 "QP positive exit flag and feasibility checks are numerical diagnostics, not a dual certificate."; ...
 "Curves are descriptive pre-2023 refits. Unobserved cells depend on shape/roughness assumptions."; ...
 "Fixed-data bootstrap intervals do not include model-refitting uncertainty or multiplicity adjustment."; ...
 "Old Step17 gender results are superseded; this stage does not alter any target policy."];
Limitations=table(notes,'VariableNames',{'Limitation'});
items={'17D_FoldCoverage',Coverage;'17D_LambdaSelection',Tuning;'17D_MatchErrors',Errors;'17D_Scores',Scores; ...
 '17D_PairedComparisons',Paired;'17D_CompetitionCoverage',ClassCoverage;'17D_GenderErrorGaps',GenderGaps; ...
 '17D_Curves',Curves;'17D_Support',Support;'17D_Gates',Gates;'17D_Limitations',Limitations;'17D_FrozenFilesAfter',After};
for k=1:size(items,1),U.Write(items{k,2},fullfile(c.Report,[items{k,1} '.csv']));end
U.Write(table(Status,'VariableNames',{'Status'}),fullfile(c.Report,'17D_Status.csv'));
RevisedCodes_17D_Figures(Curves,Scores,Paired,Audit,c);
Result=struct('Status',Status,'Config',c,'Scores',Scores,'Paired',Paired,'Gates',Gates,'Models',Models,'Audit',Audit);
save(fullfile(c.Root,'RevisedCodes_17D_Result.mat'),'Result','-v7.3');
% Include observations metadata without state-level outcomes in the audit package.
Inventory=M(M.CacheEligible,{'MatchID','Format','Gender','Date','CompetitionClass','ClassVerified','CanonicalStates','DeliveryRuns'});
U.Write(Inventory,fullfile(c.Report,'17D_EligibleInnings.csv'));
zipPath=fullfile(c.ProjectRoot,'RevisedCodes_17D_Checks.zip');
zip(zipPath,{'reports','figures'},c.Root);
fprintf('\n%s\nUpload %s\n',Status,zipPath);disp(Gates);
end
function tf=fitReady(M,q),tf=nnz(q&M.Gender=="men")>=50&&nnz(q&M.Gender=="women")>=20;end
function tf=assessmentReady(M,q,n),tf=nnz(q&M.Gender=="men")>=n&&nnz(q&M.Gender=="women")>=n;end
function T=freezeHashes(c)
U=RevisedCodes_17D_Utils;d=dir(fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','step19_final','frozen','**','*'));
d=d(~[d.isdir]);T=table(strings(0,1),strings(0,1),'VariableNames',{'Path','SHA256'});
assert(~isempty(d),'Step19 frozen files not found. This correction expects the completed Step19 freeze.');
for j=1:numel(d),p=string(fullfile(d(j).folder,d(j).name));T=[T;table(p,U.Hash(p),'VariableNames',T.Properties.VariableNames)];end %#ok<AGROW>
T=sortrows(T,'Path');
end
function T=genderGaps(E,c)
% Independent gender samples, within-year stratification. Not paired across gender.
T=table;rs=RandStream('mt19937ar','Seed',c.Seed+17);
for fmt=unique(E.Format)',for scope=unique(E.Scope(E.Format==fmt))',for model=unique(E.Model)'
 a=E(E.Format==fmt&E.Scope==scope&E.Model==model,:);m=a(a.Gender=="men",:);w=a(a.Gender=="women",:);
 if height(m)<2||height(w)<2,continue;end
 gain=sqrt(mean(w.MSE))-sqrt(mean(m.MSE));v=zeros(c.BootstrapReplicates,1);
 for r=1:numel(v),v(r)=sqrt(mean(resample(w,rs)))-sqrt(mean(resample(m,rs)));end
 z=prctile(v,[2.5 97.5]);q=table(fmt,scope,model,height(m),height(w),gain,z(1),z(2), ...
  'VariableNames',{'Format','Scope','Model','MenMatches','WomenMatches','WomenMinusMenRMSE','CI95Low','CI95High'});T=[T;q]; %#ok<AGROW>
end,end,end
end
function y=resample(T,rs)
y=zeros(height(T),1);start=0;
for f=unique(T.Fold)',a=T.MSE(T.Fold==f);n=numel(a);y(start+(1:n))=a(randi(rs,n,n,1));start=start+n;end
end
