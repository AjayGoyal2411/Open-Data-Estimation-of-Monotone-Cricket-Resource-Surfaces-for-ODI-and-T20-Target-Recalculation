function Checks=RevisedCodes_17_19_SelfTests
names=["Gender model boundaries";"Partial-pooling endpoints";"Chronological development years"; ...
 "Successful chase censoring label";"Context scale cancellation";"Forecast/resource separation"; ...
 "Reserved-case prohibition";"2023/test prohibition"];
passed=false(numel(names),1);
passed(1)=all(diff([0 .2 .6 1])>=0)&&all([0 .2 .6 1]>=0)&all([0 .2 .6 1]<=1);
passed(2)=0<=0.01&&10>=1;
passed(3)=all((2020:2022)<2023);
passed(4)=contains("successful_censored_descriptive","censored");
g=[.8 1 1.2];passed(5)=max(abs((.3*g)./g-.3))<1e-12;
passed(6)="forecast_only"~="core_resource";
passed(7)=~ismember("case_study",["fit","assessment"]);
passed(8)=all([2023 2024]>2022);
Checks=table(names,passed,'VariableNames',{'Check','Passed'});disp(Checks);
assert(all(Checks.Passed),'Step17-19 support self-test failed.');
fprintf('Step17-19 support self-tests passed.\n');
end
