function Results = RevisedCodes_17_Preflight_RunAll(settings)
% Runs both requested evidence stages. It does not fit or evaluate models.
% Run: Results = RevisedCodes_17_Preflight_RunAll;
if nargin<1,settings=struct;end
Results=struct;
Results.SelfTests=RevisedCodes_17_Preflight_SelfTests;
s17=struct;s09=struct;
if isfield(settings,'Subgroups'),s17=settings.Subgroups;end
if isfield(settings,'Cases'),s09=settings.Cases;end
unknown=setdiff(string(fieldnames(settings)),["Subgroups","Cases"]);
assert(isempty(unknown),'Unknown RunAll setting: %s',strjoin(unknown,', '));
Results.Subgroups=RevisedCodes_17_00_SubgroupPreflight(s17);
Results.Cases=RevisedCodes_09_03B_CaseEvidenceReview(s09);
fprintf('\nEvidence preflight completed. These stages do not inspect case-model outputs.\n');
fprintf('Subgroup status: %s\n',Results.Subgroups.Status);
fprintf('Case status: %s\n',Results.Cases.Status);
end
