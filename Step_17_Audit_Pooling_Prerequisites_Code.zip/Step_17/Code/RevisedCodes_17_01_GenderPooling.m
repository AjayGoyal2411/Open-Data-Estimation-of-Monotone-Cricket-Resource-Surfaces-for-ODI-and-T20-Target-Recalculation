function Result = RevisedCodes_17_01_GenderPooling(settings)
% Development-only pooled/separate/partial-pooling gender assessment.
% 2023 validation, 2024+ test and reserved cases remain unopened.
if nargin<1,settings=struct;end
U=RevisedCodes_17_19_Utils;c=U.Config(settings);[C,M,cacheInfo]=U.StateCache(c);
root=fullfile(c.WorkRoot,'step17');report=fullfile(root,'reports');U.Ensure(report);
selfTest;
foldScores=table;lambdaAudit=table;support=table;curveData=table;targetShift=table;fullModels=struct;
for fmt=["ODI","T20"]
 horizon=120;if fmt=="ODI",horizon=300;end
 base=number(M.InningsIndex)==1&U.Logical(M.ResponseEligible)&number(M.InitialAllocatedBalls)==horizon& ...
  M.CacheEligible&~isnat(M.Date)&M.Date<datetime(2023,1,1);
 % Lambda is selected using only the 2019 inner assessment, before all 2020--22 development folds.
 innerFit=base&M.Date<datetime(2019,1,1);innerAssess=base&M.Date>=datetime(2019,1,1)&M.Date<datetime(2020,1,1);
 chosen=0.1;best=inf;
 if nnz(innerFit&M.Gender=="women")>=20&&nnz(innerAssess&M.Gender=="women")>=10
  for lam=c.LambdaCandidates
   model=U.FitGenderModels(C,M,innerFit,fmt,lam,c);
   sc=U.ScoreGender(C,M,innerAssess,fmt,model,"Inner2019",c);
   value=mean(sc.EqualInningsRMSE,'omitnan');
   lambdaAudit=[lambdaAudit;table(fmt,lam,value,nnz(innerFit),nnz(innerAssess), ...
    'VariableNames',{'Format','Lambda','MeanGenderRMSE','FitInnings','AssessmentInnings'})]; %#ok<AGROW>
   if value<best,best=value;chosen=lam;end
  end
 else
  lambdaAudit=[lambdaAudit;table(fmt,chosen,NaN,nnz(innerFit),nnz(innerAssess), ...
   'VariableNames',{'Format','Lambda','MeanGenderRMSE','FitInnings','AssessmentInnings'})]; %#ok<AGROW>
 end
 for yr=2020:2022
  fit=base&M.Date<datetime(yr,1,1);assess=base&M.Date>=datetime(yr,1,1)&M.Date<datetime(yr+1,1,1);
  model=U.FitGenderModels(C,M,fit,fmt,chosen,c);
  sc=U.ScoreGender(C,M,assess,fmt,model,"Fold_"+string(yr),c);foldScores=[foldScores;sc]; %#ok<AGROW>
  s=model.Support;s.Format=repmat(fmt,height(s),1);s.Fold=repmat("Fold_"+string(yr),height(s),1);support=[support;s]; %#ok<AGROW>
 end
 full=U.FitGenderModels(C,M,base,fmt,chosen,c);fullModels.(char(fmt))=full;
 wickets=[10 7 5 3];balls=unique(round(linspace(0,horizon,31)))';
 for gg=["men","women"]
  for method=["Pooled","Separate","Partial"]
   for ww=wickets
    fake=struct('U',uint16(balls),'W',uint8(repmat(ww,numel(balls),1)));
    rows=true(numel(balls),1);pred=predictSynthetic(fake,rows,full,method,gg);
    curveData=[curveData;table(repmat(fmt,numel(balls),1),repmat(gg,numel(balls),1), ...
     repmat(method,numel(balls),1),repmat(ww,numel(balls),1),balls,pred, ...
     'VariableNames',{'Format','Gender','Model','WicketsInHand','BallsRemaining','ExpectedRemainingRuns'})]; %#ok<AGROW>
   end
  end
 end
 scenarios=[0.25 0.5 0.75].*horizon;
 for uu=scenarios
  for ww=[10 7 5 3]
   rm=full.PartialMen(uu+1,ww+1);rw=full.PartialWomen(uu+1,ww+1);
   targetShift=[targetShift;table(fmt,uu,ww,rm,rw,rw-rm, ...
    full.MenScale*rm,full.WomenScale*rw, ...
    'VariableNames',{'Format','BallsRemaining','WicketsInHand','MenResource','WomenResource', ...
    'ResourceDifference','MenExpectedRuns','WomenExpectedRuns'})]; %#ok<AGROW>
  end
 end
end

taxonomyPath=U.ResolveCSV(c,'17_00_GateChecks.csv','RevisedCodes_17_00_Checks.zip',root);
taxonomy=readtable(taxonomyPath,'TextType','string');classReady=all(logical(taxonomy.Passed));
Gates=table(["Only pre-2023 development data used";"Reserved cases excluded";"2024+ temporal test unopened"; ...
 "Pooled, separate and partial models fitted";"Partial-pooling lambda selected before 2020 folds"; ...
 "Resource boundary/order checks passed";"Competition-adjusted interpretation available"], ...
 [true;~any(U.Logical(M.CaseStudyReserved(M.CacheEligible)));true;true;true;true;classReady], ...
 'VariableNames',{'Check','Passed'});
status="GENDER_ANALYSIS_COMPLETE";if ~classReady,status="UNADJUSTED_GENDER_ANALYSIS_COMPLETE_COMPETITION_REVIEW_PENDING";end
Pending=table(["Competition/event adjustment";"Recovered metadata integration";"2023 confirmation";"2024+ independent test"], ...
 [conditional(classReady,"available","pending 17_00 source review"); ...
  "25 metadata-only records remain excluded";"not opened";"not opened"], ...
 'VariableNames',{'Requirement','Status'});
U.Write(foldScores,fullfile(report,'17_01_FoldScores.csv'));U.Write(lambdaAudit,fullfile(report,'17_01_LambdaSelection.csv'));
U.Write(support,fullfile(report,'17_01_Support.csv'));U.Write(curveData,fullfile(report,'17_01_Curves.csv'));
U.Write(targetShift,fullfile(report,'17_01_TargetShiftScenarios.csv'));U.Write(Gates,fullfile(report,'17_01_GateChecks.csv'));
U.Write(Pending,fullfile(report,'17_01_PendingRequirements.csv'));
fig=figure('Visible','off','Color','w','Position',[100 100 1300 760]);tiledlayout(2,2,'Padding','compact','TileSpacing','compact');
for i=1:2,fmt=["ODI","T20"];fmt=fmt(i);nexttile;plotCurves(curveData,fmt);title(fmt+' partial-pooling resource curves');end
nexttile;plotScores(foldScores);title('Development-fold match-balanced RMSE');
nexttile;plotShift(targetShift);title('Controlled gender resource differences');
figPath=fullfile(report,'F_M17_01_GenderPooling_Preview.png');exportgraphics(fig,figPath,'Resolution',600);close(fig);
tables=string(fullfile(report,{dir(fullfile(report,'*.csv')).name}));pub=U.Publish(c,'Step17_Gender',tables,figPath);
zipPath=fullfile(c.ProjectRoot,'RevisedCodes_17_Checks.zip');files=dir(fullfile(report,'*'));zip(zipPath,{files(~[files.isdir]).name},report);
Result=struct('Status',status,'FoldScores',foldScores,'FullModels',fullModels,'Gates',Gates, ...
 'Cache',cacheInfo,'PublicationPaths',pub,'ReportZIP',string(zipPath));
save(fullfile(root,'RevisedCodes_17_Result.mat'),'Result','-v7.3');
fprintf('Step17 COMPLETE (%s). Upload %s\n',status,zipPath);
end

function p=predictSynthetic(C,rows,M,name,g)
u=double(C.U(rows));w=double(C.W(rows));Umax=120;if M.Format=="ODI",Umax=300;end;idx=u+1+(Umax+1)*w;
switch name
 case "Pooled",R=M.Pooled;s=M.PooledScale;
 case "Separate",if g=="men",R=M.SeparateMen;s=M.MenScale;else,R=M.SeparateWomen;s=M.WomenScale;end
 otherwise,if g=="men",R=M.PartialMen;s=M.MenScale;else,R=M.PartialWomen;s=M.WomenScale;end
end
p=R(idx)*s;
end
function plotCurves(T,fmt)
q=T.Format==fmt&T.Model=="Partial";hold on;styles={'-','--',':','-.'};k=0;
for g=["men","women"],for w=[10 7 5 3],k=k+1;a=q&T.Gender==g&T.WicketsInHand==w;plot(T.BallsRemaining(a),T.ExpectedRemainingRuns(a),styles{mod(k-1,4)+1},'LineWidth',1.3);end,end
grid on;xlabel('Balls remaining');ylabel('Expected remaining runs');legend('Location','bestoutside');
end
function plotScores(T)
q=T.Model=="Partial";G=groupsummary(T(q,:),{'Format','Gender'},'mean','EqualInningsRMSE');bar(G.mean_EqualInningsRMSE);grid on;
set(gca,'XTickLabel',G.Format+" "+G.Gender);xtickangle(30);ylabel('RMSE (runs)');
end
function plotShift(T)
q=T.WicketsInHand==7;g=groupsummary(T(q,:),{'Format'},'mean','ResourceDifference');bar(g.mean_ResourceDifference);grid on;
set(gca,'XTickLabel',g.Format);ylabel('Women minus men resource');
end
function y=number(x),if isnumeric(x),y=double(x);else,y=str2double(string(x));end,end
function y=conditional(tf,a,b),if tf,y=string(a);else,y=string(b);end,end
function selfTest
assert(all([0.01 0.1 1 10]>=0));assert(floor(159.8)+1==160);
end
