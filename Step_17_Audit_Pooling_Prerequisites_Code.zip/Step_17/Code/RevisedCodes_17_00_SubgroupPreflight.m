function Result = RevisedCodes_17_00_SubgroupPreflight(settings)
% Audits gender/format/event/era metadata before Steps 17--19.
% MATLAB R2024b. This stage classifies evidence; it does not fit a model.
% Run: R = RevisedCodes_17_00_SubgroupPreflight;
if nargin < 1, settings = struct; end
cfg = RevisedCodes_09_00_Config;
opt = defaults(settings,cfg);
selfTest;

root = fullfile(cfg.OutputRoot,'step17_preflight'); ensure(root);
report = fullfile(root,'reports'); ensure(report);
inputFolder = fullfile(cfg.ProjectRoot,'Step17_SubgroupReview_Input'); ensure(inputFolder);

eligibilityPath = resolveCSV(cfg,'09_04_SensitivityEligibility.csv','RevisedCodes_09_04_Checks.zip',root);
recoveredPath = resolveCSV(cfg,'09_04_RecoveredMetadata.csv','RevisedCodes_09_04_Checks.zip',root);
retirementPath = resolveCSV(cfg,'09_04_RetirementIntegrity.csv','RevisedCodes_09_04_Checks.zip',root);
E = readtable(eligibilityPath,'TextType','string','VariableNamingRule','preserve');
R = readtable(recoveredPath,'TextType','string','VariableNamingRule','preserve');
H = readtable(retirementPath,'TextType','string','VariableNamingRule','preserve');
requireVars(E,["MatchID","InningsIndex","Format","Gender","Date","Split", ...
    "PrimaryModelEligible","CaseStudyReserved","RecordIntegrityOK"]);
requireVars(R,["MatchID","FormatCanonical","GenderCanonical","InStateCache", ...
    "RawValuesValid","SixBallSchedule","PrimaryPromoted","SensitivityStatus"]);

Inventory = buildInventory(opt.StateManifest);
assert(height(Inventory)>0,'No reconstructed innings found in RevisedCodes_09_Result.mat.');
assert(numel(unique(Inventory.Key))==height(Inventory),'Duplicate reconstructed innings keys.');
for v=["Format","EventName","Team1","Team2","Venue","Split"]
    Inventory.(v)(ismissing(Inventory.(v)))="";
end

% Reconcile the cached innings inventory with the Step 09_04 eligibility ledger.
eKey = string(E.MatchID)+"|"+string(E.InningsIndex);
[found,loc] = ismember(Inventory.Key,eKey);
Inventory.InEligibilityLedger = found;
Inventory.RecordIntegrityOK = false(height(Inventory),1);
Inventory.PrimaryModelEligible = false(height(Inventory),1);
Inventory.CaseStudyReserved = Inventory.CaseReserved;
Inventory.EligibilityRole = repmat("not_in_09_04_ledger",height(Inventory),1);
if any(found)
    Inventory.RecordIntegrityOK(found) = logicalNumber(E.RecordIntegrityOK(loc(found)));
    Inventory.PrimaryModelEligible(found) = logicalNumber(E.PrimaryModelEligible(loc(found)));
    Inventory.CaseStudyReserved(found) = logicalNumber(E.CaseStudyReserved(loc(found)));
    if ismember('SensitivityRole',E.Properties.VariableNames)
        Inventory.EligibilityRole(found) = string(E.SensitivityRole(loc(found)));
    end
end

Inventory.CalendarPeriod = calendarPeriod(Inventory.Date);
EventCatalog = eventCatalog(Inventory);
reviewCSV = fullfile(inputFolder,'17_00_EventClassification_Reviewed.csv');
reviewXLSX = fullfile(inputFolder,'17_00_EventClassification_Reviewed.xlsx');
if ~isfile(reviewCSV) && ~isfile(reviewXLSX)
    Template = EventCatalog(:,{'EventName','Format','Gender','FirstDate','LastDate','Matches','Innings'});
    Template.CompetitionClass = repmat("",height(Template),1);
    Template.ClassificationSource = repmat("",height(Template),1);
    Template.ReviewStatus = repmat("pending",height(Template),1);
    Template.ReviewerNotes = repmat("",height(Template),1);
    writetable(Template,reviewCSV);
    try, writetable(Template,reviewXLSX,'Sheet','EventClassification'); catch, end
end
Mapping = readMapping(reviewCSV,reviewXLSX);
[EventCatalog,Inventory] = applyMapping(EventCatalog,Inventory,Mapping,opt);

GenderLedger = groupedCoverage(Inventory);
RecoveredAudit = recoveredAudit(R);
RetirementAudit = retirementAudit(H);
EraDefinitions = table(["Before2020";"Development2020_2022";"Validation2023";"TemporalTest2024Plus"], ...
    ["date < 2020-01-01";"2020-01-01 <= date < 2023-01-01"; ...
     "2023-01-01 <= date < 2024-01-01";"date >= 2024-01-01"], ...
    repmat("analysis calendar stratum; not claimed as a cricket-rule era",4,1), ...
    'VariableNames',{'CalendarPeriod','Definition','Interpretation'});

unmapped = EventCatalog.EventName~="" & EventCatalog.ReviewStatus~="verified";
badGender = ~ismember(lower(Inventory.Gender),["men","women","male","female","unknown",""]);
odmPromoted = strcmpi(string(R.FormatCanonical),'ODM') & logicalNumber(R.PrimaryPromoted);
recoveredEligible = RecoveredAudit.AuxiliaryReconstructionEligible;
allMapped = ~any(unmapped & EventCatalog.Matches>=opt.MinimumMatchesForRequiredClassification);
Gates = table(["Reconstructed innings inventory is unique"; ...
    "Step09_04 eligibility joins without duplicate keys"; ...
    "Gender labels use declared canonical values"; ...
    "ODM records are not automatically promoted to ODI"; ...
    "Recovered metadata are not silently promoted"; ...
    "High-support event classifications are source-reviewed"], ...
    [true;numel(unique(eKey))==numel(eKey);~any(badGender);~any(odmPromoted); ...
     ~any(logicalNumber(R.PrimaryPromoted));allMapped], ...
    'VariableNames',{'Check','Passed'});

Status = "READY_FOR_SUBGROUP_MODELLING";
if ~all(Gates.Passed), Status = "SOURCE_REVIEW_PENDING"; end
if any(recoveredEligible), Status = Status+"_AUXILIARY_RECONSTRUCTION_AVAILABLE"; end

writetable(Inventory,fullfile(root,'17_00_InningsInventory.csv'));
writetable(EventCatalog,fullfile(report,'17_00_EventClassification.csv'));
writetable(EventCatalog(unmapped,:),fullfile(report,'17_00_UnmappedEvents.csv'));
writetable(GenderLedger,fullfile(report,'17_00_GenderFormatLedger.csv'));
writetable(RecoveredAudit,fullfile(report,'17_00_RecoveredRecordEligibility.csv'));
writetable(RetirementAudit,fullfile(report,'17_00_RetirementIntegritySummary.csv'));
writetable(EraDefinitions,fullfile(report,'17_00_EraDefinitions.csv'));
writetable(Gates,fullfile(report,'17_00_GateChecks.csv'));
Summary = table(Status,height(Inventory),numel(unique(Inventory.MatchID)),height(EventCatalog), ...
    nnz(unmapped),nnz(EventCatalog.ReviewStatus=="verified"),nnz(Inventory.Gender=="women"), ...
    nnz(RecoveredAudit.AuxiliaryReconstructionEligible), ...
    'VariableNames',{'Status','Innings','Matches','Events','UnmappedEvents', ...
    'VerifiedEventMappings','WomenInnings','RecoveredAuxiliaryEligible'});
writetable(Summary,fullfile(report,'17_00_QC_Summary.csv'));

fig = figure('Visible','off','Color','w','Position',[100 100 1200 520]);
tiledlayout(fig,1,2,'Padding','compact','TileSpacing','compact');
nexttile; coveragePlot(GenderLedger); title('Audited innings by format and gender');
nexttile; bar([nnz(EventCatalog.ReviewStatus=="verified"),nnz(unmapped)]); grid on;
set(gca,'XTickLabel',{'Source-reviewed','Pending'}); ylabel('Unique event labels');
title('Competition classification status');
figPath = fullfile(report,'F_S17_00_SubgroupPreflight_Preview.png');
exportgraphics(fig,figPath,'Resolution',600); close(fig);

pubTable=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady','Supplementary','Tables','Step17_Preflight');
pubFigure=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady','Supplementary','Figures','Step17_Preflight');
ensure(pubTable);ensure(pubFigure);
for f=["17_00_EventClassification.csv","17_00_GenderFormatLedger.csv", ...
        "17_00_RecoveredRecordEligibility.csv","17_00_EraDefinitions.csv","17_00_QC_Summary.csv"]
    copyfile(fullfile(report,f),fullfile(pubTable,f));
end
copyfile(figPath,fullfile(pubFigure,'F_S17_00_SubgroupPreflight.png'));

files = dir(fullfile(report,'*')); names = {files(~[files.isdir]).name};
zipPath = fullfile(cfg.ProjectRoot,'RevisedCodes_17_00_Checks.zip');
zip(zipPath,names,report);
Result = struct('Status',Status,'Inventory',Inventory,'EventCatalog',EventCatalog, ...
    'GenderLedger',GenderLedger,'RecoveredAudit',RecoveredAudit,'Gates',Gates, ...
    'InputFolder',string(inputFolder),'ReportFolder',string(report),'ReportZIP',string(zipPath));
save(fullfile(root,'RevisedCodes_17_00_Result.mat'),'Result','-v7.3');
fprintf('17_00 COMPLETE (%s). Upload %s\n',Status,zipPath);
if Status=="SOURCE_REVIEW_PENDING"
    fprintf('Complete %s, then rerun this stage. No event class was guessed.\n',reviewCSV);
end
end

function opt = defaults(s,cfg)
opt = struct('MinimumMatchesForRequiredClassification',20,'ForceInventoryRebuild',false, ...
    'StateManifest',fullfile(cfg.OutputRoot,'RevisedCodes_09_Result.mat'));
assert(isstruct(s)&&isscalar(s),'Settings must be a scalar struct.');
for f=fieldnames(s)'
    assert(isfield(opt,f{1}),'Unknown setting %s.',f{1}); opt.(f{1})=s.(f{1});
end
validateattributes(opt.MinimumMatchesForRequiredClassification,{'numeric'},{'scalar','integer','nonnegative'});
end

function Inventory = buildInventory(manifest)
assert(isfile(manifest),'Missing Step09 state manifest: %s',manifest);
z = load(manifest,'Result'); assert(isfield(z,'Result')&&isfield(z.Result,'Partitions'),'Invalid Step09 manifest.');
P = z.Result.Partitions; assert(ismember('Path',P.Properties.VariableNames),'Partition Path missing.');
Inventory = table(strings(0,1),zeros(0,1),strings(0,1),strings(0,1),NaT(0,1), ...
    strings(0,1),strings(0,1),strings(0,1),strings(0,1),strings(0,1),false(0,1),false(0,1),strings(0,1), ...
    'VariableNames',{'MatchID','InningsIndex','Format','Gender','Date','EventName','Team1','Team2', ...
    'Venue','Split','CaseReserved','PrimaryEligible','Key'});
for k=1:height(P)
    q = load(P.Path(k),'States'); assert(isfield(q,'States'),'States missing from %s',P.Path(k)); S=q.States;
    requireVars(S,["MatchID","InningsIndex","Format","Gender","MatchDate","EventName", ...
        "Team1","Team2","Venue","Split","CaseReserved","PrimaryEligibleObservation","StateType"]);
    take = string(S.StateType)=="initial";
    A = table(string(S.MatchID(take)),double(S.InningsIndex(take)),upper(string(S.Format(take))), ...
        canonicalGender(S.Gender(take)),toDate(S.MatchDate(take)),string(S.EventName(take)), ...
        string(S.Team1(take)),string(S.Team2(take)),string(S.Venue(take)),string(S.Split(take)), ...
        logical(S.CaseReserved(take)),logical(S.PrimaryEligibleObservation(take)), ...
        'VariableNames',Inventory.Properties.VariableNames(1:12));
    A.Key = A.MatchID+"|"+string(A.InningsIndex);
    Inventory = [Inventory;A]; %#ok<AGROW>
end
end

function C = eventCatalog(I)
key = lower(strtrim(I.EventName))+"|"+I.Format+"|"+I.Gender;
[u,~,g] = unique(key,'stable');
C = table(strings(numel(u),1),strings(numel(u),1),strings(numel(u),1),NaT(numel(u),1),NaT(numel(u),1), ...
    zeros(numel(u),1),zeros(numel(u),1),strings(numel(u),1),strings(numel(u),1), ...
    repmat("pending",numel(u),1),strings(numel(u),1), ...
    'VariableNames',{'EventName','Format','Gender','FirstDate','LastDate','Matches','Innings', ...
    'CompetitionClass','ClassificationSource','ReviewStatus','ReviewerNotes'});
for j=1:numel(u)
    a=find(g==j); C.EventName(j)=I.EventName(a(1)); C.Format(j)=I.Format(a(1)); C.Gender(j)=I.Gender(a(1));
    d=I.Date(a); d=d(~isnat(d)); if ~isempty(d),C.FirstDate(j)=min(d);C.LastDate(j)=max(d);end
    C.Matches(j)=numel(unique(I.MatchID(a))); C.Innings(j)=numel(a);
end
end

function M = readMapping(csvPath,xlsxPath)
if isfile(csvPath)
    M=readtable(csvPath,'TextType','string','VariableNamingRule','preserve');
elseif isfile(xlsxPath)
    M=readtable(xlsxPath,'Sheet','EventClassification','TextType','string','VariableNamingRule','preserve');
else
    M=table;
end
if height(M)>0
    requireVars(M,["EventName","Format","Gender","CompetitionClass","ClassificationSource","ReviewStatus"]);
end
end

function [C,I] = applyMapping(C,I,M,opt)
I.CompetitionClass = repmat("unclassified",height(I),1);
I.EventClassificationStatus = repmat("pending",height(I),1);
if isempty(M), return; end
% Spreadsheet blank cells are imported as <missing>, not as empty strings.
% Normalize blanks and common human-readable spellings without inferring a class.
cls=lower(strtrim(string(M.CompetitionClass)));cls(ismissing(cls))="";
cls=regexprep(cls,'[\s-]+','_');
cls(ismember(cls,["domestic","domestic_competition"]))="domestic_other";
cls(cls=="franchise")="domestic_franchise";
review=lower(strtrim(string(M.ReviewStatus)));review(ismissing(review)|review=="")="pending";
source=strtrim(string(M.ClassificationSource));source(ismissing(source))="";
allowed=["international","domestic_franchise","domestic_other","other","unclassified",""];
invalid=~ismember(cls,allowed);
% Invalid nonblank values remain visible and fail the readiness gate; they do
% not abort creation of the audit report or block the independent case stage.
review(invalid)="invalid";
cls(invalid)="unclassified";
M.CompetitionClass=cls;M.ReviewStatus=review;M.ClassificationSource=source;
if ismember('ReviewerNotes',M.Properties.VariableNames)
    notes=string(M.ReviewerNotes);notes(ismissing(notes))="";
    notes(invalid)=strtrim(notes(invalid)+" Invalid CompetitionClass; use international, domestic_franchise, domestic_other, other, or unclassified.");
    M.ReviewerNotes=notes;
end
mk=lower(strtrim(string(M.EventName)))+"|"+upper(strtrim(string(M.Format)))+"|"+canonicalGender(M.Gender);
assert(numel(unique(mk))==numel(mk),'Duplicate event mapping keys.');
ck=lower(strtrim(C.EventName))+"|"+C.Format+"|"+C.Gender;
[found,loc]=ismember(ck,mk);
if any(found)
    C.CompetitionClass(found)=lower(strtrim(string(M.CompetitionClass(loc(found)))));
    C.ClassificationSource(found)=string(M.ClassificationSource(loc(found)));
    C.ReviewStatus(found)=lower(strtrim(string(M.ReviewStatus(loc(found)))));
    if ismember('ReviewerNotes',M.Properties.VariableNames),C.ReviewerNotes(found)=string(M.ReviewerNotes(loc(found)));end
end
verified=C.ReviewStatus=="verified";
badVerified=verified & (C.CompetitionClass=="" | C.CompetitionClass=="unclassified" | C.ClassificationSource=="");
C.ReviewStatus(badVerified)="invalid";
C.ReviewerNotes(badVerified)=strtrim(C.ReviewerNotes(badVerified)+ ...
    " Verified mappings require a substantive class and ClassificationSource.");
ik=lower(strtrim(I.EventName))+"|"+I.Format+"|"+I.Gender;
[found,loc]=ismember(ik,ck);
I.CompetitionClass(found)=C.CompetitionClass(loc(found));
I.EventClassificationStatus(found)=C.ReviewStatus(loc(found));
if any(C.Matches>=opt.MinimumMatchesForRequiredClassification & C.ReviewStatus~="verified")
    % Expected pending gate; no assertion because this stage creates the review template.
end
end

function T = groupedCoverage(I)
key=I.Format+"|"+I.Gender+"|"+I.Split+"|"+I.CalendarPeriod+"|"+I.CompetitionClass;
[u,~,g]=unique(key,'stable');
T=table(strings(numel(u),1),strings(numel(u),1),strings(numel(u),1),strings(numel(u),1), ...
    strings(numel(u),1),zeros(numel(u),1),zeros(numel(u),1),zeros(numel(u),1),zeros(numel(u),1),zeros(numel(u),1), ...
    'VariableNames',{'Format','Gender','Split','CalendarPeriod','CompetitionClass','Matches','Innings', ...
    'PrimaryEligibleInnings','ReservedInnings','IntegrityPassedInnings'});
for j=1:numel(u)
    a=find(g==j); T.Format(j)=I.Format(a(1));T.Gender(j)=I.Gender(a(1));T.Split(j)=I.Split(a(1));
    T.CalendarPeriod(j)=I.CalendarPeriod(a(1));T.CompetitionClass(j)=I.CompetitionClass(a(1));
    T.Matches(j)=numel(unique(I.MatchID(a)));T.Innings(j)=numel(a);
    T.PrimaryEligibleInnings(j)=nnz(I.PrimaryModelEligible(a));T.ReservedInnings(j)=nnz(I.CaseStudyReserved(a));
    T.IntegrityPassedInnings(j)=nnz(I.RecordIntegrityOK(a));
end
end

function A = recoveredAudit(R)
A=R;
A.AuxiliaryReconstructionEligible = logicalNumber(A.RawValuesValid) & logicalNumber(A.SixBallSchedule) & ...
    logicalNumber(A.InStateCache) & ~logicalNumber(A.PrimaryPromoted) & ...
    ismember(upper(string(A.FormatCanonical)),["ODI","T20"]);
A.Decision = repmat("metadata_only_not_integrated",height(A),1);
A.Decision(A.AuxiliaryReconstructionEligible)="eligible_for_auxiliary_reconstruction_only";
A.Decision(logicalNumber(A.PrimaryPromoted))="ERROR_unapproved_primary_promotion";
end

function A = retirementAudit(H)
requireVars(H,["Format","Gender","Split","RetirementWithIntegrityIssue","PrimaryModelEligible"]);
key=upper(string(H.Format))+"|"+canonicalGender(H.Gender)+"|"+string(H.Split);
[u,~,g]=unique(key,'stable');
A=table(strings(numel(u),1),strings(numel(u),1),strings(numel(u),1),zeros(numel(u),1),zeros(numel(u),1),zeros(numel(u),1), ...
    'VariableNames',{'Format','Gender','Split','RetirementEventInnings','IntegrityIssueInnings','PrimaryEligibleInnings'});
for j=1:numel(u)
    a=find(g==j);A.Format(j)=upper(string(H.Format(a(1))));A.Gender(j)=canonicalGender(H.Gender(a(1)));
    A.Split(j)=string(H.Split(a(1)));A.RetirementEventInnings(j)=numel(a);
    A.IntegrityIssueInnings(j)=nnz(logicalNumber(H.RetirementWithIntegrityIssue(a)));
    A.PrimaryEligibleInnings(j)=nnz(logicalNumber(H.PrimaryModelEligible(a)));
end
end

function p = calendarPeriod(d)
p=repmat("MissingDate",numel(d),1);p(d<datetime(2020,1,1))="Before2020";
p(d>=datetime(2020,1,1)&d<datetime(2023,1,1))="Development2020_2022";
p(d>=datetime(2023,1,1)&d<datetime(2024,1,1))="Validation2023";
p(d>=datetime(2024,1,1))="TemporalTest2024Plus";
end

function coveragePlot(T)
keep=ismember(T.Format,["ODI","T20"]);T=T(keep,:);
labels=unique(T.Format+" "+T.Gender,'stable'); y=zeros(numel(labels),1);
for j=1:numel(labels),y(j)=sum(T.Innings(T.Format+" "+T.Gender==labels(j)));end
bar(y);set(gca,'XTick',1:numel(labels),'XTickLabel',labels);xtickangle(30);ylabel('Innings');grid on;
end

function g = canonicalGender(x)
g=lower(strtrim(string(x)));g(ismember(g,["male","m","mens","men's"]))="men";
g(ismember(g,["female","f","womens","women's"]))="women";g(ismissing(g)|g=="")="unknown";
end
function d = toDate(x)
if isdatetime(x),d=x;return;end
d=NaT(numel(x),1);s=string(x);formats=["yyyy-MM-dd","dd-MMM-yyyy","MM/dd/yyyy"];
for f=formats
    take=isnat(d)&~ismissing(s)&s~="";if ~any(take),break;end
    try,d(take)=datetime(s(take),'InputFormat',f);catch,end
end
take=isnat(d)&~ismissing(s)&s~="";if any(take),try,d(take)=datetime(s(take));catch,end,end
end
function v = logicalNumber(x)
if islogical(x),v=x;elseif isnumeric(x),v=isfinite(x)&x~=0;else,v=ismember(lower(strtrim(string(x))),["1","true","yes"]);end
end
function requireVars(T,n)
missing=n(~ismember(n,string(T.Properties.VariableNames)));assert(isempty(missing),'Missing variables: %s',strjoin(missing,', '));
end
function ensure(p),if ~isfolder(p),mkdir(p);end,end
function p = resolveCSV(cfg,name,zipName,root)
d=dir(fullfile(cfg.OutputRoot,'**',name));
if ~isempty(d),[~,k]=max([d.datenum]);p=fullfile(d(k).folder,d(k).name);return;end
z=fullfile(cfg.ProjectRoot,zipName);assert(isfile(z),'Missing %s and %s.',name,z);
cache=fullfile(root,'source_reports');ensure(cache);unzip(z,cache);p=fullfile(cache,name);assert(isfile(p),'%s absent from %s.',name,z);
end
function selfTest
g=canonicalGender(["male";"female";"men";"women"]);assert(isequal(g,["men";"women";"men";"women"]));
d=datetime([2019 2021 2023 2024]',1,1);assert(isequal(calendarPeriod(d),["Before2020";"Development2020_2022";"Validation2023";"TemporalTest2024Plus"]));
assert(isequal(logicalNumber([0;1;2]),[false;true;true]));
x=string(missing);x(ismissing(x))="";assert(x=="");
end
