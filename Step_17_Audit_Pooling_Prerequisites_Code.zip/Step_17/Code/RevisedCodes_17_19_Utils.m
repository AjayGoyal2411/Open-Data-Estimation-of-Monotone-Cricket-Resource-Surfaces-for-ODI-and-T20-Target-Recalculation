function U = RevisedCodes_17_19_Utils
% Shared utilities for development-only Steps 17--19 (MATLAB R2024b).
U.Config=@config; U.StateCache=@stateCache;
U.FitGenderModels=@fitGenderModels; U.FitSingle=@fitSingle;
U.ScoreGender=@scoreGender; U.Predict=@predictRows;
U.ResolveCSV=@resolveCSV; U.Require=@requireVars;
U.Write=@writeTable; U.Ensure=@ensure; U.Logical=@logicalNumber;
U.Number=@number; U.Date=@toDate; U.Publish=@publish;
U.Bootstrap=@bootstrapRMSE;
end

function c=config(settings)
if nargin<1, settings=struct; end
cfg=RevisedCodes_09_00_Config;
c=struct('ProjectRoot',cfg.ProjectRoot,'OutputRoot',cfg.OutputRoot, ...
 'WorkRoot',fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step17_19'), ...
 'StateManifest',fullfile(cfg.OutputRoot,'RevisedCodes_09_Result.mat'), ...
 'RandomSeed',1719,'BootstrapReplicates',500,'Roughness',1e-4, ...
 'LambdaCandidates',[0.01 0.1 1 10],'SupportThreshold',20,'ForceStateCache',false);
for f=fieldnames(settings)'
 assert(isfield(c,f{1}),'Unknown setting %s.',f{1}); c.(f{1})=settings.(f{1});
end
validateattributes(c.BootstrapReplicates,{'numeric'},{'scalar','integer','positive'});
validateattributes(c.LambdaCandidates,{'numeric'},{'vector','finite','nonnegative'});
ensure(c.WorkRoot);
end

function [C,M,info]=stateCache(c)
folder=fullfile(c.WorkRoot,'shared'); ensure(folder);
path=fullfile(folder,'17_19_StateCache.mat');
eligPath=resolveCSV(c,'09_04_SensitivityEligibility.csv','RevisedCodes_09_04_Checks.zip',folder);
sig=struct('Version','17.19.1','Eligibility',stamp(eligPath),'Manifest',stamp(c.StateManifest));
if isfile(path)&&~c.ForceStateCache
 z=load(path,'C','M','info');
 if isfield(z,'info')&&isequaln(z.info.Signature,sig)
  C=z.C; M=z.M; info=z.info; return;
 end
end
M=readtable(eligPath,'TextType','string','VariableNamingRule','preserve');
requireVars(M,["MatchID","InningsIndex","Format","Gender","Date","Split", ...
 "RecordIntegrityOK","CachedStateAvailable","CachedReconstructionPassed", ...
 "CaseStudyReserved","ResponseEligible","InitialAllocatedBalls","BallsPerOver", ...
 "DeliveryRuns","CompletionClass"]);
M.MatchID=string(M.MatchID); M.Format=upper(strtrim(string(M.Format)));
M.Gender=gender(M.Gender); M.Date=toDate(M.Date);
M.Key=M.MatchID+"|"+string(number(M.InningsIndex));
assert(numel(unique(M.Key))==height(M),'Duplicate innings in Step09_04 eligibility ledger.');
M.Target=nan(height(M),1); M.TargetAvailable=false(height(M),1);
[~,~,g]=unique(M.MatchID);
for j=1:max(g)
 a=find(g==j); one=a(number(M.InningsIndex(a))==1); two=a(number(M.InningsIndex(a))==2);
 if numel(one)==1&&~isempty(two)
  base=number(M.DeliveryRuns(one));
  if ismember('PenaltyPre',M.Properties.VariableNames), base=base+max(0,number(M.PenaltyPre(one))); end
  if ismember('PenaltyPost',M.Properties.VariableNames), base=base+max(0,number(M.PenaltyPost(one))); end
  if isfinite(base), M.Target(two)=base+1; M.TargetAvailable(two)=true; end
 end
end
% Do not even cache 2023 validation or 2024+ test outcomes in Steps 17--19.
M.CacheEligible=logicalNumber(M.RecordIntegrityOK)&logicalNumber(M.CachedStateAvailable)& ...
 logicalNumber(M.CachedReconstructionPassed)&~logicalNumber(M.CaseStudyReserved)& ...
 ismember(M.Format,["ODI","T20"])&ismember(M.Gender,["men","women"])&number(M.BallsPerOver)==6& ...
 ~isnat(M.Date)&M.Date<datetime(2023,1,1);
assert(isfile(c.StateManifest),'Missing Step09 state manifest.');
z=load(c.StateManifest,'Result'); P=z.Result.Partitions; requireVars(P,"Path");
meta=cell(height(P),1); u=cell(height(P),1); w=cell(height(P),1);
score=cell(height(P),1); outcome=cell(height(P),1); balls=cell(height(P),1);
for k=1:height(P)
 q=load(P.Path(k),'States'); S=q.States;
 requireVars(S,["MatchID","InningsIndex","BallsRemaining","WicketsInHand", ...
  "DeliveryScoreBefore","FinalDeliveryRuns","LegalBallsBowled"]);
 key=string(S.MatchID)+"|"+string(number(S.InningsIndex)); [found,loc]=ismember(key,M.Key);
 keep=found; keep(found)=M.CacheEligible(loc(found));
 yy=number(S.FinalDeliveryRuns)-number(S.DeliveryScoreBefore);
 keep=keep&isfinite(yy)&yy>=0&number(S.BallsRemaining)>=0& ...
  number(S.WicketsInHand)>=0&number(S.WicketsInHand)<=10;
 meta{k}=uint32(loc(keep)); u{k}=uint16(number(S.BallsRemaining(keep)));
 w{k}=uint8(number(S.WicketsInHand(keep))); score{k}=single(number(S.DeliveryScoreBefore(keep)));
 outcome{k}=single(yy(keep)); balls{k}=uint16(number(S.LegalBallsBowled(keep)));
 fprintf('Step17-19 shared state cache %d/%d\n',k,height(P));
end
C=struct('MetaRow',vertcat(meta{:}),'U',vertcat(u{:}),'W',vertcat(w{:}), ...
 'Score',vertcat(score{:}),'Outcome',vertcat(outcome{:}),'BallsBowled',vertcat(balls{:}));
assert(numel(C.MetaRow)==numel(C.U)&&numel(C.U)==numel(C.Outcome),'State-cache length mismatch.');
info=struct('Signature',sig,'Rows',numel(C.U),'Innings',nnz(M.CacheEligible),'Path',string(path));
save(path,'C','M','info','-v7.3');
end

function Models=fitGenderModels(C,M,metaMask,fmt,lambda,c)
Umax=horizon(fmt); base=metaMask&M.Format==fmt&M.CacheEligible;
men=base&M.Gender=="men"; women=base&M.Gender=="women";
assert(nnz(men)>=50&&nnz(women)>=20,'Insufficient %s gender-specific fitting innings.',fmt);
[sm,wm,mm]=cellData(C,M,men,Umax); [sw,ww,mw]=cellData(C,M,women,Umax);
[sp,wp,mp]=cellData(C,M,base,Umax);
Models=struct('Format',string(fmt),'Lambda',lambda);
Models.Pooled=fitQP(sp,wp,Umax,c.Roughness); Models.PooledScale=mp.Scale;
Models.SeparateMen=fitQP(sm,wm,Umax,c.Roughness); Models.SeparateWomen=fitQP(sw,ww,Umax,c.Roughness);
Models.MenScale=mm.Scale; Models.WomenScale=mw.Scale;
[Models.PartialMen,Models.PartialWomen]=fitJoint(sm,wm,sw,ww,Umax,c.Roughness,lambda);
Models.Support=table(["pooled";"men";"women"],[mp.Innings;mm.Innings;mw.Innings], ...
 [nnz(wp);nnz(wm);nnz(ww)],'VariableNames',{'Group','Innings','SupportedCells'});
end

function Model=fitSingle(C,M,metaMask,fmt,c)
Umax=horizon(fmt); base=metaMask&M.Format==fmt&M.CacheEligible;
[s,w,m]=cellData(C,M,base,Umax);
Model=struct('Format',string(fmt),'Surface',fitQP(s,w,Umax,c.Roughness), ...
 'Scale',m.Scale,'Innings',m.Innings,'SupportedCells',nnz(w));
end

function [sumY,weights,meta]=cellData(C,M,metaMask,Umax)
ids=find(metaMask); assert(~isempty(ids),'Empty fitting cohort.');
flag=false(height(M),1); flag(ids)=true; rows=flag(double(C.MetaRow))&double(C.U)<=Umax;
scale=mean(number(M.DeliveryRuns(ids)),'omitnan'); assert(isfinite(scale)&&scale>0,'Invalid full-start scale.');
idx=double(C.U(rows))+1+(Umax+1)*double(C.W(rows)); n=(Umax+1)*11;
weights=accumarray(idx,1,[n 1],@sum,0);
sumY=accumarray(idx,double(C.Outcome(rows))/scale,[n 1],@sum,0);
meta=struct('Scale',scale,'Innings',numel(ids),'States',nnz(rows));
end

function x=fitQP(sumY,w,Umax,rho)
n=(Umax+1)*11; [A,b,Aeq,beq,D]=constraints(Umax);
H=spdiags(2*w,0,n,n)+2*(rho*max(1,sum(w))/n)*(D'*D)+speye(n)*1e-10;
f=-2*sumY; opts=optimoptions('quadprog','Display','off','Algorithm','interior-point-convex', ...
 'ConstraintTolerance',1e-9,'OptimalityTolerance',1e-9,'MaxIterations',2000);
[x,~,exitflag]=quadprog((H+H')/2,f,A,b,Aeq,beq,zeros(n,1),ones(n,1),[],opts);
assert(exitflag>0&&all(isfinite(x)),'Resource QP failed.'); auditSurface(x,Umax);
x=reshape(x,Umax+1,11);
end

function [xm,xw]=fitJoint(sm,wm,sw,ww,Umax,rho,lambda)
n=(Umax+1)*11; [A,b,Aeq,beq,D]=constraints(Umax);
Hm=spdiags(2*wm,0,n,n)+2*(rho*max(1,sum(wm))/n)*(D'*D)+speye(n)*1e-10;
Hw=spdiags(2*ww,0,n,n)+2*(rho*max(1,sum(ww))/n)*(D'*D)+speye(n)*1e-10;
v=[wm(wm>0);ww(ww>0)]; if isempty(v),strength=0;else,strength=lambda*mean(v);end
K=speye(n); H=blkdiag(Hm,Hw)+2*strength*[K -K;-K K]; f=-2*[sm;sw];
AA=blkdiag(A,A); bb=[b;b]; EE=blkdiag(Aeq,Aeq); ee=[beq;beq];
opts=optimoptions('quadprog','Display','off','Algorithm','interior-point-convex', ...
 'ConstraintTolerance',1e-9,'OptimalityTolerance',1e-9,'MaxIterations',2500);
[x,~,exitflag]=quadprog((H+H')/2,f,AA,bb,EE,ee,zeros(2*n,1),ones(2*n,1),[],opts);
assert(exitflag>0&&all(isfinite(x)),'Partial-pooling QP failed.');
auditSurface(x(1:n),Umax); auditSurface(x(n+1:end),Umax);
xm=reshape(x(1:n),Umax+1,11); xw=reshape(x(n+1:end),Umax+1,11);
end

function [A,b,Aeq,beq,D]=constraints(Umax)
n=(Umax+1)*11; I=[]; J=[]; V=[]; r=0;
for ww=0:10
 for uu=0:Umax-1
  r=r+1; a=index(uu,ww,Umax); q=index(uu+1,ww,Umax);
  I=[I;r;r]; J=[J;a;q]; V=[V;1;-1]; %#ok<AGROW>
 end
end
for ww=0:9
 for uu=0:Umax
  r=r+1; a=index(uu,ww,Umax); q=index(uu,ww+1,Umax);
  I=[I;r;r]; J=[J;a;q]; V=[V;1;-1]; %#ok<AGROW>
 end
end
A=sparse(I,J,V,r,n); b=zeros(r,1);
eq=unique([arrayfun(@(x)index(0,x,Umax),0:10), ...
 arrayfun(@(x)index(x,0,Umax),0:Umax),index(Umax,10,Umax)]);
Aeq=sparse(1:numel(eq),eq,1,numel(eq),n); beq=zeros(numel(eq),1);
beq(eq==index(Umax,10,Umax))=1; D=A;
end

function k=index(u,w,Umax), k=u+1+(Umax+1)*w; end

function auditSurface(x,Umax)
R=reshape(x,Umax+1,11); tol=2e-7;
assert(max(abs(R(1,:)))<tol&&max(abs(R(:,1)))<tol&&abs(R(end,end)-1)<tol,'Boundary failure.');
assert(min(diff(R,1,1),[],'all')>=-tol&&min(diff(R,1,2),[],'all')>=-tol,'Monotonicity failure.');
assert(min(R,[],'all')>=-tol&&max(R,[],'all')<=1+tol,'Range failure.');
end

function T=scoreGender(C,M,metaMask,fmt,Models,fold,c)
names=["Pooled";"Separate";"Partial"]; groups=["men";"women"]; T=table;
for gg=groups'
 ids=find(metaMask&M.Format==fmt&M.Gender==gg&M.CacheEligible); if isempty(ids),continue;end
 flag=false(height(M),1); flag(ids)=true; rows=flag(double(C.MetaRow));
 for name=names'
  pred=predictRows(C,rows,Models,name,gg); obs=double(C.Outcome(rows)); mid=double(C.MetaRow(rows)); err=pred-obs;
  [u,~,loc]=unique(mid); sse=accumarray(loc,err.^2); sae=accumarray(loc,abs(err)); sb=accumarray(loc,err); cnt=accumarray(loc,1);
  [lo,hi]=bootstrapRMSE(sse,cnt,c.BootstrapReplicates,c.RandomSeed+numel(u));
  row=table(string(fold),string(fmt),gg,name,numel(u),numel(obs),sqrt(mean(sse./cnt)), ...
   mean(sae./cnt),mean(sb./cnt),sqrt(mean(err.^2)),mean(abs(err)),mean(err),lo,hi, ...
   'VariableNames',{'Fold','Format','Gender','Model','Innings','States','EqualInningsRMSE', ...
   'EqualInningsMAE','EqualInningsBias','StateRMSE','StateMAE','StateBias','RMSE_CI_Low','RMSE_CI_High'});
  T=[T;row]; %#ok<AGROW>
 end
end
end

function p=predictRows(C,rows,Models,name,gg)
Umax=horizon(Models.Format); u=double(C.U(rows)); w=double(C.W(rows)); idx=u+1+(Umax+1)*w;
switch string(name)
 case "Pooled", R=Models.Pooled; scale=Models.PooledScale;
 case "Separate"
  if gg=="men",R=Models.SeparateMen;scale=Models.MenScale;else,R=Models.SeparateWomen;scale=Models.WomenScale;end
 case "Partial"
  if gg=="men",R=Models.PartialMen;scale=Models.MenScale;else,R=Models.PartialWomen;scale=Models.WomenScale;end
 otherwise,error('Unknown gender model.');
end
p=R(idx)*scale;
end

function [lo,hi]=bootstrapRMSE(sse,n,B,seed)
rng(seed,'twister'); m=numel(sse); v=zeros(B,1);
for b=1:B,q=randi(m,m,1);v(b)=sqrt(mean(sse(q)./n(q)));end
z=prctile(v,[2.5 97.5]);lo=z(1);hi=z(2);
end

function U=horizon(fmt)
if string(fmt)=="ODI",U=300;elseif string(fmt)=="T20",U=120;else,error('Unsupported format.');end
end
function g=gender(x)
g=lower(strtrim(string(x)));g(ismember(g,["male","m","mens","men's"]))="men";
g(ismember(g,["female","f","womens","women's"]))="women";g(ismissing(g)|g=="")="unknown";
end
function d=toDate(x)
if isdatetime(x),d=x;return;end
d=NaT(numel(x),1);s=string(x);fm=["yyyy-MM-dd","dd-MMM-yyyy","MM/dd/yyyy"];
for f=fm
 t=isnat(d)&~ismissing(s)&s~="";if any(t),try,d(t)=datetime(s(t),'InputFormat',f);catch,end,end
end
t=isnat(d)&~ismissing(s)&s~="";if any(t),try,d(t)=datetime(s(t));catch,end,end
end
function v=logicalNumber(x)
if islogical(x),v=x;elseif isnumeric(x),v=isfinite(x)&x~=0;else,v=ismember(lower(strtrim(string(x))),["1","true","yes"]);end
end
function y=number(x),if isnumeric(x),y=double(x);else,y=str2double(string(x));end,end
function requireVars(T,n),n=string(n);m=n(~ismember(n,string(T.Properties.VariableNames)));assert(isempty(m),'Missing variables: %s',strjoin(m,', '));end
function ensure(p),if ~isfolder(p),mkdir(p);end,end
function writeTable(T,p),assert(istable(T),'First argument must be a table.');ensure(fileparts(p));writetable(T,p);end

function p=resolveCSV(c,name,zipName,folder)
d=dir(fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','**',name));
if ~isempty(d),[~,k]=max([d.datenum]);p=fullfile(d(k).folder,d(k).name);return;end
z=fullfile(c.ProjectRoot,zipName);assert(isfile(z),'Missing %s and %s.',name,z);
cache=fullfile(folder,'source_reports');ensure(cache);unzip(z,cache);d=dir(fullfile(cache,'**',name));
assert(~isempty(d),'%s absent from %s.',name,z);p=fullfile(d(1).folder,d(1).name);
end

function paths=publish(c,stage,tables,figs)
base=fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady','Supplementary');
td=fullfile(base,'Tables',stage);fd=fullfile(base,'Figures',stage);ensure(td);ensure(fd);paths=strings(0,1);
for p=string(tables(:))'
 if isfile(p),[~,n,e]=fileparts(p);q=fullfile(td,string(n)+string(e));copyfile(p,q);paths(end+1)=q;end %#ok<AGROW>
end
for p=string(figs(:))'
 if isfile(p),[~,n,e]=fileparts(p);q=fullfile(fd,string(n)+string(e));copyfile(p,q);paths(end+1)=q;end %#ok<AGROW>
end
end
function s=stamp(p),d=dir(p);assert(~isempty(d),'Missing file %s.',p);s=struct('Path',string(p),'Bytes',d.bytes,'Datenum',d.datenum);end
