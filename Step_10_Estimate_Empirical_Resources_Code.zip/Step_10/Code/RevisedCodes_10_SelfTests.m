function Checks=RevisedCodes_10_SelfTests(settings)
% Small real-MATLAB algorithm tests, independent of the Windows partitions.
if nargin<1,settings=struct;end
c=RevisedCodes_10_00_Config(settings);U=RevisedCodes_10_Utils;
assert(exist('quadprog','file')==2&&license('test','Optimization_Toolbox'), ...
 'Optimization Toolbox and quadprog are required for complete Step10.');
L=table([100;200;0],[2;1;1], ...
 'VariableNames',{'DeliveryRuns','CachedPrimaryStates'});
O=struct('Innings',uint32([1;1;2;3]),'u',uint16([100;80;100;100]), ...
 'w',uint8([10;8;10;10]),'Y',[80;20;180;0]);
S=U.Estimate(O,L,"T20",c);k=find(S.Grid.BallsRemaining==100&S.Grid.WicketsInHand==10);
assert(abs(S.FullStartMean-100)<1e-12,'One-total-per-innings normalization failed.');
assert(S.Grid.MatchCount(k)==3&&abs(S.Grid.MeanRunsState(k)-260/3)<1e-12, ...
 'Cell run sufficient statistics failed.');
assert(abs(S.Grid.MeanRunsInnings(k)-88)<1e-12,'Equal-total-innings weighting failed.');
assert(S.Grid.FractionCount(k)==2&&abs(S.Grid.FractionMeanState(k)-.85)<1e-12, ...
 'Mean individual fraction or zero-total exclusion failed.');
assert(abs(S.Grid.RunMeanState(k)-260/300)<1e-12&& ...
 abs(S.Grid.RunMeanState(k)-S.Grid.FractionMeanState(k))>1e-3, ...
 'Mean fractions must remain distinct from ratio-of-means resources.');
assert(S.Grid.MedianRunsState(k)==80&&S.Grid.VarianceRunsState(k)>0,'Median/variance failed.');
assert(all(isnan(S.Grid.RunMeanState(S.Grid.MatchCount==0))),'Unsupported cells filled.');
bad=O;bad.u(2)=100;bad.w(2)=10;mustFail(@()U.Estimate(bad,L,"T20",c));
% A compact synthetic resource grid, exercising the actual QP implementation.
T=S;T.Horizon=6;[u,w]=ndgrid(0:6,0:10);n=numel(u);
target=(u(:)/6).*(w(:)/10);target(20)=1.3;target(40)=-.1;
count=100*ones(n,1);count(25)=0;
T.Grid=table(count,count,ones(n,1),ones(n,1),ones(n,1),target, ...
 'VariableNames',{'MatchCount','FractionCount','InningsWeightSum', ...
 'FractionInningsWeightSum','VarianceRunsState','RunMeanState'});
C=U.Candidates();C=C(1,:);[M,Q]=U.Project(T,C,c);
assert(Q.ExitFlag>0&&U.Residual(M.Resource(:),6)<c.AcceptanceTolerance,'QP constraint check failed.');
assert(M.DataWeights(25)==0,'Unsupported cell assigned data weight.');
assert(abs(sum(M.DataWeights(:))-1)<1e-12,'Projection weights not normalized.');
C.Lambda=.01;[M,Q]=U.Project(T,C,c);
assert(Q.ExitFlag>0&&all(isfinite(M.Resource(:))),'Regularized QP failed.');
C.Lambda=0;[R,~]=U.Alternating(T,C,c);assert(all(isfinite(R(:))),'Alternating diagnostic failed.');
Checks=table(["Full-start normalization";"Cell means and variance";"Innings weighting"; ...
 "Mean fractions and zero totals";"Exact median";"Unsupported cells NaN"; ...
 "Repeated cell match rejected";"QP boundaries/order/range";"Zero unsupported data weight"; ...
 "Regularized QP";"Alternating diagnostic"],true(11,1), ...
 'VariableNames',{'Check','Passed'});disp(Checks);
fprintf('Step10 algorithm self-tests passed.\n');
end
function mustFail(action)
failed=false;try,action();catch,failed=true;end
assert(failed,'Invalid synthetic dataset accepted.');
end
