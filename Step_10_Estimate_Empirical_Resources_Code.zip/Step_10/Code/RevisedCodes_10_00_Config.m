function c=RevisedCodes_10_00_Config(settings)
% Settings for Step10 only. Does not alter the completed Step09 configuration.
if nargin<1,settings=struct;end
c=struct('Version','10.1.0','ForceRebuild',false,'SupportThresholds',[10 30 50 100], ...
 'PrimaryCandidate','mean_state_n30_count_l0','TrimFraction',0.10, ...
 'QPMaxIterations',2000,'QPTolerance',1e-8,'AcceptanceTolerance',2e-7, ...
 'PrecisionFloorQuantile',0.10,'PrecisionAbsoluteFloor',1e-8,'PrecisionCapFactor',100, ...
 'AlternatingMaxIterations',500,'AlternatingTolerance',1e-8);
assert(isstruct(settings)&&isscalar(settings),'Settings must be a scalar struct.');
for n=fieldnames(settings)'
 assert(isfield(c,n{1}),'Unknown Step10 setting %s.',n{1});c.(n{1})=settings.(n{1});
end
validateattributes(c.SupportThresholds,{'numeric'},{'vector','positive','integer','finite'});
assert(all(ismember([10 30 50 100],c.SupportThresholds)), ...
 'Preserve the planned 10/30/50/100 support audits.');
c.SupportThresholds=unique(c.SupportThresholds(:)');
validateattributes(c.ForceRebuild,{'logical'},{'scalar'});
validateattributes(c.TrimFraction,{'numeric'},{'scalar','>=',0,'<',0.5});
assert(c.TrimFraction==0.10,'The named trimmed10 estimand requires TrimFraction=0.10.');
validateattributes(c.QPMaxIterations,{'numeric'},{'scalar','positive','integer'});
validateattributes(c.QPTolerance,{'numeric'},{'scalar','finite','positive'});
validateattributes(c.AcceptanceTolerance,{'numeric'},{'scalar','finite','positive'});
validateattributes(c.PrecisionFloorQuantile,{'numeric'},{'scalar','>',0,'<=',1});
validateattributes(c.PrecisionAbsoluteFloor,{'numeric'},{'scalar','finite','positive'});
validateattributes(c.PrecisionCapFactor,{'numeric'},{'scalar','finite','positive'});
validateattributes(c.AlternatingMaxIterations,{'numeric'},{'scalar','positive','integer'});
validateattributes(c.AlternatingTolerance,{'numeric'},{'scalar','finite','positive'});
end
