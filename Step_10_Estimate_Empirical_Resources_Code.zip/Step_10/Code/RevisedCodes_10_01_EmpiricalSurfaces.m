function Empirical=RevisedCodes_10_01_EmpiricalSurfaces(settings)
% Fit empirical estimates to original train and each permitted fold fit only.
if nargin<1,settings=struct;end
c=RevisedCodes_10_00_Config(settings);U=RevisedCodes_10_Utils;
[cfg,R,D,E,paths]=U.Inputs();
root=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step10');
if ~isfolder(root),mkdir(root);end
out=fullfile(root,'RevisedCodes_10_01_Result.mat');sig=U.Signature("10_01",c,paths);
[reuse,Empirical]=U.Cache(out,'Empirical',sig,c);
if reuse,fprintf('10_01 cache reused. Upload %s\n',Empirical.ReportZIP);return;end
[g,report]=U.Generation(root);
L=E.Ledger;L=L(L.PrimaryModelEligible&L.Split=="train"&~L.CaseStudyReserved,:);
L=sortrows(L,{'MatchID','InningsIndex'});keys=U.Key(L);
assert(numel(unique(keys))==height(L)&&all(L.InningsIndex==1),'Training innings keys invalid.');
assert(all(year(L.Date)<2023)&all(~isnat(L.Date)),'Invalid primary training dates.');
assert(all(L.CachedPrimaryStates>0),'Training innings has no eligible observations.');
obsfile=fullfile(root,'10_TrainingObservations.mat');
obsSig=U.Signature("10_training_observations",struct('ScoreBasis','delivery'),paths);
reuseObs=false;
if isfile(obsfile)
 z=load(obsfile,'ObservationSignature');reuseObs=isequaln(z.ObservationSignature,obsSig);
end
if reuseObs
 z=load(obsfile,'Observations','TrainingLedger');O=z.Observations;
 assert(isequaln(L,z.TrainingLedger),'Observation cache fitting inventory differs.');
 fprintf('Validated training-observation cache reused.\n');
else
 % Preallocation avoids repeatedly concatenating million-row arrays.
 n=sum(L.CachedPrimaryStates);
 O=struct('Innings',zeros(n,1,'uint32'),'u',zeros(n,1,'uint16'), ...
  'w',zeros(n,1,'uint8'),'Y',zeros(n,1));cursor=0;seen=zeros(height(L),1);
 for k=1:height(R.Partitions)
  z=load(R.Partitions.Path(k),'States');S=z.States;
  eligible=S.PrimaryEligibleObservation&S.Split=="train"&~S.CaseReserved;
  [found,ii]=ismember(U.Key(S),keys);assert(all(found(eligible)),'Training state absent from ledger.');
  sel=find(eligible);a=ii(sel);num=numel(sel);slot=cursor+(1:num);
  assert(cursor+num<=n,'Observed training rows exceed audited count.');
  u=S.BallsRemaining(sel);w=S.WicketsInHand(sel);y=S.PrimaryRemainingRuns(sel);
  horizon=120*ones(num,1);horizon(S.Format(sel)=="ODI")=300;
  assert(all(isfinite(u)&u>=0&u<=horizon&u==floor(u)), 'Invalid verified remaining-ball state.');
  assert(all(w>=1&w<=10&w==floor(w))&&all(isfinite(y)&y>=0&y==floor(y)), ...
   'Invalid wicket/outcome state.');
  assert(all(y==S.FinalDeliveryRuns(sel)-S.DeliveryScoreBefore(sel))&& ...
   all(S.FinalDeliveryRuns(sel)==L.DeliveryRuns(a)), 'Outcome/normalization totals do not reconcile.');
  assert(all(S.Format(sel)==L.Format(a)),'Training state format differs.');
  O.Innings(slot)=uint32(a);O.u(slot)=uint16(u);O.w(slot)=uint8(w);O.Y(slot)=y;
  seen=seen+accumarray(a,ones(num,1),[height(L),1],@sum,0);cursor=cursor+num;
  fprintf('Step10 training read %d/%d; eligible states %d\n',k,height(R.Partitions),cursor);
 end
 assert(cursor==n&&isequal(seen,L.CachedPrimaryStates),'Training state populations do not reconcile.');
 assert(isequal(obsSig.Sources,U.Stamps(obsSig.Sources.Path)),'Source changed during training read.');
 ObservationSignature=obsSig;Observations=O;TrainingLedger=L; %#ok<NASGU>
 save(obsfile,'ObservationSignature','Observations','TrainingLedger','-v7.3');
end
cohorts=["FULL_TRAIN";D.Folds.FoldID];
P=table;Summary=table;Support=table;Differences=table;allFull=table;sourceFiles=strings(0,1);
for group=1:numel(cohorts)
 cohort=cohorts(group);cutoff=datetime(2023,1,1);allowed=true(height(L),1);
 if cohort~="FULL_TRAIN"
  j=find(D.Folds.FoldID==cohort);cutoff=D.Folds.AssessmentStart(j);
  M=D.InningsMembership(D.InningsMembership.FoldID==cohort,:);
  allowed=ismember(keys,U.Key(M(M.Role=="fit",:)));
  assert(nnz(allowed)==nnz(M.Role=="fit"),'Fold fitting inventory differs.');
 end
 assert(all(L.Date(allowed)<cutoff),'Forbidden date in empirical fitting set.');
 for format=["ODI","T20"]
  members=find(allowed&L.Format==format);Li=L(members,:);
  [keep,local]=ismember(O.Innings,uint32(members));
  Oi=struct('Innings',uint32(local(keep)),'u',O.u(keep),'w',O.w(keep),'Y',O.Y(keep));
  assert(numel(Oi.Y)==sum(Li.CachedPrimaryStates),'Fold fitting states differ.');
  S=U.Estimate(Oi,Li,format,c);id=cohort+"_"+format;
  S.PackageID=id;S.Cohort=cohort;S.TrainingCutoffExclusive=cutoff;
  Surface=S;p=fullfile(g,char(id+"_Empirical.mat"));save(p,'Surface','-v7.3');
  row=table(id,cohort,format,cutoff,height(Li),numel(Oi.Y),S.FullStartMean,string(p), ...
   'VariableNames',{'PackageID','Cohort','Format','TrainingCutoffExclusive','Innings','States','FullStartMean','Path'});
  P=[P;row]; %#ok<AGROW>
  G=S.Grid;
  Summary=[Summary;table(id,format,height(Li),numel(Oi.Y),S.FullStartMean,S.ZeroTotalInnings, ...
   S.FractionExcludedStates,nnz(G.MatchCount>0),nnz(G.MatchCount==0),nnz(G.RunMeanState>1), ...
   'VariableNames',{'PackageID','Format','Innings','States','FullStartMeanRuns','ZeroTotalInnings', ...
   'FractionExcludedStates','ObservedCells','UnsupportedCells','RawMeanResourceAboveOneCells'})]; %#ok<AGROW>
  for threshold=c.SupportThresholds
   Support=[Support;table(id,threshold,nnz(G.MatchCount>=threshold), ...
    sum(G.StateCount(G.MatchCount>=threshold)),nnz(G.FractionCount>=threshold), ...
    'VariableNames',{'PackageID','MinMatches','SupportedRunCells','StatesInSupportedRunCells','SupportedFractionCells'})]; %#ok<AGROW>
  end
  base=G.RunMeanState;names=["RunMeanInnings","FractionMeanState","FractionMeanInnings","RunMedianState","RunTrimmed10State"];
  for name=names
   v=G.(name);common=G.MatchCount>=30&isfinite(v)&isfinite(base);
   if startsWith(name,"Fraction"),common=common&G.FractionCount>=30;end
   delta=v(common)-base(common);weights=G.MatchCount(common);weights=weights/sum(weights);
   Differences=[Differences;table(id,name,nnz(common),sum(weights.*delta), ...
    sum(weights.*abs(delta)),sqrt(sum(weights.*delta.^2)), ...
    'VariableNames',{'PackageID','Alternative','CommonSupportedCells','SignedDifference','MAE','RMSE'})]; %#ok<AGROW>
  end
  % All underlying cells remain available locally, including unsupported NaN.
  sd=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady','SourceData');
  if ~isfolder(sd),mkdir(sd);end
  p=fullfile(sd,char("10_01_"+id+"_Grid.csv"));writetable(G,p);sourceFiles(end+1,1)=p; %#ok<AGROW>
  if cohort=="FULL_TRAIN"
   G.Format=repmat(format,height(G),1);G.FullStartMeanRuns=repmat(S.FullStartMean,height(G),1);
   allFull=[allFull;G]; %#ok<AGROW>
  end
  fprintf('%s empirical estimates complete (%d innings, %d states)\n',id,height(Li),numel(Oi.Y));
 end
end
writetable(P,fullfile(report,'10_01_PackageManifest.csv'));
writetable(Summary,fullfile(report,'10_01_NormalizationAndSupport.csv'));
writetable(Support,fullfile(report,'10_01_SupportThresholds.csv'));
writetable(Differences,fullfile(report,'10_01_EstimandDifferences.csv'));
Checks=table(["Train-only, cases excluded";"Fold fitting membership and chronology"; ...
 "Observed row populations";"One match per cell";"One outcome per full-start normalization"; ...
 "Unsupported cells missing";"Equal total innings weights"],true(7,1), ...
 'VariableNames',{'Check','Passed'});writetable(Checks,fullfile(report,'10_01_GateChecks.csv'));
Notation=table(["Y";"mu_f";"RunMeanState";"RunMeanInnings";"FractionMeanState"; ...
 "RunMedianState / RunTrimmed10State";"MatchCount"], ...
 ["Final delivery-run total minus pre-state delivery score; penalties separate"; ...
 "Arithmetic mean of one final total per eligible fitting innings"; ...
 "Cell mean remaining runs divided by mu_f"; ...
 "Cell mean with per-state weight 1/eligible states in its innings, divided by mu_f"; ...
 "Cell mean of Y/individual final total; zero-total innings excluded from this estimand"; ...
 "Alternative median/10-percent-per-tail floor-trimmed remaining runs divided by mu_f"; ...
 "Unique fitting matches per cell; equal to state counts here after an explicit uniqueness test"], ...
 'VariableNames',{'Quantity','Definition'});
pub=[U.TableExport(cfg,"Methodology","T_M13_Step10_Estimands",Notation); ...
 U.TableExport(cfg,"Methodology","T_M14_Step10_Normalization",Summary); ...
 U.TableExport(cfg,"Supplementary","T_S10_01_SupportThresholds",Support); ...
 U.TableExport(cfg,"Supplementary","T_S10_01_EstimandDifferences",Differences);sourceFiles;string(obsfile)];
fig=figure('Visible','off','Color','w','Position',[100 100 1300 820]);clean=onCleanup(@()close(fig)); %#ok<NASGU>
tiledlayout(2,3,'TileSpacing','compact','Padding','compact');
capacityLimit=max(1,max(allFull.RunMeanState(isfinite(allFull.RunMeanState))));
supportLimit=max(1,log10(max(allFull.MatchCount)));
deltaLimit=max(1e-6,max(abs(allFull.FractionMeanState(isfinite(allFull.FractionMeanState))- ...
 allFull.RunMeanState(isfinite(allFull.FractionMeanState)))));
for f=1:2
 formats=["ODI","T20"];format=formats(f);B=allFull(allFull.Format==format,:);horizon=max(B.BallsRemaining);
 fields={B.RunMeanState,log10(max(B.MatchCount,1)),B.FractionMeanState-B.RunMeanState};
 titles={'Mean-run resource','Unique-match support (log10)','Mean fraction minus mean-run resource'};
 for j=1:3
  nexttile;value=fields{j};value(B.MatchCount==0)=NaN;
  image=imagesc((0:horizon)/horizon,0:10,reshape(value,horizon+1,11)');
  image.AlphaData=isfinite(image.CData);set(gca,'YDir','normal','Color',[.95 .95 .95]);
  xlabel('Remaining legal-ball fraction');ylabel('Wickets in hand');cb=colorbar;
  if j==1,clim([0 capacityLimit]);cb.Label.String='Normalized remaining runs';
  elseif j==2,clim([0 supportLimit]);cb.Label.String='log10(match count)';
  else,clim([-deltaLimit deltaLimit]);cb.Label.String='Resource difference';end
  title(sprintf('(%c) %s: %s',64+(f-1)*3+j,format,titles{j}));
  set(gca,'FontName','Times New Roman','FontSize',10,'Box','off');
 end
end
pub=[pub;U.FigureExport(cfg,"F_M10_01_EmpiricalSupport",fig,allFull, ...
 "Full-training empirical normalized remaining scoring and unique-match support for ODI (top) and T20 (bottom). Gray cells have no observations. Remaining-run means are divided by an independently estimated full-start training mean; individual fractions are a different estimand. Raw estimates are not clipped to [0,1] or forced monotone. No assessment, validation, test or reserved-case outcome contributes. Cells are correlated across states within matches.",report)];
Empirical=struct('Stage',"10_01",'Status',"EMPIRICAL_READY_SELECTION_PENDING",'Packages',P, ...
 'Summary',Summary,'Support',Support,'Differences',Differences,'Checks',Checks, ...
 'ObservationCache',string(obsfile));
Empirical=U.Finish(cfg,'Empirical',out,sig,g,report,Empirical,pub);
end
