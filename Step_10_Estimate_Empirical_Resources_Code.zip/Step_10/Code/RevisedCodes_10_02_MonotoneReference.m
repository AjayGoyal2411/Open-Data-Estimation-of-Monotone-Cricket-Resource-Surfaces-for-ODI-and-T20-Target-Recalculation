function References=RevisedCodes_10_02_MonotoneReference(settings)
% Constrained QP references. Builds candidates; no accuracy-based selection.
if nargin<1,settings=struct;end
c=RevisedCodes_10_00_Config(settings);U=RevisedCodes_10_Utils;
assert(license('test','Optimization_Toolbox')&&exist('quadprog','file')==2, ...
 'Optimization Toolbox and quadprog required.');
[cfg,~,~,~,paths]=U.Inputs();
root=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step10');
ep=fullfile(root,'RevisedCodes_10_01_Result.mat');assert(isfile(ep),'Run 10_01 first.');
z=load(ep,'Empirical');E=z.Empirical;
assert(isequaln(E.Signature,U.Signature("10_01",c,paths)),'Empirical source/configuration signature differs. Run 10_01 with the same settings.');
assert(all(isfile(E.Packages.Path)),'Missing empirical package.');
paths=[paths;string(ep);E.Packages.Path];sig=U.Signature("10_02",c,paths);
out=fullfile(root,'RevisedCodes_10_02_Result.mat');[reuse,References]=U.Cache(out,'References',sig,c);
if reuse,fprintf('10_02 cache reused. Upload %s\n',References.ReportZIP);return;end
[g,report]=U.Generation(root);C=U.Candidates();
assert(any(C.CandidateID==string(c.PrimaryCandidate)),'Unknown primary display candidate.');
% Display candidate is provisional; it is not the selected final model.
P=table;Diagnostics=table;Alternating=table;displayData=table;sourceFiles=strings(0,1);
for j=1:height(E.Packages)
 z=load(E.Packages.Path(j),'Surface');S=z.Surface;models=cell(height(C),1);
 for k=1:height(C)
  [model,Q]=U.Project(S,C(k,:),c);models{k}=model;
  Q.PackageID=repmat(S.PackageID,height(Q),1);Q.Format=repmat(S.Format,height(Q),1);
  Diagnostics=[Diagnostics;Q]; %#ok<AGROW>
  fprintf('%s reference %d/%d %s; residual %.3g\n',S.PackageID,k,height(C),C.CandidateID(k),Q.MaxConstraintResidual);
 end
 Bundle=struct('PackageID',S.PackageID,'Cohort',S.Cohort,'Format',S.Format, ...
  'TrainingCutoffExclusive',S.TrainingCutoffExclusive,'FullStartMean',S.FullStartMean, ...
  'TrainingInnings',S.TrainingInnings,'TrainingStates',S.TrainingStates, ...
  'Candidates',C,'Models',{models},'Status','CANDIDATES_BUILT_NOT_SELECTED', ...
  'EmpiricalSource',E.Packages.Path(j));
 p=fullfile(g,char(S.PackageID+"_References.mat"));save(p,'Bundle','-v7.3');
 row=E.Packages(j,:);row.Path=string(p);P=[P;row]; %#ok<AGROW>
 if S.Cohort=="FULL_TRAIN"
  baseline=find(C.CandidateID=="mean_state_n30_count_l0");
  [Ra,Qa]=U.Alternating(S,C(baseline,:),c);
  Qqp=Diagnostics(Diagnostics.PackageID==S.PackageID&Diagnostics.CandidateID==C.CandidateID(baseline),:);
  Qa.PackageID=S.PackageID;Qa.Format=S.Format;Qa.QPWeightedAdjustmentMSE=Qqp.WeightedAdjustmentMSE;
  Qa.ObjectiveGapVsQP=Qa.WeightedAdjustmentMSE-Qa.QPWeightedAdjustmentMSE;
  Qa.MaxSurfaceDifferenceVsQP=max(abs(Ra(:)-models{baseline}.Resource(:)));
  Alternating=[Alternating;Qa]; %#ok<AGROW>
  chosen=find(C.CandidateID==string(c.PrimaryCandidate));M=models{chosen};
  G=S.Grid(:,{'BallsRemaining','WicketsInHand','MatchCount','RunMeanState'});
  G.Format=repmat(S.Format,height(G),1);G.ReferenceResource=M.Resource(:);
  G.Supported=M.Supported(:);G.Adjustment=M.Adjustment(:);G.DataWeight=M.DataWeights(:);
  G.CandidateID=repmat(string(c.PrimaryCandidate),height(G),1);
  G.EstimandResource=S.Grid.(char(C.Estimand(chosen)));
  displayData=[displayData;G]; %#ok<AGROW>
 end
 % Numeric grids for every candidate and every cohort are preserved locally.
 sd=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady','SourceData');
 if ~isfolder(sd),mkdir(sd);end
 G=S.Grid(:,{'BallsRemaining','WicketsInHand','MatchCount'});
 for k=1:height(C)
  name=char(C.CandidateID(k));G.([name '_R'])=models{k}.Resource(:);
  G.([name '_Supported'])=models{k}.Supported(:);
  G.([name '_Weight'])=models{k}.DataWeights(:);
 end
 p=fullfile(sd,char("10_02_"+S.PackageID+"_References.csv"));writetable(G,p);sourceFiles(end+1,1)=p; %#ok<AGROW>
end
writetable(P,fullfile(report,'10_02_PackageManifest.csv'));
writetable(C,fullfile(report,'10_02_CandidateDefinitions.csv'));
writetable(Diagnostics,fullfile(report,'10_02_QPDiagnostics.csv'));
writetable(Alternating,fullfile(report,'10_02_AlternatingVsQP.csv'));
Checks=table(["Converged convex quadratic programs";"Exact boundary constraints within tolerance"; ...
 "Nondecreasing balls and wickets";"Range [0,1]";"Unsupported cells have zero data weight"; ...
 "Training and fold-specific empirical inputs";"No final model selected"],true(7,1), ...
 'VariableNames',{'Check','Passed'});writetable(Checks,fullfile(report,'10_02_GateChecks.csv'));
Specification=table(["Objective";"Data weights";"Sparse threshold";"Roughness";"Unsupported cells"; ...
 "Boundary/order";"Solver";"Alternating comparison";"Selection"], ...
 ["Sum normalized weights*(R-empirical estimand)^2 + lambda*mean squared adjacent differences"; ...
 "Count, summed 1/innings-state-count, or safeguarded inverse variance-of-mean; supported weights sum to one"; ...
 "Unique matches per cell; 10/30/50/100 variants"; ...
 "First differences in balls and discrete wickets on the integer grid; a declared grid-specific assumption"; ...
 "Zero observation weight; constrained completion, not additional data; uniqueness not guaranteed for lambda=0"; ...
 "R(0,w)=R(u,0)=0, R(U,10)=1; [0,1]; nondecreasing in u and w; no imposed concavity"; ...
 "quadprog interior-point-convex; exitflag>0 and residual within acceptance tolerance required"; ...
 "Full-training baseline only; finite alternating passes are diagnosed, not assumed globally optimal"; ...
 "All candidates retained; primary display candidate provisional; later development validation selects settings"], ...
 'VariableNames',{'Component','Specification'});
pub=[U.TableExport(cfg,"Methodology","T_M15_MonotoneReferenceSpecification",Specification); ...
 U.TableExport(cfg,"Methodology","T_M16_ReferenceCandidates",C); ...
 U.TableExport(cfg,"Supplementary","T_S10_02_QPDiagnostics",Diagnostics); ...
 U.TableExport(cfg,"Supplementary","T_S10_02_AlternatingVsQP",Alternating);sourceFiles];
fig=figure('Visible','off','Color','w','Position',[100 100 1300 820]);clean=onCleanup(@()close(fig)); %#ok<NASGU>
tiledlayout(2,3,'TileSpacing','compact','Padding','compact');
capacityLimit=max(1,max(displayData.EstimandResource(displayData.Supported)));
deltaLimit=max(1e-6,max(abs(displayData.Adjustment(displayData.Supported))));
for f=1:2
 formats=["ODI","T20"];B=displayData(displayData.Format==formats(f),:);horizon=max(B.BallsRemaining);
 raw=B.EstimandResource;raw(~B.Supported)=NaN;
 fields={raw,B.ReferenceResource,B.Adjustment};titles={'Supported empirical input','Constrained reference','Supported-cell adjustment'};
 for k=1:3
  nexttile;image=imagesc((0:horizon)/horizon,0:10,reshape(fields{k},horizon+1,11)');
  image.AlphaData=isfinite(image.CData);set(gca,'YDir','normal','Color',[.95 .95 .95]);
  xlabel('Remaining legal-ball fraction');ylabel('Wickets in hand');cb=colorbar;
  if k<3,clim([0 capacityLimit]);cb.Label.String='Normalized scoring capacity';
  else,clim([-deltaLimit deltaLimit]);cb.Label.String='Reference minus empirical';end
  title(sprintf('(%c) %s: %s',64+(f-1)*3+k,formats(f),titles{k}));
  set(gca,'FontName','Times New Roman','FontSize',10,'Box','off');
 end
end
pub=[pub;U.FigureExport(cfg,"F_M10_02_MonotoneReference",fig,displayData, ...
 "Supported empirical inputs, constrained references and signed supported-cell adjustments for ODI and T20. Display candidate: "+string(c.PrimaryCandidate)+" (provisional, not performance-selected). Gray empirical/adjustment cells lack required support. Filled reference cells without support are constrained completions, not empirical evidence. Boundaries and monotonicity encode the proposed scoring-capacity interpretation. No independent prediction or target-policy performance is shown.",report)];
References=struct('Stage',"10_02",'Status',"REFERENCES_READY_SELECTION_PENDING",'Packages',P, ...
 'Candidates',C,'Diagnostics',Diagnostics,'Alternating',Alternating,'Checks',Checks, ...
 'PrimaryDisplayCandidate',string(c.PrimaryCandidate));
References=U.Finish(cfg,'References',out,sig,g,report,References,pub);
end
