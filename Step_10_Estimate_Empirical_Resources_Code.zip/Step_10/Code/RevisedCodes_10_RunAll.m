function Results=RevisedCodes_10_RunAll(settings)
% Run complete Step10 at once. No Step09 source/code changes or reruns.
if nargin<1,settings=struct;end
Results=struct;
Results.SelfTests=RevisedCodes_10_SelfTests(settings);
Results.Empirical=RevisedCodes_10_01_EmpiricalSurfaces(settings);
Results.References=RevisedCodes_10_02_MonotoneReference(settings);
cfg=RevisedCodes_09_00_Config;root=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step10');
U=RevisedCodes_10_Utils;[g,~]=U.Generation(fullfile(root,'combined_checks'));
copyfile(Results.Empirical.ReportDirectory,fullfile(g,'10_01'));
copyfile(Results.References.ReportDirectory,fullfile(g,'10_02'));
writetable(Results.SelfTests,fullfile(g,'10_AlgorithmSelfTests.csv'));
Gate=table(["Empirical packages";"Constrained candidate references";"Model settings selected"; ...
 "Independent prediction evaluated";"Interruption target policy evaluated"], ...
 [true;true;false;false;false], ...
 'VariableNames',{'Stage','Complete'});writetable(Gate,fullfile(g,'10_CompletionStatus.csv'));
combined=fullfile(cfg.ProjectRoot,'RevisedCodes_10_Checks.zip');
zip(combined,{'10_01','10_02','10_AlgorithmSelfTests.csv','10_CompletionStatus.csv'},g);
Results.CombinedChecks=string(combined);disp(Gate);
fprintf('STEP10 COMPLETE. Upload %s. Next: shared resource interface and model fitting.\n',combined);
end
