function U=RevisedCodes_10_Utils
U.Inputs=@inputs;U.Stamps=@stamps;U.Signature=@signature;U.Cache=@cache;
U.Generation=@generation;U.Finish=@finish;U.Key=@key;U.Estimate=@estimate;
U.Project=@project;U.Candidates=@candidates;U.Alternating=@alternating;
U.Constraints=@constraints;U.Residual=@residual;U.TableExport=@tableExport;
U.FigureExport=@figureExport;U.WeightTarget=@weightTarget;
end
function [cfg,R,D,E,paths]=inputs
cfg=RevisedCodes_09_00_Config;
rp=fullfile(cfg.OutputRoot,'RevisedCodes_09_Result.mat');
dp=fullfile(cfg.OutputRoot,'development_context','RevisedCodes_09_02A_Result.mat');
ep=fullfile(cfg.OutputRoot,'exceptional_audit','RevisedCodes_09_04_Result.mat');
gp=fullfile(cfg.OutputRoot,'readiness09','RevisedCodes_09_05_Result.mat');
assert(all(isfile(string({rp,dp,ep,gp}))),'Completed Step09 manifests required.');
z=load(rp,'Result');R=z.Result;z=load(dp,'Development');D=z.Development;
z=load(ep,'Exceptional');E=z.Exceptional;z=load(gp,'Readiness');G=z.Readiness;
assert(G.CoreReady&&E.PrimaryReady&&all(E.Checks.Passed),'Step09 core readiness gate failed.');
assert(isequal(D.Signature.Config,cfg),'Step09 configuration changed.');
assert(all(isfile(R.Partitions.Path))&&all(isfile(D.Partitions.Path)),'Required cached partitions missing.');
for n=["StateManifest","ContextManifest"]
 a=D.Signature.(n);live=stamps(a.Path);
 assert(live.Bytes==a.Bytes&&live.Modified==a.Modified,'09_02A source manifest changed.');
end
for n=["StatePartitions","ContextPartitions"]
 a=D.Signature.(n);assert(isequal(a,stamps(a.Path)),'09_02A source partitions changed.');
end
legacy=strings(0,1);
for n=["Delivery","Prerequisite","Corrections"]
 a=R.Signature.(n);live=stamps(a.Path);
 assert(live.Bytes==a.Bytes&&live.Modified==a.Modified,'09_01 %s source changed.',n);
 legacy(end+1,1)=a.Path; %#ok<AGROW>
end
% Independent consistency between exported fitting inventories and folds.
L=E.Ledger;primary=L.PrimaryModelEligible;
assert(all(L.CachedPrimary(primary)&L.VerifiedRaw(primary)&~L.CaseStudyReserved(primary)), ...
 'Invalid primary fitting inventory.');
assert(all(ismember(L.Format(primary),["ODI","T20"]))&&all(L.BallsPerOver(primary)==6)&& ...
 all(L.InitialAllocatedBalls(primary)==L.NominalBalls(primary))&& ...
 all(L.CachedInitialBalls(primary)==L.NominalBalls(primary)), ...
 'Primary format/allocation contract differs from standard completed innings.');
for j=1:height(D.Folds)
 id=D.Folds.FoldID(j);M=D.InningsMembership(D.InningsMembership.FoldID==id,:);
 H=D.HistorySourceLedger(D.HistorySourceLedger.FoldID==id,:);fit=M.Role=="fit";
 assert(all(H.SourceDate<D.Folds.AssessmentStart(j))&& ...
  all(ismember(key(H),key(M(fit,:)))),'Forbidden fold source.');
 assert(all(M.Date(fit)<D.Folds.AssessmentStart(j)),'Invalid fold fitting dates.');
end
paths=[string(rp);string(dp);string(ep);string(gp);R.Partitions.Path;legacy];
end
function k=key(T)
k=string(T.MatchID)+"|"+string(T.InningsIndex);
end
function T=stamps(paths)
paths=string(paths(:));bytes=zeros(numel(paths),1);modified=bytes;
for j=1:numel(paths)
 d=dir(paths(j));assert(numel(d)==1&&~d.isdir,'Missing source %s.',paths(j));
 bytes(j)=d.bytes;modified(j)=d.datenum;
end
T=table(paths,bytes,modified,'VariableNames',{'Path','Bytes','Modified'});
end
function S=signature(stage,c,paths)
S=struct('Stage',stage,'Settings',c,'Sources',stamps(paths),'CodeFiles',table);
names=["RevisedCodes_10_00_Config","RevisedCodes_10_Utils","RevisedCodes_10_01_EmpiricalSurfaces", ...
 "RevisedCodes_10_02_MonotoneReference","RevisedCodes_10_SelfTests"];
for n=names
 p=which(char(n));assert(~isempty(p),'Missing Step10 code %s.',n);
 S.CodeFiles=[S.CodeFiles;table(string(p),string(fileread(p)),'VariableNames',{'Path','Content'})]; %#ok<AGROW>
end
end
function [yes,D]=cache(out,var,S,c)
yes=false;D=struct;if ~isfile(out)||c.ForceRebuild,return;end
z=load(out,var);if ~isfield(z,var),return;end
D=z.(var);yes=isequaln(D.Signature,S)&&all(isfile(D.ArtifactPaths))&& ...
 all(isfile(D.Packages.Path))&&isfile(D.ReportZIP);
end
function [g,r]=generation(root)
ensure(root);id=javaMethod('randomUUID','java.util.UUID');id=char(id.toString);
g=fullfile(root,['generation_' char(datetime('now','Format','yyyyMMdd_HHmmss_SSS')) '_' id(1:8)]);
ensure(g);r=fullfile(g,'reports');ensure(r);
end
function ensure(p)
if ~isfolder(p),mkdir(p);end
end
function D=finish(cfg,var,out,S,g,r,D,pub)
assert(isequal(S.Sources,stamps(S.Sources.Path)),'Step10 sources changed during execution.');
for j=1:height(S.CodeFiles)
 assert(S.CodeFiles.Content(j)==string(fileread(S.CodeFiles.Path(j))),'Step10 code changed during execution.');
end
files=dir(fullfile(r,'*'));files=files(~[files.isdir]);names={files.name};
z=fullfile(cfg.ProjectRoot,char("RevisedCodes_"+D.Stage+"_Checks.zip"));zip(z,names,r);
D.Signature=S;D.Generation=string(g);D.ReportDirectory=string(r);D.ReportZIP=string(z);
D.ArtifactPaths=[string(fullfile(r,names))';string(pub(:))];
container=struct;container.(var)=D;save(out,'-struct','container','-v7.3');
fprintf('%s COMPLETE. Upload %s\n',D.Stage,z);
end
function Surface=estimate(O,L,format,c)
U=120;if format=="ODI",U=300;end
n=(U+1)*11;idx=sub2ind([U+1,11],double(O.u)+1,double(O.w)+1);
% Exactly one legal pre-state at a particular u,w per match/innings.
assert(size(unique([double(O.Innings),idx],'rows'),1)==numel(idx), ...
 'Repeated match in a cell: unique-match support must be computed explicitly.');
y=double(O.Y);a=1./double(L.CachedPrimaryStates(double(O.Innings)));
N=accumarray(idx,1,[n,1],@sum,0);sy=accumarray(idx,y,[n,1],@sum,0);
sy2=accumarray(idx,y.^2,[n,1],@sum,0);aw=accumarray(idx,a,[n,1],@sum,0);
aw2=accumarray(idx,a.^2,[n,1],@sum,0);
ay=accumarray(idx,a.*y,[n,1],@sum,0);ay2=accumarray(idx,a.*y.^2,[n,1],@sum,0);
mu=mean(L.DeliveryRuns);assert(isfinite(mu)&&mu>0,'Invalid full-start delivery-run normalization.');
means=divide(sy,N);weighted=divide(ay,aw);neff=divide(aw.^2,aw2);
varState=divide(max(0,sy2-divide(sy.^2,N)),N-1);varState(N<2)=NaN;
vPopulation=max(0,divide(ay2,aw)-weighted.^2);
varInnings=vPopulation.*divide(neff,neff-1);varInnings(neff<=1)=NaN;
total=L.DeliveryRuns(double(O.Innings));fraction=nan(size(y));good=total>0;
fraction(good)=y(good)./total(good);
nf=accumarray(idx(good),ones(nnz(good),1),[n,1],@sum,0);
sf=accumarray(idx(good),fraction(good),[n,1],@sum,0);
sf2=accumarray(idx(good),fraction(good).^2,[n,1],@sum,0);
af=accumarray(idx(good),a(good),[n,1],@sum,0);
af2=accumarray(idx(good),a(good).^2,[n,1],@sum,0);
afy=accumarray(idx(good),a(good).*fraction(good),[n,1],@sum,0);
medianY=accumarray(idx,y,[n,1],@median,NaN);
trimY=accumarray(idx,y,[n,1],@(v)trimmed(v,c.TrimFraction),NaN);
[u,w]=ndgrid(0:U,0:10);
Grid=table(u(:),w(:),N,N,sy,sy2,aw,aw2,ay,ay2,neff,means,weighted, ...
 varState,varInnings,nf,sf,sf2,af,af2,divide(sf,nf),divide(afy,af), ...
 medianY,trimY,means/mu,weighted/mu,medianY/mu,trimY/mu, ...
 'VariableNames',{'BallsRemaining','WicketsInHand','StateCount','MatchCount','SumY','SumY2', ...
 'InningsWeightSum','InningsWeightSquaredSum','WeightedSumY','WeightedSumY2','EffectiveInningsWeightN', ...
 'MeanRunsState','MeanRunsInnings','VarianceRunsState','VarianceRunsInnings','FractionCount','SumFraction', ...
 'SumFraction2','FractionInningsWeightSum','FractionInningsWeightSquaredSum','FractionMeanState', ...
 'FractionMeanInnings','MedianRunsState','Trimmed10RunsState','RunMeanState','RunMeanInnings', ...
 'RunMedianState','RunTrimmed10State'});
assert(sum(N)==numel(y)&&sum(sy)==sum(y),'Empirical sufficient statistics do not reconcile.');
assert(abs(sum(aw)-height(L))<1e-7*max(1,height(L)),'Equal-total-innings weighting does not reconcile.');
assert(all(isnan(means(N==0)))&&all(isnan(Grid.FractionMeanState(nf==0))), ...
 'Unsupported empirical cells must remain missing.');
Surface=struct('Format',format,'Horizon',U,'Grid',Grid,'FullStartMean',mu, ...
 'TrainingInnings',height(L),'TrainingStates',numel(y),'ZeroTotalInnings',nnz(L.DeliveryRuns==0), ...
 'FractionExcludedStates',nnz(~good),'TrainingLedger',L, ...
 'Normalization','one final delivery-run total per eligible fitting innings; arithmetic mean', ...
 'Estimands','run means divided by full-start mean; fractions use individual final totals as labels; medians/trimmed means are alternatives', ...
 'Support','unique matches equals legal pre-state counts within a cell, explicitly tested; across cells states remain correlated');
end
function v=divide(a,b)
v=nan(size(a));good=isfinite(b)&b>0;v(good)=a(good)./b(good);
end
function v=trimmed(y,p)
y=sort(y);k=floor(p*numel(y));v=mean(y(k+1:end-k));
end
function C=candidates
names=["mean_state_n30_count_l0";"mean_state_n10_count_l0";"mean_state_n50_count_l0"; ...
 "mean_state_n100_count_l0";"mean_state_n30_innings_l0";"mean_state_n30_precision_l0"; ...
 "mean_state_n30_count_l001";"mean_state_n30_count_l01";"mean_innings_n30_innings_l0"; ...
 "fraction_state_n30_count_l0";"fraction_innings_n30_innings_l0"; ...
 "median_state_n30_count_l0";"trimmed10_state_n30_count_l0"];
estimand=[repmat("RunMeanState",8,1);"RunMeanInnings";"FractionMeanState"; ...
 "FractionMeanInnings";"RunMedianState";"RunTrimmed10State"];
weights=[repmat("count",4,1);"innings";"precision";"count";"count";"innings";"count";"innings";"count";"count"];
C=table(names,estimand,[30;10;50;100;30;30;30;30;30;30;30;30;30],weights, ...
 [zeros(6,1);0.01;0.1;zeros(5,1)], ...
 'VariableNames',{'CandidateID','Estimand','MinMatches','Weighting','Lambda'});
end
function [A,lb,ub,x0]=constraints(U)
G=reshape(1:(U+1)*11,U+1,11);n=numel(G);
from=[reshape(G(1:end-1,:),[],1);reshape(G(:,1:end-1),[],1)];
to=[reshape(G(2:end,:),[],1);reshape(G(:,2:end),[],1)];r=(1:numel(from))';
A=sparse([r;r],[from;to],[ones(size(r));-ones(size(r))],numel(r),n);
lb=zeros(n,1);ub=ones(n,1);anchors=unique([G(1,:)';G(:,1)]);ub(anchors)=0;
lb(G(end,end))=1;ub(G(end,end))=1;
[u,w]=ndgrid(0:U,0:10);x0=(u(:)/U).*(w(:)/10);
end
function [target,weights,supported,floorUsed]=weightTarget(S,C,c)
G=S.Grid;target=G.(char(C.Estimand));fraction=startsWith(C.Estimand,"Fraction");
count=G.MatchCount;if fraction,count=G.FractionCount;end
supported=count>=C.MinMatches&isfinite(target);
floorUsed=NaN;
switch C.Weighting
 case 'count'
  weights=count;
 case 'innings'
  weights=G.InningsWeightSum;if fraction,weights=G.FractionInningsWeightSum;end
 case 'precision'
  assert(C.Estimand=="RunMeanState",'Precision weighting implemented for the run-mean estimand only.');
  v=G.VarianceRunsState./max(G.MatchCount,1)/(S.FullStartMean^2);
  positive=sort(v(supported&isfinite(v)&v>0));
  floorUsed=c.PrecisionAbsoluteFloor;
  if ~isempty(positive),floorUsed=max(floorUsed,positive(max(1,ceil(c.PrecisionFloorQuantile*numel(positive)))));end
  v(~isfinite(v)|v<floorUsed)=floorUsed;weights=1./v;
  if any(supported),weights=min(weights,c.PrecisionCapFactor*median(weights(supported)));end
 otherwise
  error('Unknown weighting.');
end
weights(~supported)=0;assert(any(weights>0),'No supported cells for this candidate.');
weights=weights/sum(weights);target(~isfinite(target))=0;
end
function [Model,Q]=project(S,C,c)
[target,weights,supported,floorUsed]=weightTarget(S,C,c);
[A,lb,ub,x0]=constraints(S.Horizon);n=numel(target);
H=2*(spdiags(weights,0,n,n)+C.Lambda*(A'*A)/size(A,1));f=-2*weights.*target;
opt=optimoptions('quadprog','Algorithm','interior-point-convex','Display','off', ...
 'MaxIterations',c.QPMaxIterations,'ConstraintTolerance',c.QPTolerance,'OptimalityTolerance',c.QPTolerance);
t=tic;[x,~,flag,output]=quadprog(H,f,A,zeros(size(A,1),1),[],[],lb,ub,x0,opt);elapsed=toc(t);
assert(flag>0&&~isempty(x)&&all(isfinite(x)),'QP did not converge: %s, flag %d.',C.CandidateID,flag);
violation=residual(x,S.Horizon);
assert(violation<=c.AcceptanceTolerance,'QP constraint residual too large: %.3g.',violation);
data=sum(weights.*(x-target).^2);penalty=C.Lambda*mean((A*x).^2);
initialObjective=sum(weights.*(x0-target).^2)+C.Lambda*mean((A*x0).^2);
firstOrder=NaN;if isfield(output,'firstorderopt'),firstOrder=output.firstorderopt;end
adjustment=x-target;adjustment(~supported)=NaN;
Model=struct('Candidate',C,'Resource',reshape(x,S.Horizon+1,11),'Supported',reshape(supported,S.Horizon+1,11), ...
 'DataWeights',reshape(weights,S.Horizon+1,11),'Adjustment',reshape(adjustment,S.Horizon+1,11), ...
 'Format',S.Format,'Horizon',S.Horizon,'FullStartMean',S.FullStartMean, ...
 'Interpretation','independently estimated normalized scoring-capacity reference; not an official DL/DLS table', ...
 'CompletionAssumption','zero-weight unsupported cells; lambda=0 completion may not be uniquely identified; lambda>0 uses declared first-difference roughness', ...
 'TargetPolicy','not implemented in Step10');
Model.OptimizerOutput=output;
Q=table(C.CandidateID,C.Estimand,C.MinMatches,C.Weighting,C.Lambda,nnz(supported),nnz(~supported), ...
 data,penalty,data+penalty,max(abs(adjustment(supported))),violation,flag,output.iterations,elapsed,floorUsed, ...
 initialObjective,initialObjective-data-penalty,firstOrder, ...
 'VariableNames',{'CandidateID','Estimand','MinMatches','Weighting','Lambda','SupportedCells','UnsupportedCells', ...
 'WeightedAdjustmentMSE','RoughnessPenalty','TotalObjective','MaxSupportedAdjustment', ...
 'MaxConstraintResidual','ExitFlag','Iterations','Seconds','PrecisionVarianceFloor', ...
 'InitialFeasibleObjective','ObjectiveReductionVsInitial','SolverFirstOrderOptimality'});
end
function v=residual(x,U)
R=reshape(x,U+1,11);
v=max([0;-x(:);x(:)-1;-reshape(diff(R,1,1),[],1); ...
 -reshape(diff(R,1,2),[],1);abs(R(1,:))';abs(R(:,1));abs(R(end,end)-1)]);
end
function [R,Q]=alternating(S,C,c)
assert(C.Lambda==0,'Alternating diagnostic excludes roughness penalties.');
[target,weights,supported]=weightTarget(S,C,c);U=S.Horizon;
[~,~,~,initial]=constraints(U);x=initial;x(supported)=target(supported);
R=reshape(x,U+1,11);W=reshape(weights,U+1,11);R=anchors(R);
previous=Inf;converged=false;t=tic;
for iteration=1:c.AlternatingMaxIterations
 old=R;
 for w=1:11,R(:,w)=pava(R(:,w),W(:,w));end
 R=anchors(R);
 for u=1:U+1,R(u,:)=pava(R(u,:)',W(u,:)')';end
 R=anchors(R);objective=sum(weights.*(R(:)-target).^2);
 change=max(abs(R(:)-old(:)));
 if change<c.AlternatingTolerance&&abs(previous-objective)<c.AlternatingTolerance
  converged=true;break;
 end
 previous=objective;
end
Q=table(iteration,converged,objective,change,residual(R(:),U),toc(t), ...
 'VariableNames',{'Iterations','Converged','WeightedAdjustmentMSE','MaxChange','MaxConstraintResidual','Seconds'});
end
function R=anchors(R)
R=min(max(R,0),1);R(1,:)=0;R(:,1)=0;R(end,end)=1;
end
function out=pava(y,w)
% Weighted 1D monotone projection; zero-weight blocks use an explicit tie rule.
n=numel(y);level=zeros(n,1);mass=level;numerator=level;tieSum=level;count=level;ends=level;k=0;
for j=1:n
 k=k+1;level(k)=y(j);mass(k)=w(j);numerator(k)=w(j)*y(j);
 tieSum(k)=y(j);count(k)=1;ends(k)=j;
 while k>1&&level(k-1)>level(k)
  mass(k-1)=mass(k-1)+mass(k);numerator(k-1)=numerator(k-1)+numerator(k);
  tieSum(k-1)=tieSum(k-1)+tieSum(k);count(k-1)=count(k-1)+count(k);ends(k-1)=ends(k);
  if mass(k-1)>0,level(k-1)=numerator(k-1)/mass(k-1);
  else,level(k-1)=tieSum(k-1)/count(k-1);end
  k=k-1;
 end
end
out=zeros(n,1);start=1;
for j=1:k,out(start:ends(j))=level(j);start=ends(j)+1;end
end
function paths=tableExport(cfg,section,name,T)
root=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady',char(section),'Tables');ensure(root);
base=fullfile(root,char(string(name)));paths=string({[base '.csv'],[base '.xlsx']})';
writetable(T,paths(1));writetable(T,paths(2));
end
function paths=figureExport(cfg,name,fig,data,caption,report)
pub=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady');
folder=fullfile(pub,'Methodology','Figures');sd=fullfile(pub,'SourceData');ci=fullfile(pub,'CaptionsAndIndex');
for p=string({folder,sd,ci}),ensure(p);end
base=fullfile(folder,char(string(name)));
paths=string({[base '.png'],[base '.pdf'],[base '.fig'],fullfile(sd,char(string(name)+".csv")), ...
 fullfile(ci,char(string(name)+"_Caption.csv"))})';
exportgraphics(fig,paths(1),'Resolution',600);exportgraphics(fig,paths(2),'ContentType','vector');savefig(fig,paths(3));
writetable(data,paths(4));writetable(table(string(name),string(caption), ...
 'VariableNames',{'Asset','Caption'}),paths(5));
exportgraphics(fig,fullfile(report,char(string(name)+"_Preview.png")),'Resolution',100);
end
