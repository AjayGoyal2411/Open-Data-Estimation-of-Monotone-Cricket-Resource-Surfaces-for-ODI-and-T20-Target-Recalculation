function Checks=RevisedCodes_12_ContextSelfTests(settings)
if nargin<1,settings=struct;end
c=RevisedCodes_12_00_Config(settings);W=RevisedCodes_12_ContextUtils;
F=table([120;80;40;10],[10;8;5;2],[0;30;60;90],[0;10;5;20], ...
 'VariableNames',{'BallsRemaining','WicketsInHand','ScoreBefore','LegalBallsSinceDismissal'});
F.NoDismissalYet=[true;false;false;false];F.RetiredNotOutEventsBefore=zeros(4,1);
F.RunRateBefore=[NaN;4.5;4.5;4.9];F.Recent30RunRate=[NaN;5;6;7];
F.Recent30Runs=[0;25;30;35];F.Recent30LegalBalls=[0;30;30;30];F.NoLegalBallYet=[true;false;false;false];
F.Venue=["A";"A";"B";"NEW"];F.EventName=["E";"E";"E";"NEW"];
for entity=["Format","Batting","Opponent","Venue","Event"]
 F.("History"+entity+"N")=[0;2;4;8];F.("History"+entity+"Mean_K"+string(c.ContextHistoryK))=[150;160;170;180];
end
cc=c;cc.ContextMinCategoryInnings=1;Cat=W.Categories(F(1:3,:),cc);
[A,names,groups]=W.Raw(F(1:3,:),120,160,Cat,c.ContextHistoryK);v=isfinite(A);Z=A;Z(~v)=0;
w=ones(3,1)/3;P=W.Preprocessor(w'*double(v),w'*Z,w'*(Z.^2),names,groups,Cat,1);
X=W.Encode(F,120,160,P,c.ContextHistoryK);assert(all(isfinite(X),'all'),'Missing predictors not handled.');
assert(~ismember("NEW",P.Categories.VenueSeen),'Assessment category leaked into training dictionary.');
% Assessment perturbations cannot affect the fixed preprocessing/fitted model.
XX=[ones(3,1),X(1:3,:)];y=[1;.8;.3];G=XX'*XX/3;b=XX'*y/3;
[beta,Q]=W.Solve(G,b,mean(y.^2),.01);
assert(Q.StationarityResidual<1e-8&&all(isfinite(beta)),'Ridge fixture failed.');
expected=(G+.01*diag([0,ones(1,size(X,2))]))\b;
assert(max(abs(beta-expected))<1e-9,'Ridge differs from normal equations.');
F.FutureOutcome=1e9*ones(4,1);F.FinalRuns=zeros(4,1);
X2=W.Encode(F,120,160,P,c.ContextHistoryK);assert(isequaln(X,X2),'Outcome-like fields entered predictors.');
F.ScoreBefore(4)=1e9;F.Venue(4)="OTHER";
X3=W.Encode(F,120,160,P,c.ContextHistoryK);
assert(isequaln(X(1:3,:),X3(1:3,:)),'Assessment perturbation changed training encoding.');
M=struct('Horizon',120,'FullStartMean',160,'HistoryK',c.ContextHistoryK, ...
 'Preprocessor',P,'Columns',1:size(X,2),'Beta',[-1;zeros(size(X,2),1)]);
[p,raw]=W.Predict(M,F);assert(all(p==0)&&all(raw==-160),'Nonnegative forecast policy failed.');
for k=1:4,assert(all(ismember(find(groups<=k),find(groups<=k+1))),'Ablations not nested.');end
% Unequal state populations: equal-innings weighting changes the estimand.
err=[1;1;9];ii=[1;1;2];count=accumarray(ii,1);weight=1./count(ii);
assert(abs(sum(weight.*err.^2)/sum(weight)-41)<1e-12,'Equal-innings SSE weighting failed.');
Checks=table(["Training-only missing-value preprocessing";"Unseen categories excluded from vocabulary"; ...
 "Actual positive-ridge normal-equation fit";"Outcome-like columns ignored by allowlist"; ...
 "Assessment perturbation leaves training encoding unchanged";"Nonnegative forecast without capacity cap"; ...
 "Five strictly nested ablations";"Equal-innings outcome weighting"],true(8,1), ...
 'VariableNames',{'Check','Passed'});disp(Checks);
end
