function Compact=RevisedCodes_12_01_CompactBaseline(settings)
if nargin<1,settings=struct;end
c=RevisedCodes_12_00_Config(settings);U=RevisedCodes_12_Utils;V=RevisedCodes_10_Utils;
[cfg,P,~,paths]=U.Inputs();S=U.Signature("12_01",c,paths);
root=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step12');out=fullfile(root,'RevisedCodes_12_01_Result.mat');
[reuse,Compact]=V.Cache(out,'Compact',S,c);if reuse,fprintf('12_01 valid cache reused.\n');return;end
[g,report]=V.Generation(root);Index=table;Models=cell(0,1);Diagnostics=table;AllStarts=table;
Coefficients=table;Derived=table;Profiles=table;BoundSensitivity=table;Sensitivity=table;display=table;SourceFiles=strings(0,1);
coefficientNames=["a","b","c","d","e","f"];
meaning=["Logistic location: changes normalized capacity saturation; interpret through Z curve"; ...
 "Linear wicket effect in logistic argument; derivative contribution b"; ...
 "Quadratic wicket curvature in logistic argument; derivative contribution 2*c*v"; ...
 "Log curvature-rate intercept; k(0)=exp(d), with w=0 boundary still zero resource"; ...
 "Linear wicket effect in log k; derivative contribution e"; ...
 "Quadratic wicket curvature in log k; derivative contribution 2*f*v"];
sd=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady','SourceData');if ~isfolder(sd),mkdir(sd);end
for j=1:height(P.Index)
 source=P.Models{j};row=P.Index(j,:);ref=row.CandidateID;id="compact__"+ref;
 [p,Starts,D]=U.CompactFit(source,c);[R,Z,k,deriv]=U.CompactGrid(p,source.Horizon);
 [newrow,M]=U.Register(row,source,id,R,source.Supported,source.DataWeights,row.Estimand,row.MinMatches,"compact",false,c);
 M.Parameters=p;M.ParameterNames=coefficientNames;M.ParameterBounds=[c.ParameterLower,c.ParameterUpper];
 M.FitDiagnostics=D;M.OptimizerOutput=D.OptimizerOutput;M.SourceReferenceID=ref;
 M.GlobalOptimumProved=false;M.ExactOriginalEquationReplication=false;
 M.CompletionAssumption="Bounded compact-family shape learned from supported reference cells; sparse areas are model predictions, not observations";
 Models{end+1,1}=M;Index=[Index;newrow]; %#ok<AGROW>
 Starts.PackageID=repmat(row.PackageID,height(Starts),1);Starts.ReferenceCandidate=repmat(ref,height(Starts),1);
 AllStarts=[AllStarts;Starts]; %#ok<AGROW>
 Diag=table(row.PackageID,ref,id,D.WeightedReferenceMSE,D.WeightedReferenceMAE,D.MaxSupportedReferenceError, ...
 D.RegularizedObjective,D.RidgePenalty,D.AcceptedStarts,D.NearOptimalStarts,D.LocalJacobianCondition, ...
 D.MinimumBoundMargin,D.ConstraintResidual,false,D.ExitFlag, ...
 'VariableNames',{'PackageID','ReferenceCandidate','ModelID','WeightedReferenceMSE','WeightedReferenceMAE', ...
 'MaxSupportedReferenceError','RegularizedObjective','RidgePenalty','AcceptedStarts','NearOptimalStarts', ...
 'LocalJacobianCondition','MinimumBoundMargin','ConstraintResidual','GlobalOptimumProved','ExitFlag'});
 Diagnostics=[Diagnostics;Diag]; %#ok<AGROW>
 SV=table(repmat(row.PackageID,6,1),repmat(ref,6,1),(1:6)',D.LocalJacobianSingularValues, ...
  'VariableNames',{'PackageID','ReferenceCandidate','SingularValueIndex','WeightedLocalJacobianSingularValue'});
 Sensitivity=[Sensitivity;SV]; %#ok<AGROW>
 for h=1:6
  coeff=table(row.PackageID,ref,coefficientNames(h),p(h),c.ParameterLower(h),c.ParameterUpper(h), ...
   D.NearOptimalParameterSpread(h),meaning(h),'VariableNames', ...
   {'PackageID','ReferenceCandidate','Coefficient','Estimate','LowerBound','UpperBound','NearOptimalStartSpread','Interpretation'});
  Coefficients=[Coefficients;coeff]; %#ok<AGROW>
 end
 [u,w]=ndgrid(0:source.Horizon,0:10);
 A=table(u(:),w(:),R(:),source.Resource(:),R(:)-source.Resource(:),source.Supported(:),source.DataWeights(:), ...
 'VariableNames',{'BallsRemaining','WicketsInHand','CompactResource','ReferenceResource','SignedResidual','Supported','DataWeight'});
 A.Format=repmat(row.Format,height(A),1);A.PackageID=repmat(row.PackageID,height(A),1);A.ReferenceCandidate=repmat(ref,height(A),1);
 path=fullfile(sd,char("12_01_"+row.PackageID+"_"+ref+".csv"));writetable(A,path);SourceFiles(end+1,1)=string(path); %#ok<AGROW>
 if row.Cohort=="FULL_TRAIN"&&ref==string(c.DisplayReference)
  display=[display;A]; %#ok<AGROW>
  for wi=0:10
   ix=round([0 .25 .5 .75 1]*source.Horizon)+1;
   B=table(repmat(row.Format,5,1),repmat(wi,5,1),(ix(:)-1)/source.Horizon, ...
    repmat(Z(wi+1),5,1),repmat(k(wi+1),5,1),R(ix,wi+1),deriv(ix,wi+1)/source.Horizon, ...
    'VariableNames',{'Format','WicketsInHand','BallFraction','Z','k','Resource','MarginalResourcePerBall'});
   Derived=[Derived;B]; %#ok<AGROW>
  end
  if c.RunBoundSensitivity
   % Prespecified e-bound/ridge sensitivity, kept separate from primary fits.
   for emin=unique(c.BoundEMinima(:)')
    for ridge=unique([0,c.CompactRidge])
     cs=c;cs.ParameterLower(5)=emin;cs.CompactRidge=ridge;
     [ps,~,DS]=U.CompactFit(source,cs);
     RS=U.CompactGrid(ps,source.Horizon);
     B=table(row.Format,emin,ridge,ps(5),DS.WeightedReferenceMSE, ...
      sqrt(sum(source.DataWeights(:).*(RS(:)-R(:)).^2)), ...
      max(abs(RS(source.Supported)-R(source.Supported))),DS.MinimumBoundMargin, ...
      DS.ConstraintResidual,DS.AcceptedStarts, ...
      'VariableNames',{'Format','DeclaredELowerBound','CoefficientRidge','EstimatedE', ...
      'WeightedReferenceMSE','WeightedChangeFromPrimaryRMSE','MaximumSupportedChange', ...
      'MinimumBoundMargin','ConstraintResidual','AcceptedStarts'});
     BoundSensitivity=[BoundSensitivity;B]; %#ok<AGROW>
    end
   end
  end
  if c.RunProfiles
   for h=1:6
    values=unique(min(max(p(h)+c.ProfileOffsets*(c.ParameterUpper(h)-c.ParameterLower(h)),c.ParameterLower(h)),c.ParameterUpper(h)));
    for value=values
     lb=c.ParameterLower;ub=c.ParameterUpper;lb(h)=value;ub(h)=value;
     ok=true;profileValue=NaN;status="ACCEPTED_LOCAL_PROFILE";
     try
      seeds=[p';p'+[1 .5 0 .5 0 0]];
      [~,~,PD]=U.CompactFit(source,c,lb,ub,seeds);profileValue=PD.RegularizedObjective;
     catch err
      ok=false;status=string(err.identifier)+": "+string(err.message);
     end
     Profiles=[Profiles;table(row.Format,coefficientNames(h),value, ...
      (value-p(h))/(c.ParameterUpper(h)-c.ParameterLower(h)),profileValue, ...
      profileValue-D.RegularizedObjective,ok,status, ...
      'VariableNames',{'Format','Coefficient','FixedValue','NormalizedOffset','LocalProfileObjective','ObjectiveChange','Accepted','Status'})]; %#ok<AGROW>
    end
   end
  end
 end
 fprintf('Step12 compact %d/%d %s %s; accepted starts %d, weighted approximation RMSE %.5g.\n', ...
 j,height(P.Index),row.PackageID,ref,D.AcceptedStarts,sqrt(D.WeightedReferenceMSE));
end
ReferencePackage=struct('SchemaVersion',"11.1.0",'Index',Index,'Models',{Models}, ...
 'Status',"COMPACT_CANDIDATES_SELECTION_PENDING",'ModelSelected',false,'PolicyFrozen',false, ...
 'OfficialTable',false,'Signature',S,'ExactOriginalEquationReplication',false);
path=fullfile(g,'RevisedCodes_12_CompactPackage.mat');save(path,'ReferencePackage','-v7.3');
z=load(path,'ReferencePackage');assert(isequaln(z.ReferencePackage.Index,Index),'Compact serialization failed.');
for j=1:height(Index)
 A=U.Evaluate(z.ReferencePackage,Index.Format(j),Index.Cohort(j),Index.CandidateID(j),Models{j}.Horizon,10,Models{j}.Horizon);
 assert(abs(A.Resource-1)<=c.ConstraintTolerance&&~A.GlobalOptimumCertified,'Compact registration failed.');
end
Checks=table(["Saved certified reference provenance";"All 13 references/cohort retained"; ...
 "Multistart local optimizer and complete-grid feasibility";"All six coefficients and derived curves"; ...
 "Local sensitivity and multistart identifiability recorded";"Shared resource interface and serialization"; ...
 "Approximation separated from independent prediction";"Original equation reproduction limitation explicit"], ...
 true(8,1),'VariableNames',{'Check','Passed'});
for item={{'12_01_Diagnostics',Diagnostics},{'12_01_Multistarts',AllStarts},{'12_01_Coefficients',Coefficients}, ...
 {'12_01_DerivedCurves',Derived},{'12_01_LocalProfiles',Profiles},{'12_01_BoundSensitivity',BoundSensitivity},{'12_01_LocalSensitivity',Sensitivity},{'12_01_ModelIndex',Index},{'12_01_GateChecks',Checks}}
 pair=item{1};writetable(pair{2},fullfile(report,[pair{1} '.csv']));
end
failedProfiles=0;if ~isempty(Profiles),failedProfiles=nnz(~Profiles.Accepted);end
Flags=table(["Primary fits near declared bound";"Unaccepted local profile points";"Local fits prove no global optimum"], ...
 [nnz(Diagnostics.MinimumBoundMargin<=1e-6);failedProfiles;height(Diagnostics)], ...
 ["Review bound/ridge sensitivity before coefficient interpretation or freeze"; ...
 "Read profile status; optimizer failure does not establish infeasibility"; ...
 "Use multi-start evidence and curve-level interpretation; global certainty is not claimed"], ...
 'VariableNames',{'Issue','Count','RequiredInterpretation'});
writetable(Flags,fullfile(report,'12_01_InterpretationFlags.csv'));
Coverage=U.Coverage();writetable(Coverage,fullfile(report,'12_01_ReviewerEditorCoverage.csv'));
Specification=U.Specification();writetable(Specification,fullfile(report,'12_ModelSpecification.csv'));
pub=[SourceFiles;V.TableExport(cfg,"Methodology","T_M18_CoreModelSpecification",Specification); ...
 V.TableExport(cfg,"Results","T_R12_01_CompactCoefficients",Coefficients((Coefficients.PackageID=="FULL_TRAIN_ODI"|Coefficients.PackageID=="FULL_TRAIN_T20")&Coefficients.ReferenceCandidate==string(c.DisplayReference),:)); ...
 V.TableExport(cfg,"Supplementary","T_S12_01_MultistartDiagnostics",AllStarts); ...
 V.TableExport(cfg,"Supplementary","T_S12_02_LocalProfiles",Profiles); ...
 V.TableExport(cfg,"Supplementary","T_S12_05_CompactBoundSensitivity",BoundSensitivity)];
fig=figure('Visible','off','Color','w','Position',[100 100 1300 820]);clean=onCleanup(@()close(fig)); %#ok<NASGU>
tiledlayout(2,3,'TileSpacing','compact','Padding','compact');formats=["ODI","T20"];
for f=1:2
 B=display(display.Format==formats(f),:);h=max(B.BallsRemaining);
 nexttile;hold on;colors=lines(4);wickets=[2 5 8 10];for z=1:4,wi=wickets(z);K=B(B.WicketsInHand==wi,:);plot(K.BallsRemaining/h,K.ReferenceResource,'--','Color',colors(z,:),'HandleVisibility','off');plot(K.BallsRemaining/h,K.CompactResource,'Color',colors(z,:),'LineWidth',1.2,'DisplayName',sprintf('w=%d',wi));end
 xlabel('Remaining legal-ball fraction');ylabel('Resource');title(formats(f)+": reference dashed / compact solid");legend('Location','northwest');ylim([0 1]);
 nexttile;D=Derived(Derived.Format==formats(f)&Derived.BallFraction==0,:);yyaxis left;plot(D.WicketsInHand,D.Z,'o-');ylabel('Z(w)');yyaxis right;plot(D.WicketsInHand,D.k,'s-');ylabel('k(w)');xlabel('Wickets in hand');title(formats(f)+": derived coefficient interpretation");
 nexttile;delta=B.SignedResidual;delta(~B.Supported)=NaN;im=imagesc((0:h)/h,0:10,reshape(delta,h+1,11)');im.AlphaData=isfinite(im.CData);set(gca,'YDir','normal','Color',[.95 .95 .95]);colorbar;xlabel('Remaining legal-ball fraction');ylabel('Wickets in hand');title(formats(f)+": supported approximation residual");
end
axesList=findall(fig,'Type','axes');set(axesList,'FontName','Times New Roman','FontSize',10);
limit=max(1e-6,max(abs(display.SignedResidual(display.Supported))));
for a=axesList'
 if contains(string(a.Title.String),'residual'),clim(a,[-limit limit]);end
end
pub=[pub;U.FigureExport(cfg,"Results","F_M12_01_CompactInterpretation",fig,display, ...
 "Provisional compact baseline: reference/fit slices, Z(w)/k(w), and supported-cell signed approximation residuals. Remaining-ball concavity is a compact-family restriction; monotonicity is checked on the full integer grid. All six coefficient estimates and local identifiability diagnostics accompany the figure. Slices include unsupported completions; masked residuals use supported cells only. These are training reference-approximation results, not independent prediction or target-policy validation. Exact original logistic argument conventions require source confirmation.",report)];
if ~isempty(Profiles)
 clear clean;
 fig=figure('Visible','off','Color','w','Position',[100 100 1200 760]);clean=onCleanup(@()close(fig)); %#ok<NASGU>
 tiledlayout(2,3,'TileSpacing','compact','Padding','compact');
 for h=1:6
  nexttile;hold on;
  for format=formats
   B=Profiles(Profiles.Format==format&Profiles.Coefficient==coefficientNames(h)&Profiles.Accepted,:);
   plot(B.NormalizedOffset,B.ObjectiveChange,'o-','DisplayName',char(format));
  end
  yline(0,':','HandleVisibility','off');xlabel('Offset / declared parameter range');ylabel('Regularized objective change');
  title("Coefficient "+coefficientNames(h));legend('Location','best');set(gca,'FontName','Times New Roman','FontSize',10);
 end
 pub=[pub;U.FigureExport(cfg,"Supplementary","F_S12_01_CompactLocalProfiles",fig,Profiles, ...
  "Conditional local objective profiles for each of the six compact coefficients, from two starts with the other five coefficients refitted. Offsets are normalized by the declared coefficient range, relative to the multistart estimate. These diagnose local flatness and alternate solutions; they are not confidence intervals or global identifiability proofs. Missing infeasible/unaccepted points are recorded. Negative changes indicate a profile-discovered better local solution requiring follow-up review.",report)];
end
Compact=struct('Stage',"12_01",'Status',"COMPACT_READY_SOURCE_EQUATION_CONFIRMATION_PENDING", ...
 'ResourcePackagePath',string(path),'Packages',table("Compact",string(path),'VariableNames',{'PackageID','Path'}), ...
 'Diagnostics',Diagnostics,'Checks',Checks,'ExactOriginalEquationReplication',false);
Compact=V.Finish(cfg,'Compact',out,S,g,report,Compact,[pub;string(path)]);
end
