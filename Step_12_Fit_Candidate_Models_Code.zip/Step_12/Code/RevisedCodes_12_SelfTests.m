function Checks=RevisedCodes_12_SelfTests(settings)
if nargin<1,settings=struct;end
c=RevisedCodes_12_00_Config(settings);U=RevisedCodes_12_Utils;V=RevisedCodes_10_Utils;
assert(license('test','Optimization_Toolbox')&&exist('fmincon','file')==2&&exist('quadprog','file')==2,'Optimization Toolbox required.');
p=[0 2 0 log(2) 0 0]';[R,Z,k,D]=U.CompactGrid(p,6);
assert(V.Residual(R(:),6)<1e-12&&Z(1)==0&&abs(Z(end)-1)<1e-12,'Compact boundaries/order failed.');
assert(all(diff(R,2,1)<=1e-12,'all')&&all(D>=0,'all')&&all(abs(k-2)<1e-12),'Compact concavity/stable derivative failed.');
sig=@(x)1./(1+exp(-x));v=(0:10)/10;expected=(sig(2*v)-sig(0))/(sig(2)-sig(0));
assert(max(abs(Z-expected))<1e-12,'Stable normalized logistic differs from definition.');
[nearLinear,~,~,~]=U.CompactGrid([0 2 0 -12 0 0]',6);assert(all(isfinite(nearLinear),'all'),'Small-k stable exponential failed.');
for d=[3 5 7]
 B=U.Basis((0:6)'/6,d);assert(max(abs(sum(B,2)-1))<1e-12,'Bernstein partition of unity failed.');
 coef=((0:d)'/d)*((0:10)/10);grid=B*coef;[x,w]=ndgrid(0:6,0:10);
 assert(max(abs(grid(:)-(x(:)/6).*(w(:)/10)))<1e-12,'Linear Bernstein reproduction failed.');
end
M=struct('Resource',R,'DataWeights',ones(size(R))/numel(R),'Horizon',6);
ct=c;ct.CompactStarts=2;ct.CompactRidge=0;
[~,Starts,Q]=U.CompactFit(M,ct);assert(any(Starts.Accepted)&&Q.ConstraintResidual<=c.ConstraintTolerance,'Actual compact toy optimization failed.');
weights=ones(numel(R),1)/numel(R);weights(25)=0;weights=weights/sum(weights);
[coef,grid,Q,A]=U.BernsteinFit(6,3,R(:),weights,0,c);
assert(Q.ObjectiveGapBound<=c.CertificateTolerance&&A.Certified(end)&&V.Residual(grid(:),6)<=c.ConstraintTolerance,'Actual Bernstein QP failed.');
assert(all(diff(coef,1,1)>=-c.ConstraintTolerance,'all')&&all(diff(coef,1,2)>=-c.ConstraintTolerance,'all'),'Coefficient order failed.');
[~,~,Q]=U.BernsteinFit(6,5,R(:),weights,.01,c);assert(Q.ObjectiveGapBound<=c.CertificateTolerance,'Smoothed Bernstein failed.');
% Exact equivalence of expanded observation SSE and cell-statistics objective.
y=[.2;.4;.8];pred=[.3;.3;.7];mass=[2;1];target=[.3;.8];weightsCell=mass/3;
constant=mean(y.^2)-sum(weightsCell.*target.^2);
assert(abs(mean((y-pred).^2)-(sum(weightsCell.*([.3;.7]-target).^2)+constant))<1e-14,'Sufficient-statistic SSE equivalence failed.');
Checks=table(["Compact boundaries and order";"Normalized logistic exact definition"; ...
 "Stable exponential and derivative";"Compact concavity documented";"Bernstein partition of unity"; ...
 "Polynomial linear reproduction";"Actual multistart compact fitting";"Actual certified Bernstein fitting"; ...
 "Coefficient monotonicity";"Roughness variant";"Exact outcome-SSE decomposition"],true(11,1), ...
 'VariableNames',{'Check','Passed'});disp(Checks);
end
