function U=RevisedCodes_12_Utils
U.Inputs=@inputs;U.Signature=@signature;U.CompactGrid=@compactGrid;U.CompactFit=@compactFit;
U.Basis=@basis;U.BernsteinFit=@bernsteinFit;U.DirectTarget=@directTarget;
U.Register=@register;U.Evaluate=@evaluate;U.Specification=@specification;U.FigureExport=@figureExport;U.Coverage=@coverage;
end
function [cfg,P,E,paths]=inputs
V=RevisedCodes_10_Utils;[cfg,~,~,~,~]=V.Inputs();
ip=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step11','RevisedCodes_11_01_Result.mat');
z=load(ip,'Interface');I=z.Interface;
assert(all(I.Checks.Passed)&&all(isfile(I.ArtifactPaths)),'Step11 incomplete.');
assert(isequal(I.Signature.Sources,V.Stamps(I.Signature.Sources.Path)),'Step11 sources changed.');
for j=1:height(I.Signature.Code)
 assert(I.Signature.Code.Content(j)==string(fileread(I.Signature.Code.Path(j))),'Step11 code changed.');
end
assert(all(I.Diagnostics.ConstraintResidual<=I.Signature.Settings.ConstraintTolerance)&& ...
 all(I.Diagnostics.ObjectiveGapBound<=I.Signature.Settings.CertificateTolerance)&& ...
 all(I.Diagnostics.GapVsWitness<=I.Diagnostics.WitnessAllowance),'Step11 numerical certification failed.');
z=load(I.ReferencePackagePath,'ReferencePackage');P=z.ReferencePackage;
assert(~P.ModelSelected&&~P.PolicyFrozen,'Use development candidates, not an already frozen package.');
assert(height(P.Index)==numel(P.Models),'Package model index differs.');
ep=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step10','RevisedCodes_10_01_Result.mat');
z=load(ep,'Empirical');E=z.Empirical;
paths=unique([string(ip);I.ReferencePackagePath;string(ep);E.Packages.Path; ...
 I.Signature.Sources.Path;I.Signature.Code.Path],'stable');
end
function S=signature(stage,c,paths)
V=RevisedCodes_10_Utils;S=struct('Stage',stage,'Settings',c,'Sources',V.Stamps(paths),'CodeFiles',table);
for name=["RevisedCodes_12_00_Config","RevisedCodes_12_Utils","RevisedCodes_12_01_CompactBaseline", ...
 "RevisedCodes_12_02_BernsteinModel","RevisedCodes_12_03_ContextForecasts", ...
 "RevisedCodes_12_ContextUtils","RevisedCodes_12_PredictContext","RevisedCodes_12_ContextSelfTests","RevisedCodes_12_SelfTests","RevisedCodes_12_RunAll"]
 p=which(char(name));assert(~isempty(p),'Missing Step12 file.');
 S.CodeFiles=[S.CodeFiles;table(string(p),string(fileread(p)),'VariableNames',{'Path','Content'})]; %#ok<AGROW>
end
end
function [R,Z,k,derivative]=compactGrid(p,U)
% Explicit six-parameter reconstruction of the plan's normalized family.
% v=w/10, s=a+b*v+c*v^2, Z=(sigmoid(s)-sigmoid(a))/(sigmoid(s1)-sigmoid(a)).
v=(0:10)/10;x=(0:U)'/U;t=p(2)*v+p(3)*v.^2;t1=p(2)+p(3);
assert(t1>0,'Normalized logistic denominator is not positive.');
Z=expm1(t)/expm1(t1).*(1+exp(p(1)+t1))./(1+exp(p(1)+t));
k=exp(p(4)+p(5)*v+p(6)*v.^2);
q=-expm1(-x.*k)./(-expm1(-k));R=q.*Z;
derivative=(k.*exp(-x.*k)./(-expm1(-k))).*Z;
end
function [ineq,eq]=compactConstraints(p,U)
R=compactGrid(p,U);difference=diff(R,1,2);
% Zero-ball row, full-horizon row and the w=0 pair are already ordered by
% construction. Avoid redundant zero-gradient active constraints in SQP.
ineq=-reshape(difference(2:end-1,2:end),[],1);eq=[];
end
function [best,Starts,D]=compactFit(M,c,extraLB,extraUB,seeds)
V=RevisedCodes_10_Utils;lb=c.ParameterLower;ub=c.ParameterUpper;
if nargin>=3,lb=max(lb,extraLB);ub=min(ub,extraUB);end
if nargin<5
 seeds=zeros(c.CompactStarts,6);
 for j=1:c.CompactStarts
  % Every seed has constant positive k and increasing Z, hence is feasible.
  seeds(j,:)=[-3+6*mod(j-1,4)/3,1+mod(j-1,3)*2,0,-1+mod(j-1,4)*.8,0,0];
 end
end
assert(all(lb<=ub),'Impossible profile bounds.');
weights=M.DataWeights(:);target=M.Resource(:);range=c.ParameterUpper-c.ParameterLower;
assert(all(isfinite(target))&&all(weights>=0)&&abs(sum(weights)-1)<1e-8,'Invalid compact fitting grid.');
objective=@(p)compactObjective(p,M.Horizon,target,weights,c.CompactRidge,range);
scale=max(1,1/median(weights(weights>0)));
options=optimoptions('fmincon','Algorithm','sqp','Display','off', ...
 'MaxIterations',c.CompactMaxIterations,'MaxFunctionEvaluations',30000, ...
 'OptimalityTolerance',c.CompactTolerance,'ConstraintTolerance',c.CompactTolerance, ...
 'StepTolerance',1e-12,'FiniteDifferenceType','central');
linear=[0 -1 -2 0 0 0];rhs=-.05;Starts=table;solutions=nan(size(seeds,1),6);
bestValue=Inf;best=[];bestOutput=struct;bestFlag=0;
for j=1:size(seeds,1)
 start=min(max(seeds(j,:)',lb),ub);
 % Fixed profile coordinates can make the old seed violate b+2*c>=.05.
 % Restore the linear domain before any exponential objective evaluation.
 deficit=.05-start(2)-2*start(3);
 if deficit>0
  add=min(deficit,ub(2)-start(2));start(2)=start(2)+add;deficit=deficit-add;
  add=min(max(0,deficit)/2,ub(3)-start(3));start(3)=start(3)+add;
 end
 assert(start(2)+2*start(3)>=.05-1e-12,'Fixed coefficient has no feasible monotone-logistic domain within bounds.');
 clock=tic;
 startR=compactGrid(start,M.Horizon);initialValue=objective(start);
 initialFeasible=V.Residual(startR(:),M.Horizon)<=c.ConstraintTolerance&&linear*start<=rhs+c.ConstraintTolerance;
 [p,~,flag,out]=fmincon(@(p)scale*objective(p),start,linear,rhs,[],[],lb,ub, ...
  @(p)compactConstraints(p,M.Horizon),options);
 R=compactGrid(p,M.Horizon);res=V.Residual(R(:),M.Horizon);val=objective(p);
 firstOrder=out.firstorderopt/scale;
 accepted=flag>0&&all(isfinite(p))&&isfinite(val)&&res<=c.ConstraintTolerance&& ...
 firstOrder<=c.CompactFirstOrderLimit&&linear*p<=rhs+c.ConstraintTolerance&& ...
 (~initialFeasible||val<=initialValue+c.NearOptimalTolerance);
 solutions(j,:)=p';
 row=table(j,flag,out.iterations,toc(clock),val,res,firstOrder,accepted, ...
  p(1),p(2),p(3),p(4),p(5),p(6),initialValue,initialFeasible, ...
  'VariableNames',{'Start','ExitFlag','Iterations','Seconds','RegularizedObjective', ...
  'ConstraintResidual','OriginalScaleFirstOrder','Accepted','a','b','c','d','e','f','InitialObjective','InitialFeasible'});
 Starts=[Starts;row]; %#ok<AGROW>
 if accepted&&val<bestValue,best=p;bestValue=val;bestOutput=out;bestFlag=flag;end
end
assert(~isempty(best),'No accepted compact local solution; inspect multistart settings and bounds.');
R=compactGrid(best,M.Horizon);delta=R(:)-target;
near=Starts.Accepted&Starts.RegularizedObjective<=bestValue+c.NearOptimalTolerance;
spread=max(solutions(near,:),[],1)-min(solutions(near,:),[],1);
% Local sensitivity of the fitting surface, not independent uncertainty.
J=zeros(nnz(weights>0),6);valid=weights>0;
for h=1:6
 epsp=1e-5*max(1,abs(best(h)));pl=best;pr=best;pl(h)=pl(h)-epsp;pr(h)=pr(h)+epsp;
 rl=compactGrid(pl,M.Horizon);rr=compactGrid(pr,M.Horizon);
 J(:,h)=(rr(valid)-rl(valid))/(2*epsp).*sqrt(weights(valid));
end
sv=svd(J,'econ');ratio=Inf;if sv(end)>0,ratio=sv(1)/sv(end);end
margin=min((best-c.ParameterLower)./range,(c.ParameterUpper-best)./range);
D=struct('WeightedReferenceMSE',sum(weights.*delta.^2),'WeightedReferenceMAE',sum(weights.*abs(delta)), ...
 'MaxSupportedReferenceError',max(abs(delta(valid))),'RegularizedObjective',bestValue, ...
 'RidgePenalty',c.CompactRidge*mean((best./range).^2),'AcceptedStarts',nnz(Starts.Accepted), ...
 'NearOptimalStarts',nnz(near),'NearOptimalParameterSpread',spread, ...
 'LocalJacobianSingularValues',sv,'LocalJacobianCondition',ratio,'MinimumBoundMargin',min(margin), ...
 'ConstraintResidual',V.Residual(R(:),M.Horizon),'ExitFlag',bestFlag,'OptimizerOutput',bestOutput, ...
 'GlobalOptimumProved',false);
end
function f=compactObjective(p,U,target,weights,ridge,range)
R=compactGrid(p,U);f=sum(weights.*(R(:)-target).^2)+ridge*mean((p./range).^2);
end
function B=basis(x,d)
x=x(:);assert(all(x>=0&x<=1),'Bernstein basis requires x in [0,1].');
B=zeros(numel(x),d+1);
for h=0:d,B(:,h+1)=nchoosek(d,h)*x.^h.*(1-x).^(d-h);end
end
function [target,weights,constant,mask]=directTarget(S,weighting)
G=S.Grid;mu=S.FullStartMean;
if weighting=="state"
 mass=G.MatchCount;target=G.RunMeanState;second=G.SumY2/mu^2;
else
 assert(weighting=="innings",'Unknown direct outcome weighting.');
 mass=G.InningsWeightSum;target=G.RunMeanInnings;second=G.WeightedSumY2/mu^2;
end
mask=mass>0;target(~mask)=0;weights=mass/sum(mass);
constant=sum(second)/sum(mass)-sum(weights.*target.^2);
assert(constant>=-1e-10,'Direct-outcome sufficient-statistic variance constant is negative.');
constant=max(0,constant);
end
function [coef,R,Q,Attempts]=bernsteinFit(U,d,target,weights,lambda,c)
V=RevisedCodes_10_Utils;B=basis((0:U)'/U,d);X=kron(speye(11),sparse(B));
[A,lb,ub,x0]=V.Constraints(d);n=numel(lb);weights=weights(:);target=target(:);
assert(numel(target)==(U+1)*11&&all(isfinite(target))&&all(weights>=0)&&abs(sum(weights)-1)<1e-8,'Invalid Bernstein fitting inputs.');
D=spdiags(weights,0,numel(weights),numel(weights));
H=2*(X'*D*X+lambda*(A'*A)/size(A,1));H=(H+H')/2;f=-2*(X'*(weights.*target));
fixed=lb==ub;free=~fixed;fix=lb(fixed);Hr=H(free,free);fr=f(free)+H(free,fixed)*fix;
Ar=A(:,free);br=-A(:,fixed)*fix;rows=any(Ar~=0,2);assert(all(br(~rows)>=-c.ConstraintTolerance));Ar=Ar(rows,:);br=br(rows);
baseScale=max(1,1/median(weights(weights>0)));certified=false;Attempts=table;clock=tic;
for attempt=1:c.QPAttempts
 scale=baseScale*10^(attempt-1);tol=max(1e-12,c.QPTolerance/10^(attempt-1));t=tic;
 options=optimoptions('quadprog','Algorithm','interior-point-convex','Display','off', ...
  'MaxIterations',c.QPMaxIterations,'OptimalityTolerance',tol,'ConstraintTolerance',tol,'StepTolerance',1e-14);
 [z,~,flag,out,l]=quadprog(scale*Hr,scale*fr,Ar,br,[],[],lb(free),ub(free),[],options);
 residual=Inf;bound=Inf;stat=Inf;compsum=Inf;
 if flag>0&&~isempty(z)&&all(isfinite(z))
  a=lb;a(free)=z;li=l.ineqlin/scale;ll=l.lower/scale;lu=l.upper/scale;
  gradient=Hr*z+fr+Ar'*li-ll+lu;slack=br-Ar*z;
  comp=[li.*slack;ll.*z;lu.*(1-z)];
  stat=norm(gradient,Inf);compsum=sum(abs(comp));dual=max([0;-li;-ll;-lu]);
  bound=numel(z)*stat+compsum+sum(abs(li).*max(-slack,0))+ ...
   sum(abs(ll).*max(-z,0))+sum(abs(lu).*max(z-1,0))+dual*numel(comp);
  R=reshape(X*a,U+1,11);residual=max(V.Residual(a,d),V.Residual(R(:),U));
 end
 certified=flag>0&&isfinite(bound)&&bound<=c.CertificateTolerance&&residual<=c.ConstraintTolerance;
 Attempts=[Attempts;table(attempt,scale,tol,flag,out.iterations,toc(t),residual,bound,certified, ...
  'VariableNames',{'Attempt','Scale','Tolerance','ExitFlag','Iterations','Seconds','ConstraintResidual','ObjectiveGapBound','Certified'})]; %#ok<AGROW>
 if certified,break;end
end
assert(certified,'Bernstein QP failed certification after %d attempts: bound %.3g, residual %.3g.',attempt,bound,residual);
coef=reshape(a,d+1,11);delta=R(:)-target;
objective=sum(weights.*delta.^2)+lambda*mean((A*a).^2);
initial=sum(weights.*(X*x0-target).^2)+lambda*mean((A*x0).^2);
assert(objective<=initial+bound+1e-8,'Bernstein result is worse than feasible coefficient witness.');
Q=struct('Degree',d,'Lambda',lambda,'FreeCoefficients',nnz(free),'TotalCoefficients',n, ...
 'ActiveOrderConstraints',nnz(abs(A*a)<1e-7),'WeightedFittingMSE',sum(weights.*delta.^2), ...
 'RoughnessPenalty',lambda*mean((A*a).^2),'TotalObjective',objective, ...
 'InitialObjective',initial,'ConstraintResidual',residual,'StationarityResidual',stat, ...
 'ComplementaritySum',compsum,'ObjectiveGapBound',bound,'Attempts',attempt,'ExitFlag',flag, ...
 'Iterations',out.iterations,'Seconds',toc(clock),'CoefficientOrderCertified',true);
end
function [row,M]=register(row,M,id,R,supported,weights,estimand,minCount,family,globalCertified,c)
M.SourceReferenceVersion=M.ModelVersion;
if isfield(M,'ObjectiveGapBound'),M.SourceReferenceObjectiveGapBound=M.ObjectiveGapBound;end
obsolete=intersect(fieldnames(M),{'OptimizerOutput','OptimizerAttempts','ObjectiveGapBound','WitnessGateStatus'});
if ~isempty(obsolete),M=rmfield(M,obsolete);end
M.Resource=R;M.Supported=reshape(supported,size(R));M.DataWeights=reshape(weights,size(R));
M.Adjustment=nan(size(R));M.Candidate=table;M.Certified=true;M.ModelSelected=false;M.PolicyFrozen=false;
M.ModelFamily=family;M.GlobalOptimumCertified=globalCertified;M.TargetPolicy="Not frozen or implemented here";
row.CandidateID=string(id);row.Estimand=string(estimand);row.MinMatches=minCount;
U11=RevisedCodes_11_Utils;row.ModelVersion=U11.Fingerprint([R(:);double(M.Supported(:));M.DataWeights(:)], ...
 string(id)+"|"+row.PackageID+"|"+string(M.FullStartMean)+"|"+string(c.Version));
M.ModelVersion=row.ModelVersion;M.Cohort=row.Cohort;M.TrainingCutoffExclusive=row.TrainingCutoffExclusive;
end
function V=evaluate(P,format,cohort,id,u,w,allocation,options)
if nargin<8,options=struct;end
if isstring(P)||ischar(P),z=load(P,'ReferencePackage');P=z.ReferencePackage;end
V=RevisedCodes_11_02_Evaluate(P,format,cohort,id,u,w,allocation,options);
j=find(P.Index.Format==upper(string(format))&P.Index.Cohort==string(cohort)&P.Index.CandidateID==string(id));
V.ModelFamily=repmat(string(P.Models{j}.ModelFamily),height(V),1);
V.GlobalOptimumCertified=repmat(P.Models{j}.GlobalOptimumCertified,height(V),1);
end
function T=specification
T=table(["Compact family";"Z(v)";"k(v)";"Compact fitting";"Compact constraints";"Compact identifiability"; ...
 "Bernstein family";"Bernstein constraints";"Bernstein reference fitting";"Bernstein direct fitting"; ...
 "Selection/evaluation";"Original equation reproduction"], ...
 ["R(x,w)=Z(w)*[-expm1(-k(w)*x)]/[-expm1(-k(w))], x=u/U"; ...
 "v=w/10, s=a+b*v+c*v^2; normalized [sigmoid(s)-sigmoid(a)]/[sigmoid(a+b+c)-sigmoid(a)]"; ...
 "exp(d+e*v+f*v^2), strictly positive; concavity in x is a baseline assumption"; ...
 "Supported candidate-weighted reference squared error plus declared small coefficient ridge; deterministic multistart SQP"; ...
 "Bounded parameters, increasing Z, exact boundaries and integer-grid cross-wicket order; shared lookup uses linear ball interpolation"; ...
 "Near-optimal start spread, weighted local Jacobian singular values, bound margins and conditional local profiles; not cluster confidence intervals"; ...
 "Degree 3/5/7 polynomial in remaining-ball fraction, separate coefficients for integer wickets"; ...
 "Coefficient differences monotone in balls/wickets, boundary coefficients fixed, all coefficients [0,1]; no imposed concavity"; ...
 "All 13 certified reference candidates retained with degrees and smoothing grid; unsupported reference cells zero data weight"; ...
 "Remaining delivery-run outcomes fitted through exact cell sufficient statistics; state and equal-total-innings weights; no full future outcome used as predictor"; ...
 "Training approximation/fitting only; independent prediction, tuning and policy comparisons occur later; no final model selected"; ...
 "Plan identifies normalized logistic/exponential-quadratic family but not exact original Z argument conventions; explicit reconstruction documented, literal Eq6/7 replication pending source confirmation"], ...
 'VariableNames',{'Component','Specification'});
end

function paths=figureExport(cfg,category,name,fig,data,caption,report)
pub=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady');
folder=fullfile(pub,char(category),'Figures');sd=fullfile(pub,'SourceData');ci=fullfile(pub,'CaptionsAndIndex');
for p=string({folder,sd,ci}),if ~isfolder(p),mkdir(p);end,end
base=fullfile(folder,char(string(name)));
paths=string({[base '.png'],[base '.pdf'],[base '.fig'],fullfile(sd,char(string(name)+".csv")), ...
 fullfile(ci,char(string(name)+"_Caption.csv"))})';
objects=findall(fig,'-property','FontName');set(objects,'FontName','Times New Roman');
objects=findall(fig,'-property','FontSize');set(objects,'FontSize',10);
exportgraphics(fig,paths(1),'Resolution',600);exportgraphics(fig,paths(2),'ContentType','vector');savefig(fig,paths(3));
writetable(data,paths(4));writetable(table(string(name),string(caption),'VariableNames',{'Asset','Caption'}),paths(5));
exportgraphics(fig,fullfile(report,char(string(name)+"_Preview.png")),'Resolution',100);
end

function T=coverage
T=table(["R1 projection convergence";"R1 all six coefficients";"R1 official/resource/output meaning"; ...
 "R1/R2.6 sparse weighting and robust estimands";"R2.10 equations and flexible alternative"; ...
 "R2.13 full-wicket T20";"R1 misinterpreted validation";"R1 independent empirical contribution"; ...
 "R1 competition/era, gender and innings selection";"R2.7/R2.8 history and partnership"; ...
 "R2.5/R2.11/R2.12 length, ball loss, illustrative scores";"R2.9/editor worked actual match"; ...
 "R2.14 comparator conclusions"], ...
 ["Step11 numerical audit passed; coefficient QPs retain certificate and witness gates"; ...
 "All coefficients, Z/k/marginal curves, starts, bound margins, singular values and local profiles"; ...
 "Nonofficial indexed resource evaluator; target output and policy freeze remain separate"; ...
 "All 13 reference variants; state/equal-innings direct objectives; sparse fitting bases explicit"; ...
 "Explicit compact reconstruction and shape restriction versus coefficient-monotone Bernstein; literal original conventions unavailable"; ...
 "Full-wicket fitting-basis slices now; competition/era/support experiments still required"; ...
 "Training reference approximation, direct training outcome SSE and later independent scoring separated"; ...
 "Reproducible constrained/direct-outcome model candidates; improvements require independent outcomes"; ...
 "Actual subgroup and assumption evidence remains in planned later steps"; ...
 "Step12_03 fits identical-population nested ridge forecasts with training-only preprocessing and chronological histories; proxies are not ICC rankings"; ...
 "Step13/16 named scenarios, thresholds and training quantiles remain required"; ...
 "Verified ledger/interruption arithmetic remain required; no synthetic case substituted"; ...
 "Verified implementations and frozen matched-case/prediction evidence still required"], ...
 ["Stage11 passed; Stage12 local checks pending";"Implemented code; local evidence pending"; ...
 "Implemented interface contract";"Implemented code; independent selection pending"; ...
 "Literal equation replication pending; model comparison code implemented"; ...
 "Later Steps13/16 subgroup evidence pending";"Later Steps15/22 independent evaluation pending"; ...
 "Later Steps15/19/20/21/22 evidence pending";"Step12_03 records actual source event/era groups; later Steps16/17/18/19 sensitivity evidence pending"; ...
 "Implemented Step12_03; development evidence pending local run, frozen evaluation remains later";"Later Steps13/16 pending"; ...
 "Later Steps14/20 pending";"Later Steps20/21/22 pending"], ...
 'VariableNames',{'ReviewerEditorRequirement','ImplementationOrRequiredEvidence','Status'});
end
