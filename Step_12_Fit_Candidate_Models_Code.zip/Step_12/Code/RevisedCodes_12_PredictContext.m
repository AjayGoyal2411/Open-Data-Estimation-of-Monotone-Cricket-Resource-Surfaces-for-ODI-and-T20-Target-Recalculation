function Result=RevisedCodes_12_PredictContext(package,format,cohort,modelID,Features)
% Example: A=RevisedCodes_12_PredictContext(path,"ODI","Fold_2020",id,F);
% F must follow the saved pre-state predictor contract with fold-safe histories.
if ischar(package)||isstring(package)
 z=load(package,'ForecastPackage');package=z.ForecastPackage;
end
assert(isstruct(package)&&package.ForecastOnly&&~package.PolicyFrozen,'Expected a development forecast package.');
assert(istable(Features),'Features must be a pre-state predictor table.');
ix=find(package.Index.Format==string(format)&package.Index.Cohort==string(cohort)&package.Index.ModelID==string(modelID));
assert(isscalar(ix),'Requested context model is absent or ambiguous.');
U=RevisedCodes_12_ContextUtils;M=package.Models{ix};[prediction,raw]=U.Predict(M,Features);
Result=table(prediction,raw,repmat(string(modelID),height(Features),1), ...
 'VariableNames',{'PredictedRemainingRuns','RawRemainingRunForecast','ModelID'});
end
