function Flexible=RevisedCodes_12_02_BernsteinModel(settings)
if nargin<1,settings=struct;end
c=RevisedCodes_12_00_Config(settings);U=RevisedCodes_12_Utils;V=RevisedCodes_10_Utils;
[cfg,P,E,paths]=U.Inputs();S=U.Signature("12_02",c,paths);
root=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step12');out=fullfile(root,'RevisedCodes_12_02_Result.mat');
[reuse,Flexible]=V.Cache(out,'Flexible',S,c);if reuse,fprintf('12_02 valid cache reused.\n');return;end
[g,report]=V.Generation(root);Index=table;Models=cell(0,1);Diagnostics=table;Attempts=table;
Coefficients=table;display=table;SourceFiles=strings(0,1);
sd=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady','SourceData');if ~isfolder(sd),mkdir(sd);end
for package=1:height(E.Packages)
 z=load(E.Packages.Path(package),'Surface');surface=z.Surface;
 available=find(P.Index.PackageID==surface.PackageID);
 assert(numel(available)==13,'Expected all 13 references in each empirical package.');
 base=available(P.Index.CandidateID(available)=="mean_state_n30_count_l0");assert(isscalar(base),'Missing mean baseline.');
 baseline=P.Models{base};assert(surface.FullStartMean==baseline.FullStartMean,'Normalization mismatch.');
 % 13 supported-reference bases plus direct state/innings outcome objectives.
 for mode=1:numel(available)+2
  direct=mode>numel(available);constant=0;
  if ~direct
   j=available(mode);source=P.Models{j};row=P.Index(j,:);ref=row.CandidateID;
   target=source.Resource(:);weights=source.DataWeights(:);supported=source.Supported(:);
   basisName="reference__"+ref;estimand=row.Estimand;minCount=row.MinMatches;
  else
   source=baseline;row=P.Index(base,:);ref="mean_state_n30_count_l0";
   names=["state","innings"];weighting=names(mode-numel(available));
   [target,weights,constant,supported]=U.DirectTarget(surface,weighting);
   basisName="direct_"+weighting;minCount=1;estimand="RunMeanState";
   if weighting=="innings",estimand="RunMeanInnings";end
  end
  for degree=c.Degrees
   for lambda=c.Smoothing
    id=string(sprintf('bern_d%d_l%g_',degree,lambda))+basisName;
    [coef,R,Q,A]=U.BernsteinFit(source.Horizon,degree,target,weights,lambda,c);
    [newrow,M]=U.Register(row,source,id,R,supported,weights,estimand,minCount,"Bernstein",true,c);
    M.Coefficients=coef;M.Degree=degree;M.Smoothing=lambda;M.FitBasis=basisName;
    M.FitDiagnostics=Q;M.ObjectiveGapBound=Q.ObjectiveGapBound;M.OptimizerAttempts=A;
    M.DirectOutcomeVarianceConstant=constant;M.SourceReferenceID=ref;
    M.CompletionAssumption="Globally monotone Bernstein coefficient family; zero fitting weight outside observed fitting basis; no empirical support created by polynomial evaluation";
    Models{end+1,1}=M;Index=[Index;newrow]; %#ok<AGROW>
    refDelta=R(:)-baseline.Resource(:);rw=baseline.DataWeights(:);
    trainingMSE=NaN;if direct,trainingMSE=Q.WeightedFittingMSE+constant;end
    D=table(surface.PackageID,id,basisName,degree,lambda,Q.FreeCoefficients,Q.TotalCoefficients, ...
     Q.ActiveOrderConstraints,nnz(weights>0),Q.WeightedFittingMSE,Q.RoughnessPenalty,Q.TotalObjective, ...
     constant,trainingMSE,sum(rw.*refDelta.^2),Q.ConstraintResidual,Q.StationarityResidual, ...
     Q.ComplementaritySum,Q.ObjectiveGapBound,Q.Attempts,Q.ExitFlag,Q.Seconds, ...
     'VariableNames',{'PackageID','ModelID','FitBasis','Degree','Lambda','FreeCoefficients','TotalCoefficients', ...
     'ActiveOrderConstraints','FittingCells','WeightedFittingMSE','RoughnessPenalty','OptimizationObjective', ...
     'DirectVarianceConstant','InSampleNormalizedOutcomeMSE','MeanReferenceApproximationMSE', ...
     'ConstraintResidual','StationarityResidual','ComplementaritySum','ObjectiveGapBound','SolverAttempts','ExitFlag','Seconds'});
    Diagnostics=[Diagnostics;D]; %#ok<AGROW>
    A.PackageID=repmat(surface.PackageID,height(A),1);A.ModelID=repmat(id,height(A),1);Attempts=[Attempts;A]; %#ok<AGROW>
    [h,w]=ndgrid(0:degree,0:10);
    CC=table(repmat(surface.PackageID,numel(coef),1),repmat(id,numel(coef),1),h(:),w(:),coef(:), ...
     'VariableNames',{'PackageID','ModelID','BernsteinIndex','WicketsInHand','Coefficient'});
    Coefficients=[Coefficients;CC]; %#ok<AGROW>
    [u,w]=ndgrid(0:source.Horizon,0:10);
    G=table(u(:),w(:),R(:),baseline.Resource(:),refDelta,reshape(supported,[],1),weights(:), ...
     'VariableNames',{'BallsRemaining','WicketsInHand','FlexibleResource','MeanReferenceResource','SignedMeanReferenceResidual','FittingSupport','DataWeight'});
    G.Format=repmat(row.Format,height(G),1);G.FitBasis=repmat(basisName,height(G),1);
    G.PackageID=repmat(surface.PackageID,height(G),1);G.ModelID=repmat(id,height(G),1);
    path=fullfile(sd,char("12_02_"+surface.PackageID+"_"+id+".csv"));writetable(G,path);SourceFiles(end+1,1)=string(path); %#ok<AGROW>
    if row.Cohort=="FULL_TRAIN"&&degree==c.DisplayDegree&&lambda==c.DisplaySmoothing&& ...
      (~direct&&ref==string(c.DisplayReference)||direct)
     display=[display;G]; %#ok<AGROW>
    end
    fprintf('Step12 Bernstein %s %s; certificate %.3g.\n',surface.PackageID,id,Q.ObjectiveGapBound);
   end
  end
 end
end
ReferencePackage=struct('SchemaVersion',"11.1.0",'Index',Index,'Models',{Models}, ...
 'Status',"BERNSTEIN_CANDIDATES_SELECTION_PENDING",'OfficialTable',false, ...
 'ModelSelected',false,'PolicyFrozen',false,'Signature',S);
path=fullfile(g,'RevisedCodes_12_BernsteinPackage.mat');save(path,'ReferencePackage','-v7.3');
z=load(path,'ReferencePackage');assert(isequaln(z.ReferencePackage.Index,Index),'Bernstein serialization failed.');
for j=1:height(Index)
 A=U.Evaluate(z.ReferencePackage,Index.Format(j),Index.Cohort(j),Index.CandidateID(j), ...
 Models{j}.Horizon,10,Models{j}.Horizon);
 assert(abs(A.Resource-1)<=c.ConstraintTolerance&&A.GlobalOptimumCertified,'Bernstein registration failed.');
end
Checks=table(["Certified fold-specific fitting provenance";"All reference/degree/smoothing combinations"; ...
 "Both direct weighting objectives via exact statistics";"Coefficient order and exact boundaries"; ...
 "Full integer-grid range/order audit";"Numerical QP certificate and feasible witness"; ...
 "Shared evaluator and serialization";"Training outcome error distinguished from reference approximation"; ...
 "No tuning, freeze or independent evaluation"],true(9,1),'VariableNames',{'Check','Passed'});
for item={{'12_02_Diagnostics',Diagnostics},{'12_02_SolverAttempts',Attempts},{'12_02_Coefficients',Coefficients}, ...
 {'12_02_ModelIndex',Index},{'12_02_GateChecks',Checks},{'12_02_DisplaySourceData',display}}
 pair=item{1};writetable(pair{2},fullfile(report,[pair{1} '.csv']));
end
Coverage=U.Coverage();writetable(Coverage,fullfile(report,'12_02_ReviewerEditorCoverage.csv'));
Specification=U.Specification();
pub=[SourceFiles;V.TableExport(cfg,"Results","T_R12_02_FlexibleComplexity", ...
 Diagnostics(startsWith(Diagnostics.PackageID,"FULL_TRAIN")& ...
 (Diagnostics.FitBasis=="reference__"+string(c.DisplayReference)|startsWith(Diagnostics.FitBasis,"direct_")),:)); ...
 V.TableExport(cfg,"Supplementary","T_S12_03_BernsteinDiagnostics",Diagnostics); ...
 V.TableExport(cfg,"Supplementary","T_S12_04_BernsteinCoefficients",Coefficients)];
fig=figure('Visible','off','Color','w','Position',[100 100 1300 820]);clean=onCleanup(@()close(fig)); %#ok<NASGU>
tiledlayout(2,3,'TileSpacing','compact','Padding','compact');formats=["ODI","T20"];
for f=1:2
 B=display(display.Format==formats(f),:);h=max(B.BallsRemaining);
 nexttile;K=B(B.FitBasis=="reference__"+string(c.DisplayReference),:);hold on;
 colors=lines(4);wickets=[2 5 8 10];for z=1:4,wi=wickets(z);T=K(K.WicketsInHand==wi,:);plot(T.BallsRemaining/h,T.MeanReferenceResource,'--','Color',colors(z,:),'HandleVisibility','off');plot(T.BallsRemaining/h,T.FlexibleResource,'Color',colors(z,:),'LineWidth',1.2,'DisplayName',sprintf('w=%d',wi));end
 xlabel('Remaining legal-ball fraction');ylabel('Resource');ylim([0 1]);title(formats(f)+": reference dashed / flexible solid");legend('Location','northwest');
 nexttile;hold on;names=["reference__"+string(c.DisplayReference),"direct_state","direct_innings"];
 labels=["Reference fit","Direct: states","Direct: innings"];for z=1:numel(names),name=names(z);T=B(B.FitBasis==name&B.WicketsInHand==10,:);plot(T.BallsRemaining/h,T.FlexibleResource,'LineWidth',1.2,'DisplayName',char(labels(z)));end
 xlabel('Remaining legal-ball fraction');ylabel('Resource');ylim([0 1]);title(formats(f)+": full-wicket fitting-basis comparison");legend('Location','northwest','Interpreter','none');
 nexttile;delta=K.SignedMeanReferenceResidual;delta(~K.FittingSupport)=NaN;im=imagesc((0:h)/h,0:10,reshape(delta,h+1,11)');im.AlphaData=isfinite(im.CData);set(gca,'YDir','normal','Color',[.95 .95 .95]);colorbar;xlabel('Remaining legal-ball fraction');ylabel('Wickets in hand');title(formats(f)+": supported approximation residual");
end
axesList=findall(fig,'Type','axes');set(axesList,'FontName','Times New Roman','FontSize',10);
mask=display.FitBasis=="reference__"+string(c.DisplayReference)&display.FittingSupport;
lim=max(1e-6,max(abs(display.SignedMeanReferenceResidual(mask))));for a=axesList',if contains(string(a.Title.String),'residual'),clim(a,[-lim lim]);end,end
pub=[pub;U.FigureExport(cfg,"Results","F_M12_02_FlexibleFit",fig,display, ...
 "Provisional Bernstein fits: nominal-resource slices, full-wicket comparison of supported-reference and direct state/innings fitting bases, and supported mean-reference approximation residuals. Display degree/smoothing are declared examples, not performance-selected settings. Coefficient order guarantees monotonicity without forced concavity. Direct in-sample outcome errors and reference approximation are separate quantities. No independent predictive or target-policy superiority is claimed.",report)];
Flexible=struct('Stage',"12_02",'Status',"FLEXIBLE_READY_SELECTION_PENDING", ...
 'ResourcePackagePath',string(path),'Packages',table("Flexible",string(path),'VariableNames',{'PackageID','Path'}), ...
 'Diagnostics',Diagnostics,'Checks',Checks);
Flexible=V.Finish(cfg,'Flexible',out,S,g,report,Flexible,[pub;string(path)]);
end
