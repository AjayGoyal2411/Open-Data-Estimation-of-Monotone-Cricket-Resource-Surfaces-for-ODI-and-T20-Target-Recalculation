function c=RevisedCodes_12_00_Config(settings)
if nargin<1,settings=struct;end
c=struct('Version','12.2.0','ForceRebuild',false,'CompactStarts',8, ...
 'CompactMaxIterations',1500,'CompactTolerance',1e-10,'CompactFirstOrderLimit',1e-4, ...
 'CompactRidge',1e-6,'ParameterLower',[-8 .05 -6 -4 -4 -4], ...
 'ParameterUpper',[8 12 6 4 4 4],'NearOptimalTolerance',1e-6, ...
 'RunProfiles',true,'ProfileOffsets',[-.2 -.1 0 .1 .2], ...
 'Degrees',[3 5 7],'Smoothing',[0 .01 .1],'QPMaxIterations',3000, ...
 'QPTolerance',1e-10,'QPAttempts',3,'CertificateTolerance',1e-6, ...
 'ConstraintTolerance',2e-7,'DisplayReference','mean_state_n30_count_l0', ...
 'DisplayDegree',5,'DisplaySmoothing',.01, ...
 'RunBoundSensitivity',true,'BoundEMinima',[-4 -6 -8],'ContextHistoryK',20, ...
 'ContextLambdas',[0.0001 .001 .01 .1],'ContextDisplayLambda',.01, ...
 'ContextWeighting','innings','ContextMinCategoryInnings',30,'ContextMaxCategories',20);
assert(isstruct(settings)&&isscalar(settings),'Settings must be a scalar struct.');
for n=fieldnames(settings)'
 assert(isfield(c,n{1}),'Unknown Step12 setting %s.',n{1});c.(n{1})=settings.(n{1});
end
for n={'ForceRebuild','RunProfiles','RunBoundSensitivity'},validateattributes(c.(n{1}),{'logical'},{'scalar'});end
validateattributes(c.CompactStarts,{'numeric'},{'scalar','integer','>=',2});
validateattributes(c.ParameterLower,{'numeric'},{'vector','numel',6,'finite'});
validateattributes(c.ParameterUpper,{'numeric'},{'vector','numel',6,'finite'});
c.ParameterLower=c.ParameterLower(:);c.ParameterUpper=c.ParameterUpper(:);
assert(all(c.ParameterLower<c.ParameterUpper)&&c.ParameterLower(2)>0,'Invalid parameter bounds.');
assert(max(abs([c.ParameterLower;c.ParameterUpper]))<=20,'Bounds exceed the declared stable exponential range.');
validateattributes(c.Degrees,{'numeric'},{'vector','integer','>=',1,'<=',12,'finite'});
validateattributes(c.Smoothing,{'numeric'},{'vector','nonnegative','finite'});
assert(all(ismember([3 5 7],c.Degrees)),'Preserve degrees 3/5/7.');
assert(all(ismember([0 .01 .1],c.Smoothing)),'Preserve smoothing 0/.01/.1 candidates.');
c.Degrees=unique(c.Degrees(:)');c.Smoothing=unique(c.Smoothing(:)');
assert(ismember(c.DisplayDegree,c.Degrees)&&ismember(c.DisplaySmoothing,c.Smoothing),'Display candidate absent.');
for n={'CompactTolerance','CompactFirstOrderLimit','NearOptimalTolerance','QPTolerance','CertificateTolerance','ConstraintTolerance'}
 validateattributes(c.(n{1}),{'numeric'},{'scalar','positive','finite'});
end
validateattributes(c.CompactRidge,{'numeric'},{'scalar','nonnegative','finite'});
for n={'CompactMaxIterations','QPMaxIterations'},validateattributes(c.(n{1}),{'numeric'},{'scalar','positive','integer'});end
validateattributes(c.QPAttempts,{'numeric'},{'scalar','integer','>=',1,'<=',4});
validateattributes(c.ProfileOffsets,{'numeric'},{'vector','finite'});
validateattributes(c.BoundEMinima,{'numeric'},{'vector','finite','>=',-12,'<=',-4});
validateattributes(c.ContextLambdas,{'numeric'},{'vector','finite','positive'});
c.ContextLambdas=unique(c.ContextLambdas(:)');
assert(ismember(c.ContextDisplayLambda,c.ContextLambdas),'Context display lambda absent.');
validateattributes(c.ContextHistoryK,{'numeric'},{'scalar','integer','positive'});
assert(ismember(string(c.ContextWeighting),["state","innings"]),'Unknown context weighting.');
for name={'ContextMinCategoryInnings','ContextMaxCategories'}
 validateattributes(c.(name{1}),{'numeric'},{'scalar','positive','integer'});
end
end
