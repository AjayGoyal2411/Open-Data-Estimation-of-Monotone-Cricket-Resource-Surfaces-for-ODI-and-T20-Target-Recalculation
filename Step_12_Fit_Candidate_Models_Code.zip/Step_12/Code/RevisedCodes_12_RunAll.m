function Results12=RevisedCodes_12_RunAll(settings)
% All Step12 stages, with prerequisite audit, self-tests and combined checks.
if nargin<1,settings=struct;end
Results12=struct;Results12.SelfTests=RevisedCodes_12_SelfTests(settings);
Results12.ContextSelfTests=RevisedCodes_12_ContextSelfTests(settings);
Results12.Compact=RevisedCodes_12_01_CompactBaseline(settings);
Results12.Flexible=RevisedCodes_12_02_BernsteinModel(settings);
Results12.Context=RevisedCodes_12_03_ContextForecasts(settings);
cfg=RevisedCodes_09_00_Config;V=RevisedCodes_10_Utils;
[g,~]=V.Generation(fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step12','combined_checks'));
copyfile(Results12.Compact.ReportDirectory,fullfile(g,'12_01'));
copyfile(Results12.Flexible.ReportDirectory,fullfile(g,'12_02'));
copyfile(Results12.Context.ReportDirectory,fullfile(g,'12_03'));
writetable([Results12.SelfTests;Results12.ContextSelfTests],fullfile(g,'12_AlgorithmSelfTests.csv'));
Status=table(["Compact candidates fitted";"Bernstein candidates fitted";"Context forecasts Step12_03"; ...
 "Literal original Z equation confirmed";"Final model selected/frozen";"Independent performance evaluated"], ...
 [true;true;true;false;false;false],'VariableNames',{'Stage','Complete'});
writetable(Status,fullfile(g,'12_CompletionStatus.csv'));
p=fullfile(cfg.ProjectRoot,'RevisedCodes_12_Checks.zip');
zip(p,{'12_01','12_02','12_03','12_AlgorithmSelfTests.csv','12_CompletionStatus.csv'},g);
Results12.CombinedChecks=string(p);disp(Status);
fprintf('STEP12 COMPLETE: 12_01, 12_02 and 12_03. Upload %s. Selection, freeze and independent evaluation remain later.\n',p);
end
