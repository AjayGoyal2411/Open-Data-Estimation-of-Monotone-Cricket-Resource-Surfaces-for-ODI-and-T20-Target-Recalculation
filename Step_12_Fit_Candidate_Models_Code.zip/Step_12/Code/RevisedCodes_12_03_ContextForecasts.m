function Context=RevisedCodes_12_03_ContextForecasts(settings)
% Development forecasting only. Context models NEVER become target resources.
if nargin<1,settings=struct;end
c=RevisedCodes_12_00_Config(settings);U=RevisedCodes_12_Utils;V=RevisedCodes_10_Utils;W=RevisedCodes_12_ContextUtils;
[cfg,~,E,paths]=U.Inputs();[~,R,D,~,~]=V.Inputs();
cp=fullfile(cfg.OutputRoot,'context','RevisedCodes_09_02_Result.mat');z=load(cp,'Context');C=z.Context;
paths=unique([paths;string(cp);string(C.Partitions.Path);string(D.Partitions.Path)],'stable');
S=U.Signature("12_03",c,paths);root=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step12');
out=fullfile(root,'RevisedCodes_12_03_Result.mat');[reuse,Context]=V.Cache(out,'Context',S,c);
if reuse,fprintf('12_03 valid cache reused.\n');return;end
assert(ismember(c.ContextHistoryK,D.Options.ShrinkageCandidates),'Requested history K absent from 09_02A.');
[g,report]=V.Generation(root);Index=table;Models=cell(0,1);Scores=table;Solver=table;Coefficients=table;
Availability=table;Population=table;Subgroups=table;Dictionary=table;Preprocessing=table;Drift=table;DataFiles=strings(0,1);
for package=1:height(E.Packages)
 row=E.Packages(package,:);z=load(row.Path,'Surface');surface=z.Surface;
 [Shards,Ledger,Inventory]=makeShards(cfg,R,D,C,surface,g,c);
 shardManifest=fullfile(g,char(row.PackageID+"_ShardManifest.csv"));writetable(Shards,shardManifest);
 DataFiles=[DataFiles;string(shardManifest);Shards.Path]; %#ok<AGROW>
 Cat=W.Categories(Inventory(Inventory.Role=="fit",:),c);
 catTable=Cat.Dictionary;catTable.PackageID=repmat(row.PackageID,height(catTable),1);Dictionary=[Dictionary;catTable]; %#ok<AGROW>
 sw=[];sx=[];sx2=[];tw=0;
 % Training-only preprocessing. Assessment rows contribute no moments.
 for j=1:height(Shards)
  z=load(Shards.Path(j),'Features','Audit');fit=z.Audit.Role=="fit";
  if ~any(fit),continue;end
  [X,names,groups]=W.Raw(z.Features(fit,:),surface.Horizon,surface.FullStartMean,Cat,c.ContextHistoryK);
  weight=z.Audit.Weight(fit);valid=isfinite(X);X(~valid)=0;
  if isempty(sw),sw=zeros(1,size(X,2));sx=sw;sx2=sw;end
  sw=sw+weight'*double(valid);sx=sx+weight'*X;sx2=sx2+weight'*(X.^2);tw=tw+sum(weight);
 end
 expectedWeight=surface.TrainingStates;if string(c.ContextWeighting)=="innings",expectedWeight=surface.TrainingInnings;end
 assert(tw>0&&abs(tw-expectedWeight)<=1e-7*max(1,expectedWeight),'Context fitting weights do not reconcile.');P=W.Preprocessor(sw,sx,sx2,names,groups,Cat,tw);
 PP=table(repmat(row.PackageID,numel(names),1),names(:),groups(:),P.Mean(:),P.Scale(:), ...
 P.AllMissing(:),P.Constant(:),P.TrainingAvailableWeight(:)/tw, ...
 'VariableNames',{'PackageID','Term','AblationGroup','TrainingMean','TrainingScale','AllTrainingMissing','TrainingConstant','TrainingAvailability'});
 Preprocessing=[Preprocessing;PP]; %#ok<AGROW>
 active=find(~P.Constant);dimension=numel(active)+1;G=zeros(dimension);b=zeros(dimension,1);y2=0;
 for j=1:height(Shards)
  z=load(Shards.Path(j),'Features','Audit');fit=z.Audit.Role=="fit";
  if ~any(fit),continue;end
  X=W.Encode(z.Features(fit,:),surface.Horizon,surface.FullStartMean,P,c.ContextHistoryK);
  X=[ones(nnz(fit),1),X(:,active)];weight=z.Audit.Weight(fit);y=z.Audit.RemainingRuns(fit)/surface.FullStartMean;
  G=G+X'*(X.*weight);b=b+X'*(weight.*y);y2=y2+sum(weight.*y.^2);
 end
 G=G/tw;b=b/tw;y2=y2/tw;packageModels=cell(0,1);labels=W.Labels();
 for ablation=1:5
  positions=find(groups(active)<=ablation);cols=active(positions);select=[1,positions+1];
  for lambda=c.ContextLambdas
   [beta,Q]=W.Solve(G(select,select),b(select),y2,lambda);
   id="C1_"+labels(ablation)+"_lambda"+string(lambda);
   M=struct('ModelID',id,'PackageID',row.PackageID,'Cohort',row.Cohort,'Format',row.Format, ...
    'Horizon',surface.Horizon,'FullStartMean',surface.FullStartMean,'HistoryK',c.ContextHistoryK, ...
    'Preprocessor',P,'Columns',cols,'Beta',beta,'Lambda',lambda,'Ablation',labels(ablation), ...
    'TrainingCutoffExclusive',row.TrainingCutoffExclusive,'FitDiagnostics',Q, ...
    'ForecastOnly',true,'OfficialRankings',false,'ModelSelected',false,'PolicyFrozen',false, ...
    'FeatureNames',["Intercept",names(cols)],'OutputPolicy',"Nonnegative remaining-run forecast, no upper capacity cap");
   packageModels{end+1,1}=M;Models{end+1,1}=M; %#ok<AGROW>
   ix=table(row.PackageID,row.Cohort,row.Format,id,labels(ablation),lambda,numel(beta), ...
    row.TrainingCutoffExclusive,'VariableNames',{'PackageID','Cohort','Format','ModelID','Ablation','Lambda','Coefficients','TrainingCutoffExclusive'});
   Index=[Index;ix]; %#ok<AGROW>
   Solver=[Solver;table(row.PackageID,id,Q.StationarityResidual,Q.ConditionNumber,Q.RegularizedObjective, ...
    Q.TrainingNormalizedRawSSE,Q.Penalty,'VariableNames',{'PackageID','ModelID','StationarityResidual', ...
    'ConditionNumber','RegularizedObjective','TrainingNormalizedRawSSE','Penalty'})]; %#ok<AGROW>
   coef=table(repmat(row.PackageID,numel(beta),1),repmat(id,numel(beta),1),M.FeatureNames(:),beta, ...
    beta*surface.FullStartMean,'VariableNames',{'PackageID','ModelID','Term','NormalizedCoefficient','RunsPerTrainingSD'});
   Coefficients=[Coefficients;coef]; %#ok<AGROW>
  end
 end
 % Stream identical states through EVERY candidate. Retain clustered errors.
 numModels=numel(packageModels);n=height(Ledger);sumSq=zeros(n,numModels);sumAbs=sumSq;negative=sumSq;count=zeros(n,1);
 support=zeros(2,6);supportTotal=zeros(2,1);populationStates=zeros(2,1);
 driftSum=zeros(2,numel(names));driftWeight=zeros(2,1);
 for j=1:height(Shards)
  z=load(Shards.Path(j),'Features','Audit');F=z.Features;A=z.Audit;
  X=W.Encode(F,surface.Horizon,surface.FullStartMean,P,c.ContextHistoryK);
  for k=1:numModels
   M=packageModels{k};raw=([ones(height(F),1),X(:,M.Columns)]*M.Beta)*surface.FullStartMean;
   prediction=max(0,raw);error=prediction-A.RemainingRuns;
   sumSq(:,k)=sumSq(:,k)+accumarray(A.LedgerIndex,error.^2,[n,1],@sum,0);
   sumAbs(:,k)=sumAbs(:,k)+accumarray(A.LedgerIndex,abs(error),[n,1],@sum,0);
   negative(:,k)=negative(:,k)+accumarray(A.LedgerIndex,double(raw<0),[n,1],@sum,0);
  end
  count=count+accumarray(A.LedgerIndex,1,[n,1],@sum,0);
  missingVenue=ismissing(string(F.Venue))|strlength(strtrim(string(F.Venue)))==0;
  missingEvent=ismissing(string(F.EventName))|strlength(strtrim(string(F.EventName)))==0;
  missing=[double(F.HistoryBattingN)==0,double(F.HistoryOpponentN)==0, ...
   double(F.HistoryVenueN)==0,double(F.HistoryEventN)==0, ...
   ~missingVenue&~ismember(string(F.Venue),Cat.VenueSeen),~missingEvent&~ismember(string(F.EventName),Cat.EventNameSeen)];
  for role=1:2
   keep=A.Role==roleName(role);weight=A.Weight(keep);
   driftSum(role,:)=driftSum(role,:)+weight'*X(keep,:);driftWeight(role)=driftWeight(role)+sum(weight);
   support(role,:)=support(role,:)+sum(missing(keep,:),1);
   supportTotal(role)=supportTotal(role)+nnz(keep);populationStates(role)=populationStates(role)+nnz(keep);
  end
 end
 assert(isequal(count,Ledger.States),'Context states differ from audited innings inventory.');
 % Cluster table is saved locally, while compact summaries enter review ZIP.
 ClusterScores=Ledger;ClusterScores.MSE=sumSq./count;ClusterScores.MAE=sumAbs./count;ModelIDs=strings(numModels,1);
 for k=1:numModels,ModelIDs(k)=packageModels{k}.ModelID;end %#ok<NASGU>
 clusterPath=fullfile(g,char(row.PackageID+"_ClusterScores.mat"));save(clusterPath,'ClusterScores','ModelIDs','-v7.3');DataFiles(end+1,1)=string(clusterPath); %#ok<AGROW>
 for role=1:2
  keep=Ledger.Role==roleName(role);if ~any(keep),continue;end
  Population=[Population;table(row.PackageID,roleName(role),nnz(keep),numel(unique(Ledger.MatchID(keep))), ...
   sum(count(keep)),min(Ledger.Date(keep)),max(Ledger.Date(keep)), ...
   'VariableNames',{'PackageID','Role','Innings','Matches','States','EarliestDate','LatestDate'})]; %#ok<AGROW>
  Drift=[Drift;table(repmat(row.PackageID,numel(names),1),repmat(roleName(role),numel(names),1), ...
   names(:),(driftSum(role,:)/driftWeight(role))',P.Constant(:), ...
   'VariableNames',{'PackageID','Role','Term','WeightedMeanInTrainingSD','TrainingConstant'})]; %#ok<AGROW>
  missingVenue=ismissing(string(Inventory.Venue))|strlength(strtrim(string(Inventory.Venue)))==0;
  missingEvent=ismissing(string(Inventory.EventName))|strlength(strtrim(string(Inventory.EventName)))==0;
  inningsMissing=[Inventory.HistoryBattingN==0,Inventory.HistoryOpponentN==0, ...
   Inventory.HistoryVenueN==0,Inventory.HistoryEventN==0, ...
   ~missingVenue&~ismember(string(Inventory.Venue),Cat.VenueSeen), ...
   ~missingEvent&~ismember(string(Inventory.EventName),Cat.EventNameSeen)];
  diagnosticNames=["NoBattingHistory","NoOpponentHistory","NoVenueHistory","NoEventHistory","UnseenVenue","UnseenEvent"];
  for h=1:6
   Availability=[Availability;table(row.PackageID,roleName(role),diagnosticNames(h),support(role,h),supportTotal(role), ...
    support(role,h)/supportTotal(role),nnz(keep&inningsMissing(:,h)),nnz(keep), ...
    'VariableNames',{'PackageID','Role','Diagnostic','States','PopulationStates','Fraction','Innings','PopulationInnings'})]; %#ok<AGROW>
  end
  for k=1:numModels
   M=packageModels{k};mseState=sum(sumSq(keep,k))/sum(count(keep));maeState=sum(sumAbs(keep,k))/sum(count(keep));
   mseInnings=mean(sumSq(keep,k)./count(keep));maeInnings=mean(sumAbs(keep,k)./count(keep));
   Scores=[Scores;table(row.PackageID,row.Cohort,row.Format,roleName(role),M.ModelID,M.Ablation,M.Lambda, ...
    nnz(keep),sum(count(keep)),sqrt(mseState),maeState,sqrt(mseInnings),maeInnings, ...
    sum(negative(keep,k))/sum(count(keep)), ...
    'VariableNames',{'PackageID','Cohort','Format','Role','ModelID','Ablation','Lambda','Innings','States', ...
    'StateRMSE','StateMAE','EqualInningsRMSE','EqualInningsMAE','NegativeRawForecastFraction'})]; %#ok<AGROW>
   if M.Lambda==c.ContextDisplayLambda&&M.Ablation==labels(end)
    Subgroups=[Subgroups;subgroupScores(Ledger,keep,count,sumSq(:,k),sumAbs(:,k),row,M.ModelID)]; %#ok<AGROW>
   end
  end
 end
 fprintf('Step12 context %s complete: %d fitting states, %d assessment states, %d candidates.\n', ...
 row.PackageID,populationStates(1),populationStates(2),numModels);
end
ForecastPackage=struct('SchemaVersion',"12.2.0",'Index',Index,'Models',{Models},'Signature',S, ...
 'ForecastOnly',true,'OfficialRankings',false,'ModelSelected',false,'PolicyFrozen',false, ...
 'Status',"CONTEXT_FORECAST_CANDIDATES_DEVELOPMENT_EVIDENCE_ONLY");
path=fullfile(g,'RevisedCodes_12_ContextPackage.mat');save(path,'ForecastPackage','-v7.3');
z=load(path,'ForecastPackage');assert(isequaln(z.ForecastPackage.Index,Index),'Context serialization failed.');
Checks=table(["Exact state/source feature joins";"Original-train only; cases and validation/test excluded"; ...
 "Fold fitting and assessment chronology";"Histories strictly earlier and before fold cutoff"; ...
 "Training-only imputation/scaling/category vocabulary";"Identical states/innings for all five ablations"; ...
 "Positive ridge and normal-equation stationarity";"Raw source labels and actual calendar era retained"; ...
 "Development errors distinct from independent performance";"Forecasts excluded from target-resource policy"], ...
 true(10,1),'VariableNames',{'Check','Passed'});
for item={{'12_03_ModelIndex',Index},{'12_03_DevelopmentScores',Scores},{'12_03_SolverDiagnostics',Solver}, ...
 {'12_03_Coefficients',Coefficients},{'12_03_ContextAvailability',Availability},{'12_03_Populations',Population}, ...
 {'12_03_ActualEventEraGroups',Subgroups},{'12_03_CategoryDictionary',Dictionary}, ...
 {'12_03_TrainingPreprocessing',Preprocessing},{'12_03_ContextDrift',Drift},{'12_03_GateChecks',Checks}}
 pair=item{1};writetable(pair{2},fullfile(report,[pair{1} '.csv']));
end
writetable(U.Coverage(),fullfile(report,'12_03_ReviewerEditorCoverage.csv'));
pub=[V.TableExport(cfg,"Methodology","T_M19_ContextModelSpecification", ...
 table((1:5)',labels(:),["u,w polynomial terms";"Add genuine partnership reset and retirement count"; ...
 "Add strictly earlier format/team/opponent scoring histories and support"; ...
 "Add earlier venue/event scoring histories, exact source categories and missingness"; ...
 "Add score and recent-window rates; context-by-ball-fraction interactions retained"], ...
 'VariableNames',{'Order','Ablation','AddedInformation'})); ...
 V.TableExport(cfg,"Results","T_R12_03_ContextAblations",Scores(Scores.Role=="assessment"&Scores.Lambda==c.ContextDisplayLambda,:)); ...
 V.TableExport(cfg,"Supplementary","T_S12_06_ContextCandidateScores",Scores); ...
 V.TableExport(cfg,"Supplementary","T_S12_07_ContextAvailability",Availability); ...
 V.TableExport(cfg,"Supplementary","T_S12_08_ActualEventEraGroups",Subgroups)];
fig=figure('Visible','off','Color','w','Position',[100 100 1400 880]);clean=onCleanup(@()close(fig)); %#ok<NASGU>
tiledlayout(2,3,'TileSpacing','compact','Padding','compact');formats=["ODI","T20"];FigureSource=table;
for f=1:2
 nexttile;B=Scores(Scores.Format==formats(f)&Scores.Role=="assessment"&Scores.Lambda==c.ContextDisplayLambda,:);
 value=nan(5,1);for a=1:5,K=B(B.Ablation==labels(a),:);if ~isempty(K),value(a)=sqrt(sum(K.EqualInningsRMSE.^2.*K.Innings)/sum(K.Innings));end;end
 FigureSource=[FigureSource;table(repmat("DevelopmentRMSE",5,1),repmat(formats(f),5,1),labels(:),value, ...
  repmat("runs",5,1),'VariableNames',{'Panel','Format','Label','Value','Unit'})]; %#ok<AGROW>
 bar(1:5,value);xticks(1:5);xticklabels(["Core","Partner","History","Venue/event","Score/rate"]);xtickangle(25);
 ylabel('Equal-innings RMSE (runs)');title(formats(f)+": chronological development forecasts");
 nexttile;B=Coefficients(Coefficients.PackageID=="FULL_TRAIN_"+formats(f)& ...
 Coefficients.ModelID=="C1_"+labels(end)+"_lambda"+string(c.ContextDisplayLambda)& ...
 ~contains(Coefficients.Term,"Missing")&~ismember(Coefficients.Term, ...
 ["Intercept","BallFraction","WicketFraction","BallWicket","BallSquared","WicketSquared","BallSquaredWicket","BallWicketSquared"]),:);
 [~,ix]=sort(abs(B.RunsPerTrainingSD),'descend');ix=ix(1:min(8,numel(ix)));B=B(ix,:);
 FigureSource=[FigureSource;table(repmat("ConditionalCoefficient",height(B),1),repmat(formats(f),height(B),1), ...
  B.Term,B.RunsPerTrainingSD,repmat("runs per training SD",height(B),1), ...
  'VariableNames',{'Panel','Format','Label','Value','Unit'})]; %#ok<AGROW>
 barh(B.RunsPerTrainingSD);yticks(1:height(B));modelIndex=find(Index.PackageID=="FULL_TRAIN_"+formats(f)&Index.ModelID=="C1_"+labels(end)+"_lambda"+string(c.ContextDisplayLambda));
 yticklabels(shortLabels(B.Term,Models{modelIndex}.Preprocessor.Categories));set(gca,'TickLabelInterpreter','none');
 xlabel('Conditional coefficient (runs / training SD)');title(formats(f)+": association, not causal effect");
 nexttile;B=Availability(Availability.PackageID=="FULL_TRAIN_"+formats(f)&Availability.Role=="fit",:);
 FigureSource=[FigureSource;table(repmat("HistoryAvailability",height(B),1),repmat(formats(f),height(B),1), ...
  B.Diagnostic,100*B.Fraction,repmat("states percent",height(B),1), ...
  'VariableNames',{'Panel','Format','Label','Value','Unit'})]; %#ok<AGROW>
 bar(100*B.Fraction);xticks(1:height(B));xticklabels(["Team","Opponent","Venue","Event","New venue","New event"]);xtickangle(25);
 ylabel('States (%)');title(formats(f)+": missing history / unseen categories");
end
pub=[pub;U.FigureExport(cfg,"Results","F_M12_03_ContextForecasts",fig,FigureSource, ...
 "Nested ridge context ablations on identical chronological development populations, conditional standardized coefficients, and history availability. Lambda is a prespecified display value, not an independently selected optimum. Coefficients are associations conditional on correlated predictors, not causal effects. Histories are scoring proxies, not official ICC rankings. Original validation/test/case observations are excluded. Forecasts do not modify nominal resource or target policy.",report)];
Context=struct('Stage',"12_03",'Status',"CONTEXT_READY_DEVELOPMENT_ONLY_SELECTION_PENDING", ...
 'ForecastPackagePath',string(path),'Packages',table("Context",string(path),'VariableNames',{'PackageID','Path'}), ...
 'Scores',Scores,'Checks',Checks,'ForecastOnly',true,'IndependentPerformanceEvaluated',false);
Context=V.Finish(cfg,'Context',out,S,g,report,Context,[pub;DataFiles;string(path)]);
end
function labels=shortLabels(labels,C)
for field=["Venue","EventName"]
 for j=1:numel(C.(field))
  v=labels==field+"Category"+string(j);text=C.(field)(j);
  if strlength(text)>22,text=extractBefore(text,23)+"...";end
  labels(v)=field+": "+text;
 end
end
labels=strrep(labels,"_ByBallFraction"," x ball fraction");
labels=strrep(labels,"HistoricalMeanOverMu"," history / mean");
labels=strrep(labels,"HistoryN"," history count");
labels=strrep(labels,"LogBallsSinceDismissal","Log partnership balls");
end
function s=roleName(k)
s="fit";if k==2,s="assessment";end
end
function [Shards,L,Inventory]=makeShards(cfg,R,D,C,surface,g,c)
V=RevisedCodes_10_Utils;W=RevisedCodes_12_ContextUtils;
cohort=surface.Cohort;format=surface.Format;cut=surface.TrainingCutoffExclusive;
L=surface.TrainingLedger(:,{'MatchID','InningsIndex','Date','CachedPrimaryStates'});
L.Properties.VariableNames{4}='States';L.Role=repmat("fit",height(L),1);
if cohort~="FULL_TRAIN"
 M=D.InningsMembership(D.InningsMembership.FoldID==cohort&D.InningsMembership.Format==format&D.InningsMembership.Role=="assessment",:);
 B=M(:,{'MatchID','InningsIndex','Date','States','Role'});L=[L;B];
end
L.MatchID=string(L.MatchID);keys=V.Key(L);assert(numel(unique(keys))==height(L),'Duplicated context innings ledger.');
Inventory=table;seen=zeros(height(L),1);Shards=table;folder=fullfile(g,char(surface.PackageID+"_context_data"));mkdir(folder);
if cohort=="FULL_TRAIN"
 dates=unique(dateshift(L.Date,'start','day'));previousDate=[NaT;dates(1:end-1)];
 source=(1:height(R.Partitions))';paths=string(C.Partitions.Path);
else
 B=D.Partitions(D.Partitions.FoldID==cohort,:);source=B.SourcePartition;paths=B.Path;
end
for part=1:numel(source)
 if part==1||mod(part,16)==0,fprintf('Context %s source partitions %d/%d.\n',surface.PackageID,part,numel(source));end
 z=load(R.Partitions.Path(source(part)),'States');S=z.States;
 if cohort=="FULL_TRAIN"
  z=load(paths(part),'Features');F=z.Features;
  assert(isequal(W.StateKey(S),W.StateKey(F)),'Original context keys differ.');
  keep=S.PrimaryEligibleObservation&S.Split=="train"&~S.CaseReserved&S.Format==format;
  S=S(keep,:);F=F(keep,:);
  for entity=["Format","Batting","Opponent","Venue","Event"]
   name="History"+entity+"Mean";cnt=double(F.("History"+entity+"N"));mu=double(F.HistoryFormatMean);
   if entity=="Format",value=mu;else
    total=double(F.(name)).*(cnt+C.ShrinkagePseudoInnings)-C.ShrinkagePseudoInnings*mu;
    value=(total+c.ContextHistoryK*mu)./(cnt+c.ContextHistoryK);
   end
   F.(name+"_K"+string(c.ContextHistoryK))=value;
  end
  [found,dateIndex]=ismember(dateshift(S.MatchDate,'start','day'),dates);assert(all(found));
  maxSourceDate=previousDate(dateIndex);
  assert(all(isnat(maxSourceDate)|(maxSourceDate<dateshift(S.MatchDate,'start','day')&maxSourceDate<cut)), ...
   'Forbidden full-training chronological history source.');
 else
  z=load(paths(part),'Features','Identities','Membership','Provenance');
  [found,ix]=ismember(W.StateKey(z.Identities),W.StateKey(S));assert(all(found),'Fold state missing from source.');
  S=S(ix,:);F=z.Features;assert(isequal(W.StateKey(z.Identities),W.StateKey(z.Membership)),'Fold membership key mismatch.');
  assert(isequal(string(z.Provenance.MatchID),string(z.Identities.MatchID))&& ...
   isequal(z.Provenance.InningsIndex,z.Identities.InningsIndex),'Fold provenance join differs.');
  keep=S.Format==format;S=S(keep,:);F=F(keep,:);maxSourceDate=z.Provenance.MaxHistorySourceDate(keep);
  expectedRole=z.Membership.Role(keep);
  assert(all(isnat(maxSourceDate)|(maxSourceDate<S.MatchDate&maxSourceDate<cut)),'Forbidden fold history source.');
 end
 if isempty(S),continue;end
 [found,ix]=ismember(V.Key(S),keys);assert(all(found),'State not in allowed context ledger.');
 roles=L.Role(ix);if cohort~="FULL_TRAIN",assert(isequal(roles,expectedRole),'Fold roles differ.');end
 assert(all(S.PrimaryEligibleObservation&S.Split=="train"&~S.CaseReserved),'Forbidden context observations.');
 assert(all(S.MatchDate(roles=="fit")<cut),'Fitting date crosses cutoff.');
 if any(roles=="assessment")
  f=find(D.Folds.FoldID==cohort);assert(isscalar(f),'Unknown fold.');
  assert(all(S.MatchDate(roles=="assessment")>=cut&S.MatchDate(roles=="assessment")<D.Folds.AssessmentEndExclusive(f)), ...
   'Assessment date outside declared fold.');
 end
 assert(numel(unique(W.StateKey(S)))==height(S),'Duplicate source states.');
 assert(all(S.PrimaryRemainingRuns==S.FinalDeliveryRuns-S.DeliveryScoreBefore)&& ...
  all(isfinite(S.PrimaryRemainingRuns)&S.PrimaryRemainingRuns>=0),'Outcome reconciliation differs.');
 fit=roles=="fit";assert(all(S.FinalDeliveryRuns(fit)==surface.TrainingLedger.DeliveryRuns(ix(fit))), ...
  'Context training totals differ from Step10 normalization inventory.');
 weight=ones(height(S),1);if string(c.ContextWeighting)=="innings",weight=1./L.States(ix);end
 Audit=S(:,{'MatchID','InningsIndex','DeliverySeq','StateType','MatchDate','Gender','EventName','Venue'});
 Audit.Role=roles;Audit.RemainingRuns=double(S.PrimaryRemainingRuns);Audit.Weight=weight;Audit.LedgerIndex=ix;
 Audit.MaxHistorySourceDate=maxSourceDate;Audit.SourceCutoffExclusive=repmat(cut,height(S),1);
 allowed=["BallsRemaining","WicketsInHand","ScoreBefore","LegalBallsSinceDismissal", ...
  "NoDismissalYet","RetiredNotOutEventsBefore","RunRateBefore","NoLegalBallYet", ...
  "Recent30Runs","Recent30LegalBalls","Recent30RunRate","Opponent","BattingTeam","Venue","EventName"];
 for entity=["Format","Batting","Opponent","Venue","Event"]
  allowed=[allowed,"History"+entity+"N","History"+entity+"Mean_K"+string(c.ContextHistoryK)]; %#ok<AGROW>
 end
 Features=F(:,cellstr(allowed)); %#ok<NASGU>
 path=fullfile(folder,sprintf('Part%04d.mat',part));save(path,'Features','Audit','-v7.3');
 Shards=[Shards;table(string(path),height(S),'VariableNames',{'Path','Rows'})]; %#ok<AGROW>
 seen=seen+accumarray(ix,1,[height(L),1],@sum,0);
 [~,first]=unique(ix,'stable');B=Audit(first,{'MatchID','InningsIndex','Role','Gender','EventName','Venue'});
 for entity=["Batting","Opponent","Venue","Event"]
  B.("History"+entity+"N")=double(F.("History"+entity+"N")(first));
 end
 Inventory=[Inventory;B]; %#ok<AGROW>
end
assert(isequal(seen,L.States),'Context construction populations differ from Step10/09_02A.');
assert(height(Inventory)==height(L)&&numel(unique(V.Key(Inventory)))==height(L),'Innings span repeated partitions.');
[found,ix]=ismember(keys,V.Key(Inventory));assert(all(found));Inventory=Inventory(ix,:);
L.Gender=Inventory.Gender;L.EventName=Inventory.EventName;L.Venue=Inventory.Venue;
% Era means actual calendar year, no invented historical eras.
L.CalendarYear=year(L.Date);
end
function T=subgroupScores(L,keep,count,sq,ab,row,id)
T=table;
for field=["EventName","CalendarYear","Gender"]
 values=string(L.(field));values(ismissing(values)|strlength(strtrim(values))==0)="[source missing]";
 for value=unique(values(keep))'
  v=keep&values==value;
  T=[T;table(row.PackageID,id,string(L.Role(find(v,1))),field,value,nnz(v),sum(count(v)), ...
   sqrt(mean(sq(v)./count(v))),mean(ab(v)./count(v)), ...
   'VariableNames',{'PackageID','ModelID','Role','SourceGrouping','RawSourceCategory','Innings','States','EqualInningsRMSE','EqualInningsMAE'})]; %#ok<AGROW>
 end
end
end
