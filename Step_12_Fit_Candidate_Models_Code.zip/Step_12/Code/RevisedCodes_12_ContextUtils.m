function U=RevisedCodes_12_ContextUtils
% Predictors are an explicit allowlist. Outcomes and identifiers stay separate.
U.Raw=@raw;U.Encode=@encode;U.Solve=@solve;U.Predict=@predict;U.Preprocessor=@preprocessor;
U.StateKey=@stateKey;U.Categories=@categories;U.Labels=@labels;
end
function k=stateKey(T)
k=string(T.MatchID)+"|"+string(T.InningsIndex)+"|"+string(T.DeliverySeq)+"|"+string(T.StateType);
end
function names=labels
names=["Core","Partnership","TeamOpponentHistory","VenueEvent","ScoreRecentRate"];
end
function C=categories(T,c)
% Exact source labels only: no inferred aliases or fabricated ICC categories.
C=struct;C.Dictionary=table;
for field=["Venue","EventName"]
 value=string(T.(field));good=~ismissing(value)&strlength(strtrim(value))>0;
 [v,~,g]=unique(value(good));count=zeros(numel(v),1);if ~isempty(v),count=accumarray(g,1,[numel(v),1]);end
 B=table(v,count,'VariableNames',{'RawLabel','TrainingInnings'});
 B=sortrows(B,{'TrainingInnings','RawLabel'},{'descend','ascend'});
 selected=B.TrainingInnings>=c.ContextMinCategoryInnings;
 ix=find(selected);ix=ix(1:min(numel(ix),c.ContextMaxCategories));
 C.(field)=B.RawLabel(ix);C.([char(field) 'Seen'])=B.RawLabel;
 B.Selected=ismember(B.RawLabel,C.(field));B.Entity=repmat(field,height(B),1);
 C.Dictionary=[C.Dictionary;B]; %#ok<AGROW>
end
end
function [X,names,groups]=raw(F,U,mu,C,K)
x=double(F.BallsRemaining)/U;w=double(F.WicketsInHand)/10;
X=[x,w,x.*w,x.^2,w.^2,x.^2.*w,x.*w.^2];
names=["BallFraction","WicketFraction","BallWicket","BallSquared","WicketSquared","BallSquaredWicket","BallWicketSquared"];
groups=ones(1,7);
A=[log1p(double(F.LegalBallsSinceDismissal)),double(F.NoDismissalYet),double(F.RetiredNotOutEventsBefore)];
n=["LogBallsSinceDismissal","NoDismissalYet","RetiredNotOutEventsBefore"];
X=[X,A];names=[names,n];groups=[groups,repmat(2,1,size(A,2))];
suffix="_K"+string(K);
for group=3:4
 entities=["Format","Batting","Opponent"];if group==4,entities=["Venue","Event"];end
 A=[];n=strings(1,0);
 for entity=entities
  field="History"+entity+"Mean"+suffix;
  assert(ismember(field,string(F.Properties.VariableNames)),'Missing fold-safe %s.',field);
  count=double(F.("History"+entity+"N"));
  A=[A,double(F.(field))/mu,log1p(count),double(count==0)]; %#ok<AGROW>
  n=[n,entity+"HistoricalMeanOverMu","Log"+entity+"HistoryN","No"+entity+"History"]; %#ok<AGROW>
 end
 X=[X,A];names=[names,n];groups=[groups,repmat(group,1,size(A,2))]; %#ok<AGROW>
end
A=[double(F.ScoreBefore)/mu,double(F.RunRateBefore)/6,double(F.Recent30RunRate)/6, ...
 double(F.Recent30Runs)/mu,double(F.Recent30LegalBalls)/30,double(F.NoLegalBallYet)];
n=["ScoreOverMu","RunsPerBallBefore","RecentRunsPerBall","RecentRunsOverMu","RecentWindowFraction","NoLegalBallYet"];
X=[X,A];names=[names,n];groups=[groups,repmat(5,1,size(A,2))];
% Allow contextual associations to depend on remaining-ball fraction.
context=find(groups>1);X=[X,X(:,context).*x];names=[names,names(context)+"_ByBallFraction"];groups=[groups,groups(context)];
for field=["Venue","EventName"]
 value=string(F.(field));missing=ismissing(value)|strlength(strtrim(value))==0;
 A=double(missing);n=field+"Missing";
 selected=C.(field);
 for j=1:numel(selected)
  v=double(~missing&value==selected(j));v(missing)=0;
  A=[A,v];n=[n,field+"Category"+string(j)]; %#ok<AGROW>
 end
 other=~missing&~ismember(value,selected);A=[A,double(other)];n=[n,field+"Other"];
 X=[X,A];names=[names,n];groups=[groups,repmat(4,1,size(A,2))]; %#ok<AGROW>
end
missing=~isfinite(X);X(missing)=NaN;
X=[X,double(missing)];names=[names,names+"_Missing"];groups=[groups,groups];
end
function P=preprocessor(sw,sx,sx2,names,groups,C,totalWeight)
meanValue=zeros(1,numel(sw));good=sw>0;meanValue(good)=sx(good)./sw(good);
variance=zeros(size(meanValue));variance(good)=max(0,sx2(good)./sw(good)-meanValue(good).^2);
% Imputed entries equal the mean; normalize variance over ALL training weight.
variance=variance.*sw/totalWeight;sd=sqrt(variance);constant=sd<1e-10;sd(constant)=1;
P=struct('Mean',meanValue,'Scale',sd,'Names',names,'Groups',groups,'Categories',C, ...
 'AllMissing',~good,'Constant',constant,'TrainingAvailableWeight',sw, ...
 'TotalTrainingWeight',totalWeight,'Policy',"Training-only weighted mean imputation and standardization; explicit missing indicators");
end
function X=encode(F,U,mu,P,K)
[A,names,groups]=raw(F,U,mu,P.Categories,K);
assert(isequal(names,P.Names)&&isequal(groups,P.Groups),'Feature specification changed.');
for j=1:size(A,2),v=~isfinite(A(:,j));A(v,j)=P.Mean(j);end
X=(A-P.Mean)./P.Scale;
assert(all(isfinite(X),'all'),'Nonfinite encoded predictor.');
end
function [beta,D]=solve(G,b,y2,lambda)
% G,b,y2 already divided by total training weight. Intercept is unpenalized.
G=(G+G')/2;penalty=eye(size(G));penalty(1,1)=0;H=G+lambda*penalty;
[R,flag]=chol(H);assert(flag==0,'Ridge matrix is not positive definite.');
beta=R\(R'\b);stationarity=norm(H*beta-b,Inf);
objective=max(0,beta'*G*beta-2*beta'*b+y2)+lambda*sum(beta(2:end).^2);
assert(all(isfinite(beta))&&stationarity<=1e-8*max(1,norm(b,Inf)),'Ridge stationarity failed.');
D=struct('StationarityResidual',stationarity,'ConditionNumber',cond(H), ...
 'RegularizedObjective',objective,'TrainingNormalizedRawSSE',max(0,beta'*G*beta-2*beta'*b+y2), ...
 'Penalty',lambda*sum(beta(2:end).^2),'Coefficients',numel(beta));
end
function [y,rawValue]=predict(M,F)
X=encode(F,M.Horizon,M.FullStartMean,M.Preprocessor,M.HistoryK);
rawValue=([ones(height(F),1),X(:,M.Columns)]*M.Beta)*M.FullStartMean;
y=max(0,rawValue); % Forecast lower bound only; never truncate at a resource cap.
end
