function U=RevisedCodes_15_16_Utils
U.Inputs=@inputs;U.Validate=@validate;U.Signature=@signature;U.Data=@data;
U.Candidates=@candidates;U.Predict=@predict;U.Score=@score;U.Summary=@summary;
U.Bootstrap=@bootstrap;U.Subgroups=@subgroups;U.Export=@exportTables;
U.History=@history;U.ContextFit=@contextFit;U.Resource=@resource;
U.ReadShardManifest=@readShardManifest;
end

function I=inputs
V=RevisedCodes_10_Utils;U13=RevisedCodes_13_Utils;
[cfg,C,F,P,E,paths]=U13.Inputs();
root=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes');
cp=fullfile(root,'step12','RevisedCodes_12_03_Result.mat');z=load(cp,'Context');H=z.Context;validate(H);
z=load(H.ForecastPackagePath,'ForecastPackage');Forecast=z.ForecastPackage;
for stage=[13 14]
 if stage==13,var='Diagnostics';file='RevisedCodes_13_01_Result.mat';else,var='Engine';file='RevisedCodes_14_01_Result.mat';end
 path=fullfile(root,sprintf('step%d',stage),file);z=load(path,var);validate(z.(var));paths=[paths;string(path)]; %#ok<AGROW>
end
[~,~,D,Exceptional,~]=V.Inputs();
paths=unique([paths;string(cp);H.ForecastPackagePath;H.ArtifactPaths(:)],'stable');
I=struct('cfg',cfg,'Compact',C.Package,'Flexible',F.Package,'Reference',P, ...
 'Empirical',E,'Context',H,'Forecast',Forecast,'Development',D,'Exceptional',Exceptional,'Paths',paths);
end

function validate(D)
V=RevisedCodes_10_Utils;
assert(all(D.Checks.Passed)&&all(isfile(D.ArtifactPaths)),'Upstream result incomplete.');
assert(isequal(D.Signature.Sources,V.Stamps(D.Signature.Sources.Path)),'Upstream source changed; rerun its owning stage.');
if isfield(D.Signature,'CodeFiles'),T=D.Signature.CodeFiles;else,T=D.Signature.Code;end
for j=1:height(T),assert(T.Content(j)==string(fileread(T.Path(j))),'Upstream code changed: %s.',T.Path(j));end
end

function S=signature(stage,c,paths)
V=RevisedCodes_10_Utils;S=struct('Stage',stage,'Settings',c,'Sources',V.Stamps(paths),'CodeFiles',table);
names=["RevisedCodes_15_00_Config","RevisedCodes_16_00_Config","RevisedCodes_15_16_Utils", ...
 "RevisedCodes_15_01_DevelopmentValidation","RevisedCodes_16_01_SensitivityAnalysis", ...
 "RevisedCodes_15_SelfTests","RevisedCodes_16_SelfTests","RevisedCodes_15_RunAll", ...
 "RevisedCodes_16_RunAll","RevisedCodes_15_16_RunAll"];
for name=names
 p=which(char(name));assert(~isempty(p),'Missing file %s.',name);
 S.CodeFiles=[S.CodeFiles;table(string(p),string(fileread(p)),'VariableNames',{'Path','Content'})]; %#ok<AGROW>
end
end

function [F,A]=data(I,row,role)
% Consume only previously audited Step12 fold-safe shards. Never open raw test/case partitions.
V=RevisedCodes_10_Utils;W=RevisedCodes_12_ContextUtils;
mp=fullfile(I.Context.Generation,char(row.PackageID+"_ShardManifest.csv"));
assert(isfile(mp),'Missing Step12 shard manifest %s.',mp);T=readShardManifest(mp);
F=table;A=table;
for j=1:height(T)
 z=load(T.Path(j),'Features','Audit');
 assert(isfield(z,'Features')&&isfield(z,'Audit')&&istable(z.Features)&&istable(z.Audit), ...
  'Shard must contain Features and Audit tables: %s.',T.Path(j));
 assert(height(z.Features)==T.Rows(j)&&height(z.Audit)==T.Rows(j), ...
  'Shard row count differs from its manifest: %s.',T.Path(j));
 mask=z.Audit.Role==string(role);
 if ~any(mask),continue;end
 B=z.Audit(mask,:);X=z.Features(mask,:);
 assert(height(B)==height(X)&&all(B.InningsIndex==1),'Invalid assessment row alignment.');
 if string(role)=="fit"
  assert(all(B.MatchDate<row.TrainingCutoffExclusive),'Training date crosses cutoff.');
 else
  fi=find(I.Development.Folds.FoldID==row.Cohort);assert(isscalar(fi),'Missing assessment fold.');
  assert(all(B.MatchDate>=row.TrainingCutoffExclusive&B.MatchDate<I.Development.Folds.AssessmentEndExclusive(fi)),'Assessment date outside fold.');
 end
 assert(all(isnat(B.MaxHistorySourceDate)|(B.MaxHistorySourceDate<B.MatchDate&B.MaxHistorySourceDate<row.TrainingCutoffExclusive)), ...
  'History provenance crosses the permitted cutoff.');
 F=[F;X];A=[A;B]; %#ok<AGROW>
end
assert(~isempty(A)&&numel(unique(W.StateKey(A)))==height(A),'Empty/duplicated state population.');
if string(role)=="assessment"
 L=I.Development.InningsMembership;L=L(L.FoldID==row.Cohort&L.Format==row.Format&L.Role=="assessment",:);
 [found,k]=ismember(V.Key(A),V.Key(L));assert(all(found));
 assert(isequal(accumarray(k,1,[height(L),1]),double(L.States)),'Assessment innings/state inventory mismatch.');
else
 z=load(row.Path,'Surface');L=z.Surface.TrainingLedger;
 [found,k]=ismember(V.Key(A),V.Key(L));assert(all(found));
 assert(isequal(accumarray(k,1,[height(L),1]),double(L.CachedPrimaryStates)),'Fitting inventory mismatch.');
end
end

function T=readShardManifest(path)
% Step12 writes exactly Path,Rows. Never infer header, row names or data types.
[fid,msg]=fopen(path,'rt','n','UTF-8');assert(fid>=0,'Cannot read manifest %s: %s.',path,msg);
cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
header=fgetl(fid);assert(ischar(header),'Empty shard manifest: %s.',path);
header=strtrim(strrep(header,char(65279),''));
assert(~isempty(regexpi(header,'^"?Path"?\s*,\s*"?Rows"?$','once')), ...
 'Unexpected shard manifest header in %s: %s. Expected Path,Rows; no column guessing is permitted.',path,header);
opts=delimitedTextImportOptions('NumVariables',2);
opts.Delimiter=',';opts.DataLines=[2 Inf];
opts.VariableNames={'Path','Rows'};opts.VariableTypes={'string','double'};
opts.ExtraColumnsRule='error';opts.EmptyLineRule='skip';
T=readtable(path,opts);
assert(height(T)>0&&isequal(T.Properties.VariableNames,{'Path','Rows'}),'Invalid shard manifest schema: %s.',path);
assert(all(~ismissing(T.Path)&strlength(T.Path)>0),'Manifest contains a missing path: %s.',path);
assert(all(isfinite(T.Rows)&T.Rows>0&T.Rows==floor(T.Rows)),'Manifest contains invalid row counts: %s.',path);
assert(numel(unique(T.Path))==height(T),'Manifest contains duplicate paths: %s.',path);
assert(all(isfile(T.Path)),'One or more recorded shard files are missing: %s.',path);
end

function [Index,Models]=candidates(I,row,c)
U12=RevisedCodes_12_Utils;V=RevisedCodes_10_Utils;
z=load(row.Path,'Surface');S=z.Surface;H=S.Horizon;
[u,w]=ndgrid(0:H,0:10);R=u/H;R(:,1)=0;
B=struct('Resource',R,'Horizon',H,'FullStartMean',S.FullStartMean,'Supported',true(size(R)));
Index=entry("B0_LinearBalls","Baseline","RunMeanState",1,1,true,"training-mean-linear-balls");Models={B};
% Training mean in remaining-ball phase and wicket group; empty groups fall back to B0.
R=B.Resource;grid=S.Grid;phase=min(3,floor(3*grid.BallsRemaining/(H+1))+1);
for ph=1:3
 for wi=1:10
  mask=phase==ph&grid.WicketsInHand==wi;mass=sum(grid.MatchCount(mask));
  if mass>0,R(mask)=sum(grid.SumY(mask))/mass/S.FullStartMean;end
 end
end
B.Resource=R;B.Resource(1,:)=0;
Index=[Index;entry("B1_PhaseWicketMean","Baseline","RunMeanState",2,30,true,"training-cell-sums-phase-wicket")];Models{end+1,1}=B;
packages={I.Reference,I.Compact,I.Flexible};families=["Reference","Compact","Bernstein"];
for f=1:3
 P=packages{f};ix=find(P.Index.PackageID==row.PackageID);
 for j=ix'
  M=P.Models{j};id=families(f)+"::"+P.Index.CandidateID(j);complexity=numel(M.Resource);
  rank=5;if f==2,rank=3;complexity=6;elseif f==3,rank=4;complexity=numel(M.Coefficients);end
  eligible=ismember(P.Index.Estimand(j),["RunMeanState","RunMeanInnings"]);
  assert(V.Residual(M.Resource(:),H)<=c.ConstraintTolerance,'Candidate violates shape constraints.');
  Index=[Index;entry(id,families(f),P.Index.Estimand(j),rank,complexity,eligible,P.Index.ModelVersion(j))];Models{end+1,1}=M; %#ok<AGROW>
 end
end
if c.FitExpandedCompact
 j=find(I.Reference.Index.PackageID==row.PackageID&I.Reference.Index.CandidateID=="mean_state_n30_count_l0");assert(isscalar(j));
 source=I.Reference.Models{j};
 for emin=[-4 -6 -8]
 for ridge=[0 1e-6]
  if emin==-4&&ridge==1e-6,continue;end
  cc=RevisedCodes_12_00_Config;cc.ParameterLower(5)=emin;cc.CompactRidge=ridge;
  [p,starts,D]=U12.CompactFit(source,cc);M=source;
  M.Resource=U12.CompactGrid(p,H);M.Parameters=p;M.FitDiagnostics=D;M.Multistarts=starts;
  id="CompactBound_e"+string(emin)+"_ridge"+string(ridge);W=RevisedCodes_11_Utils;
  ver=W.Fingerprint(M.Resource(:),id+"|"+row.PackageID);
  Index=[Index;entry(id,"CompactExpanded","RunMeanState",3,6,true,ver)];Models{end+1,1}=M; %#ok<AGROW>
 end
 end
end
ix=find(I.Forecast.Index.PackageID==row.PackageID);assert(~isempty(ix),'Context candidates absent.');
for j=ix'
 M=I.Forecast.Models{j};W=RevisedCodes_11_Utils;ver=W.Fingerprint(M.Beta,M.ModelID+"|"+row.PackageID);
 Index=[Index;entry("Context::"+M.ModelID,"Context","ConditionalRemainingRuns",6,numel(M.Beta),true,ver)];Models{end+1,1}=M; %#ok<AGROW>
end
assert(numel(unique(Index.ModelID))==height(Index));
end

function T=entry(id,family,estimand,rank,complexity,eligible,version)
track="Resource";if family=="Context",track="Context";elseif family=="Baseline",track="Baseline";end
T=table(string(id),string(family),string(estimand),string(track),double(rank),double(complexity), ...
 logical(eligible),string(version),'VariableNames',{'ModelID','Family','Estimand','Track','ParsimonyRank','Complexity','SelectionEligible','ModelVersion'});
end

function [p,raw,supported]=predict(M,F)
if isfield(M,'ForecastOnly')&&M.ForecastOnly
 W=RevisedCodes_12_ContextUtils;p=zeros(height(F),1);raw=p;
 for start=1:25000:height(F)
  ix=start:min(height(F),start+24999);[p(ix),raw(ix)]=W.Predict(M,F(ix,:));
 end
 supported=true(height(F),1);
else
 u=double(F.BallsRemaining);w=double(F.WicketsInHand);
 assert(all(u==floor(u)&u>=0&u<=M.Horizon&w==floor(w)&w>=0&w<=10),'Invalid integer resource states.');
 ix=sub2ind(size(M.Resource),u+1,w+1);raw=M.Resource(ix)*M.FullStartMean;p=raw;supported=logical(M.Supported(ix));
end
assert(all(isfinite(p))&&all(isfinite(raw)),'Nonfinite predictions; no candidate-specific row deletion permitted.');
end

function C=score(A,p,raw)
V=RevisedCodes_10_Utils;key=V.Key(A);[~,first,g]=unique(key,'stable');n=numel(first);
assert(isvector(p)&&numel(p)==height(A)&&all(isfinite(p))&& ...
 isvector(raw)&&numel(raw)==height(A)&&all(isfinite(raw)),'Prediction alignment failed.');
p=p(:);raw=raw(:);
y=double(A.RemainingRuns);e=p-y;N=accumarray(g,1,[n,1]);
C=A(first,{'MatchID','InningsIndex','MatchDate','EventName'});C.States=N;
fields={'MSE','MAE','Bias','MeanPrediction','MeanOutcome','PredictionSquared','PredictionOutcome','NegativeRawFraction'};
values={e.^2,abs(e),e,p,y,p.^2,p.*y,double(raw<0)};
for j=1:numel(fields),C.(fields{j})=accumarray(g,values{j},[n,1])./N;end
assert(numel(unique(C.MatchID))==height(C),'Primary score requires one eligible innings per match.');
end

function T=summary(C)
assert(~isempty(C));
mp=mean(C.MeanPrediction);my=mean(C.MeanOutcome);variance=mean(C.PredictionSquared)-mp^2;
slope=NaN;intercept=NaN;
if variance>1e-12,slope=(mean(C.PredictionOutcome)-mp*my)/variance;intercept=my-slope*mp;end
T=table(height(C),sum(C.States),sqrt(mean(C.MSE)),mean(C.MAE),mean(C.Bias), ...
 sqrt(sum(C.States.*C.MSE)/sum(C.States)),sum(C.States.*C.MAE)/sum(C.States), ...
 sum(C.States.*C.Bias)/sum(C.States),intercept,slope,mean(C.NegativeRawFraction), ...
 'VariableNames',{'Innings','States','EqualInningsRMSE','EqualInningsMAE','EqualInningsBias', ...
 'StateRMSE','StateMAE','StateBias','CalibrationIntercept','CalibrationSlope','EqualInningsNegativeRawFraction'});
end

function [B,Selection]=bootstrap(C,Index,c)
% Paired, fold-stratified match bootstrap. C contains one primary innings/match.
ids=Index.ModelID;n=height(Index);base=C(C.ModelID==ids(1),:);
key=string(base.MatchID)+"|"+string(base.PackageID);X=zeros(height(base),n);
for j=1:n
 T=C(C.ModelID==ids(j),:);[ok,k]=ismember(key,string(T.MatchID)+"|"+string(T.PackageID));assert(all(ok)&&height(T)==height(base),'Candidate populations differ.');X(:,j)=T.MSE(k);
end
assert(numel(unique(base.MatchID))==height(base),'Assessment matches overlap development folds.');
stream=RandStream('mt19937ar','Seed',c.Seed);rep=zeros(c.BootstrapReplicates,n);
folds=unique(base.PackageID);for b=1:c.BootstrapReplicates
 take=zeros(0,1);
 for f=folds',ix=find(base.PackageID==f);take=[take;ix(randi(stream,numel(ix),numel(ix),1))];end %#ok<AGROW>
 rep(b,:)=sqrt(mean(X(take,:),1));
end
point=sqrt(mean(X,1));ci=quantile(rep,[.025 .975],1);se=std(rep,0,1);
simple=find(Index.Family=="Baseline");[~,k]=min(point(simple));ref=simple(k);
delta=rep-rep(:,ref);dci=quantile(delta,[.025 .975],1);
B=[Index,table(point',se',ci(1,:)',ci(2,:)',repmat(ids(ref),n,1), ...
 (point-point(ref))',dci(1,:)',dci(2,:)', ...
 'VariableNames',{'RMSE','BootstrapSE','Lower95','Upper95','SimpleComparator', ...
 'DifferenceVsSimple','DifferenceLower95','DifferenceUpper95'})];
Selection=table;
for track=["Resource","Context"]
 pool=Index.SelectionEligible&Index.Track==track;
 if track=="Context",pool=pool|(Index.SelectionEligible&Index.Track=="Baseline");end
 ix=find(pool);assert(~isempty(ix),'No eligible candidates for %s.',track);
 [~,k]=min(point(ix));best=ix(k);limit=point(best)+min(se(best),c.PracticalMarginRuns);
 eligible=pool&point'<=limit;T=Index(eligible,:);T.Score=point(eligible)';
 T=sortrows(T,{'ParsimonyRank','Complexity','Score','ModelID'});chosen=T.ModelID(1);
 Selection=[Selection;table(track,ids(best),chosen,point(best),se(best),limit,c.PracticalMarginRuns, ...
  "PROVISIONAL_FOLD_ONLY_2023_AND_COMPLETION_REVIEW_PENDING", ...
  'VariableNames',{'Track','LowestRMSEModel','ProvisionalChoice','BestRMSE','BestBootstrapSE', ...
  'AcceptanceLimit','PracticalMarginRuns','Status'})]; %#ok<AGROW>
end
end

function T=subgroups(A,F,p,raw,commonSupport,minN,H)
T=table;
phase=repmat("Middle",height(F),1);phase(F.BallsRemaining<=H/3)="Late";phase(F.BallsRemaining>2*H/3)="Early";
support=repmat("Unsupported",height(F),1);support(commonSupport)="Supported";
labels={phase,string(F.WicketsInHand),support,string(A.EventName),string(year(A.MatchDate))};names=["Phase","Wickets","MeanReferenceSupport","EventName","CalendarYear"];
for h=1:numel(labels)
 v=labels{h};v(ismissing(v)|strlength(v)==0)="[missing]";
 for value=unique(v)'
  keep=v==value;C=score(A(keep,:),p(keep),raw(keep));S=summary(C);
  S.GroupType=names(h);S.Group=value;S.SufficientGroup=height(C)>=minN;
  T=[T;S]; %#ok<AGROW>
 end
end
end

function exportTables(folder,items)
for j=1:numel(items)
 pair=items{j};assert(istable(pair{2}),'Export %s is %s, not table.',pair{1},class(pair{2}));
end
for j=1:numel(items),pair=items{j};writetable(pair{2},fullfile(folder,char(string(pair{1})+".csv")));end
end

function F=history(F,oldK,newK,startupMultiplier)
originalMu=double(F.("HistoryFormatMean_K"+string(oldK)));mu=originalMu;
startup=double(F.HistoryFormatN)==0;mu(startup)=mu(startup)*startupMultiplier;
F.("HistoryFormatMean_K"+string(newK))=mu;
for entity=["Batting","Opponent","Venue","Event"]
 n=double(F.("History"+entity+"N"));old=double(F.("History"+entity+"Mean_K"+string(oldK)));
 % Recover prior-free historical totals from the existing shrinkage contract.
 total=old.*(n+oldK)-oldK*originalMu;total(n==0)=0;
 F.("History"+entity+"Mean_K"+string(newK))=(total+newK*mu)./(n+newK);
end
end

function M=contextFit(F,A,H,mu,K,ablation,lambda)
W=RevisedCodes_12_ContextUtils;V=RevisedCodes_10_Utils;cc=RevisedCodes_12_00_Config;
[~,first,g]=unique(V.Key(A),'stable');count=accumarray(g,1);weight=1./count(g);tw=sum(weight);
Cat=W.Categories(F(first,:),cc);sw=[];sx=[];sx2=[];
for start=1:25000:height(F)
 ix=start:min(height(F),start+24999);[X,names,groups]=W.Raw(F(ix,:),H,mu,Cat,K);
 valid=isfinite(X);X(~valid)=0;ww=weight(ix);
 if isempty(sw),sw=zeros(1,size(X,2));sx=sw;sx2=sw;end
 sw=sw+ww'*double(valid);sx=sx+ww'*X;sx2=sx2+ww'*(X.^2);
end
P=W.Preprocessor(sw,sx,sx2,names,groups,Cat,tw);cols=find(~P.Constant&groups<=ablation);
d=numel(cols)+1;gram=zeros(d);rhs=zeros(d,1);y2=0;
for start=1:25000:height(F)
 ix=start:min(height(F),start+24999);X=W.Encode(F(ix,:),H,mu,P,K);
 Z=[ones(numel(ix),1),X(:,cols)];y=A.RemainingRuns(ix)/mu;ww=weight(ix);
 gram=gram+Z'*(Z.*ww);rhs=rhs+Z'*(ww.*y);y2=y2+sum(ww.*y.^2);
end
[beta,D]=W.Solve(gram/tw,rhs/tw,y2/tw,lambda);
M=struct('Horizon',H,'FullStartMean',mu,'HistoryK',K,'Preprocessor',P,'Columns',cols, ...
 'Beta',beta,'ForecastOnly',true,'FitDiagnostics',D,'ModelSelected',false,'PolicyFrozen',false);
end

function r=resource(M,u,w)
assert(all(u>=0&u<=M.Horizon&w>=0&w<=10&w==floor(w)));
lo=floor(u);hi=ceil(u);a=u-lo;
r=(1-a).*M.Resource(sub2ind(size(M.Resource),lo+1,w+1))+a.*M.Resource(sub2ind(size(M.Resource),hi+1,w+1));
end
