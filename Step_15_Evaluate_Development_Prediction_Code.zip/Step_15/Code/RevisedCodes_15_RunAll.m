function Results=RevisedCodes_15_RunAll(settings)
if nargin<1,settings=struct;end
Results=RevisedCodes_15_01_DevelopmentValidation(settings);
fprintf('Step15 finished: chronological-fold development only; 2023 confirmation remains pending.\n');
end
