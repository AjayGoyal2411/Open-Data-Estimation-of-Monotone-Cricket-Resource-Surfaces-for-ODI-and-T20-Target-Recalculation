function Validation=RevisedCodes_15_01_DevelopmentValidation(settings)
if nargin<1,settings=struct;end
c=RevisedCodes_15_00_Config(settings);U=RevisedCodes_15_16_Utils;V=RevisedCodes_10_Utils;
I=U.Inputs();root=fullfile(I.cfg.ProjectRoot,'paper_outputs_revisedcodes','step15');
out=fullfile(root,'RevisedCodes_15_01_Result.mat');S=U.Signature("15",c,I.Paths);
[reuse,Validation]=V.Cache(out,'Validation',S,c);if reuse,fprintf('Step15 valid cache reused.\n');return;end
Tests=RevisedCodes_15_SelfTests();[g,report]=V.Generation(root);
Scores=table;Clusters=table;Groups=table;Manifest=table;CandidateIndex=table;Populations=table;
rows=I.Empirical.Packages(I.Empirical.Packages.Cohort~="FULL_TRAIN",:);
for h=1:height(rows)
 row=rows(h,:);fprintf('Step15 %s: load identical assessment states.\n',row.PackageID);
 [F,A]=U.Data(I,row,"assessment");[Index,Models]=U.Candidates(I,row,c);
 n=height(A);m=height(Index);Prediction=zeros(n,m);RawPrediction=zeros(n,m);CandidateSupport=false(n,m);
 j=find(I.Reference.Index.PackageID==row.PackageID&I.Reference.Index.CandidateID=="mean_state_n30_count_l0");
 [~,~,commonSupport]=U.Predict(I.Reference.Models{j},F);
 foldClusters=table;
 for k=1:m
  [p,raw,supported]=U.Predict(Models{k},F);Prediction(:,k)=p;RawPrediction(:,k)=raw;CandidateSupport(:,k)=supported;
  C=U.Score(A,p,raw);Q=U.Summary(C);
  Q.PackageID=row.PackageID;Q.Format=row.Format;Q.ModelID=Index.ModelID(k);Q.Family=Index.Family(k);
  Q.SelectionEligible=Index.SelectionEligible(k);Q.CandidateUnsupportedFraction=mean(~supported);
  if Index.Track(k)~="Resource",Q.CandidateUnsupportedFraction=NaN;end
  Scores=[Scores;Q]; %#ok<AGROW>
  C.PackageID=repmat(row.PackageID,height(C),1);C.Format=repmat(row.Format,height(C),1);C.ModelID=repmat(Index.ModelID(k),height(C),1);
  foldClusters=[foldClusters;C]; %#ok<AGROW>
  G=U.Subgroups(A,F,p,raw,commonSupport,c.MinGroupInnings,Models{1}.Horizon);
  G.PackageID=repmat(row.PackageID,height(G),1);G.Format=repmat(row.Format,height(G),1);G.ModelID=repmat(Index.ModelID(k),height(G),1);
  Groups=[Groups;G]; %#ok<AGROW>
  if mod(k,20)==0||k==m,fprintf('Step15 %s scored %d/%d candidates.\n',row.PackageID,k,m);end
 end
 Clusters=[Clusters;foldClusters]; %#ok<AGROW>
 B=Index;B.PackageID=repmat(row.PackageID,height(B),1);B.Format=repmat(row.Format,height(B),1);CandidateIndex=[CandidateIndex;B]; %#ok<AGROW>
 % Exact state keys, outcomes, predictions, support and candidate fits retained locally.
 Audit=A;Features=F;CommonReferenceSupport=commonSupport;ScoringMask=true(n,1); %#ok<NASGU>
 path=fullfile(g,char(row.PackageID+"_Predictions.mat"));
 save(path,'Audit','Features','Prediction','RawPrediction','CandidateSupport','CommonReferenceSupport', ...
  'ScoringMask','Index','Models','-v7.3');
 Manifest=[Manifest;table(row.PackageID,row.Format,string(path),'VariableNames',{'PackageID','Format','Path'})]; %#ok<AGROW>
 Populations=[Populations;table(row.PackageID,row.Format,numel(unique(A.MatchID)),n,min(A.MatchDate),max(A.MatchDate), ...
  'VariableNames',{'PackageID','Format','Matches','States','Earliest','Latest'})]; %#ok<AGROW>
end
Pooled=table;Intervals=table;Selection=table;
for fmt=["ODI","T20"]
 C=Clusters(Clusters.Format==fmt,:);J=CandidateIndex(CandidateIndex.Format==fmt,:);
 [~,first]=unique(J.ModelID,'stable');J=J(first,:);J.ModelVersion(:)="FOLD_SPECIFIC_SEE_CANDIDATE_INDEX";
 for k=1:height(J)
  Q=U.Summary(C(C.ModelID==J.ModelID(k),:));Q.Format=fmt;Q.ModelID=J.ModelID(k);Q.Family=J.Family(k);
  gg=Groups(Groups.Format==fmt&Groups.ModelID==J.ModelID(k)&Groups.SufficientGroup,:);
  Q.MaximumEligibleFoldSubgroupRMSE=NaN;if ~isempty(gg),Q.MaximumEligibleFoldSubgroupRMSE=max(gg.EqualInningsRMSE);end
  Pooled=[Pooled;Q]; %#ok<AGROW>
 end
 [B,choice]=U.Bootstrap(C,J,c);B.Format=repmat(fmt,height(B),1);choice.Format=repmat(fmt,height(choice),1);
 Intervals=[Intervals;B];Selection=[Selection;choice]; %#ok<AGROW>
end
Pending=table(["2023 validation";"Final independent test";"Resource completion safety";"Fraction/median/trimmed score conversion";"Case-study evaluation"], ...
 ["NOT_EVALUATED";"NOT_OPENED";"REVIEW_REQUIRED";"EXPLORATORY_ONLY";"NOT_OPENED"], ...
 ["This runner uses the audited 2020-2022 development shards. A separately audited 2023 context population is required before confirmation."; ...
 "No final test performance is used for selection."; ...
 "Grid feasibility passes do not establish empirical validity of unsupported completions. Provisional choices cannot be frozen yet."; ...
 "Multiplication by training mean is a declared common-scale heuristic for non-mean estimands, not a conditional-mean prediction. These candidates cannot win selection."; ...
 "Reserved match evidence remains unopened until the planned policy freeze."], ...
 'VariableNames',{'Requirement','Status','Meaning'});
Checks=table(["Upstream source/code provenance verified";"Assessment membership and chronology reconciled"; ...
 "Identical finite prediction population for every candidate";"One primary innings per match"; ...
 "Paired match bootstrap with fixed fold strata";"Separate ODI/T20 and resource/context decisions"; ...
 "Exact predictions, masks and fold fits saved";"Non-mean estimands excluded from primary selection"; ...
 "2023, final test and reserved cases not opened";"Choices provisional, not frozen"],true(10,1), ...
 'VariableNames',{'Check','Passed'});
U.Export(report,{{'15_SelfTests',Tests},{'15_GateChecks',Checks},{'15_FoldScores',Scores}, ...
 {'15_PooledScores',Pooled},{'15_MatchBootstrap',Intervals},{'15_ProvisionalSelection',Selection}, ...
 {'15_SubgroupScores',Groups},{'15_CandidateIndex',CandidateIndex},{'15_Populations',Populations},{'15_PendingRequirements',Pending}});
clusterPath=fullfile(g,'15_ClusterErrors.mat');save(clusterPath,'Clusters','CandidateIndex','-v7.3');
pub=[V.TableExport(I.cfg,"Results","T_R15_DevelopmentScores",Pooled); ...
 V.TableExport(I.cfg,"Results","T_R15_ProvisionalSelection",Selection); ...
 V.TableExport(I.cfg,"Supplementary","T_S15_MatchBootstrap",Intervals)];
W=RevisedCodes_12_Utils;fig=figure('Visible','off','Color','w','Position',[100 100 1200 650]);clean=onCleanup(@()close(fig)); %#ok<NASGU>
tiledlayout(1,2,'Padding','compact');PlotData=table;
for fmt=["ODI","T20"]
 B=Intervals(Intervals.Format==fmt&Intervals.SelectionEligible,:);B=sortrows(B,'RMSE');B=B(1:min(12,height(B)),:);
 nexttile;hold on;
 for j=1:height(B),plot([j j],[B.Lower95(j) B.Upper95(j)],'-','Color',[.2 .4 .7]);end
 scatter(1:height(B),B.RMSE,25,'filled');
 xticks(1:height(B));xticklabels(B.ModelID);xtickangle(65);set(gca,'TickLabelInterpreter','none');ylabel('Equal-innings RMSE (runs)');title(fmt+": development, not final test");
 PlotData=[PlotData;B]; %#ok<AGROW>
end
pub=[pub;W.FigureExport(I.cfg,"Results","F_M15_DevelopmentValidation",fig,PlotData, ...
 "Chronological development scores and fold-stratified paired match-bootstrap intervals. Twelve lowest RMSE eligible candidates are displayed per format; all candidates remain in tables. Selection is provisional and development-adaptive, not independent performance estimation. 2023 confirmation and unsupported-region review remain outstanding.",report)];
Validation=struct('Stage',"15",'Status',"FOLD_VALIDATION_COMPLETE_2023_CONFIRMATION_PENDING", ...
 'Checks',Checks,'Packages',Manifest,'ClusterPath',string(clusterPath),'Selection',Selection, ...
 'Pending',Pending,'ModelSelected',false,'PolicyFrozen',false);
Validation=V.Finish(I.cfg,'Validation',out,S,g,report,Validation,[pub;Manifest.Path;string(clusterPath)]);
end
