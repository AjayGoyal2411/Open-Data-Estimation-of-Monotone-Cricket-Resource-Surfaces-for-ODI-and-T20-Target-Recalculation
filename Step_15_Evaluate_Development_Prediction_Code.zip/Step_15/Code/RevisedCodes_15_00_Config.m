function c=RevisedCodes_15_00_Config(settings)
if nargin<1,settings=struct;end
c=struct('Version','15.1.0','ForceRebuild',false,'BootstrapReplicates',500, ...
 'Seed',1516,'PracticalMarginRuns',1,'FitExpandedCompact',true, ...
 'ConstraintTolerance',2e-7,'MinGroupInnings',20);
assert(isstruct(settings)&&isscalar(settings));
for n=fieldnames(settings)',assert(isfield(c,n{1}),'Unknown Step15 setting %s.',n{1});c.(n{1})=settings.(n{1});end
validateattributes(c.ForceRebuild,{'logical'},{'scalar'});
validateattributes(c.FitExpandedCompact,{'logical'},{'scalar'});
validateattributes(c.BootstrapReplicates,{'numeric'},{'scalar','integer','>=',100});
validateattributes(c.Seed,{'numeric'},{'scalar','integer','nonnegative'});
validateattributes(c.PracticalMarginRuns,{'numeric'},{'scalar','nonnegative','finite'});
validateattributes(c.MinGroupInnings,{'numeric'},{'scalar','integer','positive'});
end
