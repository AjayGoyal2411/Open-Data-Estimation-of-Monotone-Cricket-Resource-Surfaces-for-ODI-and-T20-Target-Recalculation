function Checks=RevisedCodes_15_SelfTests
U=RevisedCodes_15_16_Utils;
A=table(["a";"a";"b"],[1;1;1],repmat(datetime(2020,1,1),3,1),["E";"E";"E"],[0;0;0], ...
 'VariableNames',{'MatchID','InningsIndex','MatchDate','EventName','RemainingRuns'});
p=[1;1;9];C=U.Score(A,p,p);S=U.Summary(C);
assert(abs(S.EqualInningsRMSE-sqrt(41))<1e-12,'Equal-innings RMSE incorrect.');
assert(abs(S.StateRMSE-sqrt(83/3))<1e-12,'State RMSE incorrect.');
assert(S.Innings==2&&S.States==3,'State/innings counts incorrect.');
C=U.Score(A,zeros(3,1),-ones(3,1));S=U.Summary(C);
assert(S.EqualInningsNegativeRawFraction==1&&S.EqualInningsRMSE==0,'Raw-negative/clipped distinction failed.');
assert(isnan(S.CalibrationSlope),'Constant forecast slope must be undefined.');
A.RemainingRuns=[3;5;9];C=U.Score(A,[1;2;4],[1;2;4]);S=U.Summary(C);
assert(abs(S.CalibrationSlope-2)<1e-12&&abs(S.CalibrationIntercept-1)<1e-12,'Weighted calibration failed.');
bad=false;try,U.Score(A,[1;NaN;2],[1;NaN;2]);catch,bad=true;end;assert(bad,'Nonfinite prediction accepted.');
folder=tempname;mkdir(folder);cleanup=onCleanup(@()rmdir(folder,'s')); %#ok<NASGU>
U.Export(folder,{{'Fixture',S}});T=readtable(fullfile(folder,'Fixture.csv'));assert(istable(T)&&height(T)==1,'Export round trip failed.');
bad=false;try,U.Export(folder,{{'Bad',@table}});catch,bad=true;end;assert(bad,'Function handle export not rejected.');
% Real writer/reader regression, including a quoted filename containing a comma.
Features=table((1:2)','VariableNames',{'Value'});Audit=Features; %#ok<NASGU>
shard=fullfile(folder,'Part 0001, fixture.mat');save(shard,'Features','Audit');
manifest=fullfile(folder,'ShardManifest.csv');
expected=table(string(shard),2,'VariableNames',{'Path','Rows'});writetable(expected,manifest);
actual=U.ReadShardManifest(manifest);assert(isequal(actual,expected),'Explicit Path/Rows manifest import failed.');
invalid=table(string(shard),2,'VariableNames',{'WrongHeader','Rows'});writetable(invalid,manifest);
bad=false;try,U.ReadShardManifest(manifest);catch,bad=true;end;assert(bad,'Unknown manifest header was accepted.');
writetable([expected;expected],manifest);
bad=false;try,U.ReadShardManifest(manifest);catch,bad=true;end;assert(bad,'Duplicate shard paths were accepted.');
H=12;[u,w]=ndgrid(0:H,0:10);M=struct('Resource',(u/H).*(w/10),'Supported',true(H+1,11),'FullStartMean',100,'Horizon',H);
F=table([12;6;0],[10;5;1],'VariableNames',{'BallsRemaining','WicketsInHand'});
[p,~,sup]=U.Predict(M,F);assert(max(abs(p-[100;25;0]))<1e-12&&all(sup),'Resource prediction indexing failed.');
% Deterministic paired bootstrap: the identical resource and context models have zero differences.
c=RevisedCodes_15_00_Config(struct('BootstrapReplicates',100));
J=table(["b";"r";"c"],["Baseline";"Reference";"Context"],["Baseline";"Resource";"Context"], ...
 [1;5;6],[1;10;2],true(3,1), 'VariableNames',{'ModelID','Family','Track','ParsimonyRank','Complexity','SelectionEligible'});
C=U.Score(A,[1;2;4],[1;2;4]);C.PackageID=["FoldA";"FoldB"];All=table;
for id=J.ModelID',Q=C;Q.ModelID=repmat(id,height(Q),1);All=[All;Q];end %#ok<AGROW>
[B,choice]=U.Bootstrap(All,J,c);[B2,~]=U.Bootstrap(All,J,c);
assert(isequaln(B,B2)&&all(B.DifferenceVsSimple==0)&&all(B.DifferenceLower95==0),'Paired deterministic bootstrap failed.');
assert(choice.ProvisionalChoice(choice.Track=="Resource")=="r",'Unconstrained baseline selected as resource model.');
Checks=table(["Equal-innings versus state weighting";"Innings/state reconciliation"; ...
 "Raw-negative forecasts retained";"Undefined constant-forecast calibration"; ...
 "Weighted calibration identity";"Nonfinite predictions rejected"; ...
 "Actual table CSV round trip";"Function-handle export rejected"; ...
 "Integer resource indexing";"Paired deterministic match bootstrap"; ...
 "Unconstrained baseline excluded from resource selection"; ...
 "Explicit Path/Rows manifest round trip with quoted comma"; ...
 "Unexpected manifest header rejected";"Duplicate shard paths rejected"],true(14,1), ...
 'VariableNames',{'Check','Passed'});disp(Checks);
end
