function Results=RevisedCodes_15_16_RunAll(settings)
if nargin<1,settings=struct;end
assert(isstruct(settings)&&isscalar(settings),'Settings must be scalar struct.');
if isfield(settings,'Step15')||isfield(settings,'Step16')
 assert(all(ismember(fieldnames(settings),{'Step15','Step16'})),'Use nested Step15 and Step16 settings only.');
 s15=struct;s16=struct;
 if isfield(settings,'Step15'),s15=settings.Step15;end
 if isfield(settings,'Step16'),s16=settings.Step16;end
else
 assert(all(ismember(fieldnames(settings),{'ForceRebuild'})),'Use nested settings for stage-specific options.');
 s15=settings;s16=settings;
end
% Validate both configurations before expensive work.
RevisedCodes_15_00_Config(s15);RevisedCodes_16_00_Config(s16);
Results=struct;Results.Step15=RevisedCodes_15_RunAll(s15);Results.Step16=RevisedCodes_16_RunAll(s16);
fprintf('\nUpload RevisedCodes_15_Checks.zip and RevisedCodes_16_Checks.zip.\n');
fprintf('Read PendingRequirements in both reports. Final selection/freeze and independent evaluation remain pending.\n');
end
