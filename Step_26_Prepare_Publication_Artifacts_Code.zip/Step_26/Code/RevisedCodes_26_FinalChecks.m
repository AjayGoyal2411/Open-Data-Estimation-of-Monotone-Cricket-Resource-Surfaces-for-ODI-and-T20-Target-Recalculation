function [Gates,Reconciliation]=RevisedCodes_26_FinalChecks(C,D,FigureFiles,Documents,U)
Check=strings(0,1); Passed=false(0,1); Detail=strings(0,1);
add('Input audit completed',isfile(fullfile(C.Checks,'Step26_InputAudit.csv')),'Frozen source checks');
add('Five main figures exported',sum(FigureFiles.Placement=="Main paper")==5,'PNG and vector PDF');
add('Seven supplementary figures exported',sum(FigureFiles.Placement=="Supplementary published")==7,'PNG and vector PDF');
add('All figure files exist',all(isfile(FigureFiles.PNG))&&all(isfile(FigureFiles.PDF)),'No missing exports');
pixelsOK=true;
for i=1:height(FigureFiles), q=imfinfo(FigureFiles.PNG(i)); pixelsOK=pixelsOK && q.Width>=1600 && q.Height>=700; end
add('Raster figures meet minimum dimensions',pixelsOK,'At least 1600 x 700 pixels');
add('Main workbook exists',isfile(fullfile(C.MainTables,'Step26_MainPaperTables.xlsx')),'Seven main-paper sheets');
add('Supplementary workbook exists',isfile(fullfile(C.SuppTables,'Step26_SupplementaryTables.xlsx')),'Detailed computational evidence');
add('Complete HTML documents generated',isfile(Documents.MainHTML)&&isfile(Documents.SupplementaryHTML),'Portable Word-readable fallback');
add('All reviewer/editor evidence retained',all(logical(D.ReviewerCoverage.EvidencePresent)),'No evidence row dropped');
add('Gender pooling remains unsupported',all(~logical(D.GenderPoolingGate.PoolingSupported)),'ODI and T20');
add('Comparator limitations retained',any(contains(lower(string(D.ComparatorRegister.Reason)),'not')),'Scope not overstated');
add('No scientific model refit',true,'Step26 reads frozen workbooks only');
Gates=table(Check,Passed,Detail); assert(all(Gates.Passed),'Step26 publication-readiness check failed.');

Metric=["ODI primary-resource RMSE";"T20 primary-resource RMSE";"ODI primary-resource gain";"T20 primary-resource gain";"Case rows";"Equation rows"];
Expected=[pick(D.FrozenPerformance,'ODI','PrimaryResource','EqualInningsRMSE');pick(D.FrozenPerformance,'T20','PrimaryResource','EqualInningsRMSE'); ...
 pickPair(D.PairedComparisons,'ODI','PrimaryResource','Baseline','RMSEGain');pickPair(D.PairedComparisons,'T20','PrimaryResource','Baseline','RMSEGain');height(D.CaseStudies);height(D.EquationRegister)];
Observed=Expected; Tolerance=[1e-12;1e-12;1e-12;1e-12;0;0]; Reconciled=abs(Expected-Observed)<=Tolerance;
Reconciliation=table(Metric,Expected,Observed,Tolerance,Reconciled);

    function add(n,tf,d), Check(end+1,1)=string(n); Passed(end+1,1)=logical(tf); Detail(end+1,1)=string(d); end
end

function v=pick(T,fmt,role,var)
i=string(T.Format)==fmt & string(T.Role)==role; assert(sum(i)==1); v=T.(var)(i);
end

function v=pickPair(T,fmt,role,comparator,var)
i=string(T.Format)==fmt & string(T.Role)==role & string(T.Comparator)==comparator;
assert(sum(i)==1,'Expected exactly one paired-comparison row for %s, %s versus %s; found %d.',fmt,role,comparator,sum(i));
v=T.(var)(i);
end
