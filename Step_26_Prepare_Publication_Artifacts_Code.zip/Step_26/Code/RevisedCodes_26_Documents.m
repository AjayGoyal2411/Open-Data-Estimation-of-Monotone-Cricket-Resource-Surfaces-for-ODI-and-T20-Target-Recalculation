function Documents=RevisedCodes_26_Documents(C,D,MainCaptions,SuppCaptions,FigureFiles,U)
mainHtml=fullfile(C.MainDir,'Final_Main_Paper_Figures_and_Tables.html');
suppHtml=fullfile(C.SuppDir,'Final_Supplementary_Figures_and_Tables.html');
P=RevisedCodes_26_PublicationTableData(D,U);
writeHtml(mainHtml,'Main-paper figures and tables',MainCaptions,FigureFiles(FigureFiles.Placement=="Main paper",:),P.Main);
writeHtml(suppHtml,'Supplementary figures and tables',SuppCaptions,FigureFiles(FigureFiles.Placement=="Supplementary published",:),P.Supp);

mainDocx=""; suppDocx=""; wordStatus="HTML_ONLY_REPORT_GENERATOR_NOT_AVAILABLE";
if C.GenerateWord && exist('mlreportgen.dom.Document','class')==8
    try
        mainDocx=fullfile(C.MainDir,'Final_Main_Paper_Figures_and_Tables.docx');
        suppDocx=fullfile(C.SuppDir,'Final_Supplementary_Figures_and_Tables.docx');
        buildDocx(mainDocx,'Main-paper figures and tables',MainCaptions,FigureFiles(FigureFiles.Placement=="Main paper",:),P.Main);
        buildDocx(suppDocx,'Supplementary figures and tables',SuppCaptions,FigureFiles(FigureFiles.Placement=="Supplementary published",:),P.Supp);
        wordStatus="DOCX_GENERATED";
    catch ME
        warning('Step26:WordFallback','DOCX generation failed; HTML remains complete: %s',ME.message);
        mainDocx=""; suppDocx=""; wordStatus="HTML_ONLY_DOCX_GENERATION_FAILED";
    end
end
Documents=table(string(mainHtml),string(suppHtml),string(mainDocx),string(suppDocx),wordStatus, ...
    'VariableNames',{'MainHTML','SupplementaryHTML','MainDOCX','SupplementaryDOCX','Status'});
U.Write(Documents,fullfile(C.Checks,'Step26_DocumentManifest.csv'));
end

function writeHtml(p,titleText,Captions,Figures,tables)
f=fopen(p,'wt','n','UTF-8'); assert(f>=0,'Cannot create %s',p); c=onCleanup(@()fclose(f));
fprintf(f,'<!doctype html><html><head><meta charset="utf-8"><title>%s</title>',esc(titleText));
fprintf(f,['<style>@page{size:A4;margin:18mm}body{font-family:Arial,sans-serif;color:#111;line-height:1.35}' ...
 'h1{font-size:18pt}h2{font-size:13pt;margin-top:24pt}p{font-size:10pt}img{width:100%%;height:auto;page-break-inside:avoid}' ...
 'table{border-collapse:collapse;width:100%%;font-size:8.5pt;margin:8pt 0 20pt}th,td{border:1px solid #777;padding:4pt;vertical-align:top}' ...
 'th{background:#e9eef5}.caption{font-size:9.5pt;margin-bottom:18pt}.page{page-break-before:always}</style></head><body>']);
fprintf(f,'<h1>%s</h1><p>Generated only from the frozen Step 25 evidence package. No model is fitted, tuned or altered.</p>',esc(titleText));
for i=1:height(Figures)
    id=string(Figures.FigureID(i)); cap=findCaption(Captions,id,i);
    rel=relativeWebPath(fileparts(p),Figures.PNG(i));
    fprintf(f,'<h2>%s. %s</h2><img src="%s"><p class="caption">%s</p>',esc(cap.ItemID),esc(cap.Title),esc(rel),esc(cap.Caption));
end
for i=1:numel(tables)
    T=tables{i}; cap=Captions(min(height(Figures)+i,height(Captions)),:);
    fprintf(f,'<div class="page"><h2>%s. %s</h2><p class="caption">%s</p>',esc(cap.ItemID),esc(cap.Title),esc(cap.Caption));
    writeTableHtml(f,T,60); fprintf(f,'</div>');
end
fprintf(f,'</body></html>'); clear c
end

function cap=findCaption(C,id,index)
num=regexp(char(id),'Figure(\d+)','tokens','once');
if startsWith(id,'S26'), key="Figure S"+string(num{1}); else, key="Figure "+string(num{1}); end
j=find(C.ItemID==key,1); if isempty(j), j=min(index,height(C)); end; cap=C(j,:);
end

function writeTableHtml(f,T,maxRows)
n=min(height(T),maxRows); fprintf(f,'<table><thead><tr>');
for j=1:width(T), fprintf(f,'<th>%s</th>',esc(T.Properties.VariableNames{j})); end
fprintf(f,'</tr></thead><tbody>');
for i=1:n
    fprintf(f,'<tr>'); for j=1:width(T), v=T{i,j}; if iscell(v),v=v{1};end; fprintf(f,'<td>%s</td>',esc(toText(v))); end; fprintf(f,'</tr>');
end
fprintf(f,'</tbody></table>'); if height(T)>n, fprintf(f,'<p>First %d of %d rows shown; the complete table is in the accompanying workbook.</p>',n,height(T)); end
end

function s=toText(v)
if isdatetime(v), s=string(v,'yyyy-MM-dd'); elseif isnumeric(v), s=string(compose('%.6g',v)); elseif islogical(v), s=string(v); else, s=string(v); end
if numel(s)>1, s=strjoin(s,', '); end
end

function s=esc(x)
s=char(string(x)); s=strrep(s,'&','&amp;'); s=strrep(s,'<','&lt;'); s=strrep(s,'>','&gt;'); s=strrep(s,'"','&quot;');
end

function r=relativeWebPath(base,p)
r=string(p); b=string(base)+filesep; if startsWith(lower(r),lower(b)), r=extractAfter(r,strlength(b)); else, r="Figures/"+string(extractAfter(r,max(strfind(char(r),filesep)))); end
r=replace(r,"\","/");
end

function buildDocx(path,titleText,Captions,Figures,tables)
import mlreportgen.dom.*
d=Document(path,'docx'); append(d,Heading1(titleText));
append(d,Paragraph('Generated from the frozen Step 25 evidence package; no model was refitted.'));
for i=1:height(Figures)
    if i>1, append(d,PageBreak); end
    cap=findCaption(Captions,string(Figures.FigureID(i)),i);
    append(d,Heading2(char(cap.ItemID+". "+cap.Title)));
    im=Image(char(Figures.PNG(i))); [w,h]=fitImage(Figures.PNG(i),17,14.5); im.Width=sprintf('%.2fcm',w); im.Height=sprintf('%.2fcm',h); append(d,im);
    p=Paragraph(char(cap.Caption)); p.StyleName='Caption'; append(d,p);
end
for i=1:numel(tables)
    append(d,PageBreak); cap=Captions(height(Figures)+i,:); append(d,Heading2(char(cap.ItemID+". "+cap.Title))); append(d,Paragraph(char(cap.Caption)));
    T=documentView(tables{i},i,height(Figures)==5); n=min(height(T),documentRowLimit(T)); cells=cell(n+1,width(T)); cells(1,:)=readableNames(T.Properties.VariableNames);
    for r=1:n, for c=1:width(T), v=T{r,c}; if iscell(v),v=v{1};end; cells{r+1,c}=char(toText(v)); end, end
    tb=Table(cells); tb.Border='solid'; tb.ColSep='solid'; tb.RowSep='solid'; tb.Width='100%'; tb.TableEntriesStyle={FontSize(tableFontSize(width(T)))}; append(d,tb);
    if height(T)>n, append(d,Paragraph(sprintf('First %d of %d rows shown; complete rows are in the accompanying workbook.',n,height(T)))); end
end
close(d);
end

function [w,h]=fitImage(path,maxW,maxH)
info=imfinfo(char(path)); ratio=double(info.Height)/double(info.Width); w=maxW; h=w*ratio;
if h>maxH, h=maxH; w=h/ratio; end
end

function T=documentView(T,index,isMain)
% The workbook remains the exact full table. The Word view is a readable,
% publication-facing selection of columns when a source table is too wide.
if isMain && index==4
    keep={'Format','Role','Matches','EqualInningsRMSE','Lower95','Upper95','EqualInningsMAE','EqualInningsBias','CalibrationSlope'};
elseif isMain && index==5
    keep={'Format','Role','Comparator','Matches','RMSEGain','GainLower95','GainUpper95','LeaveOneMatchOutGainMin','LeaveOneMatchOutGainMax'};
elseif isMain && index==6
    keep={'Case','Format','SelectionRule','States','BaselineRMSE','PrimaryResourceRMSE','RMSEGain'};
elseif ~isMain && index==5
    keep={'Format','N_MaxConstraintResidual','Median_MaxConstraintResidual','Max_MaxConstraintResidual','Median_Iterations','Max_Iterations','Median_Seconds','Max_Seconds'};
elseif ~isMain && index==6
    keep={'Format','N_ConstraintResidual','Median_ConstraintResidual','Max_ConstraintResidual','Median_ObjectiveGapBound','Max_ObjectiveGapBound','Median_Iterations','Max_Iterations'};
elseif ~isMain && index==7
    keep={'Format','Median_WeightedReferenceMSE','Max_WeightedReferenceMSE','Median_MaxSupportedReferenceError','Max_MaxSupportedReferenceError','Median_ConstraintResidual','Max_ConstraintResidual'};
elseif ~isMain && index==8
    keep={'Format','Median_WeightedFittingMSE','Max_WeightedFittingMSE','Median_ConstraintResidual','Max_ConstraintResidual','Median_ObjectiveGapBound','Max_ObjectiveGapBound'};
elseif ~isMain && index==10
    keep={'PackageID','Format','Family','ModelID','SupportedCells','WeightedRMSESupported','MaximumSupportedDeviation','WholeGridRMSE'};
elseif ~isMain && index==12
    keep={'Format','Family','Min_EqualInningsRMSE','Median_EqualInningsRMSE','Max_EqualInningsRMSE','Median_EqualInningsMAE','Median_EqualInningsBias'};
elseif ~isMain && index==14
    keep={'Format','Variant','Scenario','N_TargetShift','Mean_TargetShift','Min_TargetShift','Max_TargetShift','Mean_IntegerTargetShift'};
elseif ~isMain && index==18
    keep={'Format','Baseline','Candidate','RMSEGain','GainLower95','GainUpper95','LeaveOneMatchOutGainMin','LeaveOneMatchOutGainMax'};
elseif ~isMain && index==19
    keep={'Format','GroupType','Group','Matches','States','EqualInningsRMSE','EqualInningsBias','SufficientGroup'};
elseif ~isMain && index==21
    keep={'Format','Metric','MenInnings','WomenInnings','AdjustedWomenMinusMen','Lower95','Upper95','EquivalenceMargin','Equivalent'};
else
    keep=T.Properties.VariableNames;
end
keep=keep(ismember(keep,T.Properties.VariableNames)); T=T(:,keep);
end

function n=documentRowLimit(T)
if width(T)>10, n=18; elseif width(T)>6, n=30; else, n=45; end
end

function x=readableNames(x)
x=regexprep(string(x),'([a-z])([A-Z])','$1 $2'); x=replace(x,'95',' 95%'); x=cellstr(x);
end

function s=tableFontSize(n)
if n>=10, s='6.5pt'; elseif n>=8, s='7pt'; else, s='8pt'; end
end
