function [SourceManifest,Audit]=RevisedCodes_26_Audit(D,S,U)
checks=strings(0,1); passed=false(0,1); detail=strings(0,1);
add('All required Step25 artifacts found',all(~logical(D.EvidenceManifest.Required) | logical(D.EvidenceManifest.Found)), ...
    sprintf('%d/%d required',sum(logical(D.EvidenceManifest.Found)&logical(D.EvidenceManifest.Required)),sum(logical(D.EvidenceManifest.Required))));
add('All Step25 consistency gates passed',all(logical(D.Step25Gates.Passed)),sprintf('%d gates',height(D.Step25Gates)));
add('ODI and T20 frozen results present',all(ismember(["ODI","T20"],unique(string(D.FrozenPerformance.Format)))),'FrozenPerformance');
add('Temporal test contains no baseline-only result',all(D.FrozenPerformance.Matches>0),'All frozen rows have matches');
add('Bootstrap interval ordering valid',all(D.Bootstrap95CI.Lower95<=D.Bootstrap95CI.Estimate & D.Bootstrap95CI.Estimate<=D.Bootstrap95CI.Upper95),'95% limits bracket estimates');
add('Paired gain identity valid',max(abs(D.PairedComparisons.RMSEGain-(D.PairedComparisons.ComparatorRMSE-D.PairedComparisons.CandidateRMSE)))<1e-9,'Comparator minus candidate');
add('Case gain identity valid',max(abs(D.CaseStudies.RMSEGain-(D.CaseStudies.BaselineRMSE-D.CaseStudies.PrimaryResourceRMSE)))<1e-9,'Baseline minus resource');
add('Compact model has six parameters',all(ismember({'a','b','c','d','e','f'},D.CompactParameters.Properties.VariableNames)),'a-f present');
add('All 14 equations have sources',height(D.EquationRegister)==14 && all(logical(D.EquationRegister.SourcePresent)),'Equation register');
add('No reviewer evidence item is missing',all(logical(D.ReviewerCoverage.EvidencePresent)),sprintf('%d reviewer/editor items',height(D.ReviewerCoverage)));
add('Gender pooling decision present',all(ismember(["ODI","T20"],string(D.GenderPoolingGate.Format))),'Pooling gate remains evidence-based');
add('Opponent recovery limitation retained',height(D.OpponentValidation)==1,'Recovery check is not relabelled as external validation');
Audit=table(checks,passed,detail,'VariableNames',{'Check','Passed','Detail'});
assert(all(Audit.Passed),'Step26 input audit failed. See Step26_InputAudit.csv.');

ArtifactID=["Main tables";"Supplementary tables";"Evidence manifest";"Reviewer coverage";"Step25 gates"];
Path=[S.MainWorkbook;S.SuppWorkbook;S.Manifest;S.Coverage;S.Gates];
SHA256=strings(numel(Path),1); Bytes=zeros(numel(Path),1);
for i=1:numel(Path), a=dir(Path(i)); Bytes(i)=a.bytes; SHA256(i)=U.Hash(Path(i)); end
SourceManifest=table(ArtifactID,Path,Bytes,SHA256);

    function add(name,tf,msg)
        checks(end+1,1)=string(name); passed(end+1,1)=logical(tf); detail(end+1,1)=string(msg);
    end
end

