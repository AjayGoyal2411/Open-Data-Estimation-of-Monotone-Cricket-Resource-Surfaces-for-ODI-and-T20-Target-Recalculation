function [MainFiles,SuppFiles,Allocation]=RevisedCodes_26_Tables(C,D,U)
P=RevisedCodes_26_PublicationTableData(D,U);
mainBook=fullfile(C.MainTables,'Step26_MainPaperTables.xlsx'); suppBook=fullfile(C.SuppTables,'Step26_SupplementaryTables.xlsx'); repoBook=fullfile(C.RepositoryOnly,'Step26_FullComputationalAuditTables.xlsx');
for i=1:numel(P.Main), U.Write(P.Main{i},mainBook,P.MainNames{i}); end
for i=1:numel(P.Supp), U.Write(P.Supp{i},suppBook,P.SuppNames{i}); end
for i=1:numel(P.Repo), U.Write(P.Repo{i},repoBook,P.RepoNames{i}); end
MainFiles=table(string(mainBook),string(strjoin(P.MainNames,'; ')),'VariableNames',{'Workbook','Sheets'});
SuppFiles=table([string(suppBook);string(repoBook)],[string(strjoin(P.SuppNames,'; '));string(strjoin(P.RepoNames,'; '))],["Supplementary published";"Repository only"],'VariableNames',{'Workbook','Sheets','Placement'});
ItemID=["Tables 1-7";"Tables S1-S26";"Full computational audit tables"]; Placement=["Main paper";"Supplementary published";"Repository only"];
Reason=["Core cohort, model, performance, case and comparator evidence";"Concise detailed methods, sensitivity, subgroup and comparator evidence";"Complete row-level audit and large diagnostic grids retained without typesetting"];
Allocation=table(ItemID,Placement,Reason);
end

