function Files=RevisedCodes_26_Figures(C,D,U)
Files=table; setupDefaults(C);
Files=[Files;workflowFigure(C,U)];
Files=[Files;resourceFigure(C,D,U)];
Files=[Files;rmseFigure(C,D,U)];
Files=[Files;gainFigure(C,D,U)];
Files=[Files;caseFigure(C,D,U)];
Files=[Files;estimandFigure(C,D,U)];
Files=[Files;ablationFigure(C,D,U)];
Files=[Files;genderFigure(C,D,U)];
Files=[Files;subgroupFigure(C,D,U)];
Files=[Files;eventFigure(C,D,U)];
Files=[Files;supportFigure(C,D,U)];
Files=[Files;calibrationFigure(C,D,U)];
end

function setupDefaults(C)
set(groot,'defaultAxesFontName',C.Font,'defaultTextFontName',C.Font, ...
    'defaultAxesFontSize',C.AxisFontSize,'defaultAxesLineWidth',0.8, ...
    'defaultLineLineWidth',C.LineWidth,'defaultLegendBox','off');
end

function row=workflowFigure(C,U)
f=figure('Visible','off','Position',[50 50 1800 820]); ax=axes(f,'Position',[0 0 1 1]); axis(ax,[0 1 0 1]); axis(ax,'off');
titles=["Data and eligibility","State construction","Development only","Locked evaluation"];
body=["Cricsheet YAML/JSON\nODI and T20 cohorts\nLegal-delivery QC"; ...
      "Balls remaining\nWickets in hand\nRemaining scoring output"; ...
      "Empirical surface\nMonotone reference\nCompact, flexible and context models"; ...
      "Temporal test\nRule-selected cases\nSubgroups and comparators"];
x=[.03 .275 .52 .765]; colors={[.88 .94 1],[.90 1 .93],[1 .96 .87],[.95 .91 1]};
for i=1:4
 rectangle(ax,'Position',[x(i) .29 .205 .48],'FaceColor',colors{i},'EdgeColor',[.15 .30 .50],'LineWidth',1.5);
 text(ax,x(i)+.1025,.67,sprintf('%c  %s','A'+i-1,titles(i)),'HorizontalAlignment','center','FontWeight','bold','FontSize',14,'Interpreter','none');
 text(ax,x(i)+.1025,.50,replace(body(i),'\n',newline),'HorizontalAlignment','center','VerticalAlignment','middle','FontSize',12,'Interpreter','none');
 if i<4, annotation(f,'arrow',[x(i)+.205 x(i+1)],[.53 .53],'LineWidth',1.5); end
end
text(ax,.5,.17,'All model choices precede temporal-test prediction; no test observation is used for fitting or selection.', ...
 'HorizontalAlignment','center','FontWeight','bold','FontSize',12);
row=tag(U.SaveFigure(f,C.MainFigures,'M26_Figure1_StudyWorkflow'),'Main paper'); close(f);
end

function row=resourceFigure(C,D,U)
f=figure('Visible','off','Position',[50 50 1800 780]); t=tiledlayout(f,1,2,'TileSpacing','compact','Padding','compact');
W=[10 7 5 3]; cols=lines(numel(W));
for k=1:2
 fmt=["ODI","T20"]; r=D.CompactParameters(string(D.CompactParameters.Format)==fmt(k),:); assert(height(r)==1);
 if fmt(k)=="ODI", umax=300; else, umax=120; end
 u=linspace(0,umax,601); nexttile; hold on
 for j=1:numel(W), plot(u,compactR(u/umax,W(j),r),'-','Color',cols(j,:),'DisplayName',sprintf('%d wickets in hand',W(j))); end
 xlabel('Balls remaining'); ylabel('Normalized remaining scoring capacity'); title(fmt(k));
 xlim([0 umax]); ylim([0 1]); grid on; legend('Location','northwest');
 text(.98,.04,sprintf('a=%.3f, b=%.3f, c=%.3f\nd=%.3f, e=%.3f, f=%.3f',r.a,r.b,r.c,r.d,r.e,r.f), ...
  'Units','normalized','HorizontalAlignment','right','VerticalAlignment','bottom','FontSize',9,'BackgroundColor','white','EdgeColor',[.8 .8 .8]);
end
title(t,'Frozen six-parameter compact resource surfaces','FontWeight','bold','FontSize',16);
row=tag(U.SaveFigure(f,C.MainFigures,'M26_Figure2_FrozenCompactSurfaces'),'Main paper'); close(f);
end

function R=compactR(x,w,p)
v=w/10; sig=@(z)1./(1+exp(-z)); z=(sig(p.a+p.b*v+p.c*v.^2)-sig(p.a))/(sig(p.a+p.b+p.c)-sig(p.a));
k=exp(p.d+p.e*v+p.f*v.^2); R=z.*(-expm1(-k*x))./(-expm1(-k));
end

function row=rmseFigure(C,D,U)
B=D.Bootstrap95CI(string(D.Bootstrap95CI.Metric)=="EqualInningsRMSE",:); roles=unique(string(B.Role),'stable');
f=figure('Visible','off','Position',[50 50 1700 760]); t=tiledlayout(f,1,2,'TileSpacing','compact','Padding','compact');
for k=1:2
 fmt=["ODI","T20"]; X=B(string(B.Format)==fmt(k),:); [~,ix]=ismember(roles,string(X.Role)); X=X(ix(ix>0),:);
 y=(1:height(X))'; nexttile; hold on; errorbar(X.Estimate,y,X.Estimate-X.Lower95,X.Upper95-X.Estimate,'horizontal','o', ...
  'Color',C.Colors.Blue,'MarkerFaceColor',C.Colors.Blue,'CapSize',7);
 yticks(y); yticklabels(U.HumanRole(X.Role)); set(gca,'YDir','reverse'); xlabel('Equal-innings RMSE (runs)'); title(sprintf('%s temporal test (n = %d matches)',fmt(k),X.Matches(1))); grid on
end
title(t,'Locked temporal-test performance with match-bootstrap 95% confidence intervals','FontWeight','bold','FontSize',15);
row=tag(U.SaveFigure(f,C.MainFigures,'M26_Figure3_HeldOutRMSE'),'Main paper'); close(f);
end

function row=gainFigure(C,D,U)
P=D.PairedComparisons(string(D.PairedComparisons.Comparator)=="Baseline",:);
f=figure('Visible','off','Position',[50 50 1700 760]); t=tiledlayout(f,1,2,'TileSpacing','compact','Padding','compact');
for k=1:2
 fmt=["ODI","T20"]; X=P(string(P.Format)==fmt(k),:); y=(1:height(X))'; nexttile; hold on
 errorbar(X.RMSEGain,y,X.RMSEGain-X.GainLower95,X.GainUpper95-X.RMSEGain,'horizontal','o','Color',C.Colors.Green,'MarkerFaceColor',C.Colors.Green,'CapSize',7);
 xline(0,'k-'); yticks(y); yticklabels(U.HumanRole(X.Role)); set(gca,'YDir','reverse'); xlabel('RMSE reduction versus linear-balls baseline (runs)'); title(fmt(k)); grid on
end
title(t,'Paired whole-match performance gains on the locked temporal test','FontWeight','bold','FontSize',15);
row=tag(U.SaveFigure(f,C.MainFigures,'M26_Figure4_PairedGains'),'Main paper'); close(f);
end

function row=caseFigure(C,D,U)
X=D.CaseStudies; f=figure('Visible','off','Position',[50 50 1900 900]); t=tiledlayout(f,1,2,'TileSpacing','compact','Padding','compact');
for k=1:2
 fmt=["ODI","T20"]; A=X(string(X.Format)==fmt(k),:); y=(1:height(A))'; nexttile; hold on
 for i=1:height(A), plot([A.BaselineRMSE(i) A.PrimaryResourceRMSE(i)],[y(i) y(i)],'-','Color',[.65 .65 .65],'HandleVisibility','off'); end
 scatter(A.BaselineRMSE,y,75,C.Colors.Grey,'filled','DisplayName','Linear-balls baseline');
 scatter(A.PrimaryResourceRMSE,y,75,C.Colors.Orange,'filled','DisplayName','Frozen resource model');
 labels=A.BattingTeam+" v "+A.Opponent+" | "+string(A.MatchDate,'yyyy-MM-dd')+" | ID "+string(A.MatchID);
 yticks(y); yticklabels(labels); set(gca,'YDir','reverse'); xlabel('Case-level RMSE (runs)'); title(fmt(k)); grid on; legend('Location','best');
end
title(t,'Rule-selected real-match examples: improvement, median gain and deterioration','FontWeight','bold','FontSize',15);
row=tag(U.SaveFigure(f,C.MainFigures,'M26_Figure5_RealMatchCases'),'Main paper'); close(f);
end

function row=estimandFigure(C,D,U)
X=D.EstimandSensitivity(startsWith(string(D.EstimandSensitivity.PackageID),"FULL_TRAIN"),:);
alts=unique(string(X.Alternative),'stable'); f=figure('Visible','off','Position',[50 50 1700 760]); t=tiledlayout(f,1,2,'TileSpacing','compact','Padding','compact');
for k=1:2
 fmt=["ODI","T20"]; A=X(endsWith(string(X.PackageID),fmt(k)),:); [~,ix]=ismember(alts,string(A.Alternative)); A=A(ix(ix>0),:);
 nexttile; barh(categorical(prettyEstimand(A.Alternative),prettyEstimand(A.Alternative)),A.RMSE,'FaceColor',C.Colors.Blue); xlabel('RMSE from primary empirical estimand'); title(fmt(k)); grid on
end
title(t,'Development-data empirical-estimand sensitivity','FontWeight','bold','FontSize',15);
row=tag(U.SaveFigure(f,C.SuppFigures,'S26_Figure1_EstimandSensitivity'),'Supplementary published'); close(f);
end

function s=prettyEstimand(x)
s=string(x); s=replace(s,"RunMeanInnings","Run mean, equal innings"); s=replace(s,"FractionMeanState","Fraction mean, state weighted");
s=replace(s,"FractionMeanInnings","Fraction mean, equal innings"); s=replace(s,"RunMedianState","Run median, state weighted"); s=replace(s,"RunTrimmed10State","10% trimmed run mean");
end

function row=ablationFigure(C,D,U)
X=D.ContextAblations; f=figure('Visible','off','Position',[50 50 1800 900]); t=tiledlayout(f,1,2,'TileSpacing','compact','Padding','compact');
for k=1:2
 fmt=["ODI","T20"]; lam=["lambda0.001","lambda0.0001"]; A=X(string(X.Format)==fmt(k) & contains(string(X.Candidate),lam(k)),:);
 A=A(~contains(string(A.Baseline),"B0_LinearBalls"),:); labels=contextName(A.Candidate); [labels,ia]=unique(labels,'stable'); A=A(ia,:);
 y=(1:height(A))'; nexttile; hold on; errorbar(A.RMSEGain,y,A.RMSEGain-A.GainLower95,A.GainUpper95-A.RMSEGain,'horizontal','o','Color',C.Colors.Purple,'MarkerFaceColor',C.Colors.Purple);
 xline(0,'k-'); yticks(y); yticklabels(labels); set(gca,'YDir','reverse'); xlabel('Incremental RMSE reduction (runs)'); title(fmt(k)); grid on
end
title(t,'Development-only adjacent context ablations','FontWeight','bold','FontSize',15);
row=tag(U.SaveFigure(f,C.SuppFigures,'S26_Figure2_ContextAblations'),'Supplementary published'); close(f);
end

function s=contextName(x)
s=string(x); s=regexprep(s,'.*C1_',''); s=regexprep(s,'_lambda.*','');
s=replace(s,"Partnership","Partnership state"); s=replace(s,"ScoreRecentRate","Recent scoring rate"); s=replace(s,"TeamOpponentHistory","Past-only team/opponent history"); s=replace(s,"VenueEvent","Venue/event metadata"); s=replace(s,"Core","Core resource state");
end

function row=genderFigure(C,D,U)
X=D.GenderEquivalence; f=figure('Visible','off','Position',[50 50 1800 650]); t=tiledlayout(f,1,2,'TileSpacing','compact','Padding','compact');
for k=1:2
 fmt=["ODI","T20"]; A=X(string(X.Format)==fmt(k),:); y=(1:height(A))'; nexttile; hold on
 v=A.AdjustedWomenMinusMen./A.EquivalenceMargin; lo=A.Lower95./A.EquivalenceMargin; hi=A.Upper95./A.EquivalenceMargin;
 errorbar(v,y,v-lo,hi-v,'horizontal','o','Color',C.Colors.Red,'MarkerFaceColor',C.Colors.Red); xline(-1,'k--'); xline(1,'k--'); xline(0,'k-');
 yticks(y); yticklabels(replace(string(A.Metric),["FinalRuns","RunsPerLegalBall"],["Final runs","Runs per legal ball"])); set(gca,'YDir','reverse');
 ylim([.5 max(2.5,height(A)+.5)]); xlabel('Adjusted women-minus-men difference / equivalence margin'); title(fmt(k)+" pooling supported: no"); grid on
end
title(t,'Prespecified gender-equivalence tests and pooling decision','FontWeight','bold','FontSize',15);
row=tag(U.SaveFigure(f,C.SuppFigures,'S26_Figure3_GenderEquivalence'),'Supplementary published'); close(f);
end

function row=subgroupFigure(C,D,U)
X=D.Subgroups(string(D.Subgroups.Role)=="PrimaryResource" & ismember(string(D.Subgroups.GroupType),["Phase","Year"]),:);
f=figure('Visible','off','Position',[50 50 1800 1000]); t=tiledlayout(f,2,2,'TileSpacing','compact','Padding','compact');
for k=1:2
 fmt=["ODI","T20"]; for g=1:2
 typ=["Phase","Year"]; A=X(string(X.Format)==fmt(k)&string(X.GroupType)==typ(g),:); nexttile; b=bar(categorical(string(A.Group),string(A.Group)),A.EqualInningsRMSE,'FaceColor',C.Colors.Blue);
 ylabel('Equal-innings RMSE (runs)'); title(fmt(k)+" by "+lower(typ(g))); grid on
 if ~isempty(A), ylim([0 max(A.EqualInningsRMSE)*1.22]); end
 text(b.XEndPoints,b.YEndPoints,string("n="+A.Matches+", states="+A.States),'HorizontalAlignment','center','VerticalAlignment','bottom','FontSize',8);
 end
end
title(t,'Frozen-resource performance by innings phase and temporal-test year','FontWeight','bold','FontSize',15);
row=tag(U.SaveFigure(f,C.SuppFigures,'S26_Figure4_PhaseAndYear'),'Supplementary published'); close(f);
end

function row=eventFigure(C,D,U)
X=D.Subgroups(string(D.Subgroups.Role)=="PrimaryResource" & string(D.Subgroups.GroupType)=="EventNameAsRecorded" & logical(D.Subgroups.SufficientGroup),:);
f=figure('Visible','off','Position',[50 50 1900 1050]); t=tiledlayout(f,1,2,'TileSpacing','compact','Padding','compact');
for k=1:2
 fmt=["ODI","T20"]; A=X(string(X.Format)==fmt(k),:); [~,ix]=sort(A.Matches,'descend'); A=A(ix(1:min(10,height(A))),:); A=flipud(A);
 nexttile; 
 if isempty(A)
  axis off; text(.5,.5,'No recorded event met the prespecified support rule','Units','normalized','HorizontalAlignment','center'); title(fmt(k)+" recorded events");
 else
  b=barh(categorical(string(A.Group),string(A.Group)),A.EqualInningsRMSE,'FaceColor',C.Colors.Blue); xlabel('Equal-innings RMSE (runs)'); title(fmt(k)+" recorded events"); grid on
  xlim([0 max(A.EqualInningsRMSE)*1.28]);
  text(A.EqualInningsRMSE,(1:height(A))',"  n="+string(A.Matches),'HorizontalAlignment','left','VerticalAlignment','middle','FontSize',8,'Clipping','off');
 end
end
title(t,'Recorded-event diagnostics among source-defined sufficient groups','FontWeight','bold','FontSize',15);
row=tag(U.SaveFigure(f,C.SuppFigures,'S26_Figure5_RecordedEvents'),'Supplementary published'); close(f);
end

function row=supportFigure(C,D,U)
X=D.SupportThresholds(startsWith(string(D.SupportThresholds.PackageID),"FULL_TRAIN"),:);
f=figure('Visible','off','Position',[50 50 1800 1050]); t=tiledlayout(f,2,2,'TileSpacing','compact','Padding','compact');
for k=1:2
 fmt=["ODI","T20"]; A=X(endsWith(string(X.PackageID),fmt(k)),:); A=sortrows(A,'MinMatches');
 nexttile(k); plot(A.MinMatches,A.SupportedRunCells,'-o','Color',C.Colors.Blue,'MarkerFaceColor',C.Colors.Blue); ylabel('Supported state cells'); xlabel('Minimum matches per cell'); title(fmt(k)+" supported cells"); grid on
 nexttile(k+2); plot(A.MinMatches,A.StatesInSupportedRunCells,'-s','Color',C.Colors.Orange,'MarkerFaceColor','white'); ylabel('Delivery states in supported cells'); xlabel('Minimum matches per cell'); title(fmt(k)+" supported delivery states"); grid on
end
title(t,'Empirical support as the development-data threshold changes','FontWeight','bold','FontSize',15);
row=tag(U.SaveFigure(f,C.SuppFigures,'S26_Figure6_EmpiricalSupport'),'Supplementary published'); close(f);
end

function row=calibrationFigure(C,D,U)
X=D.FrozenPerformance; f=figure('Visible','off','Position',[50 50 1800 820]); t=tiledlayout(f,1,2,'TileSpacing','compact','Padding','compact');
for k=1:2
 fmt=["ODI","T20"]; A=X(string(X.Format)==fmt(k),:); labels=U.HumanRole(A.Role); y=(1:height(A))'; nexttile; hold on
 scatter(A.CalibrationSlope,y,70,C.Colors.Blue,'filled'); xline(1,'k--');
 xr=[min(A.CalibrationSlope) max(A.CalibrationSlope)]; span=max(diff(xr),.08); xlim([xr(1)-.18*span xr(2)+.65*span]);
 for i=1:height(A)
  if A.CalibrationSlope(i)>xr(1)+.72*diff(xr), ha='right'; dx=-.015*span; else, ha='left'; dx=.015*span; end
  text(A.CalibrationSlope(i)+dx,y(i),sprintf('intercept %.2f',A.CalibrationIntercept(i)),'HorizontalAlignment',ha,'VerticalAlignment','middle','FontSize',8,'Clipping','off');
 end
 yticks(y); yticklabels(labels); set(gca,'YDir','reverse'); xlabel('Calibration slope (ideal = 1)'); title(fmt(k)); grid on
end
title(t,'Locked temporal-test calibration','FontWeight','bold','FontSize',15);
row=tag(U.SaveFigure(f,C.SuppFigures,'S26_Figure7_Calibration'),'Supplementary published'); close(f);
end

function T=tag(T,placement)
T.Placement=repmat(string(placement),height(T),1);
end
