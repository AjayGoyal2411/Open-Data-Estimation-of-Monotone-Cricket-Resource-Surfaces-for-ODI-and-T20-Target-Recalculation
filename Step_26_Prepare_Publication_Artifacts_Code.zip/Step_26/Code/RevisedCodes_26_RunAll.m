function Results=RevisedCodes_26_RunAll(settings)
if nargin<1,settings=struct;end
C=RevisedCodes_26_Config(settings); U=RevisedCodes_26_Utils;
U.MakeDirs(C.OutputRoot,C.MainDir,C.MainFigures,C.MainTables,C.SuppDir,C.SuppFigures,C.SuppTables,C.RepositoryOnly,C.Checks,C.Work);
fprintf('Step26 publication-artifact production started %s\n',datestr(now));
try
 Tests=RevisedCodes_26_SelfTests(U); U.Write(Tests,fullfile(C.Checks,'Step26_SelfTests.csv'));
 S=RevisedCodes_26_LocateStep25(C,U); D=RevisedCodes_26_Load(S,U);
 [SourceManifest,InputAudit]=RevisedCodes_26_Audit(D,S,U); U.Write(SourceManifest,fullfile(C.Checks,'Step26_SourceManifest.csv')); U.Write(InputAudit,fullfile(C.Checks,'Step26_InputAudit.csv'));
 [MainFiles,SuppFiles,Allocation]=RevisedCodes_26_Tables(C,D,U); U.Write(Allocation,fullfile(C.Checks,'Step26_AllocationManifest.csv'));
 [MainCaptions,SuppCaptions]=RevisedCodes_26_Captions; U.Write(MainCaptions,fullfile(C.MainDir,'Step26_MainPaper_Captions.csv')); U.Write(SuppCaptions,fullfile(C.SuppDir,'Step26_Supplementary_Captions.csv'));
 FigureFiles=RevisedCodes_26_Figures(C,D,U); U.Write(FigureFiles,fullfile(C.Checks,'Step26_FigureManifest.csv'));
 Documents=RevisedCodes_26_Documents(C,D,MainCaptions,SuppCaptions,FigureFiles,U);
 Coverage=step26Coverage(D.ReviewerCoverage); U.Write(Coverage,fullfile(C.Checks,'Step26_ReviewerCoverage.csv'));
 [Gates,Reconciliation]=RevisedCodes_26_FinalChecks(C,D,FigureFiles,Documents,U); U.Write(Gates,fullfile(C.Checks,'Step26_PublicationReadinessChecks.csv')); U.Write(Reconciliation,fullfile(C.Checks,'Step26_NumericReconciliation.csv'));
 Summary=table(string(C.OutputRoot),height(FigureFiles),height(MainCaptions),height(SuppCaptions),all(Gates.Passed),Documents.Status, ...
  'VariableNames',{'OutputRoot','Figures','MainItems','SupplementaryItems','AllChecksPassed','DocumentStatus'});
 U.Write(Summary,fullfile(C.OutputRoot,'Step26_CompletionSummary.csv')); writeReadme(C,Documents);
 U.ZipFolder(C.OutputRoot,C.PackageZip); U.ZipFolder(C.Checks,C.ChecksZip);
 fprintf('Step26 completed.\nUpload %s\nPublication package %s\n',C.ChecksZip,C.PackageZip);
 Results=struct('Config',C,'Sources',S,'MainTables',MainFiles,'SupplementaryTables',SuppFiles,'Figures',FigureFiles,'Documents',Documents,'Gates',Gates,'Summary',Summary);
catch ME
 try, failed=fullfile(C.OutputBase,[C.Generation '_FAILED_Checks.zip']); U.ZipFolder(C.OutputRoot,failed); fprintf(2,'Upload %s\n',failed); catch, end
 rethrow(ME)
end

function T=step26Coverage(T)
req=lower(string(T.Requirement)); T.Step26Artifact=repmat("Supplementary tables and source manifest",height(T),1);
T.Step26Artifact(contains(req,'real odi')|contains(req,'case'))="Figure 5; Table 6";
T.Step26Artifact(contains(req,'weight')|contains(req,'convergence'))="Tables S4-S8; Figure S6";
T.Step26Artifact(contains(req,'variable')|contains(req,'yaml'))="Tables S1, S9 and S17";
T.Step26Artifact(contains(req,'retired'))="Table S2; repository-only full audit";
T.Step26Artifact(contains(req,'six compact'))="Figure 2; Table 3";
T.Step26Artifact(contains(req,'gender'))="Figure S3; Tables S20-S23";
T.Step26Artifact(contains(req,'competition')|contains(req,'era'))="Figures S4-S5; Table S19";
T.Step26Artifact(contains(req,'comparator')|contains(req,'dls')|contains(req,'vjd'))="Table 7; Table S25";
T.Step26Artifact(contains(req,'readability')|contains(req,'official label')|contains(req,'table reference'))="Rebuilt vector figures; caption and allocation registers";
T.Step26Status=repmat("CODING_AND_DATA_EVIDENCE_ADDRESSED",height(T),1);
lim=string(T.Disposition)=="LIMITATION_DOCUMENTED"; T.Step26Status(lim)="EVIDENCE_LIMITATION_RETAINED_WITHOUT_OVERCLAIM";
end
end

function writeReadme(C,Documents)
p=fullfile(C.OutputRoot,'README.txt'); f=fopen(p,'wt'); assert(f>=0); c=onCleanup(@()fclose(f));
fprintf(f,'Step26 Publication Artifacts\n\n');
fprintf(f,'This stage reads the frozen Step25 evidence and does not fit, tune or modify a scientific model.\n');
fprintf(f,'MainPaper contains five publication figures, seven table sheets, captions and a complete HTML document.\n');
fprintf(f,'Supplementary contains seven publication figures, detailed table sheets, captions and a complete HTML document.\n');
fprintf(f,'Checks contains input hashes, allocation, reviewer coverage, numeric reconciliation and readiness gates.\n');
fprintf(f,'Word status: %s\n',Documents.Status);
fprintf(f,'If DOCX is absent, open the HTML document in Microsoft Word and Save As DOCX; figures remain linked within the package.\n');
fprintf(f,'Scientific limitations retained: proprietary modern DLS parameters are not reproduced; competition/year subgroups are diagnostic; gender pooling is unsupported; no external-validation claim is made.\n');
end
