clear; clc;
here=fileparts(mfilename('fullpath')); addpath(here);
settings=struct;
% Optional overrides:
% settings.ProjectRoot='D:\VihaanProject1';
% settings.Step25Root='D:\VihaanProject1\paper_outputs_revisedcodes\step25_manuscript_evidence\generation_...';
% settings.GenerateWord=true;  % uses MATLAB Report Generator when installed
Results=RevisedCodes_26_RunAll(settings); %#ok<NASGU>

