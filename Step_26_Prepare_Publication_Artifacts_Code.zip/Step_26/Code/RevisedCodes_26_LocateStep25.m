function S=RevisedCodes_26_LocateStep25(C,U)
root=string(C.Step25Root);
if strlength(root)>0
    assert(isfolder(root),'Configured Step25Root does not exist: %s',root);
else
    d=dir(fullfile(C.ProjectRoot,'paper_outputs_revisedcodes','step25_manuscript_evidence','**','Step25_MainPaperTables.xlsx'));
    d=d(~contains(lower(string({d.folder})),'failed'));
    if ~isempty(d)
        [~,i]=max([d.datenum]); root=string(fileparts(fileparts(fileparts(fullfile(d(i).folder,d(i).name)))));
    else
        z=dir(fullfile(C.CodeRoot,'ReferenceInput','*Step25*Evidence*.zip'));
        assert(~isempty(z),['No completed Step25 evidence package found. Place the Step25 evidence ZIP under ' ...
            'this code folder\ReferenceInput or set settings.Step25Root.']);
        [~,i]=max([z.datenum]); root=fullfile(C.Work,'Step25Reference'); U.MakeDirs(root);
        unzip(fullfile(z(i).folder,z(i).name),root);
    end
end
main=dir(fullfile(root,'**','Step25_MainPaperTables.xlsx'));
supp=dir(fullfile(root,'**','Step25_SupplementaryTables.xlsx'));
manifest=dir(fullfile(root,'**','Step25_EvidenceManifest.csv'));
coverage=dir(fullfile(root,'**','Step25_ReviewerCoverage.csv'));
gates=dir(fullfile(root,'**','Step25_ConsistencyGates.csv'));
assert(~isempty(main)&&~isempty(supp)&&~isempty(manifest)&&~isempty(coverage)&&~isempty(gates), ...
    'Step25 package is incomplete. Main/supplementary workbooks and checks are required.');
S.Root=root; S.MainWorkbook=latest(main); S.SuppWorkbook=latest(supp);
S.Manifest=latest(manifest); S.Coverage=latest(coverage); S.Gates=latest(gates);
S.MainFigureDir=string(fileparts(latest(dir(fullfile(root,'**','M25_Figure1_Workflow.png')))));
end

function p=latest(d)
[~,i]=max([d.datenum]); p=string(fullfile(d(i).folder,d(i).name));
end

