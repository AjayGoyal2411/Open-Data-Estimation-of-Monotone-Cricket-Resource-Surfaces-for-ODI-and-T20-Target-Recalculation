function T=RevisedCodes_26_SelfTests(U)
Check=["Human labels replace raw role";"Gain identity";"Compact boundary at zero balls"; ...
    "Compact boundary at full balls";"Truth parser accepts one";"Truth parser rejects zero"; ...
    "Filename concatenation scalar safe";"Grouped count compatibility";"Grouped finite mean compatibility"; ...
    "Paired comparator key is unique";"Windows ZIP relative path preserves separator"];
Passed=false(size(Check));
Passed(1)=U.HumanRole("PrimaryResource")=="Frozen resource model";
Passed(2)=abs((57.3571664982665-47.7713952538547)-9.58577124441188)<1e-12;
p=struct('a',-2,'b',3,'c',-.4,'d',3,'e',-3,'f',1); sig=@(z)1./(1+exp(-z)); v=1; z=(sig(p.a+p.b*v+p.c*v^2)-sig(p.a))/(sig(p.a+p.b+p.c)-sig(p.a)); k=exp(p.d+p.e*v+p.f*v^2);
Passed(3)=abs(z*(-expm1(-k*0))/(-expm1(-k)))<1e-12;
Passed(4)=abs(z*(-expm1(-k*1))/(-expm1(-k))-1)<1e-12;
Passed(5)=U.Truth(1); Passed(6)=~U.Truth(0);
n='abc'; Passed(7)=strcmp([char(string(n)) '.png'],'abc.png');
g=table(["a";"a";"b"],[1;2;3],'VariableNames',{'Group','Value'}); [G,keys]=findgroups(g(:,'Group')); %#ok<ASGLU>
counts=splitapply(@numel,g.Value,G); Passed(8)=isequal(counts,[2;1]);
means=splitapply(@(x)mean(x(isfinite(x))),g.Value,G); Passed(9)=max(abs(means-[1.5;3]))<1e-12;
pair=table(["ODI";"ODI"],["PrimaryResource";"PrimaryResource"],["Baseline";"FlexibleComparator"], ...
    'VariableNames',{'Format','Role','Comparator'});
Passed(10)=sum(pair.Format=="ODI" & pair.Role=="PrimaryResource" & pair.Comparator=="Baseline")==1;
base='D:\VihaanProject1\output'; absolute=[base '\Checks\Step26_Checks.csv']; prefix=[base '\'];
relative=absolute(numel(prefix)+1:end); Passed(11)=strcmp(relative,'Checks\Step26_Checks.csv');
T=table(Check,Passed); assert(all(Passed),'Step26 self-test failed.');
end
