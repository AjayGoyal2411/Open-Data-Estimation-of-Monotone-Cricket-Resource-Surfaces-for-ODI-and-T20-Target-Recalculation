function P=RevisedCodes_26_PublicationTableData(D,U)
T4=performanceTable(D); T5=D.PairedComparisons; T5.Role=U.HumanRole(T5.Role); T5.Comparator=U.HumanRole(T5.Comparator);
T6=D.CaseStudies; T6.Case=T6.BattingTeam+" v "+T6.Opponent+" ("+string(T6.MatchDate,'yyyy-MM-dd')+", "+string(T6.MatchID)+")"; T6=movevars(T6,'Case','Before','Format');
P.Main={D.DataPartitions,D.ModelSpecification,D.CompactParameters,T4,T5,T6,D.ComparatorRegister};
P.MainNames={'Table1_DataCohorts','Table2_ModelSpecification','Table3_CompactParameters','Table4_HeldOutPerformance','Table5_PairedComparisons','Table6_RealMatchCases','Table7_ComparatorScope'};
P.SuppNames={'S1_VariableDictionary','S2_RetiredHurtSummary','S3_EstimandSensitivity','S4_SupportThresholds', ...
 'S5_ProjectionSummary','S6_CertificationSummary','S7_CompactSummary','S8_FlexibleSummary','S9_ContextPreprocessSummary','S10_Approximation','S11_TargetPolicy','S12_DevelopmentScoreSummary', ...
 'S13_SensitivityCertificates','S14_SensitivityTargetSummary','S15_SecondInnings','S16_InningsDistances','S17_InputDecisions','S18_ContextAblations','S19_SupportedSubgroups', ...
 'S20_GenderSummary','S21_GenderEquivalence','S22_GenderPoolingGate','S23_GenderSurfaces','S24_OpponentRecoveryCheck','S25_VJDExamples','S26_EquationRegister'};
P.Supp={D.VariableDictionary,summaryCount(D.RetiredHurtAudit,{'Split','CompletionClass'},'MatchID'),D.EstimandSensitivity,D.SupportThresholds, ...
 numericSummary(withFormat(D.ProjectionConvergence),{'Format'},{'MaxConstraintResidual','Iterations','Seconds'}), ...
 numericSummary(withFormat(D.ReferenceCertification),{'Format'},{'ConstraintResidual','ObjectiveGapBound','Iterations'}), ...
 numericSummary(withFormat(D.CompactDiagnostics),{'Format'},{'WeightedReferenceMSE','MaxSupportedReferenceError','ConstraintResidual'}), ...
 numericSummary(withFormat(D.FlexibleDiagnostics),{'Format'},{'WeightedFittingMSE','ConstraintResidual','ObjectiveGapBound'}), ...
 preprocessingSummary(withFormat(D.ContextPreprocessing)),D.Approximation,D.TargetPolicy, ...
 numericSummary(D.DevelopmentScores,{'Format','Family'},{'EqualInningsRMSE','EqualInningsMAE','EqualInningsBias'}), ...
 D.SensitivityCertificates,targetSummary(D.SensitivityTargets),D.SecondInnings,D.InningsDistances,D.InputDecisions,D.ContextAblations, ...
 D.Subgroups(string(D.Subgroups.Role)=="PrimaryResource" & logical(D.Subgroups.SufficientGroup),:),D.GenderSummary,D.GenderEquivalence,D.GenderPoolingGate,D.GenderSurfaces,D.OpponentValidation,D.VJDExamples,D.EquationRegister};
P.RepoNames={'Full_RetiredHurtAudit','Full_ProjectionConvergence','Full_ReferenceCertification','Full_CompactDiagnostics','Full_FlexibleDiagnostics','Full_ContextPreprocessing','Full_DevelopmentScores','Full_SensitivityTargets','Full_Subgroups'};
P.Repo={D.RetiredHurtAudit,D.ProjectionConvergence,D.ReferenceCertification,D.CompactDiagnostics,D.FlexibleDiagnostics,D.ContextPreprocessing,D.DevelopmentScores,D.SensitivityTargets,D.Subgroups};
end

function T=performanceTable(D)
P=D.FrozenPerformance; B=D.Bootstrap95CI(string(D.Bootstrap95CI.Metric)=="EqualInningsRMSE",{'Format','Role','Lower95','Upper95','BootstrapReplicates'});
T=outerjoin(P,B,'Keys',{'Format','Role'},'MergeKeys',true,'Type','left');
T.Role=human(T.Role); T=movevars(T,{'Lower95','Upper95','BootstrapReplicates'},'After','EqualInningsRMSE');
end
function s=human(x)
s=string(x); s=replace(s,"PrimaryResource","Frozen resource model"); s=replace(s,"PrimaryForecast","Frozen context model"); s=replace(s,"FlexibleComparator","Shape-constrained flexible model"); s=replace(s,"LiveScoreComparator","Recent-score context model"); s=replace(s,"Baseline","Linear-balls baseline");
end
function T=summaryCount(Tin,groups,id)
[G,T]=findgroups(Tin(:,groups));
T.Rows=splitapply(@numel,Tin.(id),G);
end
function T=withFormat(T)
if ~ismember('Format',T.Properties.VariableNames), T.Format=repmat("",height(T),1); p=string(T.PackageID); T.Format(contains(p,'ODI'))="ODI"; T.Format(contains(p,'T20'))="T20"; end
end
function T=numericSummary(Tin,groups,vars)
vars=vars(ismember(vars,Tin.Properties.VariableNames)); [G,T]=findgroups(Tin(:,groups));
for i=1:numel(vars)
    name=vars{i}; x=Tin.(name);
    assert(isnumeric(x)||islogical(x),'Summary variable must be numeric: %s',name);
    T.(['N_' name])=splitapply(@finiteCount,x,G);
    T.(['Min_' name])=splitapply(@finiteMin,x,G);
    T.(['Median_' name])=splitapply(@finiteMedian,x,G);
    T.(['Max_' name])=splitapply(@finiteMax,x,G);
end
end
function T=preprocessingSummary(Tin)
[G,T]=findgroups(Tin(:,{'Format','AblationGroup'}));
vars={'TrainingAvailability','AllTrainingMissing','TrainingConstant'};
for i=1:numel(vars)
    name=vars{i}; x=Tin.(name);
    T.(['N_' name])=splitapply(@finiteCount,x,G);
    T.(['Mean_' name])=splitapply(@finiteMean,x,G);
end
end
function T=targetSummary(Tin)
groups={'Format','Variant','Scenario'}; groups=groups(ismember(groups,Tin.Properties.VariableNames)); [G,T]=findgroups(Tin(:,groups));
vars={'TargetShift','IntegerTargetShift'};
for i=1:numel(vars)
    name=vars{i}; x=Tin.(name);
    T.(['N_' name])=splitapply(@finiteCount,x,G);
    T.(['Mean_' name])=splitapply(@finiteMean,x,G);
    T.(['Min_' name])=splitapply(@finiteMin,x,G);
    T.(['Max_' name])=splitapply(@finiteMax,x,G);
end
end

function y=finiteCount(x)
y=sum(isfinite(double(x)));
end
function y=finiteMean(x)
x=double(x); x=x(isfinite(x));
if isempty(x), y=NaN; else, y=mean(x); end
end
function y=finiteMin(x)
x=double(x); x=x(isfinite(x));
if isempty(x), y=NaN; else, y=min(x); end
end
function y=finiteMedian(x)
x=double(x); x=x(isfinite(x));
if isempty(x), y=NaN; else, y=median(x); end
end
function y=finiteMax(x)
x=double(x); x=x(isfinite(x));
if isempty(x), y=NaN; else, y=max(x); end
end
