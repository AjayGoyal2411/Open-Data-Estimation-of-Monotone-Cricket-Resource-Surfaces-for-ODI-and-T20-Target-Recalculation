function U=RevisedCodes_26_Utils
U.MakeDirs=@makeDirs; U.Write=@writeTable; U.Read=@safeRead;
U.SaveFigure=@saveFigure; U.ZipFolder=@zipFolder; U.Hash=@hashFile;
U.HumanRole=@humanRole; U.Truth=@truthValue; U.CellText=@cellText;
end

function makeDirs(varargin)
for i=1:nargin, if ~isfolder(varargin{i}), mkdir(varargin{i}); end, end
end

function writeTable(T,p,varargin)
assert(istable(T),'Expected table.'); folder=fileparts(p); if ~isfolder(folder), mkdir(folder); end
if endsWith(lower(string(p)),'.xlsx')
    if isempty(varargin), sheet='Sheet1'; else, sheet=varargin{1}; end
    writetable(T,p,'Sheet',sheet,'WriteMode','overwritesheet');
else
    writetable(T,p,'Encoding','UTF-8');
end
end

function T=safeRead(p,varargin)
assert(isfile(p),'Required file missing: %s',p);
if isempty(varargin)
    o=detectImportOptions(p,'VariableNamingRule','preserve');
else
    o=detectImportOptions(p,'Sheet',varargin{1},'VariableNamingRule','preserve');
end
T=readtable(p,o);
end

function row=saveFigure(f,out,name)
name=char(string(name)); png=fullfile(out,[name '.png']); pdf=fullfile(out,[name '.pdf']);
set(f,'Color','w','InvertHardcopy','off');
exportgraphics(f,png,'Resolution',600,'BackgroundColor','white');
exportgraphics(f,pdf,'ContentType','vector','BackgroundColor','white');
row=table(string(name),string(png),string(pdf),'VariableNames',{'FigureID','PNG','PDF'});
end

function zipFolder(folder,zipPath)
base=char(string(folder));
while endsWith(base,filesep), base=base(1:end-1); end
prefix=[base filesep];
d=dir(fullfile(base,'**','*')); d=d(~[d.isdir]); files=cell(numel(d),1);
for i=1:numel(d)
    absolutePath=fullfile(d(i).folder,d(i).name);
    assert(startsWith(lower(absolutePath),lower(prefix)),'ZIP member is outside source folder: %s',absolutePath);
    relativePath=absolutePath(numel(prefix)+1:end);
    assert(strlength(string(relativePath))>0,'Empty ZIP member path for %s',absolutePath);
    files{i}=relativePath;
end
target=char(string(zipPath));
if isfile(target), delete(target); end
zip(target,files,base);
assert(isfile(target),'ZIP creation failed: %s',target);
end

function h=hashFile(p)
assert(isfile(p),'Cannot hash missing file: %s',p);
if ispc
    [status,out]=system(sprintf('certutil -hashfile "%s" SHA256',strrep(p,'"','')));
    tok=regexp(out,'[A-Fa-f0-9]{64}','match','once');
else
    [status,out]=system(sprintf('sha256sum "%s"',strrep(p,'"','')));
    tok=regexp(out,'[A-Fa-f0-9]{64}','match','once');
end
assert(status==0 && ~isempty(tok),'SHA-256 command failed for %s',p); h=lower(string(tok));
end

function s=humanRole(x)
s=string(x); s=replace(s,"PrimaryResource","Frozen resource model");
s=replace(s,"PrimaryForecast","Frozen context model");
s=replace(s,"FlexibleComparator","Shape-constrained flexible model");
s=replace(s,"LiveScoreComparator","Recent-score context model");
s=replace(s,"Baseline","Linear-balls baseline");
end

function tf=truthValue(x)
if islogical(x), tf=all(x(:)); elseif isnumeric(x), tf=all(isfinite(x(:)) & x(:)~=0);
else, tf=all(ismember(lower(strtrim(string(x))),["1","true","yes","pass","passed","complete"])); end
end

function s=cellText(x)
if ismissing(x), s=""; elseif isdatetime(x), s=string(x,'yyyy-MM-dd');
elseif isnumeric(x), s=string(compose('%.6g',x)); elseif islogical(x), s=string(x); else, s=string(x); end
end
