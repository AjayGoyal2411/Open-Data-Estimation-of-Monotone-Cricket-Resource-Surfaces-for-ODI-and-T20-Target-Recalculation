function C=RevisedCodes_26_Config(settings)
if nargin<1, settings=struct; end
here=fileparts(mfilename('fullpath'));
C.CodeRoot=here;
C.ProjectRoot=pick(settings,'ProjectRoot',inferProjectRoot(here));
C.Step25Root=pick(settings,'Step25Root',"");
C.OutputBase=pick(settings,'OutputRoot',fullfile(C.ProjectRoot,'paper_outputs_revisedcodes','step26_publication_artifacts'));
C.GenerateWord=logical(pick(settings,'GenerateWord',true));
C.Generation=['generation_' datestr(now,'yyyymmdd_HHMMSS_FFF')];
C.OutputRoot=fullfile(C.OutputBase,C.Generation);
C.MainDir=fullfile(C.OutputRoot,'MainPaper');
C.MainFigures=fullfile(C.MainDir,'Figures');
C.MainTables=fullfile(C.MainDir,'Tables');
C.SuppDir=fullfile(C.OutputRoot,'Supplementary');
C.SuppFigures=fullfile(C.SuppDir,'Figures');
C.SuppTables=fullfile(C.SuppDir,'Tables');
C.RepositoryOnly=fullfile(C.OutputRoot,'RepositoryOnly');
C.Checks=fullfile(C.OutputRoot,'Checks');
C.Work=fullfile(C.OutputRoot,'Work');
C.PackageZip=fullfile(C.OutputBase,[C.Generation '_Step26_PublicationArtifacts.zip']);
C.ChecksZip=fullfile(C.OutputBase,[C.Generation '_Checks.zip']);
C.Font='Arial'; C.FontSize=10; C.AxisFontSize=9; C.LineWidth=1.35;
C.Colors=struct('Blue',[0.000 0.447 0.741],'Orange',[0.850 0.325 0.098], ...
    'Yellow',[0.929 0.694 0.125],'Purple',[0.494 0.184 0.556], ...
    'Green',[0.220 0.557 0.286],'Red',[0.750 0.220 0.220],'Grey',[0.45 0.45 0.45]);
end

function v=pick(s,n,d)
if isfield(s,n) && ~isempty(s.(n)), v=s.(n); else, v=d; end
end

function root=inferProjectRoot(here)
root=""; p=string(here);
for i=1:8
    if isfolder(fullfile(p,'paper_outputs_revisedcodes')), root=p; return; end
    q=string(fileparts(p)); if q==p, break; end; p=q;
end
if ispc && isfolder('D:\VihaanProject1'), root="D:\VihaanProject1"; else, root=string(fileparts(here)); end
end

