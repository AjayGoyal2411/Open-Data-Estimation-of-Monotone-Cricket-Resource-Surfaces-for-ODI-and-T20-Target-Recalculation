function B=RevisedCodes_23_RepositoryBundle(C,report,here,U)
root=fullfile(report,'repository_bundle');code=fullfile(root,'code','step23');s22=fullfile(root,'data','step22');s23=fullfile(root,'data','step23');docs=fullfile(root,'documentation');
for p=string({root,code,s22,s23,docs}),if ~isfolder(p),mkdir(p);end,end
files=dir(fullfile(here,'*'));for i=1:numel(files)
 [~,~,ext]=fileparts(files(i).name);
 if ~files(i).isdir&&ismember(string(ext),[".m",".csv",".md"]),copyfile(fullfile(files(i).folder,files(i).name),fullfile(code,files(i).name));end
end
keep22=["Step22_TestPopulation.csv","Step22_PerformanceSummary.csv","Step22_PerformanceBootstrap95CI.csv","Step22_PairedComparisons.csv", ...
 "Step22_MatchErrors.csv","Step22_Subgroups.csv","Step22_Calibration.csv","Step22_MatchInfluence.csv","Step22_RealMatchExamples.csv", ...
 "Step22_HistoryCoverage.csv","Step22_UncertaintyScope.csv","Step22_StateArtifactHashes.csv","Step22_ExecutionGates.csv"];
for n=keep22,src=fullfile(C.Step22Checks,n);if isfile(src),copyfile(src,fullfile(s22,n));end,end
files=dir(fullfile(report,'Step23_*.csv'));for i=1:numel(files),copyfile(fullfile(files(i).folder,files(i).name),fullfile(s23,files(i).name));end
readme=fullfile(docs,'README.txt');f=fopen(readme,'wt');assert(f>=0);c=onCleanup(@()fclose(f));
fprintf(f,'Computational closure repository bundle\n\n');
fprintf(f,'This bundle contains executable Step23 MATLAB code, complete derived Step22 result tables, and Step23 derived evidence tables.\n');
fprintf(f,'Run RUN_Step23_ComputationalClosure.m from the project root environment after the frozen Steps 1-22 dependencies are present.\n');
fprintf(f,'Raw Cricsheet redistribution and any third-party operational target evidence must follow their original licences and provenance records.\n');
fprintf(f,'Modern professional DLS is not implemented because public sources do not disclose the required functional forms and fitted values.\n');clear c
all=dir(fullfile(root,'**','*'));all=all(~[all.isdir]);paths=string(fullfile({all.folder},{all.name}))';Manifest=U.Hashes(paths,U);Manifest.RelativePath=erase(Manifest.Path,string(root)+filesep);Manifest=movevars(Manifest,'RelativePath','Before','Path');
U.Write(Manifest,fullfile(root,'MANIFEST_SHA256.csv'));zipPath=string(report)+"_RepositoryBundle.zip";zip(zipPath,{'*'},root);
B=struct('Root',string(root),'Zip',zipPath,'Manifest',Manifest);
end
