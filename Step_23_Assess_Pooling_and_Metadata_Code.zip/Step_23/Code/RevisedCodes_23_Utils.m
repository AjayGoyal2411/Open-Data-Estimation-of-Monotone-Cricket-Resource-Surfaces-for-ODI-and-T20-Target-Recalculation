function U=RevisedCodes_23_Utils
U.Hash=@hashFile;U.Hashes=@hashes;U.Write=@writeCSV;U.Require=@requireColumns;
U.Pct=@percentile;U.Figure=@saveFigure;U.Nonblank=@nonblank;U.Read=@readChecked;
end
function h=hashFile(p)
f=fopen(p,'rb');assert(f>=0,'Cannot hash %s',p);c=onCleanup(@()fclose(f));md=java.security.MessageDigest.getInstance('SHA-256');
while ~feof(f),b=fread(f,1048576,'*uint8');md.update(typecast(b,'int8'));end
h=lower(string(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[])));clear c
end
function T=hashes(paths,U)
if nargin<2,U=RevisedCodes_23_Utils;end;paths=unique(string(paths(:)),'stable');sha=strings(numel(paths),1);
for i=1:numel(paths),assert(isfile(paths(i)),'Missing artifact: %s',paths(i));sha(i)=U.Hash(paths(i));end
T=table(paths,sha,'VariableNames',{'Path','SHA256'});
end
function writeCSV(T,path),assert(istable(T));writetable(T,path);end
function requireColumns(T,names),m=setdiff(string(names),string(T.Properties.VariableNames));assert(isempty(m),'Missing columns: %s',strjoin(m,', '));end
function q=percentile(x,p)
x=sort(double(x(isfinite(x))));assert(~isempty(x));if numel(x)==1,q=x;return;end
t=1+(numel(x)-1)*p/100;lo=floor(t);hi=ceil(t);q=x(lo)+(t-lo)*(x(hi)-x(lo));
end
function tf=nonblank(x),s=strtrim(string(x));tf=~ismissing(s)&strlength(s)>0;end
function T=readChecked(path,cols,U),assert(isfile(path),'Missing input: %s',path);T=readtable(path,'TextType','string');U.Require(T,cols);end
function T=saveFigure(fig,out,name)
set(findall(fig,'Type','axes'),'TickLabelInterpreter','none');name=string(name);
png=string(fullfile(out,char(name+".png")));pdf=string(fullfile(out,char(name+".pdf")));figp=string(fullfile(out,char(name+".fig")));
exportgraphics(fig,char(png),'Resolution',600);exportgraphics(fig,char(pdf),'ContentType','vector');savefig(fig,char(figp));close(fig);
T=table(name,png,pdf,figp,'VariableNames',{'Figure','PNG','PDF','FIG'});
end

