function [Register,Examples]=RevisedCodes_23_ComparatorAudit(here)
V=RevisedCodes_23_VJD(fullfile(here,'VJD_Table5_2002.csv'));
Method=["Frozen proposed models";"Historical VJD 2002";"Historical published D/L table";"Modern professional DLS";"McHale-Asif modified D/L (DLMA)"];
Enabled=[true;true;false;false;false];
Scope=["Frozen ODI and T20 prediction and verified-case interfaces";V.Scope;"Only if the precise edition and table are supplied"; ...
 "Not reproducible from public coefficients";"Equation is public, but source-certified fitted parameters and reproduction tests are absent"];
Source=["Frozen Step19 manifest";V.Source;"Historical edition-specific table";"Duckworth-Lewis/Stern professional implementation"; ...
 "McHale and Asif, European Journal of Operational Research 225 (2013) 353-362"];
Reason=["Enabled only through frozen interface";"Complete published Table 5 transcribed and tested";"Do not merge editions or call historical output modern DLS"; ...
 "Functional forms and fitted values were not disclosed for commercial-confidentiality reasons";"No unverified coefficient transcription or refit is labelled as the published comparator"];
Register=table(Method,Enabled,Scope,Source,Reason);
Scenario=["Between innings 40 of 50 overs";"Stopped at 30 of 50 overs with six wickets lost";"Half of remaining spell available"];
Lookup=[V.Lookup(80,0,"target");V.Lookup(60,6,"normal");V.Lookup(50,0,"target")];Expected=[87.6;70.0;63.4];
Meaning=["Target percentage";"Completed-innings normal percentage";"Target percentage for shortened remaining spell"];
Examples=table(Scenario,Lookup,Expected,Lookup==Expected,Meaning);
Examples.Properties.VariableNames={'Scenario','Lookup','Expected','LookupMatchesPublishedExample','Meaning'};
assert(all(Examples.LookupMatchesPublishedExample),'VJD worked example failed.');
end
