function [found,Gender,source]=RevisedCodes_23_LoadCheckpoint(base,U)
% Reuse completed expensive analyses after a downstream reporting failure.
% A complete MAT checkpoint is preferred. Otherwise reconstruct it from a
% prior failed report only when every required CSV is present.
found=false;Gender=struct;source="";
checkpoint=fullfile(base,'Step23_Intermediate.mat');
if isfile(checkpoint)
 z=load(checkpoint,'Gender');
 if isfield(z,'Gender')
  Gender=z.Gender;found=valid(Gender);source=string(checkpoint);
  if found,return;end
 end
end
d=dir(base);d=d([d.isdir]);d=d(~ismember(string({d.name}),[".",".."])) ;
[~,ord]=sort([d.datenum],'descend');d=d(ord);
required=["Step23_GenderInnings.csv","Step23_GenderSummary.csv","Step23_GenderEquivalence.csv", ...
 "Step23_GenderSurfaceComparison.csv","Step23_GenderCommonCells.csv","Step23_GenderPoolingGate.csv"];
for k=1:numel(d)
 folder=string(fullfile(d(k).folder,d(k).name));if ~all(isfile(fullfile(folder,required))),continue;end
 Gender=struct('Innings',readtable(fullfile(folder,required(1)),'TextType','string'), ...
  'Summary',readtable(fullfile(folder,required(2)),'TextType','string'), ...
  'Equivalence',readtable(fullfile(folder,required(3)),'TextType','string'), ...
  'Surface',readtable(fullfile(folder,required(4)),'TextType','string'), ...
  'SurfaceCells',readtable(fullfile(folder,required(5)),'TextType','string'), ...
  'Gate',readtable(fullfile(folder,required(6)),'TextType','string'));
  normalize();
 if valid(Gender),found=true;source=folder;save(checkpoint,'Gender','source','-v7.3');return;end
end

 function normalize
  Gender.Gate.Format=string(Gender.Gate.Format);
  for n=["OutcomeEquivalence","SurfaceWithinMargin","PoolingSupported"]
   Gender.Gate.(n)=toLogical(Gender.Gate.(n));
  end
  Gender.Equivalence.Format=string(Gender.Equivalence.Format);Gender.Equivalence.Metric=string(Gender.Equivalence.Metric);
  Gender.Equivalence.Equivalent=toLogical(Gender.Equivalence.Equivalent);
  Gender.Surface.Format=string(Gender.Surface.Format);Gender.Surface.WithinMargin=toLogical(Gender.Surface.WithinMargin);
 end
end
function tf=valid(G)
tf=isfield(G,'Gate')&&height(G.Gate)==2&&all(ismember(["ODI","T20"],string(G.Gate.Format)))&& ...
 isfield(G,'Innings')&&height(G.Innings)>0&&isfield(G,'SurfaceCells')&&height(G.SurfaceCells)>0;
end
function x=toLogical(v)
if islogical(v),x=v;return;end
if isnumeric(v),x=v~=0;return;end
s=lower(strtrim(string(v)));assert(all(ismember(s,["true","false","1","0"])),'Invalid logical value in checkpoint.');x=ismember(s,["true","1"]);
end
