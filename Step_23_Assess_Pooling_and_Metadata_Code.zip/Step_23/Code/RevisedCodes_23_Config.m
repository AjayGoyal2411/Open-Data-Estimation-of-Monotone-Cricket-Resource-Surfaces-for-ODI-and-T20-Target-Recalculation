function C=RevisedCodes_23_Config(settings)
if nargin<1,settings=struct;end
assert(isstruct(settings)&&isscalar(settings),'settings must be a scalar struct.');
allowed=["ProjectRoot","BootstrapReplicates","RandomSeed","EquivalenceSDMargin","SurfaceNRMSEMargin", ...
 "MinCommonCellStates","FigureVisible","Step22Checks"];
assert(all(ismember(string(fieldnames(settings)),allowed)),'Unknown Step23 setting.');
C.ProjectRoot="D:\VihaanProject1";C.BootstrapReplicates=5000;C.RandomSeed=20260923;
C.EquivalenceSDMargin=0.20;C.SurfaceNRMSEMargin=0.20;C.MinCommonCellStates=30;
C.FigureVisible=false;C.Step22Checks="";
for n=reshape(string(fieldnames(settings)),1,[]),C.(n)=settings.(n);end
C.ProjectRoot=string(C.ProjectRoot);C.Step22Checks=string(C.Step22Checks);
assert(isfolder(C.ProjectRoot),'ProjectRoot not found: %s',C.ProjectRoot);
assert(C.BootstrapReplicates>=1000&&fix(C.BootstrapReplicates)==C.BootstrapReplicates);
assert(C.EquivalenceSDMargin>0&&C.EquivalenceSDMargin<=0.5);
assert(C.SurfaceNRMSEMargin>0&&C.SurfaceNRMSEMargin<=0.5);
assert(C.MinCommonCellStates>=5&&fix(C.MinCommonCellStates)==C.MinCommonCellStates);
assert(islogical(C.FigureVisible)&&isscalar(C.FigureVisible));
if C.Step22Checks==""
 base=fullfile(C.ProjectRoot,'paper_outputs_revisedcodes','step22_final');
 d=dir(fullfile(base,'*_Checks'));d=d([d.isdir]);
 if numel(d)==1,C.Step22Checks=string(fullfile(d.folder,d.name));
 elseif isfile(fullfile(base,'RevisedCodes_22_Result.mat'))
  z=load(fullfile(base,'RevisedCodes_22_Result.mat'),'Results');C.Step22Checks=string(z.Results.ReportPath);
 end
end
assert(isfolder(C.Step22Checks),'Step22 checks folder not found. Set Step22Checks explicitly.');
end

