function V=RevisedCodes_23_VJD(tablePath)
if nargin<1,tablePath=fullfile(fileparts(mfilename('fullpath')),'VJD_Table5_2002.csv');end
T=readtable(tablePath,'TextType','string');
req=["OversPercent","TargetPercent","Wickets0","Wickets1","Wickets2","Wickets3","Wickets4","Wickets5","Wickets6","Wickets7","Wickets8","Wickets9"];
assert(all(ismember(req,string(T.Properties.VariableNames))),'VJD table schema changed.');
assert(height(T)==100&&isequal(double(T.OversPercent),(1:100)'),'VJD Table 5 must contain exact integer percentages 1 to 100.');
X=double(T{:,2:end});assert(all(isfinite(X),'all')&&all(X>=0&X<=100,'all'),'Invalid VJD percentage.');
assert(all(diff(X)>=-1e-12,'all'),'VJD columns must be nondecreasing in overs percentage.');
V.Table=T;V.Lookup=@lookup;V.Source="V. Jayadevan, Current Science 83(5), 2002, 577-586";
V.SourceURL="https://jayadevan.yolasite.com/resources/Firstarticle.pdf";
V.Scope="Published 50-over Table 5 at integer percentage points only";
 function y=lookup(percent,wicketsLost,kind)
  validateattributes(percent,{'numeric'},{'scalar','integer','>=',1,'<=',100});
  validateattributes(wicketsLost,{'numeric'},{'scalar','integer','>=',0,'<=',9});kind=lower(string(kind));
  r=find(T.OversPercent==percent);assert(isscalar(r));
  if kind=="target",y=double(T.TargetPercent(r));
  elseif kind=="normal",y=double(T.("Wickets"+string(wicketsLost))(r));
  else,error('kind must be target or normal.');end
 end
end
