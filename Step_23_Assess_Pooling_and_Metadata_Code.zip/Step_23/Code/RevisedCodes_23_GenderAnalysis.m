function G=RevisedCodes_23_GenderAnalysis(I,C,U)
% Corrected analysis: one row per innings for equivalence; canonical legal
% pre-delivery states only for surfaces. No legacy initial, terminal, or
% illegal-delivery rows enter either calculation.
V=RevisedCodes_17_19_Utils;W=RevisedCodes_12_ContextUtils;p=I.Step17.Cache.Path;assert(isfile(p),'Step17 cache missing.');z=load(p,'M');M=z.M;
H=120*ones(height(M),1);H(string(M.Format)=="ODI")=300;
gender=lower(string(M.Gender));gender(ismember(gender,["male","men"]))="men";gender(ismember(gender,["female","women"]))="women";
base=V.Logical(M.CacheEligible)&V.Number(M.InningsIndex)==1&V.Logical(M.ResponseEligible)& ...
 V.Number(M.InitialAllocatedBalls)==H&M.Date<datetime(2023,1,1)&ismember(gender,["men","women"]);
assert(any(base&gender=="men")&&any(base&gender=="women"),'Both gender cohorts are required.');
legalBalls=zeros(height(M),1);finalRuns=nan(height(M),1);event=repmat("",height(M),1);
formats=["ODI","T20"];genders=["men","women"];
for f=1:2
 h=120;if formats(f)=="ODI",h=300;end
 for g=1:2
  A.(char(formats(f))).(char(genders(g))).N=zeros(h+1,10);
  A.(char(formats(f))).(char(genders(g))).Sum=zeros(h+1,10);
 end
end
for part=1:height(I.States.Partitions)
 qz=load(I.States.Partitions.Path(part),'States');S=qz.States;
 qx=load(I.OriginalContext.Partitions.Path(part),'Features');X=qx.Features;assert(isequal(W.StateKey(S),W.StateKey(X)),'State/context partition mismatch.');
 key=string(S.MatchID)+"|"+string(S.InningsIndex);[ok,j]=ismember(key,string(M.Key));q=ok;q(ok)=base(j(ok));
 q=q&string(S.StateType)=="delivery"&double(S.CorrectedIsLegalBall)==1&double(S.WicketsInHand)>0&double(S.BallsRemaining)>0;
 if any(q)
  jj=j(q);legalBalls=legalBalls+accumarray(jj,1,[height(M),1]);fr=double(S.FinalDeliveryRuns(q));
  [ui,ia]=unique(jj,'stable');old=finalRuns(ui);new=fr(ia);assert(all(isnan(old)|old==new),'Final total changed within innings.');finalRuns(ui)=new;
  ev=string(X.EventName(q));oldEvent=event(ui);newEvent=ev(ia);newEvent(ismissing(newEvent))="";
  assert(all(strlength(oldEvent)==0|oldEvent==newEvent),'Event label changed within innings.');event(ui)=newEvent;
  rem=fr-double(S.DeliveryScoreBefore(q));u=double(S.BallsRemaining(q));w=double(S.WicketsInHand(q));
  sf=string(S.Format(q));sg=lower(string(S.Gender(q)));sg(ismember(sg,["male","men"]))="men";sg(ismember(sg,["female","women"]))="women";
  for f=1:2,for g=1:2
   take=sf==formats(f)&sg==genders(g);if ~any(take),continue;end
   h=size(A.(char(formats(f))).(char(genders(g))).N,1)-1;
   assert(all(u(take)>=1&u(take)<=h&w(take)>=1&w(take)<=10&rem(take)>=0));
   ix=sub2ind([h+1,10],u(take)+1,w(take));
   tmpn=accumarray(ix,1,[(h+1)*10,1],@sum,0);
   A.(char(formats(f))).(char(genders(g))).N=A.(char(formats(f))).(char(genders(g))).N+reshape(tmpn,h+1,10);
   tmp=accumarray(ix,rem(take),[(h+1)*10,1],@sum,0);
   A.(char(formats(f))).(char(genders(g))).Sum=A.(char(formats(f))).(char(genders(g))).Sum+reshape(tmp,h+1,10);
  end,end
 end
 if mod(part,24)==0,fprintf('Step23 gender extraction %d/%d\n',part,height(I.States.Partitions));end
end
assert(all(legalBalls(base)>0&isfinite(finalRuns(base))),'Eligible innings lacks canonical states.');
T=table(string(M.MatchID),string(M.Format),gender,M.Date,finalRuns,legalBalls,finalRuns./legalBalls,event, ...
 'VariableNames',{'MatchID','Format','Gender','Date','FinalRuns','LegalBalls','RunsPerLegalBall','EventName'});T=T(base,:);
T.CompetitionClass=RevisedCodes_23_CompetitionClass(T.EventName);T.Year=year(T.Date);
Summary=groupsummary(T,{'Format','Gender'},{'mean','std'},{'FinalRuns','RunsPerLegalBall'});
Equivalence=table;for fmt=formats,for metric=["FinalRuns","RunsPerLegalBall"]
 X=T(T.Format==fmt,:);R=equivalence(X,metric,C,U);R.Format=fmt;R.Metric=metric;Equivalence=[Equivalence;R]; %#ok<AGROW>
end,end
Surface=table;SurfaceCells=table;
for fmt=formats
 men=A.(char(fmt)).men;women=A.(char(fmt)).women;common=men.N>=C.MinCommonCellStates&women.N>=C.MinCommonCellStates;
 mm=men.Sum./max(men.N,1);ww=women.Sum./max(women.N,1);pp=(men.Sum+women.Sum)./max(men.N+women.N,1);d=ww-mm;pd=pp-mm;weight=min(men.N,women.N);
 scale=mean(T.FinalRuns(T.Format==fmt));
 if any(common,'all')
  nrmse=sqrt(sum(weight(common).*d(common).^2)/sum(weight(common)))/scale;mx=max(abs(d(common)))/scale;
  pooledNRMSE=sqrt(sum(weight(common).*pd(common).^2)/sum(weight(common)))/scale;
 else,nrmse=NaN;mx=NaN;pooledNRMSE=NaN;end
 Surface=[Surface;table(fmt,nnz(common),sum(men.N(common)),sum(women.N(common)),scale,nrmse,pooledNRMSE,mx,pooledNRMSE<=C.SurfaceNRMSEMargin, ...
  'VariableNames',{'Format','CommonCells','MenStatesInCommonCells','WomenStatesInCommonCells','PooledMeanFinalRuns','WomenVersusMenWeightedNRMSE','PooledVersusMenWeightedNRMSE','MaximumNormalizedDifference','WithinMargin'})]; %#ok<AGROW>
 [uu,w]=find(common);if ~isempty(uu)
  SurfaceCells=[SurfaceCells;table(repmat(fmt,numel(uu),1),uu-1,w,men.N(common),women.N(common),mm(common),ww(common),pp(common),d(common),pd(common), ...
   'VariableNames',{'Format','BallsRemaining','WicketsInHand','MenStates','WomenStates','MenMeanRemainingRuns','WomenMeanRemainingRuns','PooledMeanRemainingRuns','WomenMinusMen','PooledMinusMen'})]; %#ok<AGROW>
 end
end
Gate=table(formats',false(2,1),false(2,1),false(2,1),'VariableNames',{'Format','OutcomeEquivalence','SurfaceWithinMargin','PoolingSupported'});
for i=1:2
 fmt=formats(i);Gate.OutcomeEquivalence(i)=all(Equivalence.Equivalent(Equivalence.Format==fmt));
 Gate.SurfaceWithinMargin(i)=Surface.WithinMargin(Surface.Format==fmt);Gate.PoolingSupported(i)=Gate.OutcomeEquivalence(i)&Gate.SurfaceWithinMargin(i);
end
G=struct('Innings',T,'Summary',Summary,'Equivalence',Equivalence,'Surface',Surface,'SurfaceCells',SurfaceCells,'Gate',Gate);
end

function R=equivalence(T,metric,C,U)
y=double(T.(metric));female=T.Gender=="women";classes=unique(T.CompetitionClass,'sorted');yr=T.Year-mean(T.Year);
X=[ones(height(T),1),double(female),yr];
for k=2:numel(classes),X=[X,double(T.CompetitionClass==classes(k))];end %#ok<AGROW>
b=X\y;res=y-X*b;withinMenSD=std(res(~female),1);margin=C.EquivalenceSDMargin*withinMenSD;
stream=RandStream('mt19937ar','Seed',C.RandomSeed+sum(double(char(metric))));boot=zeros(C.BootstrapReplicates,1);
im=find(~female);iw=find(female);
for r=1:numel(boot)
 ix=[im(randi(stream,numel(im),numel(im),1));iw(randi(stream,numel(iw),numel(iw),1))];
 XX=X(ix,:);yy=y(ix);bb=pinv(XX)*yy;boot(r)=bb(2);
end
lo=U.Pct(boot,2.5);hi=U.Pct(boot,97.5);equiv=lo>-margin&&hi<margin;
R=table(nnz(~female),nnz(female),mean(y(~female)),mean(y(female)),b(2),lo,hi,withinMenSD,margin,equiv, ...
 'VariableNames',{'MenInnings','WomenInnings','MenMean','WomenMean','AdjustedWomenMinusMen','Lower95','Upper95','WithinMenResidualSD','EquivalenceMargin','Equivalent'});
end
