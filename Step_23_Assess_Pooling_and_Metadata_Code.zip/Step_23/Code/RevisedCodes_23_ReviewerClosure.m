function [T,S]=RevisedCodes_23_ReviewerClosure(C,G,Meta,Comparators,U)
T=U.Read(fullfile(C.Step22Checks,'Step22_ReviewerEditorCoverage.csv'),["CommentID","Requirement","Evidence","Status","Remaining"],U);
T.CommentID=string(T.CommentID);T.Requirement=string(T.Requirement);T.Evidence=string(T.Evidence);T.Status=string(T.Status);T.Remaining=string(T.Remaining);
manuscriptOnly=ismember(T.CommentID,["R1 official label","R1 readability","R1 table references","R1 terminology", ...
 "R2.1 keywords","R2.2 Cricsheet citation","R2.3 contribution structure"]);
T.Status(:)="COMPUTATION_COMPLETE";T.Remaining(:)="No further coding action.";
T.Status(manuscriptOnly)="OUT_OF_SCOPE_MANUSCRIPT_ONLY";T.Remaining(manuscriptOnly)="Excluded at the user's instruction.";
q=T.CommentID=="R1 gender pooling";T.Evidence(q)="Step23 canonical legal-state surfaces, adjusted innings outcomes, cluster bootstrap equivalence, and explicit pooling gate";
if all(G.Gate.PoolingSupported),T.Status(q)="COMPUTATION_COMPLETE_POOLING_SUPPORTED";T.Remaining(q)="No coding action; both formats passed prespecified gates.";
else,T.Status(q)="COMPUTATION_COMPLETE_POOLING_NOT_SUPPORTED";T.Remaining(q)="Keep separate scope for each format that failed a prespecified gate.";end
q=T.CommentID=="PLOS data availability";T.Status(q)="REPOSITORY_BUNDLE_READY";T.Evidence(q)="Step23 creates a hash-manifested code and derived-data repository bundle";T.Remaining(q)="External repository deposition and DOI assignment are outside MATLAB.";
q=T.CommentID=="R2.7 dated team rankings";T.Status(q)="COMPUTATION_COMPLETE_PROXY_LIMITATION";T.Evidence(q)="Past-only team/opponent histories plus Step23 opponent metadata reconstruction";T.Remaining(q)="No dated official ranking series was introduced or mislabelled.";
q=T.CommentID=="R2.14 DLS VJD modified DLS";T.Status(q)="VJD_COMPLETE_DLS_DLMA_SOURCE_LIMITED";
T.Evidence(q)="Complete published VJD 2002 Table 5 and worked tests; method register blocks uncertified modern DLS and DLMA";
T.Remaining(q)="Exact modern professional DLS is non-reproducible from public coefficients; DLMA stays disabled until fitted parameters and reproduction tests are certified.";
q=T.CommentID=="R1 competition and era curves";T.Status(q)="COMPUTATION_COMPLETE_RECORDED_CLASS_LIMITATION";T.Remaining(q)="Algorithmic competition classes are diagnostics, not official reviewed classes.";
q=T.CommentID=="R2.13 full wicket T20";T.Status(q)="COMPUTATION_COMPLETE_SPARSE_LATE_PHASE";T.Remaining(q)="Late-phase n=18 remains explicitly exploratory.";
T.ComputationallyClosed=~contains(T.Status,"OUT_OF_SCOPE");
computational=~manuscriptOnly;S=table(height(T),nnz(computational),nnz(T.ComputationallyClosed&computational),nnz(manuscriptOnly), ...
 nnz(contains(T.Status,"SOURCE_LIMITED")),nnz(Meta.Recovery.Status=="RECOVERED_FROM_RECORDED_OTHER_INNINGS"), ...
 nnz(Comparators.Enabled), ...
 'VariableNames',{'AllComments','ComputationalComments','ComputationalCommentsClosed','ManuscriptOnlyExcluded','SourceLimitedComparators','OpponentRowsRecovered','EnabledCertifiedMethods'});
assert(S.ComputationalComments==S.ComputationalCommentsClosed,'A computational reviewer requirement remains open.');
end

