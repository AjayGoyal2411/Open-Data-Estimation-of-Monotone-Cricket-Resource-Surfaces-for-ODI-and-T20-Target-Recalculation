function R=RevisedCodes_23_MetadataRepair(I,C,U)
M=U.Read(fullfile(C.Step22Checks,'Step22_MatchErrors.csv'),["MatchID","Format","Role","BattingTeam","Opponent","MSE"],U);
M.MatchID=string(M.MatchID);M.BattingTeam=string(M.BattingTeam);M.Opponent=string(M.Opponent);M.Format=string(M.Format);M.Role=string(M.Role);
M.Opponent(ismissing(M.Opponent))="";M.BattingTeam(ismissing(M.BattingTeam))="";
one=unique(M(:,{'MatchID','Format','BattingTeam','Opponent'}),'rows','stable');
assert(numel(unique(one.MatchID))==height(one),'Step22 match metadata is inconsistent across model roles.');
missing=~U.Nonblank(one.Opponent);target=unique(one.MatchID);
teams=table(strings(0,1),strings(0,1),'VariableNames',{'MatchID','Team'});
W=RevisedCodes_12_ContextUtils;
for part=1:height(I.OriginalContext.Partitions)
 z=load(I.OriginalContext.Partitions.Path(part),'Features');X=z.Features;
 ids=string(X.MatchID);q=ismember(ids,target)&U.Nonblank(X.BattingTeam);if ~any(q),continue;end
 teams=[teams;table(ids(q),string(X.BattingTeam(q)),'VariableNames',{'MatchID','Team'})]; %#ok<AGROW>
 if mod(part,24)==0,fprintf('Step23 opponent recovery %d/%d\n',part,height(I.OriginalContext.Partitions));end
end
teams=unique(teams,'rows','stable');Recovery=table;
for i=1:height(one)
 id=one.MatchID(i);tt=unique(teams.Team(teams.MatchID==id&U.Nonblank(teams.Team)),'stable');derived="";
 if numel(tt)==2
  other=tt(tt~=one.BattingTeam(i));if isscalar(other),derived=other;end
 end
 currentValid=U.Nonblank(one.Opponent(i));agree=currentValid&&U.Nonblank(derived)&&one.Opponent(i)==derived;
 status="NOT_RECOVERABLE";
 if currentValid&&agree,status="VALIDATED_AGAINST_TWO_TEAM_SOURCE";
 elseif currentValid&&U.Nonblank(derived),status="CONFLICT";
 elseif currentValid,status="NO_SECOND_TEAM_AVAILABLE";
 elseif U.Nonblank(derived),status="RECOVERED_FROM_RECORDED_OTHER_INNINGS";end
 Recovery=[Recovery;table(id,one.Format(i),one.BattingTeam(i),one.Opponent(i),strjoin(tt," | "),derived,status, ...
  'VariableNames',{'MatchID','Format','BattingTeam','OriginalOpponent','RecordedBattingTeams','RecoveredOpponent','Status'})]; %#ok<AGROW>
end
assert(numel(unique(Recovery.MatchID))==height(Recovery),'Opponent recovery contains repeated matches.');
v=Recovery.Status=="VALIDATED_AGAINST_TWO_TEAM_SOURCE"|Recovery.Status=="CONFLICT";
Validation=table(nnz(v),nnz(Recovery.Status=="VALIDATED_AGAINST_TWO_TEAM_SOURCE"),nnz(Recovery.Status=="CONFLICT"), ...
 nnz(Recovery.Status=="RECOVERED_FROM_RECORDED_OTHER_INNINGS"),nnz(missing), ...
 'VariableNames',{'PopulatedRowsChecked','PopulatedRowsAgreed','Conflicts','MissingRowsRecovered','OriginalMissingRows'});
assert(Validation.MissingRowsRecovered+nnz(Recovery.Status=="NOT_RECOVERABLE")==Validation.OriginalMissingRows, ...
 'Missing-opponent disposition does not reconcile.');
assert(Validation.MissingRowsRecovered==Validation.OriginalMissingRows&&~any(Recovery.Status=="NOT_RECOVERABLE"), ...
 'At least one missing opponent could not be reconstructed.');
Validation.PopulatedRowsWithoutTwoTeamSource=nnz(~missing)-Validation.PopulatedRowsChecked;
Validation.MissingRecoveryComplete=Validation.MissingRowsRecovered==Validation.OriginalMissingRows&&~any(Recovery.Status=="NOT_RECOVERABLE");
affected=Recovery.MatchID(Recovery.Status=="RECOVERED_FROM_RECORDED_OTHER_INNINGS");Sensitivity=table;
for fmt=unique(M.Format)',for role=unique(M.Role(M.Format==fmt))'
 q=M.Format==fmt&M.Role==role;allM=M(q,:);keep=~ismember(allM.MatchID,affected);
 Sensitivity=[Sensitivity;table(fmt,role,height(allM),nnz(keep),sqrt(mean(double(allM.MSE))),sqrt(mean(double(allM.MSE(keep)))), ...
  sqrt(mean(double(allM.MSE(keep))))-sqrt(mean(double(allM.MSE))), ...
  'VariableNames',{'Format','Role','AllMatches','MatchesAfterExclusion','AllRMSE','RMSEAfterExcludingRecoveredMetadata','Difference'})]; %#ok<AGROW>
end,end
R=struct('Recovery',Recovery,'Validation',Validation,'Sensitivity',Sensitivity);
end
