function T=RevisedCodes_23_SelfTests(here)
if nargin<1,here=fileparts(mfilename('fullpath'));end
Check=["VJD 80 percent target";"VJD 60 percent six wickets";"VJD 50 percent target"; ...
 "VJD full innings";"VJD rejects fractional percentage";"Competition class bilateral"; ...
 "Competition class tournament";"Competition class domestic";"SHA deterministic";"Safe blank test"];
Passed=false(size(Check));
V=RevisedCodes_23_VJD(fullfile(here,'VJD_Table5_2002.csv'));
Passed(1)=V.Lookup(80,0,"target")==87.6;Passed(2)=V.Lookup(60,6,"normal")==70.0;
Passed(3)=V.Lookup(50,0,"target")==63.4;Passed(4)=V.Lookup(100,9,"normal")==100;
try,V.Lookup(60.5,2,"normal");catch,Passed(5)=true;end
Passed(6)=RevisedCodes_23_CompetitionClass("India tour of England")=="BILATERAL_TOUR_SERIES";
Passed(7)=RevisedCodes_23_CompetitionClass("ICC Men's Cricket World Cup")=="INTERNATIONAL_TOURNAMENT_QUALIFIER";
Passed(8)=RevisedCodes_23_CompetitionClass("Indian Premier League")=="DOMESTIC_FRANCHISE_LEAGUE";
p=string(tempname);f=fopen(p,'wb');fwrite(f,uint8('step23'));fclose(f);c=onCleanup(@()delete(p));U=RevisedCodes_23_Utils;Passed(9)=U.Hash(p)==U.Hash(p);clear c
Passed(10)=~U.Nonblank(" ")&&U.Nonblank("x");T=table(Check,Passed);assert(all(Passed),'Step23 self-test failed.');
end

