function c=RevisedCodes_23_CompetitionClass(event)
s=lower(strtrim(string(event)));c=repmat("OTHER_RECORDED_EVENT",size(s));blank=ismissing(s)|strlength(s)==0;c(blank)="MISSING";
intl=contains(s,["world cup","champions trophy","asia cup","qualifier","qualification","commonwealth games","icc "]);
tour=contains(s,[" tour of "," in "])|contains(s,["bilateral","tri-series","tri series"]);
dom=contains(s,["premier league","super league","big bash","blast","hundred","super smash","cpl","bpl","psl","ipl","wpl","wbbl","vitality"]);
c(intl)="INTERNATIONAL_TOURNAMENT_QUALIFIER";c(tour&~intl)="BILATERAL_TOUR_SERIES";c(dom&~intl)="DOMESTIC_FRANCHISE_LEAGUE";
end
