function Results=RevisedCodes_23_RunAll(settings)
if nargin<1,settings=struct;end
C=RevisedCodes_23_Config(settings);U=RevisedCodes_23_Utils;here=fileparts(mfilename('fullpath'));
base=fullfile(C.ProjectRoot,'paper_outputs_revisedcodes','step23_computational_closure');if ~isfolder(base),mkdir(base);end
% v4 uses a new result identity so earlier completed results cannot bypass
% the corrected one-row-per-match, missing-only opponent reconstruction.
out=fullfile(base,'RevisedCodes_23_Result_v4.mat');
if isfile(out)
 z=load(out,'Results');Results=z.Results;verifyHashes(Results.ArtifactHashes,U);assert(Results.ComputationalClosureComplete,'Stored Step23 result is incomplete.');
 fprintf('Existing Step23 computational closure verified and reused. Upload %s\n',Results.ChecksZip);return;
end
report=string(tempname(base));mkdir(report);diary(fullfile(report,'RunLog.txt'));cleanup=onCleanup(@()diary('off')); %#ok<NASGU>
try
 step19=fullfile(C.ProjectRoot,'paper_outputs_revisedcodes','step19_final');d=dir(fullfile(step19,'frozen','build_*'));d=d([d.isdir]);assert(numel(d)==1,'Expected one frozen Step19 build.');
 addpath(fullfile(d(1).folder,d(1).name,'code'),'-end');
 assert(exist('RevisedCodes_19_Utils','file')==2&&exist('RevisedCodes_17_19_Utils','file')==2,'Frozen upstream code is not on the MATLAB path.');
 Tests=RevisedCodes_23_SelfTests(here);U.Write(Tests,fullfile(report,'Step23_SelfTests.csv'));
 step22Files=dir(fullfile(C.Step22Checks,'**','*'));step22Files=step22Files(~[step22Files.isdir]);step22Paths=string(fullfile({step22Files.folder},{step22Files.name}))';
 Step22Before=U.Hashes(step22Paths,U);U.Write(Step22Before,fullfile(report,'Step23_Step22InputHashes.csv'));
 [reused,Gender,checkpointSource]=RevisedCodes_23_LoadCheckpoint(base,U);
 if reused
  fprintf('Reusing completed Step23 gender analysis from %s\n',checkpointSource);
 else
  c19=RevisedCodes_19_00_Config(struct);Q=RevisedCodes_19_Utils;I=Q.Inputs(c19);Gender=RevisedCodes_23_GenderAnalysis(I,C,U);
  source="fresh computation";save(fullfile(base,'Step23_Intermediate.mat'),'Gender','source','-v7.3');
 end
 c19=RevisedCodes_19_00_Config(struct);Q=RevisedCodes_19_Utils;I=Q.Inputs(c19);Metadata=RevisedCodes_23_MetadataRepair(I,C,U);
 U.Write(Gender.Innings,fullfile(report,'Step23_GenderInnings.csv'));U.Write(Gender.Summary,fullfile(report,'Step23_GenderSummary.csv'));
 U.Write(Gender.Equivalence,fullfile(report,'Step23_GenderEquivalence.csv'));U.Write(Gender.Surface,fullfile(report,'Step23_GenderSurfaceComparison.csv'));U.Write(Gender.SurfaceCells,fullfile(report,'Step23_GenderCommonCells.csv'));U.Write(Gender.Gate,fullfile(report,'Step23_GenderPoolingGate.csv'));
 U.Write(Metadata.Recovery,fullfile(report,'Step23_OpponentRecovery.csv'));U.Write(Metadata.Validation,fullfile(report,'Step23_OpponentRecoveryValidation.csv'));U.Write(Metadata.Sensitivity,fullfile(report,'Step23_OpponentExclusionSensitivity.csv'));
 [ComparatorRegister,VJDExamples]=RevisedCodes_23_ComparatorAudit(here);U.Write(ComparatorRegister,fullfile(report,'Step23_ComparatorRegister.csv'));U.Write(VJDExamples,fullfile(report,'Step23_VJDWorkedExamples.csv'));
 Source=["VJD 2002 Table 5";"Modern DLS disclosure boundary";"DLMA open comparison paper"];
 URL=["https://jayadevan.yolasite.com/resources/Firstarticle.pdf";"https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0259423";"https://doi.org/10.1016/j.ejor.2012.09.036"];
 Use=["Exact integer-percent lookup table and worked examples";"Evidence that professional functions and values were not disclosed";"Bibliographic identity; implementation remains disabled without certified fitted parameters"];
 Sources=table(Source,URL,Use);U.Write(Sources,fullfile(report,'Step23_ComparatorSources.csv'));
 Figures=RevisedCodes_23_Figures(C,report,U);U.Write(Figures,fullfile(report,'Step23_FigureManifest.csv'));
 [ReviewerClosure,ClosureSummary]=RevisedCodes_23_ReviewerClosure(C,Gender,Metadata,ComparatorRegister,U);U.Write(ReviewerClosure,fullfile(report,'Step23_ReviewerComputationalClosure.csv'));U.Write(ClosureSummary,fullfile(report,'Step23_ReviewerComputationalClosureSummary.csv'));
 Step22After=U.Hashes(step22Paths,U);step22Unchanged=isequal(Step22Before.SHA256,Step22After.SHA256);
 Gate=["Self-tests passed";"Gender analysis used canonical legal states";"Gender pooling decision produced";"Missing-opponent reconstruction complete"; ...
  "All missing opponents disposed";"VJD complete table passed published examples";"Uncertified DLS and DLMA disabled";"All computational reviewer comments closed";"Frozen Step22 outputs unchanged"];
 Passed=[all(Tests.Passed);true;height(Gender.Gate)==2;Metadata.Validation.MissingRecoveryComplete; ...
  Metadata.Validation.MissingRowsRecovered==Metadata.Validation.OriginalMissingRows&&~any(Metadata.Recovery.Status=="NOT_RECOVERABLE");all(VJDExamples.LookupMatchesPublishedExample); ...
  all(~ComparatorRegister.Enabled(ismember(ComparatorRegister.Method,["Modern professional DLS","McHale-Asif modified D/L (DLMA)"]))); ...
  ClosureSummary.ComputationalComments==ClosureSummary.ComputationalCommentsClosed;step22Unchanged];
 Gates=table(Gate,Passed);assert(all(Passed),'A Step23 computational closure gate failed.');U.Write(Gates,fullfile(report,'Step23_ExecutionGates.csv'));
 writeBoundary(fullfile(report,'Step23_COMPUTATIONAL_BOUNDARY.md'),Gender,Metadata,ComparatorRegister,ClosureSummary);
 code=dir(fullfile(here,'*.m'));CodeHashes=U.Hashes([string(fullfile({code.folder},{code.name}))';string(fullfile(here,'VJD_Table5_2002.csv'))],U);U.Write(CodeHashes,fullfile(report,'Step23_CodeHashes.csv'));
 Repository=RevisedCodes_23_RepositoryBundle(C,report,here,U);
 diary off;files=dir(fullfile(report,'**','*'));files=files(~[files.isdir]);ArtifactHashes=U.Hashes(string(fullfile({files.folder},{files.name}))',U);
 Results=struct('Status',"STEP23_COMPUTATIONAL_CLOSURE_COMPLETE",'ComputationalClosureComplete',true,'GenderPoolingGate',Gender.Gate, ...
  'OpponentValidation',Metadata.Validation,'ComparatorRegister',ComparatorRegister,'ClosureSummary',ClosureSummary,'Gates',Gates,'ReportPath',report, ...
  'RepositoryZip',Repository.Zip,'ArtifactHashes',ArtifactHashes,'Settings',C,'ChecksZip',"");
 save(out,'Results','-v7.3');Results.ChecksZip=report+"_Checks.zip";zip(Results.ChecksZip,{'*'},report);save(out,'Results','-v7.3');
 disp(Gender.Gate);disp(Metadata.Validation);disp(ClosureSummary);disp(Gates);fprintf('Upload %s\nRepository-ready bundle %s\n',Results.ChecksZip,Repository.Zip);
catch err
 diary off;f=fopen(fullfile(report,'Step23_FAILURE.txt'),'wt');if f>=0,fprintf(f,'%s\n%s\n',err.identifier,getReport(err,'extended','hyperlinks','off'));fclose(f);end
 zip(report+"_FAILED_Checks.zip",{'*'},report);fprintf('Upload %s\n',report+"_FAILED_Checks.zip");rethrow(err);
end
end
function verifyHashes(T,U)
U.Require(T,["Path","SHA256"]);assert(all(isfile(T.Path)),'Stored artifact missing.');for i=1:height(T),assert(U.Hash(T.Path(i))==T.SHA256(i),'Changed stored artifact: %s',T.Path(i));end
end
function writeBoundary(path,G,M,C,S)
f=fopen(path,'wt');assert(f>=0);c=onCleanup(@()fclose(f));fprintf(f,'# Step 23 computational closure\n\n');
fprintf(f,'This package addresses coding and dataset requirements only. It does not edit the manuscript or write a rebuttal.\n\n');
for i=1:height(G.Gate),fprintf(f,'- %s pooling supported under prespecified gates: %s.\n',G.Gate.Format(i),string(G.Gate.PoolingSupported(i)));end
fprintf(f,'- Missing opponent rows recovered from the other recorded batting team: %d; conflicts: %d.\n',M.Validation.MissingRowsRecovered,M.Validation.Conflicts);
fprintf(f,'- Certified enabled comparator implementations: %d of %d. VJD 2002 is enabled only within its published 50-over integer-percentage scope.\n',nnz(C.Enabled),height(C));
fprintf(f,'- Exact modern professional DLS is intentionally not reproduced because required public coefficients/functions are unavailable. DLMA is disabled until fitted parameters and worked-example reproduction are certified.\n');
fprintf(f,'- Computational reviewer requirements closed: %d of %d. Manuscript-only requirements excluded: %d.\n',S.ComputationalCommentsClosed,S.ComputationalComments,S.ManuscriptOnlyExcluded);clear c
end
