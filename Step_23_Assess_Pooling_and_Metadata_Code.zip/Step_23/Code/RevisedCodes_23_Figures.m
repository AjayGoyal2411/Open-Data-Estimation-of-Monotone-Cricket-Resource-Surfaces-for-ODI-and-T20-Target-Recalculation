function Files=RevisedCodes_23_Figures(C,out,U)
vis='off';if C.FigureVisible,vis='on';end;Files=table(strings(0,1),strings(0,1),strings(0,1),strings(0,1),'VariableNames',{'Figure','PNG','PDF','FIG'});
S=U.Read(fullfile(C.Step22Checks,'Step22_Subgroups.csv'),["Format","Role","GroupType","Group","EqualInningsRMSE","EqualInningsBias","Matches"],U);
S.Format=string(S.Format);S.Role=string(S.Role);S.GroupType=string(S.GroupType);S.Group=string(S.Group);
f=figure('Visible',vis,'Color','w','Position',[80 80 1180 760]);t=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');
for fmt=["ODI","T20"],for gt=["Phase","WicketsInHand"]
 nexttile;X=S(S.Format==fmt&S.Role=="PrimaryResource"&S.GroupType==gt,:);
 if gt=="Phase",order=["EARLY","MIDDLE","LATE"];else,order=["8_TO_10","5_TO_7","1_TO_4"];end
 [ok,ix]=ismember(order,X.Group);X=X(ix(ok),:);bar(X.EqualInningsRMSE,'FaceColor',[.20 .50 .72]);grid on;
 xticks(1:height(X));xticklabels(replace(X.Group,'_',' '));ylabel('Equal-innings RMSE (runs)');title(fmt+" primary resource by "+lower(gt));
 yl=ylim;ylim([yl(1),yl(2)*1.18]);for k=1:height(X),text(k,X.EqualInningsRMSE(k),sprintf('n=%d',X.Matches(k)),'HorizontalAlignment','center','VerticalAlignment','bottom','FontSize',8);end
end,end;title(t,'Phase and wicket-state performance');Files=[Files;U.Figure(f,out,"Step23_Figure1_PhaseWicketPerformance")];
f=figure('Visible',vis,'Color','w','Position',[80 80 1180 520]);t=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');
for fmt=["ODI","T20"],nexttile;hold on;yrs=[];for role=["PrimaryResource","PrimaryForecast"]
 X=S(S.Format==fmt&S.Role==role&S.GroupType=="Year",:);[yr,ix]=sort(str2double(X.Group));yrs=[yrs;yr];plot(yr,X.EqualInningsRMSE(ix),'o-','LineWidth',1.5,'DisplayName',replace(role,'_',' '));
end;grid on;xticks(unique(yrs));xlabel('Test year');ylabel('Equal-innings RMSE (runs)');title(fmt+" performance by test year");legend('Location','best');end
title(t,'Frozen-model performance by test year');Files=[Files;U.Figure(f,out,"Step23_Figure2_PerformanceByTestYear")];
f=figure('Visible',vis,'Color','w','Position',[80 80 1150 520]);t=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');
for gt=["T20FullWicketPhase","T20FullWicketYear"],nexttile;X=S(S.Format=="T20"&S.Role=="PrimaryResource"&S.GroupType==gt,:);
 if gt=="T20FullWicketPhase",order=["EARLY","MIDDLE","LATE"];[ok,ix]=ismember(order,X.Group);X=X(ix(ok),:);else,[~,ix]=sort(str2double(X.Group));X=X(ix,:);end
 yyaxis left;bar(X.EqualInningsRMSE,'FaceColor',[.25 .55 .76]);ylabel('RMSE (runs)');yyaxis right;plot(1:height(X),X.EqualInningsBias,'o-','LineWidth',1.4,'Color',[.75 .25 .20]);yline(0,'k:');ylabel('Bias (runs)');grid on;xticks(1:height(X));xticklabels(replace(X.Group,'_',' '));
 title(replace(gt,"T20FullWicket","Full-wicket "));for k=1:height(X),text(k,X.EqualInningsBias(k),sprintf(' n=%d',X.Matches(k)),'HorizontalAlignment','center','VerticalAlignment','bottom','FontSize',8);end
end;title(t,'T20 full-wicket sensitivity with denominators');Files=[Files;U.Figure(f,out,"Step23_Figure3_T20FullWicketSensitivity")];
end
