function Files=RevisedCodes_22_Figures(R,out,C,U)
vis='off';if C.FigureVisible,vis='on';end;Files=table(strings(0,1),strings(0,1),strings(0,1),strings(0,1),'VariableNames',{'Figure','PNG','PDF','FIG'});

f=figure('Visible',vis,'Color','w','Position',[80 80 1180 500]);t=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');
for fmt=["ODI","T20"],nexttile;X=R.Pairs(R.Pairs.Format==fmt&R.Pairs.Comparator=="Baseline",:);y=(1:height(X))';errorbar(X.RMSEGain,y,X.RMSEGain-X.GainLower95,X.GainUpper95-X.RMSEGain,'horizontal','o','LineWidth',1.4,'MarkerFaceColor',[.18 .45 .70]);xline(0,'k--');grid on;yticks(y);yticklabels(replace(X.Role,'_',' '));set(gca,'YDir','reverse');xlabel('RMSE reduction versus linear baseline (runs)');title(fmt+" locked temporal test");end
title(t,'Paired whole-match performance with bootstrap 95% intervals');Files=[Files;U.Figure(f,out,"Step22_Figure1_PairedPerformance")];

f=figure('Visible',vis,'Color','w','Position',[80 80 1100 760]);t=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');
for fmt=["ODI","T20"],for role=["PrimaryResource","PrimaryForecast"],nexttile;X=R.Calibration(R.Calibration.Format==fmt&R.Calibration.Role==role,:);plot(X.MeanPrediction,X.MeanObserved,'o-','LineWidth',1.4,'MarkerFaceColor',[.18 .45 .70]);hold on;z=[min([X.MeanPrediction;X.MeanObserved]),max([X.MeanPrediction;X.MeanObserved])];plot(z,z,'k--');grid on;axis square;xlabel('Mean predicted remaining runs');ylabel('Mean observed remaining runs');title(fmt+" "+replace(role,'_',' '));end,end
title(t,'Temporal-test calibration by prediction decile');Files=[Files;U.Figure(f,out,"Step22_Figure2_Calibration")];

f=figure('Visible',vis,'Color','w','Position',[80 80 1180 760]);t=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');
for fmt=["ODI","T20"],for gt=["Phase","WicketsInHand"],nexttile;X=R.Subgroups(R.Subgroups.Format==fmt&R.Subgroups.Role=="PrimaryResource"&R.Subgroups.GroupType==gt,:);[~,ord]=sort(X.Group);X=X(ord,:);bar(X.EqualInningsRMSE,'FaceColor',[.20 .50 .72]);grid on;xticks(1:height(X));xticklabels(replace(X.Group,'_',' '));ylabel('Equal-innings RMSE (runs)');title(fmt+" primary resource by "+replace(gt,'_',' '));for k=1:height(X),text(k,X.EqualInningsRMSE(k),sprintf(' n=%d',X.Matches(k)),'Rotation',90,'VerticalAlignment','bottom','FontSize',8);end;end,end
title(t,'Phase and wicket-state performance');Files=[Files;U.Figure(f,out,"Step22_Figure3_PhaseWicketPerformance")];

f=figure('Visible',vis,'Color','w','Position',[80 80 1180 520]);t=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');
for fmt=["ODI","T20"],nexttile;hold on;for role=["PrimaryResource","PrimaryForecast"],X=R.Subgroups(R.Subgroups.Format==fmt&R.Subgroups.Role==role&R.Subgroups.GroupType=="Year",:);[yr,ord]=sort(str2double(X.Group));plot(yr,X.EqualInningsRMSE(ord),'o-','LineWidth',1.5,'DisplayName',replace(role,'_',' '));end;grid on;xlabel('Test year');ylabel('Equal-innings RMSE (runs)');title(fmt+" temporal stability");legend('Location','best');end
title(t,'Frozen-model performance by calendar year');Files=[Files;U.Figure(f,out,"Step22_Figure4_YearStability")];

f=figure('Visible',vis,'Color','w','Position',[80 80 900 520]);X=R.Subgroups(R.Subgroups.Format=="T20"&R.Subgroups.GroupType=="T20FullWicketPhase"&ismember(R.Subgroups.Role,["Baseline","PrimaryResource","FlexibleComparator"]),:);groups=unique(X.Group,'stable');roles=["Baseline","PrimaryResource","FlexibleComparator"];Y=nan(numel(groups),numel(roles));N=zeros(numel(groups),1);
for i=1:numel(groups),for j=1:numel(roles),q=X.Group==groups(i)&X.Role==roles(j);if any(q),Y(i,j)=X.EqualInningsRMSE(q);N(i)=X.Matches(q);end,end,end
bar(Y);grid on;xticks(1:numel(groups));xticklabels(replace(groups,'_',' '));ylabel('Equal-innings RMSE (runs)');xlabel('T20 states with ten wickets in hand');legend(replace(roles,'_',' '),'Location','best');title('Full-wicket T20 sensitivity across innings phases');
Files=[Files;U.Figure(f,out,"Step22_Figure5_T20FullWicketSensitivity")];
end
