function Lock=RevisedCodes_22_OpenLock(C,U,here)
resultPath=fullfile(C.ProjectRoot,'paper_outputs_revisedcodes','step19_final','RevisedCodes_19_02_Result.mat');
integrityPath=fullfile(C.FrozenRoot,'FrozenIntegrity.mat');protocolPath=fullfile(C.FrozenRoot,'Frozen_Protocol.csv');modelPath=fullfile(C.FrozenRoot,'RevisedCodes_19_FrozenModels.mat');
assert(all(isfile([string(resultPath);string(integrityPath);string(protocolPath);string(modelPath)])),'Frozen Step19 files missing.');
z=load(resultPath,'Result');assert(z.Result.PolicyFrozen&&~z.Result.IndependentPerformanceEvaluated,'Unexpected Step19 status.');U.Verify(z.Result.Hashes,U);
code=dir(fullfile(here,'*.m'));paths=string(fullfile({code.folder},{code.name}))';CodeHashes=U.Hashes(paths,U);
frozenIntegritySHA=U.Hash(integrityPath);protocolSHA=U.Hash(protocolPath);modelSHA=U.Hash(modelPath);
signature=signatureHash(C,U);openPath=fullfile(C.ProjectRoot,'paper_outputs_revisedcodes','step22_final','Step22_OpeningRecord.mat');
if ~isfolder(fileparts(openPath)),mkdir(fileparts(openPath));end
if isfile(openPath)
 z=load(openPath,'Lock');old=z.Lock;changed=old.FrozenIntegritySHA256~=frozenIntegritySHA||old.ProtocolSHA256~=protocolSHA||old.FrozenModelSHA256~=modelSHA||old.SettingsSignature~=signature||~isequal(old.CodeHashes.SHA256,CodeHashes.SHA256);
 if changed
  reason=C.AmendmentReason;
  if old.TestOutcomesPreviouslyOpenedByStep22
   assert(strlength(strtrim(reason))>0,'Step22 changed after test outcomes were opened. Supply a documented AmendmentReason; do not delete the opening record.');
  elseif strlength(strtrim(reason))==0
   reason="PRE_OUTCOME_CODE_OR_CONFIGURATION_CORRECTION";
  end
  amendment=table(datetime('now','TimeZone','UTC'),reason,old.CodeHashes.SHA256(1),CodeHashes.SHA256(1),'VariableNames',{'UTC','Reason','PriorCodeAnchor','NewCodeAnchor'});
  if isfield(old,'Amendments'),old.Amendments=[old.Amendments;amendment];else,old.Amendments=amendment;end
  old.CodeHashes=CodeHashes;old.SettingsSignature=signature;Lock=old;save(openPath,'Lock');
 else,Lock=old;end
else
 Lock=struct('OpenedUTC',datetime('now','TimeZone','UTC'),'FrozenIntegritySHA256',frozenIntegritySHA,'ProtocolSHA256',protocolSHA, ...
  'FrozenModelSHA256',modelSHA,'SettingsSignature',signature,'CodeHashes',CodeHashes,'TestOutcomesPreviouslyOpenedByStep22',false,'Amendments',table);
 save(openPath,'Lock');
end
Lock.RecordPath=string(openPath);
end
function h=signatureHash(C,U)
p=string(tempname);f=fopen(p,'wt');assert(f>=0);fprintf(f,'%d|%d|%d|%d|%d|%d|%d',C.BootstrapReplicates,C.RandomSeed,C.MinSubgroupMatches,C.ExpectedODIMatches,C.ExpectedODIStates,C.ExpectedT20Matches,C.ExpectedT20States);fclose(f);h=U.Hash(p);delete(p);
end
