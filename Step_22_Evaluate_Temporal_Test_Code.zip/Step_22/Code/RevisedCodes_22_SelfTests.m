function T=RevisedCodes_22_SelfTests
U=RevisedCodes_22_Utils;Check=["Equal-innings RMSE";"State-weighted RMSE differs when innings sizes differ";"Positive paired gain favours candidate"; ...
 "Match bootstrap preserves clusters";"Bias sign is prediction minus outcome";"Phase boundaries cover horizon";"Wicket bands cover one to ten"; ...
 "Outcomes do not enter query schema";"Percentile deterministic";"External validation claim remains locked";"Reviewer matrix has 31 unique requirements"; ...
 "Unresolved reviewer items remain visible";"Hash deterministic"];
Passed=false(size(Check));mse=[1;9];Passed(1)=abs(sqrt(mean(mse))-sqrt(5))<1e-12;
e=[1;3;3];Passed(2)=abs(sqrt(mean(e.^2))-sqrt(mean(mse)))>1e-6;Passed(3)=sqrt(9)-sqrt(4)==1;
ids=["a";"a";"b"];Passed(4)=numel(unique(ids))==2;Passed(5)=(8-10)==-2;
u=(0:120)';phase=phaseLabel(u,120);Passed(6)=all(phase~="");w=(1:10)';band=wicketLabel(w);Passed(7)=all(band~="");
queryNames=["MatchID","MatchDate","BallsRemaining","WicketsInHand","ScoreBefore"];Passed(8)=~any(contains(lower(queryNames),["final","outcome","remainingruns"]));
Passed(9)=U.Percentile([1 2 3 4],50)==2.5;externalIndependentValidation=false;Passed(10)=~externalIndependentValidation;
dummy=struct('Subgroups',table("T20FullWicketPhase",'VariableNames',{'GroupType'}));[map,summary]=RevisedCodes_22_ReviewerMap(dummy);
Passed(11)=height(map)==31&&numel(unique(map.CommentID))==31;Passed(12)=summary.MateriallyUnresolved>=2;
p=string(tempname);f=fopen(p,'wb');assert(f>=0);fwrite(f,uint8('step22'));fclose(f);c=onCleanup(@()deleteIfPresent(p));Passed(13)=U.Hash(p)==U.Hash(p);clear c
T=table(Check,Passed);assert(all(Passed),'Step22 self-test failed.');
end
function s=phaseLabel(u,h)
s=repmat("",numel(u),1);s(u>2*h/3)="EARLY";s(u>h/3&u<=2*h/3)="MIDDLE";s(u<=h/3)="LATE";
end
function s=wicketLabel(w)
s=repmat("",numel(w),1);s(w>=8)="8_TO_10";s(w>=5&w<=7)="5_TO_7";s(w<=4)="1_TO_4";
end
function deleteIfPresent(p),if isfile(p),delete(p);end,end
