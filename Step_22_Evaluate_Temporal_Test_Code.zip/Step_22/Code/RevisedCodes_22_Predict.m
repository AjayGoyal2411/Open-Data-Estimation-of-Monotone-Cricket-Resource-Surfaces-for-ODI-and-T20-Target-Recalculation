function P=RevisedCodes_22_Predict(D,Frozen,C,out,U)
P=struct;allFiles=strings(0,1);Population=table;InterfaceAudit=table;
for fmt=["ODI","T20"]
 X=D.(char(fmt));F=X.Features;A=X.Audit;idx=find(Frozen.Index.Format==fmt);Index=Frozen.Index(idx,:);n=height(A);k=height(Index);
 Prediction=zeros(n,k);RawPrediction=nan(n,k);Supported=true(n,k);LowerBound=false(n,k);MatchErrors=table;
 for j=1:k
  role=Index.Role(j);[p,info]=RevisedCodes_19_PredictFrozen(Frozen,fmt,role,F);Prediction(:,j)=double(p);
  assert(all(isfinite(p)),'Nonfinite Step22 prediction.');
  if ismember('RawForecast',info.Properties.VariableNames),RawPrediction(:,j)=double(info.RawForecast);LowerBound(:,j)=logical(info.LowerBoundApplied);end
  if ismember('EmpiricallySupported',info.Properties.VariableNames),Supported(:,j)=logical(info.EmpiricallySupported);end
  M=perMatch(A,p,Supported(:,j),LowerBound(:,j));M.Format=repmat(fmt,height(M),1);M.Role=repmat(role,height(M),1);M.ModelID=repmat(Index.ModelID(j),height(M),1);MatchErrors=[MatchErrors;M]; %#ok<AGROW>
 end
 assert(height(MatchErrors)==numel(unique(A.MatchID))*k,'Incomplete paired match errors.');
 path=fullfile(fileparts(out),char("Step22_StatePredictions_"+fmt+".mat"));save(path,'A','F','Prediction','RawPrediction','Supported','LowerBound','Index','-v7.3');allFiles(end+1,1)=string(path); %#ok<AGROW>
 P.(char(fmt))=struct('Audit',A,'Features',F,'Prediction',Prediction,'RawPrediction',RawPrediction,'Supported',Supported,'LowerBound',LowerBound,'Index',Index,'MatchErrors',MatchErrors,'Path',string(path));
 Population=[Population;table(fmt,numel(unique(A.MatchID)),height(A),min(A.MatchDate),max(A.MatchDate),nnz(A.CaseReserved), ...
  'VariableNames',{'Format','Matches','States','Earliest','Latest','ReservedStates'})]; %#ok<AGROW>
 InterfaceAudit=[InterfaceAudit;table(fmt,k,all(all(isfinite(Prediction))),all(~A.CaseReserved),all(A.MatchDate>=datetime(2024,1,1)), ...
  'VariableNames',{'Format','Roles','FinitePredictions','ReservedCasesExcluded','DatesAtOrAfter2024'})]; %#ok<AGROW>
end
P.Population=Population;P.InterfaceAudit=InterfaceAudit;P.StateFiles=allFiles;P.StateHashes=U.Hashes(allFiles,U);
end

function T=perMatch(A,p,supported,lowerBound)
[ids,first,g]=unique(A.MatchID,'stable');n=accumarray(g,1);e=double(p)-A.RemainingRuns;
MSE=accumarray(g,e.^2)./n;MAE=accumarray(g,abs(e))./n;Bias=accumarray(g,e)./n;
MeanObserved=accumarray(g,A.RemainingRuns)./n;MeanPrediction=accumarray(g,double(p))./n;
SupportedPercent=100*accumarray(g,double(supported))./n;LowerBoundPercent=100*accumarray(g,double(lowerBound))./n;
T=table(ids,A.MatchDate(first),A.EventName(first),A.BattingTeam(first),A.Opponent(first),n,MSE,MAE,Bias,MeanObserved,MeanPrediction,SupportedPercent,LowerBoundPercent, ...
 'VariableNames',{'MatchID','MatchDate','EventName','BattingTeam','Opponent','States','MSE','MAE','Bias','MeanObserved','MeanPrediction','SupportedPercent','LowerBoundPercent'});
end
