function Results=RevisedCodes_22_RunAll(settings)
if nargin<1,settings=struct;end
C=RevisedCodes_22_Config(settings);U=RevisedCodes_22_Utils;here=fileparts(mfilename('fullpath'));
base=fullfile(C.ProjectRoot,'paper_outputs_revisedcodes','step22_final');if ~isfolder(base),mkdir(base);end
out=fullfile(base,'RevisedCodes_22_Result.mat');
if isfile(out)
 z=load(out,'Results');Results=z.Results;U.Verify(Results.ArtifactHashes,U);assert(Results.IndependentPerformanceEvaluated,'Stored Step22 result is incomplete.');
 current=dir(fullfile(here,'*.m'));CurrentCodeHashes=U.Hashes(string(fullfile({current.folder},{current.name}))',U);
 assert(isequal(Results.CodeHashes.SHA256,CurrentCodeHashes.SHA256),'Current Step22 code differs from the completed evaluated code. Restore the archived code; do not rerun the test with silent changes.');
 if strlength(string(Results.ChecksZip))==0||~isfile(Results.ChecksZip)
  assert(isfolder(Results.ReportPath),'Verified report folder is unavailable for checks-archive recovery.');
  Results.ChecksZip=string(Results.ReportPath)+"_Checks.zip";zip(Results.ChecksZip,{'*'},Results.ReportPath);save(out,'Results','-v7.3');
 end
 fprintf('Existing Step22 result verified and reused. Upload %s\n',Results.ChecksZip);return;
end
report=string(tempname(base));mkdir(report);diary(fullfile(report,'RunLog.txt'));cdia=onCleanup(@()diary('off')); %#ok<NASGU>
try
 codeRoot=fullfile(C.FrozenRoot,'code');if isfolder(codeRoot),addpath(codeRoot,'-end');end
 Tests=RevisedCodes_22_SelfTests;U.Write(Tests,fullfile(report,'Step22_SelfTests.csv'));
 step19Root=fullfile(C.ProjectRoot,'paper_outputs_revisedcodes','step19_final');Frozen=RevisedCodes_19_LoadFrozen(step19Root);
 Lock=RevisedCodes_22_OpenLock(C,U,here);
 % Persist the opening event before the first test-outcome table is loaded.
 if ~Lock.TestOutcomesPreviouslyOpenedByStep22
  Lock.TestOutcomesPreviouslyOpenedByStep22=true;Lock.TestOutcomesOpenedUTC=datetime('now','TimeZone','UTC');record=Lock.RecordPath;save(record,'Lock');
 end
 D=RevisedCodes_22_LoadTest(C,Frozen);
 P=RevisedCodes_22_Predict(D,Frozen,C,out,U);R=RevisedCodes_22_Analyse(P,Frozen,C,U);
 U.Write(P.Population,fullfile(report,'Step22_TestPopulation.csv'));U.Write(P.InterfaceAudit,fullfile(report,'Step22_PredictionInterfaceAudit.csv'));
 U.Write(P.StateHashes,fullfile(report,'Step22_StateArtifactHashes.csv'));U.Write(R.Scores,fullfile(report,'Step22_PerformanceSummary.csv'));
 U.Write(R.Intervals,fullfile(report,'Step22_PerformanceBootstrap95CI.csv'));U.Write(R.Pairs,fullfile(report,'Step22_PairedComparisons.csv'));
 U.Write(R.MatchErrors,fullfile(report,'Step22_MatchErrors.csv'));U.Write(R.Subgroups,fullfile(report,'Step22_Subgroups.csv'));
 U.Write(R.Calibration,fullfile(report,'Step22_Calibration.csv'));U.Write(R.Influence,fullfile(report,'Step22_MatchInfluence.csv'));
 U.Write(R.CaseExamples,fullfile(report,'Step22_RealMatchExamples.csv'));
 U.Write(R.HistoryCoverage,fullfile(report,'Step22_HistoryCoverage.csv'));U.Write(R.UncertaintyScope,fullfile(report,'Step22_UncertaintyScope.csv'));
 Figures=RevisedCodes_22_Figures(R,report,C,U);U.Write(Figures,fullfile(report,'Step22_FigureManifest.csv'));
 [ReviewerMap,ReviewerSummary]=RevisedCodes_22_ReviewerMap(R);U.Write(ReviewerMap,fullfile(report,'Step22_ReviewerEditorCoverage.csv'));U.Write(ReviewerSummary,fullfile(report,'Step22_ReviewerEditorCoverageSummary.csv'));
 Gate=["Frozen Step19 package verified";"Step22 opening record preserved";"ODI locked population exact";"T20 locked population exact"; ...
  "Reserved cases excluded";"All five roles finite and paired";"No model fitting tuning or switching";"Whole-match uncertainty exported"; ...
  "Frozen temporal evaluation completed";"External independent validation established";"Fairness or superiority established";"VJD and modified-DL comparison completed"];
 Passed=[true;true;P.Population.Matches(P.Population.Format=="ODI")==C.ExpectedODIMatches&&P.Population.States(P.Population.Format=="ODI")==C.ExpectedODIStates; ...
  P.Population.Matches(P.Population.Format=="T20")==C.ExpectedT20Matches&&P.Population.States(P.Population.Format=="T20")==C.ExpectedT20States; ...
  all(P.Population.ReservedStates==0);all(P.InterfaceAudit.FinitePredictions)&all(P.InterfaceAudit.Roles==5);true;true;true;false;false;false];
 Gates=table(Gate,Passed);assert(all(Passed(1:9)),'A required Step22 computational gate failed.');U.Write(Gates,fullfile(report,'Step22_ExecutionGates.csv'));
 writeNarrative(fullfile(report,'Step22_RESULTS_INTERPRETATION.md'),R,P,ReviewerSummary);
 writeCoverageNarrative(fullfile(report,'Step22_REVIEWER_EDITOR_REMAINING.md'),ReviewerMap,ReviewerSummary);
 code=dir(fullfile(here,'*.m'));CodeHashes=U.Hashes(string(fullfile({code.folder},{code.name}))',U);U.Write(CodeHashes,fullfile(report,'Step22_CodeHashes.csv'));
 InputHashes=table(["Frozen integrity";"Frozen model";"Frozen protocol";"Opening record"],[Lock.FrozenIntegritySHA256;Lock.FrozenModelSHA256;Lock.ProtocolSHA256;U.Hash(Lock.RecordPath)], ...
  'VariableNames',{'Input','SHA256'});U.Write(InputHashes,fullfile(report,'Step22_InputHashes.csv'));
 diary off;
 files=dir(fullfile(report,'*'));files=files(~[files.isdir]);reportPaths=string(fullfile({files.folder},{files.name}))';ArtifactHashes=U.Hashes([P.StateFiles;reportPaths],U);
 Results=struct('Status',"STEP22_COMPLETE_LOCKED_TEMPORAL_EVALUATION",'IndependentPerformanceEvaluated',true,'ExternalIndependentValidation',false, ...
  'FrozenModelUnchanged',true,'Population',P.Population,'Scores',R.Scores,'Pairs',R.Pairs,'ReviewerSummary',ReviewerSummary,'Gates',Gates, ...
  'ReportPath',report,'ArtifactHashes',ArtifactHashes,'CodeHashes',CodeHashes,'Settings',C,'ClaimBoundary',"FROZEN_2024PLUS_TEMPORAL_TEST_NOT_EXTERNAL_VALIDATION",'ChecksZip',"");
 save(out,'Results','-v7.3');zipPath=report+"_Checks.zip";zip(zipPath,{'*'},report);Results.ChecksZip=zipPath;save(out,'Results','-v7.3');
 disp(P.Population);disp(R.Scores);disp(R.Pairs);disp(ReviewerSummary);disp(Gates);fprintf('Upload %s\n',zipPath);
catch err
 diary off;writeFailure(fullfile(report,'Step22_FAILURE.txt'),err,C);zip(report+"_FAILED_Checks.zip",{'*'},report);fprintf('Upload %s\n',report+"_FAILED_Checks.zip");rethrow(err);
end
end

function writeNarrative(path,R,P,review)
f=fopen(path,'wt');assert(f>=0);c=onCleanup(@()fclose(f));fprintf(f,'# Step 22 locked temporal evaluation\n\n');
fprintf(f,'The through-2023 frozen models were evaluated once on the predefined 2024+ primary first-innings test population. No fitting, tuning, model switching, threshold selection or case-study row entered this evaluation.\n\n');
for fmt=["ODI","T20"]
 pop=P.Population(P.Population.Format==fmt,:);fprintf(f,'## %s\n\nPopulation: %d matches and %d legal-delivery states, %s to %s.\n\n',fmt,pop.Matches,pop.States,string(pop.Earliest),string(pop.Latest));
 for role=["Baseline","PrimaryResource","PrimaryForecast","FlexibleComparator","LiveScoreComparator"]
  q=R.Scores.Format==fmt&R.Scores.Role==role;if ~any(q),continue;end;s=R.Scores(q,:);ci=R.Intervals(R.Intervals.Format==fmt&R.Intervals.Role==role&R.Intervals.Metric=="EqualInningsRMSE",:);
  fprintf(f,'- %s: equal-innings RMSE %.3f runs (95%% match-bootstrap CI %.3f to %.3f), MAE %.3f, bias %.3f.\n',replace(role,'_',' '),s.EqualInningsRMSE,ci.Lower95,ci.Upper95,s.EqualInningsMAE,s.EqualInningsBias);
 end
end
fprintf(f,'\n## Interpretation boundary\n\nThis is a temporally held-out frozen-model performance evaluation. It is not an external validation cohort, an operational DLS/VJD reproduction, or evidence of competitive fairness. Fixed-model whole-match uncertainty is reported; full pipeline refit uncertainty is not estimated. Subgroups are diagnostic and retain their denominators.\n');
fprintf(f,'\n## Reviewer status after Step 22\n\nOf %d tracked requirements, %d are evidence-complete, %d remain partial or writing-dependent, and %d remain materially unresolved. The separate coverage files identify each remaining action.\n',review.Comments,review.EvidenceComplete,review.PartialOrWritingPending,review.MateriallyUnresolved);clear c
end

function writeCoverageNarrative(path,T,S)
f=fopen(path,'wt');assert(f>=0);c=onCleanup(@()fclose(f));fprintf(f,'# Reviewer and editor requirements after Step 22\n\n');
fprintf(f,'Step 22 completes the locked temporal performance analysis but does not by itself complete the revision. %d requirements are tracked; %d are materially unresolved and %d still require manuscript editing or explicit limitation language.\n\n',S.Comments,S.MateriallyUnresolved,S.ManuscriptEditPending);
fprintf(f,'## Materially unresolved\n\n');Q=T(contains(T.Status,"UNRESOLVED")|contains(T.Status,"BLOCKED"),:);for i=1:height(Q),fprintf(f,'- %s: %s\n',Q.CommentID(i),Q.Remaining(i));end
fprintf(f,'\n## Required before resubmission\n\n- Complete the corrected gender-pooling analysis or explicitly narrow and defend the men-only scope.\n- Obtain source-certified VJD and modified-DL implementations, or state transparently that reproducible comparisons could not be performed.\n- Deposit the minimal data, code, metadata and execution instructions in a persistent repository.\n- Complete the Step23 manuscript, numbering, terminology, citation and response-letter audit.\n');clear c
end

function writeFailure(path,err,C)
f=fopen(path,'wt');if f<0,return;end;c=onCleanup(@()fclose(f));fprintf(f,'Message: %s\nIdentifier: %s\nProjectRoot: %s\nFrozenRoot: %s\n\nStack:\n',err.message,err.identifier,C.ProjectRoot,C.FrozenRoot);for k=1:numel(err.stack),fprintf(f,'%s line %d\n',err.stack(k).name,err.stack(k).line);end;clear c
end
