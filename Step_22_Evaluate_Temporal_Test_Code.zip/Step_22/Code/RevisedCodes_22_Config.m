function C=RevisedCodes_22_Config(settings)
if nargin<1,settings=struct;end
assert(isstruct(settings)&&isscalar(settings),'settings must be a scalar struct.');
allowed=["ProjectRoot","FrozenRoot","BootstrapReplicates","RandomSeed","MinSubgroupMatches","FigureVisible","AmendmentReason"];
assert(all(ismember(string(fieldnames(settings)),allowed)),'Unknown Step22 setting.');
C.ProjectRoot="D:\VihaanProject1"; C.FrozenRoot=""; C.BootstrapReplicates=10000;
C.RandomSeed=20260922; C.MinSubgroupMatches=20; C.FigureVisible=false; C.AmendmentReason="";
C.ExpectedODIMatches=169; C.ExpectedODIStates=47533; C.ExpectedT20Matches=2083; C.ExpectedT20States=246400;
for n=reshape(string(fieldnames(settings)),1,[]),C.(n)=settings.(n);end
C.ProjectRoot=string(C.ProjectRoot);C.FrozenRoot=string(C.FrozenRoot);C.AmendmentReason=string(C.AmendmentReason);
assert(isfolder(C.ProjectRoot),'ProjectRoot not found: %s',C.ProjectRoot);
if C.FrozenRoot==""
 d=dir(fullfile(C.ProjectRoot,'paper_outputs_revisedcodes','step19_final','frozen','build_*'));d=d([d.isdir]);
 assert(numel(d)==1,'Expected exactly one frozen Step19 build; found %d.',numel(d));C.FrozenRoot=string(fullfile(d(1).folder,d(1).name));
end
assert(isfolder(C.FrozenRoot),'FrozenRoot not found: %s',C.FrozenRoot);
assert(C.BootstrapReplicates>=1000&&fix(C.BootstrapReplicates)==C.BootstrapReplicates);
assert(C.MinSubgroupMatches>=5&&fix(C.MinSubgroupMatches)==C.MinSubgroupMatches);
assert(islogical(C.FigureVisible)&&isscalar(C.FigureVisible));
end

