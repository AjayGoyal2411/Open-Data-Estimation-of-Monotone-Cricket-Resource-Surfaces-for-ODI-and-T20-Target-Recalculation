function U=RevisedCodes_22_Utils
U.Hash=@hashFile;U.Hashes=@hashes;U.Verify=@verify;U.Write=@writeCSV;U.Percentile=@percentile;
U.Bool=@toLogical;U.Require=@requireColumns;U.Figure=@saveFigure;U.SafeName=@safeName;
end
function h=hashFile(p)
f=fopen(p,'rb');assert(f>=0,'Cannot hash %s',p);c=onCleanup(@()fclose(f));md=java.security.MessageDigest.getInstance('SHA-256');
while ~feof(f),b=fread(f,1048576,'*uint8');md.update(typecast(b,'int8'));end
h=lower(string(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[])));clear c
end
function T=hashes(paths,U)
if nargin<2,U=RevisedCodes_22_Utils;end;paths=unique(string(paths(:)),'stable');h=strings(numel(paths),1);
for i=1:numel(paths),assert(isfile(paths(i)),'Missing dependency: %s',paths(i));h(i)=U.Hash(paths(i));end
T=table(paths,h,'VariableNames',{'Path','SHA256'});
end
function verify(T,U)
if nargin<2,U=RevisedCodes_22_Utils;end;U.Require(T,["Path","SHA256"]);assert(all(isfile(T.Path)),'Dependency missing.');
for i=1:height(T),assert(U.Hash(T.Path(i))==T.SHA256(i),'Changed dependency: %s',T.Path(i));end
end
function writeCSV(T,path),assert(istable(T));writetable(T,path);end
function q=percentile(x,p)
x=sort(double(x(isfinite(x))));assert(~isempty(x));if numel(x)==1,q=x;return;end
t=1+(numel(x)-1)*p/100;lo=floor(t);hi=ceil(t);q=x(lo)+(t-lo)*(x(hi)-x(lo));
end
function x=toLogical(v)
if islogical(v),x=v;return;end;s=lower(strtrim(string(v)));assert(all(ismember(s,["1","0","true","false","yes","no"])));x=ismember(s,["1","true","yes"]);
end
function requireColumns(T,names),m=setdiff(string(names),string(T.Properties.VariableNames));assert(isempty(m),'Missing columns: %s',strjoin(m,', '));end
function T=saveFigure(fig,out,name)
set(findall(fig,'Type','axes'),'TickLabelInterpreter','none');name=string(name);png=string(fullfile(out,char(name+".png")));pdf=string(fullfile(out,char(name+".pdf")));figp=string(fullfile(out,char(name+".fig")));
exportgraphics(fig,char(png),'Resolution',600);exportgraphics(fig,char(pdf),'ContentType','vector');savefig(fig,char(figp));close(fig);
T=table(name,png,pdf,figp,'VariableNames',{'Figure','PNG','PDF','FIG'});
end
function s=safeName(v),s=strip(regexprep(lower(string(v)),'[^a-z0-9]+','_'),'_');end

