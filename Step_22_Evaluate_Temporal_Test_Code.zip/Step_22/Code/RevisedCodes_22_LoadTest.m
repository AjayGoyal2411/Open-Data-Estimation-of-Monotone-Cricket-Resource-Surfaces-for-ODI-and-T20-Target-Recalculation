function D=RevisedCodes_22_LoadTest(C,Frozen)
assert(exist('RevisedCodes_19_Utils','file')==2&&exist('RevisedCodes_10_Utils','file')==2&&exist('RevisedCodes_12_ContextUtils','file')==2,'Required frozen-pipeline functions are unavailable.');
c19=RevisedCodes_19_00_Config(struct);assert(string(c19.ProjectRoot)==C.ProjectRoot,'Step19 and Step22 project roots differ.');
Q=RevisedCodes_19_Utils;I=Q.Inputs(c19);V=RevisedCodes_10_Utils;W=RevisedCodes_12_ContextUtils;
assert(Frozen.TrainingCutoffExclusive==datetime(2024,1,1),'Frozen training cutoff changed.');
for fmt=["ODI","T20"]
 L=I.Exceptional.Ledger;allow=L.PrimaryModelEligible&~L.CaseStudyReserved&string(L.Format)==fmt&L.Date>=datetime(2024,1,1)&string(L.Split)=="test";L=L(allow,:);assert(~isempty(L));
 keys=V.Key(L);assert(numel(unique(keys))==height(L),'Repeated test ledger key.');seen=zeros(height(L),1);F=table;A=table;
 assert(height(I.States.Partitions)==height(I.OriginalContext.Partitions),'State/context partition count differs.');
 allowedVars=["BallsRemaining","WicketsInHand","ScoreBefore","LegalBallsSinceDismissal","NoDismissalYet","RetiredNotOutEventsBefore", ...
  "RunRateBefore","NoLegalBallYet","Recent30Runs","Recent30LegalBalls","Recent30RunRate","Opponent","BattingTeam","Venue","EventName"];
 for part=1:height(I.States.Partitions)
  z=load(I.States.Partitions.Path(part),'States');S=z.States;z=load(I.OriginalContext.Partitions.Path(part),'Features');X=z.Features;
  assert(isequal(W.StateKey(S),W.StateKey(X)),'Source/context state keys differ.');
  keep=S.PrimaryEligibleObservation&~S.CaseReserved&string(S.Format)==fmt&S.InningsIndex==1&S.MatchDate>=datetime(2024,1,1)&string(S.Split)=="test";
  S=S(keep,:);X=X(keep,:);if isempty(S),continue;end
  assert(all(string(S.StateType)=="delivery"&S.CorrectedIsLegalBall==1&S.WicketsInHand>0),'Noncanonical test state.');
  [ok,j]=ismember(V.Key(S),keys);assert(all(ok),'Unexpected test innings.');seen=seen+accumarray(j,1,[height(L),1]);
  assert(all(S.FinalDeliveryRuns==L.DeliveryRuns(j))&&all(S.PrimaryRemainingRuns==S.FinalDeliveryRuns-S.DeliveryScoreBefore),'Test labels do not reconcile.');
  B=table(string(S.MatchID),S.InningsIndex,S.DeliverySeq,string(S.StateType),S.MatchDate,string(S.Gender),string(S.Format),string(X.EventName),string(X.Venue),string(X.BattingTeam),string(X.Opponent), ...
   double(S.FinalDeliveryRuns),double(S.PrimaryRemainingRuns),double(S.BallsRemaining),double(S.WicketsInHand),string(S.Split),logical(S.CaseReserved), ...
   'VariableNames',{'MatchID','InningsIndex','DeliverySeq','StateType','MatchDate','Gender','Format','EventName','Venue','BattingTeam','Opponent','FinalDeliveryRuns','RemainingRuns','BallsRemaining','WicketsInHand','Split','CaseReserved'});
  XX=X(:,cellstr(allowedVars));XX.MatchID=string(S.MatchID);XX.MatchDate=S.MatchDate;
  F=[F;XX];A=[A;B]; %#ok<AGROW>
  if mod(part,16)==0,fprintf('Step22 %s test extraction %d/%d\n',fmt,part,height(I.States.Partitions));end
 end
 assert(isequal(seen,double(L.CachedPrimaryStates)),'Test inventory does not reconcile with ledger.');
 assert(numel(unique(string(A.MatchID)))==height(L),'Test match count does not match ledger.');assert(all(~A.CaseReserved));
 assert(all(A.MatchDate>=datetime(2024,1,1)&A.Split=="test"&ismember(lower(A.Gender),["men","male"])),'Test scope changed.');
 if fmt=="ODI",assert(height(L)==C.ExpectedODIMatches&&height(A)==C.ExpectedODIStates,'Locked ODI test population changed.');
 else,assert(height(L)==C.ExpectedT20Matches&&height(A)==C.ExpectedT20States,'Locked T20 test population changed.');end
 assert(numel(unique(W.StateKey(A)))==height(A),'Repeated test state.');
 D.(char(fmt))=struct('Features',F,'Audit',A,'Ledger',L);
end
end
