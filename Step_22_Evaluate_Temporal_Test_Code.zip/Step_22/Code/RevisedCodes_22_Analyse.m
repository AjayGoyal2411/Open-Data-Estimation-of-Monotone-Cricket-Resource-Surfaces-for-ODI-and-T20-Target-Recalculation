function R=RevisedCodes_22_Analyse(P,Frozen,C,U)
R=struct;Scores=table;Intervals=table;Pairs=table;Subgroups=table;Calibration=table;Influence=table;HistoryCoverage=table;MatchErrors=table;CaseExamples=table;
for fmt=["ODI","T20"]
 X=P.(char(fmt));A=X.Audit;F=X.Features;Index=X.Index;h=120;if fmt=="ODI",h=300;end
 resourceCol=find(Index.Role=="PrimaryResource");forecastCol=find(Index.Role=="PrimaryForecast");assert(isscalar(resourceCol)&&isscalar(forecastCol));
 primarySupport=X.Supported(:,resourceCol);forecastModel=Frozen.Models{find(Frozen.Index.Format==fmt&Frozen.Index.Role=="PrimaryForecast",1)};
 [historyLabel,HC]=historySupport(F,A,forecastModel,fmt);HistoryCoverage=[HistoryCoverage;HC]; %#ok<AGROW>
 for j=1:height(Index)
  p=X.Prediction(:,j);M=X.MatchErrors(X.MatchErrors.Role==Index.Role(j),:);MatchErrors=[MatchErrors;M]; %#ok<AGROW>
  modelSupport=double(X.Supported(:,j));if ismember(Index.Role(j),["PrimaryForecast","LiveScoreComparator"]),modelSupport(:)=NaN;end
  S=score(A,p,M,modelSupport,X.LowerBound(:,j),fmt,Index.Role(j),Index.ModelID(j));Scores=[Scores;S]; %#ok<AGROW>
  Intervals=[Intervals;bootMetrics(M,fmt,Index.Role(j),C,U)]; %#ok<AGROW>
  Calibration=[Calibration;calibrationRows(A,p,fmt,Index.Role(j))]; %#ok<AGROW>
  Influence=[Influence;influenceRows(M,fmt,Index.Role(j))]; %#ok<AGROW>
  phase=phaseLabel(A.BallsRemaining,h);wband=wicketLabel(A.WicketsInHand);yr=string(year(A.MatchDate));event=A.EventName;event(strlength(strtrim(event))==0|ismissing(event))="MISSING";
  Subgroups=[Subgroups;groupSet(A,p,modelSupport,fmt,Index.Role(j),"Phase",phase,C); ...
   groupSet(A,p,modelSupport,fmt,Index.Role(j),"WicketsInHand",wband,C); ...
   groupSet(A,p,modelSupport,fmt,Index.Role(j),"Year",yr,C); ...
   groupSet(A,p,modelSupport,fmt,Index.Role(j),"EventNameAsRecorded",event,C); ...
   groupSet(A,p,modelSupport,fmt,Index.Role(j),"PrimaryResourceSupport",supportLabel(primarySupport),C); ...
   groupSet(A,p,modelSupport,fmt,Index.Role(j),"TeamOpponentHistory",historyLabel,C)]; %#ok<AGROW>
  if fmt=="T20"
   full=A.WicketsInHand==10;Subgroups=[Subgroups;groupSet(A,p,modelSupport,fmt,Index.Role(j),"T20FullWicketPhase",phase,C,full); ...
    groupSet(A,p,modelSupport,fmt,Index.Role(j),"T20FullWicketYear",yr,C,full)]; %#ok<AGROW>
  end
 end
 base=X.MatchErrors(X.MatchErrors.Role=="Baseline",:);
 for role=setdiff(Index.Role,"Baseline","stable")'
  alt=X.MatchErrors(X.MatchErrors.Role==role,:);Pairs=[Pairs;pair(base,alt,fmt,role,"Baseline",C,U)]; %#ok<AGROW>
 end
 comparisonPairs=["PrimaryResource","FlexibleComparator";"PrimaryForecast","LiveScoreComparator"];
 for z=1:size(comparisonPairs,1)
  candidate=comparisonPairs(z,1);comparator=comparisonPairs(z,2);
  a=X.MatchErrors(X.MatchErrors.Role==candidate,:);b=X.MatchErrors(X.MatchErrors.Role==comparator,:);
  P1=pair(b,a,fmt,candidate,comparator,C,U);Pairs=[Pairs;P1]; %#ok<AGROW>
 end
 CaseExamples=[CaseExamples;caseExamples(X.MatchErrors,fmt)]; %#ok<AGROW>
end
R.Scores=Scores;R.Intervals=Intervals;R.Pairs=Pairs;R.Subgroups=Subgroups;R.Calibration=Calibration;R.Influence=Influence;R.HistoryCoverage=HistoryCoverage;R.MatchErrors=MatchErrors;R.CaseExamples=CaseExamples;
R.UncertaintyScope=table(["Fixed-model temporal performance";"Whole-match sampling uncertainty";"Full pipeline refit uncertainty"], ...
 ["ESTIMATED";"ESTIMATED";"NOT_ESTIMATED"],["Frozen through-2023 models evaluated once";"Percentile bootstrap, whole matches";"Would require repeating all constrained fits and selection; no test-informed refit permitted"], ...
 'VariableNames',{'Quantity','Status','Definition'});
end

function T=caseExamples(M,fmt)
% Transparent post-evaluation examples: extremes plus the match nearest the median gain.
b=M(M.Role=="Baseline",:);a=M(M.Role=="PrimaryResource",:);[ok,j]=ismember(b.MatchID,a.MatchID);assert(all(ok)&&height(b)==height(a));a=a(j,:);
gain=sqrt(b.MSE)-sqrt(a.MSE);[~,fav]=max(gain);[~,unfav]=min(gain);med=median(gain);[~,typ]=min(abs(gain-med));
ix=[fav;typ;unfav];kind=["LARGEST_PRIMARY_RESOURCE_IMPROVEMENT";"NEAREST_MEDIAN_PRIMARY_RESOURCE_GAIN";"LARGEST_PRIMARY_RESOURCE_DETERIORATION"];
T=table(repmat(fmt,3,1),kind,b.MatchID(ix),b.MatchDate(ix),b.EventName(ix),b.BattingTeam(ix),b.Opponent(ix),b.States(ix), ...
 sqrt(b.MSE(ix)),sqrt(a.MSE(ix)),gain(ix),b.MeanObserved(ix),a.MeanPrediction(ix), ...
 'VariableNames',{'Format','SelectionRule','MatchID','MatchDate','EventName','BattingTeam','Opponent','States','BaselineRMSE','PrimaryResourceRMSE','RMSEGain','MeanObservedRemainingRuns','MeanPrimaryResourcePrediction'});
end

function S=score(A,p,M,modelSupport,lowerBound,fmt,role,id)
e=double(p)-A.RemainingRuns;w=1./M.States;[ok,j]=ismember(A.MatchID,M.MatchID);assert(all(ok));ww=w(j);X=[ones(height(A),1),double(p)];beta=(X'*(X.*ww))\(X'*(A.RemainingRuns.*ww));
S=table(fmt,role,id,height(M),height(A),sqrt(mean(M.MSE)),mean(M.MAE),mean(M.Bias),sqrt(mean(e.^2)),mean(abs(e)),mean(e),beta(1),beta(2),100*mean(modelSupport),100*mean(lowerBound), ...
 'VariableNames',{'Format','Role','ModelID','Matches','States','EqualInningsRMSE','EqualInningsMAE','EqualInningsBias','StateWeightedRMSE','StateWeightedMAE','StateWeightedBias','CalibrationIntercept','CalibrationSlope','EmpiricallySupportedStatesPercent','LowerBoundAppliedStatesPercent'});
end

function T=bootMetrics(M,fmt,role,C,U)
n=height(M);B=C.BootstrapReplicates;stream=RandStream('mt19937ar','Seed',C.RandomSeed+sum(double(char(fmt+role))));z=zeros(B,3);
for b=1:B,ix=randi(stream,n,n,1);z(b,:)=[sqrt(mean(M.MSE(ix))),mean(M.MAE(ix)),mean(M.Bias(ix))];end
Metric=["EqualInningsRMSE";"EqualInningsMAE";"EqualInningsBias"];est=[sqrt(mean(M.MSE));mean(M.MAE);mean(M.Bias)];lo=zeros(3,1);hi=lo;
for k=1:3,lo(k)=U.Percentile(z(:,k),2.5);hi(k)=U.Percentile(z(:,k),97.5);end
T=table(repmat(fmt,3,1),repmat(role,3,1),Metric,repmat(n,3,1),est,lo,hi,repmat(B,3,1),'VariableNames',{'Format','Role','Metric','Matches','Estimate','Lower95','Upper95','BootstrapReplicates'});
end

function T=pair(base,alt,fmt,role,comparator,C,U)
[ok,j]=ismember(base.MatchID,alt.MatchID);assert(all(ok)&&height(base)==height(alt),'Paired populations differ.');alt=alt(j,:);assert(isequal(base.States,alt.States));
x=base.MSE;y=alt.MSE;n=height(base);gain=sqrt(mean(x))-sqrt(mean(y));stream=RandStream('mt19937ar','Seed',C.RandomSeed+sum(double(char(fmt+role+comparator))));z=zeros(C.BootstrapReplicates,1);
for b=1:numel(z),ix=randi(stream,n,n,1);z(b)=sqrt(mean(x(ix)))-sqrt(mean(y(ix)));end
leave=sqrt(max(0,(sum(x)-x)/(n-1)))-sqrt(max(0,(sum(y)-y)/(n-1)));
T=table(fmt,role,comparator,n,sqrt(mean(x)),sqrt(mean(y)),gain,U.Percentile(z,2.5),U.Percentile(z,97.5),std(z),min(leave),max(leave), ...
 'VariableNames',{'Format','Role','Comparator','Matches','ComparatorRMSE','CandidateRMSE','RMSEGain','GainLower95','GainUpper95','BootstrapSE','LeaveOneMatchOutGainMin','LeaveOneMatchOutGainMax'});
end

function T=groupSet(A,p,support,fmt,role,type,label,C,base)
if nargin<9,base=true(height(A),1);end;T=table;label=string(label);values=unique(label(base),'stable');
for v=values'
 q=base&label==v;if ~any(q),continue;end;[ids,~,g]=unique(A.MatchID(q),'stable');e=double(p(q))-A.RemainingRuns(q);n=accumarray(g,1);mse=accumarray(g,e.^2)./n;mae=accumarray(g,abs(e))./n;bias=accumarray(g,e)./n;
 row=table(fmt,role,type,v,numel(ids),nnz(q),sqrt(mean(mse)),mean(mae),mean(bias),100*mean(support(q)),numel(ids)>=C.MinSubgroupMatches, ...
  'VariableNames',{'Format','Role','GroupType','Group','Matches','States','EqualInningsRMSE','EqualInningsMAE','EqualInningsBias','EmpiricallySupportedStatesPercent','SufficientGroup'});T=[T;row]; %#ok<AGROW>
end
end

function T=calibrationRows(A,p,fmt,role)
n=height(A);[~,ord]=sort(p);bin=zeros(n,1);bin(ord)=ceil((1:n)'*10/n);bin(bin<1)=1;T=table;
for b=1:10,q=bin==b;[ids,~,g]=unique(A.MatchID(q),'stable');count=accumarray(g,1);obs=accumarray(g,A.RemainingRuns(q))./count;pred=accumarray(g,double(p(q)))./count;
 T=[T;table(fmt,role,b,numel(ids),nnz(q),mean(pred),mean(obs),'VariableNames',{'Format','Role','PredictionDecile','Matches','States','MeanPrediction','MeanObserved'})]; %#ok<AGROW>
end
end

function T=influenceRows(M,fmt,role)
n=height(M);full=sqrt(mean(M.MSE));leave=sqrt(max(0,(sum(M.MSE)-M.MSE)/(n-1)));T=table(repmat(fmt,n,1),repmat(role,n,1),M.MatchID,repmat(full,n,1),leave,leave-full, ...
 'VariableNames',{'Format','Role','OmittedMatchID','FullRMSE','LeaveOneOutRMSE','RMSEChange'});
end

function [label,T]=historySupport(F,A,M,fmt)
[ids,first,g]=unique(A.MatchID,'stable');H=M.TrainingHistory;team=zeros(numel(ids),1);opp=team;maxDate=NaT(numel(ids),1);
for i=1:numel(ids),q=H.Date<dateshift(A.MatchDate(first(i)),'start','day')&H.Date<M.TrainingCutoffExclusive;if any(q),maxDate(i)=max(H.Date(q));end
 team(i)=nnz(q&string(H.BattingTeam)==string(F.BattingTeam(first(i))));opp(i)=nnz(q&string(H.Opponent)==string(F.Opponent(first(i))));end
lab=repmat("BOTH_PRESENT",numel(ids),1);lab(team==0&opp>0)="TEAM_MISSING";lab(team>0&opp==0)="OPPONENT_MISSING";lab(team==0&opp==0)="BOTH_MISSING";label=lab(g);
T=table(repmat(fmt,numel(ids),1),ids,A.MatchDate(first),string(F.BattingTeam(first)),string(F.Opponent(first)),team,opp,maxDate,lab, ...
 'VariableNames',{'Format','MatchID','MatchDate','BattingTeam','Opponent','PriorTeamInnings','PriorOpponentInnings','MaximumHistoryDate','HistorySupport'});
assert(all(isnat(maxDate)|maxDate<A.MatchDate(first)),'History leakage detected.');
end

function s=phaseLabel(u,h),s=repmat("",numel(u),1);s(u>2*h/3)="EARLY";s(u>h/3&u<=2*h/3)="MIDDLE";s(u<=h/3)="LATE";end
function s=wicketLabel(w),s=repmat("",numel(w),1);s(w>=8)="8_TO_10";s(w>=5&w<=7)="5_TO_7";s(w<=4)="1_TO_4";end
function s=supportLabel(x),s=repmat("UNSUPPORTED_COMPLETION",numel(x),1);s(x)="EMPIRICALLY_SUPPORTED";end
