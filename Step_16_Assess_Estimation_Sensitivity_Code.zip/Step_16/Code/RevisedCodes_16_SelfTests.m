function Checks=RevisedCodes_16_SelfTests
U=RevisedCodes_15_16_Utils;W=RevisedCodes_12_Utils;c=RevisedCodes_12_00_Config;
F=table([0;2;4],[100;120;130],'VariableNames',{'HistoryFormatN','HistoryFormatMean_K20'});
for entity=["Batting","Opponent","Venue","Event"]
 F.("History"+entity+"N")=[0;2;4];
 F.("History"+entity+"Mean_K20")=([0;300;640]+20*F.HistoryFormatMean_K20)./([0;2;4]+20);
end
G=U.History(F,20,20,1);assert(max(abs(F{:,:}-G{:,:}),[],'all')<1e-10,'K20 identity failed.');
G=U.History(F,20,5,1);
expected=([0;300;640]+5*[100;120;130])./([0;2;4]+5);
assert(max(abs(G.HistoryBattingMean_K5-expected))<1e-12,'Prior-free history reconstruction failed.');
G=U.History(F,20,20,.8);
assert(abs(G.HistoryBattingMean_K20(1)-80)<1e-12&& ...
 max(abs(G.HistoryBattingMean_K20(2:3)-F.HistoryBattingMean_K20(2:3)))<1e-12,'Startup sensitivity changed established histories.');
F.BallsRemaining=[120;60;100];F.WicketsInHand=[10;7;9];F.ScoreBefore=[0;80;25];
F.LegalBallsSinceDismissal=[0;8;4];F.NoDismissalYet=[true;false;false];
F.RetiredNotOutEventsBefore=zeros(3,1);F.RunRateBefore=[NaN;8;7.5];
F.Recent30RunRate=[NaN;8;7.5];F.Recent30Runs=[0;40;25];F.Recent30LegalBalls=[0;30;20];
F.NoLegalBallYet=[true;false;false];F.Venue=["A";"A";"B"];F.EventName=["E";"E";"F"];
A=table(["a";"a";"b"],ones(3,1),[150;70;125], ...
 'VariableNames',{'MatchID','InningsIndex','RemainingRuns'});
M=U.ContextFit(F,A,120,150,20,3,.01);[p,raw]=U.Predict(M,F);
assert(all(isfinite(p))&&all(isfinite(raw))&&M.FitDiagnostics.StationarityResidual<1e-8, ...
 'Actual blockwise context fit/predict failed.');
G=F;G.FutureOutcome=1e9*ones(3,1);q=U.Predict(M,G);
assert(isequal(p,q),'Outcome-like extra field altered context prediction.');
H=12;[u,w]=ndgrid(0:H,0:10);R=(u/H).*(w/10);weights=ones(numel(R),1)/numel(R);
[~,fit,Q]=W.BernsteinFit(H,3,R(:),weights,0,c);
assert(Q.ObjectiveGapBound<=c.CertificateTolerance&&max(abs(fit(:)-R(:)))<.01,'Actual toy Bernstein QP failed.');
% The corrected event-engine suite is a prerequisite for target-shift sensitivities.
E=RevisedCodes_14_SelfTests();assert(all(E.Passed),'Step14 invariants failed.');
Checks=table(["History K identity";"Historical-total reconstruction"; ...
 "Startup-only perturbation";"Actual training-preprocessed context fit"; ...
 "Context outcome-column exclusion";"Actual certified Bernstein fit";"Interruption engine invariants"], ...
 true(7,1),'VariableNames',{'Check','Passed'});disp(Checks);
end
