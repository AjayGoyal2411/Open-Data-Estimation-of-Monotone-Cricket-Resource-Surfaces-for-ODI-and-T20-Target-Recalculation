function c=RevisedCodes_16_00_Config(settings)
if nargin<1,settings=struct;end
c=struct('Version','16.1.0','ForceRebuild',false,'Thresholds',[1 10 20 30 50], ...
 'MinSubsetInnings',100,'MinEventInnings',200,'MaxEventGroups',5, ...
 'HistoryK',[5 20 50],'StartupMultipliers',[.8 1 1.2], ...
 'Degree',5,'Smoothing',.01,'ConstraintTolerance',2e-7);
assert(isstruct(settings)&&isscalar(settings));
for n=fieldnames(settings)',assert(isfield(c,n{1}),'Unknown Step16 setting %s.',n{1});c.(n{1})=settings.(n{1});end
validateattributes(c.ForceRebuild,{'logical'},{'scalar'});
for n={'MinSubsetInnings','MinEventInnings','MaxEventGroups','Degree'}
 validateattributes(c.(n{1}),{'numeric'},{'scalar','integer','positive'});
end
validateattributes(c.Thresholds,{'numeric'},{'vector','integer','positive'});
validateattributes(c.HistoryK,{'numeric'},{'vector','positive','finite'});
validateattributes(c.StartupMultipliers,{'numeric'},{'vector','positive','finite'});
validateattributes(c.Smoothing,{'numeric'},{'scalar','nonnegative','finite'});
end
