function Sensitivity=RevisedCodes_16_01_SensitivityAnalysis(settings)
if nargin<1,settings=struct;end
c=RevisedCodes_16_00_Config(settings);U=RevisedCodes_15_16_Utils;V=RevisedCodes_10_Utils;W=RevisedCodes_12_Utils;
I=U.Inputs();p15=fullfile(I.cfg.ProjectRoot,'paper_outputs_revisedcodes','step15','RevisedCodes_15_01_Result.mat');
assert(isfile(p15),'Run Step15 first.');z=load(p15,'Validation');D=z.Validation;U.Validate(D);
paths=unique([I.Paths;string(p15);D.Packages.Path],'stable');S=U.Signature("16",c,paths);
root=fullfile(I.cfg.ProjectRoot,'paper_outputs_revisedcodes','step16');out=fullfile(root,'RevisedCodes_16_01_Result.mat');
[reuse,Sensitivity]=V.Cache(out,'Sensitivity',S,c);if reuse,fprintf('Step16 valid cache reused.\n');return;end
Tests=RevisedCodes_16_SelfTests();[g,report]=V.Generation(root);
Scores=table;HistoryScores=table;TargetShifts=table;
Skipped=table(strings(0,1),strings(0,1),zeros(0,1),strings(0,1), ...
 'VariableNames',{'PackageID','Variant','TrainingInnings','Reason'});
Manifest=table;Fits=table;Groups=table;ExistingCurves=table;ExistingTargets=table;
rows=I.Empirical.Packages(I.Empirical.Packages.Cohort~="FULL_TRAIN",:);
for h=1:height(rows)
 row=rows(h,:);fprintf('Step16 %s: audited training states and fixed assessment population.\n',row.PackageID);
 [Ffit,Afit]=U.Data(I,row,"fit");[F,A]=U.Data(I,row,"assessment");
 z=load(row.Path,'Surface');BaseSurface=z.Surface;L=BaseSurface.TrainingLedger;
 dp=D.Packages.Path(D.Packages.PackageID==row.PackageID);assert(isscalar(dp));
 prior=load(dp,'Models','Index');j=find(prior.Index.ModelID=="Reference::mean_state_n30_count_l0");assert(isscalar(j));
 ref=prior.Models{j};
 for k=1:height(prior.Index)
  if prior.Index.Track(k)~="Resource",continue;end
  M=prior.Models{k};delta=M.Resource-ref.Resource;common=M.Supported&ref.Supported;
  curve=NaN;if any(common,'all'),curve=sqrt(mean(delta(common).^2));end
  [p,~,sup]=U.Predict(M,F); %#ok<ASGLU>
  ExistingCurves=[ExistingCurves;table(row.PackageID,row.Format,prior.Index.ModelID(k),prior.Index.Estimand(k), ...
   nnz(M.Supported),nnz(common),curve,sqrt(mean(delta(:).^2)),max(abs(delta(:))),mean(~sup), ...
   'VariableNames',{'PackageID','Format','ModelID','Estimand','SupportedCells','CommonSupportedCells', ...
   'CommonSupportCurveRMSE','WholeGridCurveRMSE','MaximumCurveShift','AssessmentUnsupportedFraction'})]; %#ok<AGROW>
  ExistingTargets=[ExistingTargets;targetShifts(M,ref,L.DeliveryRuns,row,prior.Index.ModelID(k))]; %#ok<AGROW>
 end
 clear prior;
 [Specs,Masks]=specifications(L,Afit,c,row.Format);
 n=height(A);m=height(Specs);Prediction=nan(n,m);Models=cell(m,1);LocalScores=table;
 baseModel=[];baseScore=NaN;baseSupport=[];Audit=A;Features=F; %#ok<NASGU>
 for k=1:m
  spec=Specs(k,:);keep=Masks{k};N=nnz(keep);
  if N<c.MinSubsetInnings
   Skipped=[Skipped;table(row.PackageID,spec.Variant,N,"INSUFFICIENT_TRAINING_INNINGS", ...
    'VariableNames',{'PackageID','Variant','TrainingInnings','Reason'})]; %#ok<AGROW>
   continue;
  end
  T=estimateSubset(Ffit,Afit,L,keep,row);G=T.Grid;
  C=table(spec.Variant,spec.Estimand,spec.MinMatches,spec.Weighting,0, ...
   'VariableNames',{'CandidateID','Estimand','MinMatches','Weighting','Lambda'});
  c10=RevisedCodes_10_00_Config;
  if ~any(G.MatchCount>=spec.MinMatches)
   Skipped=[Skipped;table(row.PackageID,spec.Variant,N,"NO_SUPPORTED_TRAINING_CELLS", ...
    'VariableNames',{'PackageID','Variant','TrainingInnings','Reason'})];continue; %#ok<AGROW>
  end
  [target,weights,supported]=V.WeightTarget(T,C,c10);cc=RevisedCodes_12_00_Config;
  [coef,R,Q,attempts]=W.BernsteinFit(T.Horizon,c.Degree,target,weights,c.Smoothing,cc);
  M=struct('Resource',R,'Supported',reshape(supported,size(R)),'DataWeights',reshape(weights,size(R)), ...
   'Horizon',T.Horizon,'FullStartMean',T.FullStartMean,'Coefficients',coef, ...
   'FitDiagnostics',Q,'OptimizerAttempts',attempts,'TrainingKeys',V.Key(T.TrainingLedger), ...
   'TrainingCutoffExclusive',row.TrainingCutoffExclusive,'Variant',spec.Variant,'ModelSelected',false,'PolicyFrozen',false);
  Models{k}=M;[p,raw,sup]=U.Predict(M,F);Prediction(:,k)=p;Cscore=U.Score(A,p,raw);Rscore=U.Summary(Cscore);
  if k==1,baseModel=M;baseScore=Rscore.EqualInningsRMSE;baseSupport=sup;end
  assert(~isempty(baseModel),'Baseline sensitivity could not be fitted.');
  delta=M.Resource-baseModel.Resource;common=M.Supported&baseModel.Supported;
  if any(common,'all'),distance=sqrt(mean(delta(common).^2));else,distance=NaN;end
  Rscore.PackageID=row.PackageID;Rscore.Format=row.Format;Rscore.Variant=spec.Variant;Rscore.Dimension=spec.Dimension;
  Rscore.TrainingInnings=N;Rscore.RemovedTrainingInnings=height(L)-N;Rscore.NormalizationRuns=T.FullStartMean;
  Rscore.SupportedCells=nnz(M.Supported);Rscore.SupportGained=nnz(M.Supported&~baseModel.Supported);
  Rscore.SupportLost=nnz(~M.Supported&baseModel.Supported);Rscore.CommonSupportCurveRMSE=distance;
  Rscore.WholeGridCurveRMSE=sqrt(mean(delta(:).^2));Rscore.AssessmentUnsupportedFraction=mean(~sup);
  Rscore.RMSEDifferenceFromBaseline=Rscore.EqualInningsRMSE-baseScore;
  Rscore.ScoreConversion="Resource times variant training mean; non-mean estimands exploratory";
  Rscore.MeanEstimand=ismember(spec.Estimand,["RunMeanState","RunMeanInnings"]);
  LocalScores=[LocalScores;Rscore]; %#ok<AGROW>
  Frow=table(row.PackageID,spec.Variant,spec.Estimand,spec.Weighting,spec.MinMatches,Q.ObjectiveGapBound,Q.ConstraintResidual, ...
   'VariableNames',{'PackageID','Variant','Estimand','Weighting','MinMatches','ObjectiveGapBound','ConstraintResidual'});
  Fits=[Fits;Frow]; %#ok<AGROW>
  Tshift=targetShifts(M,baseModel,BaseSurface.TrainingLedger.DeliveryRuns,row,spec.Variant);TargetShifts=[TargetShifts;Tshift]; %#ok<AGROW>
  GG=U.Subgroups(A,F,p,raw,baseSupport,20,M.Horizon);GG.PackageID=repmat(row.PackageID,height(GG),1);GG.Variant=repmat(spec.Variant,height(GG),1);Groups=[Groups;GG]; %#ok<AGROW>
  fprintf('Step16 %s %d/%d %s; N=%d, RMSE change %.4f runs.\n',row.PackageID,k,m,spec.Variant,N,Rscore.RMSEDifferenceFromBaseline);
 end
 Scores=[Scores;LocalScores]; %#ok<AGROW>
 path=fullfile(g,char(row.PackageID+"_SensitivityFits.mat"));
 save(path,'Models','Specs','Prediction','Audit','Features','LocalScores','-v7.3');
 Manifest=[Manifest;table(row.PackageID+"_resource",string(path),'VariableNames',{'PackageID','Path'})]; %#ok<AGROW>

 % Refit each history alternative, including imputation, scaling and coefficients.
 j=find(I.Forecast.Index.PackageID==row.PackageID,1);oldK=I.Forecast.Models{j}.HistoryK;
 H=BaseSurface.Horizon;mu=BaseSurface.FullStartMean;
 HM=cell(0,1);HI=table;HP=zeros(n,0);
 variants=table;
 for K=c.HistoryK
  for ablation=[3 5]
   variants=[variants;table(K,1,ablation,'VariableNames',{'K','StartupMultiplier','Ablation'})]; %#ok<AGROW>
  end
 end
 for mul=c.StartupMultipliers(c.StartupMultipliers~=1)
  for ablation=[3 5],variants=[variants;table(20,mul,ablation,'VariableNames',{'K','StartupMultiplier','Ablation'})];end %#ok<AGROW>
 end
 variants=[table(20,1,2,'VariableNames',{'K','StartupMultiplier','Ablation'});variants];
 for k=1:height(variants)
  v=variants(k,:);train=U.History(Ffit,oldK,v.K,v.StartupMultiplier);test=U.History(F,oldK,v.K,v.StartupMultiplier);
  M=U.ContextFit(train,Afit,H,mu,v.K,v.Ablation,.01);[p,raw]=U.Predict(M,test);
  Cscore=U.Score(A,p,raw);Q=U.Summary(Cscore);id="history_K"+string(v.K)+"_startup"+string(v.StartupMultiplier)+"_ablation"+string(v.Ablation);
  Q.PackageID=row.PackageID;Q.Format=row.Format;Q.Variant=id;Q.K=v.K;Q.StartupMultiplier=v.StartupMultiplier;Q.Ablation=v.Ablation;
  Q.TrainingStartupStates=nnz(Ffit.HistoryFormatN==0);Q.AssessmentStartupStates=nnz(F.HistoryFormatN==0);
  Q.StationarityResidual=M.FitDiagnostics.StationarityResidual;
  HistoryScores=[HistoryScores;Q];HM{end+1,1}=M;HP(:,end+1)=p; %#ok<AGROW>
  HI=[HI;table(id,v.K,v.StartupMultiplier,v.Ablation,'VariableNames',{'Variant','K','StartupMultiplier','Ablation'})]; %#ok<AGROW>
  fprintf('Step16 %s context %d/%d %s.\n',row.PackageID,k,height(variants),id);
 end
 path=fullfile(g,char(row.PackageID+"_HistoryFits.mat"));save(path,'HM','HI','HP','Audit','-v7.3');
 Manifest=[Manifest;table(row.PackageID+"_history",string(path),'VariableNames',{'PackageID','Path'})]; %#ok<AGROW>
end
% Existing degree/smoothing/reference/robust-estimand variants were scored on identical states in Step15.
ExistingGrid=readtable(fullfile(D.ReportDirectory,'15_FoldScores.csv'),'TextType','string');
ExistingGrid=ExistingGrid(ExistingGrid.Family~="Context",:);
% Restrict eligibility audit to development training split; no reserved/test outcomes exported.
L=I.Exceptional.Ledger;keep=L.Split=="train"&~L.CaseStudyReserved&L.InningsIndex==1;
Eligibility=L(keep,{'MatchID','InningsIndex','Format','LegalBalls','CompletionClass', ...
 'PrimaryModelEligible','RetiredHurtEvents','ExceedsNominal','ExceedsInitial','ObservedLengthRatio','MinimumLength60ODI30T20'});
Pending=table(["2023 validation";"Domestic versus international classification"; ...
 "Ambiguous/recovered/excess-delivery reintegration";"Gender and chase censoring"], ...
 ["Separate audited assessment context required; not silently introduced here"; ...
 "Raw source event labels are used. No domestic/international category is guessed from names"; ...
 "Existing audit and exclusion sensitivity retained; reintegration requires separate record-level reconstruction and provenance audit"; ...
 "Remain Steps17-18; not interpreted from this primary first-innings sensitivity"], ...
 'VariableNames',{'Requirement','PendingReason'});
Checks=table(["Training-only refits with fixed assessment states";"Length cutoffs separate from record integrity"; ...
 "New sparse support thresholds and weighting refits";"Non-mean estimands explicitly exploratory"; ...
 "Training-selected raw event/year subsets";"History shrinkage refits include preprocessing"; ...
 "History startup sensitivity touches zero-history states only";"Scenario shifts use identical scores and timelines"; ...
 "All Bernstein fits numerically certified";"Unresolved requirements disclosed"], ...
 [true(8,1);all(Fits.ObjectiveGapBound<=1e-6&Fits.ConstraintResidual<=c.ConstraintTolerance);true], ...
 'VariableNames',{'Check','Passed'});assert(all(Checks.Passed),'Step16 certification failed.');
U.Export(report,{{'16_SelfTests',Tests},{'16_GateChecks',Checks},{'16_RefitScores',Scores}, ...
 {'16_HistoryScores',HistoryScores},{'16_TargetShifts',TargetShifts},{'16_Certificates',Fits}, ...
 {'16_SubgroupScores',Groups},{'16_ExistingCandidateGrid',ExistingGrid},{'16_ExistingCurveDistances',ExistingCurves}, ...
 {'16_ExistingTargetShifts',ExistingTargets},{'16_EligibilityAudit',Eligibility}, ...
 {'16_SkippedVariants',Skipped},{'16_PendingRequirements',Pending}});
pub=[V.TableExport(I.cfg,"Results","T_R16_Sensitivity",Scores); ...
 V.TableExport(I.cfg,"Supplementary","T_S16_HistorySensitivity",HistoryScores); ...
 V.TableExport(I.cfg,"Supplementary","T_S16_TargetShifts",TargetShifts)];
fig=figure('Visible','off','Color','w','Position',[100 100 1200 720]);clean=onCleanup(@()close(fig)); %#ok<NASGU>
tiledlayout(2,2,'Padding','compact');
for fmt=["ODI","T20"]
 B=Scores(Scores.Format==fmt,:);nexttile;boxchart(categorical(B.Dimension),B.RMSEDifferenceFromBaseline);yline(0,':');ylabel('RMSE change (runs)');title(fmt+": training-only refits");xtickangle(25);
 nexttile;B=TargetShifts(TargetShifts.Format==fmt,:);boxchart(categorical(B.Scenario),B.TargetShift);yline(0,':');ylabel('Unrounded par shift (runs)');title(fmt+": synthetic policy sensitivity");xtickangle(25);
end
pub=[pub;W.FigureExport(I.cfg,"Results","F_M16_Sensitivity",fig,Scores, ...
 "Fold-specific sensitivity refits on fixed assessment populations. RMSE changes compare with the prespecified empirical-target degree-5 Bernstein baseline at support 30 and smoothing .01. Synthetic target shifts use common score grids and event histories. Non-mean estimands are exploratory. Event/year subsets are training-defined, not inferred international/domestic classes. No final policy is selected by these plots.",report)];
Sensitivity=struct('Stage',"16",'Status',"SENSITIVITY_RUN_COMPLETE_DECLARED_REQUIREMENTS_PENDING", ...
 'Checks',Checks,'Packages',Manifest,'Pending',Pending,'PolicyFrozen',false);
Sensitivity=V.Finish(I.cfg,'Sensitivity',out,S,g,report,Sensitivity,[pub;Manifest.Path]);
end

function [T,masks]=specifications(L,A,c,format)
V=RevisedCodes_10_Utils;n=height(L);allRows=true(n,1);masks={allRows};
T=spec("Baseline_n30","Baseline","RunMeanState","count",30);
for threshold=c.Thresholds
 if threshold==30,continue;end
 T=[T;spec("Support_n"+string(threshold),"Support","RunMeanState","count",threshold)];masks{end+1,1}=allRows; %#ok<AGROW>
end
for weighting=["innings","precision"]
 T=[T;spec("Weight_"+weighting,"Weighting","RunMeanState",weighting,30)];masks{end+1,1}=allRows; %#ok<AGROW>
end
for estimand=["RunMeanInnings","FractionMeanState","FractionMeanInnings","RunMedianState","RunTrimmed10State"]
 weighting="count";if contains(estimand,"Innings"),weighting="innings";end
 T=[T;spec("Estimand_"+estimand,"Estimand",estimand,weighting,30)];masks{end+1,1}=allRows; %#ok<AGROW>
end
thresholds=[30 60 90];if format=="T20",thresholds=[15 30 45];end
assert(ismember('LegalBalls',L.Properties.VariableNames),'Verified innings legal-ball lengths required.');
for b=thresholds
 T=[T;spec("MinimumBalls_"+string(b),"Length","RunMeanState","count",30)];masks{end+1,1}=L.LegalBalls>=b; %#ok<AGROW>
end
if ismember('RetiredHurtEvents',L.Properties.VariableNames)
 T=[T;spec("ExcludeRetirementInnings","Retirement","RunMeanState","count",30)];masks{end+1,1}=L.RetiredHurtEvents==0;
end
if ismember('ExceedsNominal',L.Properties.VariableNames)
 T=[T;spec("ExcludeExcessDeliveryInnings","ExcessDeliveries","RunMeanState","count",30)];masks{end+1,1}=~L.ExceedsNominal&~L.ExceedsInitial;
end
[~,first]=unique(V.Key(A),'stable');[ok,ix]=ismember(V.Key(L),V.Key(A(first,:)));assert(all(ok));events=string(A.EventName(first(ix)));
valid=~ismissing(events)&strlength(events)>0;[v,~,g]=unique(events(valid));count=accumarray(g,1);
B=table(v,count,'VariableNames',{'Event','N'});B=B(B.N>=c.MinEventInnings,:);B=sortrows(B,{'N','Event'},{'descend','ascend'});
if format=="T20"
 for j=1:min(c.MaxEventGroups,height(B))
  T=[T;spec("Event_"+B.Event(j),"EventSubset","RunMeanState","count",30)];masks{end+1,1}=valid&events==B.Event(j); %#ok<AGROW>
 end
end
years=year(L.Date);
for y=unique(years)'
 if nnz(years==y)<c.MinSubsetInnings,continue;end
 T=[T;spec("CalendarYear_"+string(y),"CalendarYear","RunMeanState","count",30)];masks{end+1,1}=years==y; %#ok<AGROW>
end
end

function T=spec(name,dimension,estimand,weighting,minMatches)
T=table(string(name),string(dimension),string(estimand),string(weighting),minMatches, ...
 'VariableNames',{'Variant','Dimension','Estimand','Weighting','MinMatches'});
end

function S=estimateSubset(F,A,L,keep,row)
V=RevisedCodes_10_Utils;L=L(keep,:);[valid,k]=ismember(V.Key(A),V.Key(L));
O=struct('Innings',uint32(k(valid)),'u',uint16(F.BallsRemaining(valid)), ...
 'w',uint8(F.WicketsInHand(valid)),'Y',double(A.RemainingRuns(valid)));
assert(all(L.Date<row.TrainingCutoffExclusive),'Sensitivity training cutoff violated.');
assert(isequal(accumarray(double(O.Innings),1,[height(L),1]),double(L.CachedPrimaryStates)),'Subset state counts changed.');
S=V.Estimate(O,L,row.Format,RevisedCodes_10_00_Config());S.PackageID=row.PackageID;
end

function T=targetShifts(M,B,scores,row,id)
U=RevisedCodes_14_Utils;c=RevisedCodes_14_00_Config;pm=U.DefaultPolicy(M,c);pb=U.DefaultPolicy(B,c);
scenarios=U.SyntheticScenarios(M.Horizon);values=round(quantile(double(scores),[.1 .25 .5 .75 .9]));
illustrative=160;if row.Format=="ODI",illustrative=275;end
values=[values(:);illustrative];labels=["q10";"q25";"q50";"q75";"q90";"illustrative"];
T=table;
for j=1:numel(scenarios)
 for k=1:numel(values)
  a=U.Apply(M,values(k),scenarios(j).First,scenarios(j).Second,pm);b=U.Apply(B,values(k),scenarios(j).First,scenarios(j).Second,pb);
  T=[T;table(row.PackageID,row.Format,id,scenarios(j).Name,labels(k),values(k), ...
   a.Target.SelectedUnroundedPar,b.Target.SelectedUnroundedPar, ...
   a.Target.SelectedUnroundedPar-b.Target.SelectedUnroundedPar,a.Target.WinningTarget-b.Target.WinningTarget, ...
   'VariableNames',{'PackageID','Format','Variant','Scenario','ScoreSource','FirstInningsScore', ...
   'VariantPar','BaselinePar','TargetShift','IntegerTargetShift'})]; %#ok<AGROW>
 end
end
end
