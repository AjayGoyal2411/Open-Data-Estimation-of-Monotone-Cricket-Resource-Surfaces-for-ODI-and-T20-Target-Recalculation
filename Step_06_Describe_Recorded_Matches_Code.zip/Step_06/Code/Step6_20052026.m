%% Step 5
%% AllFiguresTablesFromRetainedFiles (REVISED v7 — Format grouping + strict LO filter)
% Fixes requested:
% 1) Fig3_FormatDistribution: merge mdm, odm, it20 into "non-standard / excluded"
% 2) Limited-overs subset: STRICTLY keep only odi/t20/t20i (exclude mdm/odm/it20)
%
% Notes:
% - Keeps your datastore TextscanFormats fix (read everything as text).
% - Fig7/Fig8 logic unchanged (anchor truth).

clc; clear;

%% ---------------- USER SETTINGS ----------------
inFolder  = 'D:\VihaanProject1\final_retained_dataset';
outRoot   = 'D:\VihaanProject1\paper_outputs';

f_match   = fullfile(inFolder,'match_info_all_noCompetition.csv');
f_ball    = fullfile(inFolder,'ball_by_ball_all.csv');
f_evM     = fullfile(inFolder,'JSON_EventMaster_FromMatchIDs.csv');
f_evC     = fullfile(inFolder,'JSON_EventCounts_FromMatchIDs.csv');

assert(isfile(f_match), 'Missing: %s', f_match);
assert(isfile(f_ball),  'Missing: %s', f_ball);
assert(isfile(f_evM),   'Missing: %s', f_evM);
assert(isfile(f_evC),   'Missing: %s', f_evC);

outFig = fullfile(outRoot,'figures');
outTab = fullfile(outRoot,'tables');
outLog = fullfile(outRoot,'runlog');
if ~exist(outFig,'dir'), mkdir(outFig); end
if ~exist(outTab,'dir'), mkdir(outTab); end
if ~exist(outLog,'dir'), mkdir(outLog); end

logFile = fullfile(outLog, sprintf('RunLog_%s.txt', datestr(now,'yyyymmdd_HHMMSS')));
diary(logFile); diary on;

fprintf('Logging to: %s\n', logFile);
fprintf('Input folder: %s\n', inFolder);
fprintf('Output root : %s\n\n', outRoot);

%% ---------------- READ TABLES ----------------
fprintf('Reading match_info...\n');
Tm  = readtable(f_match, 'TextType','string');

fprintf('Reading JSON_EventMaster...\n');
Tev = readtable(f_evM, 'TextType','string');

fprintf('Reading JSON_EventCounts...\n');
TevC = readtable(f_evC, 'TextType','string');

% Normalize MatchID types
Tm.MatchID  = normalizeID(Tm.MatchID);
Tev.MatchID = normalizeID(Tev.MatchID);

% Ensure EventName exists in Tev
if ~ismember("EventName", string(Tev.Properties.VariableNames))
    Tev.EventName = repmat("UNKNOWN", height(Tev), 1);
else
    Tev.EventName = string(Tev.EventName);
    Tev.EventName(ismissing(Tev.EventName) | strlength(strtrim(Tev.EventName))==0) = "UNKNOWN";
end

keepEvCols = intersect(["MatchID","EventName","MatchType","Gender","Season","StartDateRaw","Venue","TeamsRaw"], ...
                       string(Tev.Properties.VariableNames), 'stable');
Tev2 = Tev(:, keepEvCols);

fprintf('Joining match_info + JSON event master...\n');
Tmeta = outerjoin(Tm, Tev2, 'Keys','MatchID', 'MergeKeys',true, 'Type','left');

fmtVar    = pickVar(Tmeta, ["Format","MatchType","MatchType_Tev2","MatchType_Tev"]);
genderVar = pickVar(Tmeta, ["Gender","Gender_Tm","Gender_Tev2","Gender_Tev"]);

% Canonical format
if fmtVar == ""
    Tmeta.FormatCanon = repmat("unknown", height(Tmeta), 1);
else
    Tmeta.FormatCanon = lower(strtrim(string(Tmeta.(fmtVar))));
    Tmeta.FormatCanon(ismissing(Tmeta.FormatCanon) | strlength(strtrim(Tmeta.FormatCanon))==0) = "unknown";
end

% Canonical gender
if genderVar == ""
    Tmeta.GenderCanon = repmat("unknown", height(Tmeta), 1);
else
    Tmeta.GenderCanon = lower(strtrim(string(Tmeta.(genderVar))));
    Tmeta.GenderCanon(ismissing(Tmeta.GenderCanon) | strlength(strtrim(Tmeta.GenderCanon))==0) = "unknown";
end

% -------- FORMAT GROUPING (for Fig3) --------
% Merge mdm, odm, it20 -> "non-standard / excluded"
Tmeta.FormatGroup = Tmeta.FormatCanon;
nonStd = ismember(Tmeta.FormatCanon, ["mdm","odm","it20"]);
Tmeta.FormatGroup(nonStd) = "non-standard / excluded";

% Keep unknown separate (QC)
unk = (Tmeta.FormatCanon=="unknown");
Tmeta.FormatGroup(unk) = "unknown";

% Year extraction
startDateVar = pickVar(Tmeta, ["StartDate","StartDate_Tm","StartDate_match_info_all_noCompetition"]);
if startDateVar == ""
    startCol = strings(height(Tmeta),1);
else
    startCol = string(Tmeta.(startDateVar));
end

Tmeta.Year = nan(height(Tmeta),1);
Tmeta.Year = extractYearSmart(startCol);

sdrVar = pickVar(Tmeta, ["StartDateRaw","StartDateRaw_Tev2","StartDateRaw_Tev"]);
if sdrVar ~= ""
    y2 = extractYearSmart(Tmeta.(sdrVar));
    Tmeta.Year(isnan(Tmeta.Year)) = y2(isnan(Tmeta.Year));
end

seasonVar = pickVar(Tmeta, ["Season","Season_Tev2","Season_Tev","Season_Tm"]);
if seasonVar ~= ""
    y3 = extractYearSmart(Tmeta.(seasonVar));
    Tmeta.Year(isnan(Tmeta.Year)) = y3(isnan(Tmeta.Year));
end

% -------- Limited-overs STRICT --------
% Keep only odi, t20, t20i (exclude mdm/odm/it20)
isLO = ismember(Tmeta.FormatCanon, ["odi","t20","t20i"]);
Tlo  = Tmeta(isLO, :);

fprintf('Rows: match_info=%d | event_master=%d | joined=%d | limited-overs(STRICT)=%d\n\n', ...
    height(Tm), height(Tev), height(Tmeta), height(Tlo));

%% ---------------- SUMMARY TABLES ----------------
fprintf('Writing summary tables...\n');

S1 = table();
S1.TotalMatches_All          = height(Tmeta);
S1.TotalMatches_LimitedOvers = height(Tlo);
S1.UniqueCompetitions        = numel(unique(string(Tmeta.EventName)));
S1.YearMin = min(Tmeta.Year, [], 'omitnan');
S1.YearMax = max(Tmeta.Year, [], 'omitnan');
writetable(S1, fullfile(outTab,'TableS1_DatasetOverview.csv'));

TevC.EventName = string(TevC.EventName);
TevC = sortrows(TevC, "MatchCount", "descend");
writetable(TevC, fullfile(outTab,'TableS2_TopCompetitions_All.csv'));

S3 = groupsummary(Tmeta, ["FormatCanon","GenderCanon"]);
S3 = renamevars(S3, "GroupCount", "MatchCount");
writetable(S3, fullfile(outTab,'TableS3_FormatGenderBreakdown_All.csv'));

S3b = groupsummary(Tlo, ["FormatCanon","GenderCanon"]);
S3b = renamevars(S3b, "GroupCount", "MatchCount");
writetable(S3b, fullfile(outTab,'TableS3b_FormatGenderBreakdown_LimitedOvers.csv'));

S4 = table();
S4.Missing_EventName = sum(string(Tmeta.EventName)=="UNKNOWN");
S4.Missing_Year      = sum(isnan(Tmeta.Year));
writetable(S4, fullfile(outTab,'TableS4_MissingnessQC.csv'));

fprintf('Tables written to: %s\n\n', outTab);

%% ---------------- FIG2–FIG6 ----------------
fprintf('Fig2...\n');
topN = 20;
TcTop = TevC(1:min(topN,height(TevC)), :);

fig = figure('Visible','off');
bar(TcTop.MatchCount); grid on;
xlabel('Competition (Top)'); ylabel('Match count');
title(sprintf('Top %d Competitions by Match Count (JSON)', height(TcTop)));
set(gca,'XTick',1:height(TcTop),'XTickLabel',TcTop.EventName,'XTickLabelRotation',45);
set(gcf,'Color','w');
exportgraphics(fig, fullfile(outFig,'Fig2_TopCompetitions.png'), 'Resolution',300);
close(fig);

fprintf('Fig3...\n');
Tf = groupsummary(Tmeta, "FormatGroup");
Tf = renamevars(Tf, "GroupCount", "MatchCount");
Tf = sortrows(Tf, "MatchCount", "descend");

fig = figure('Visible','off');
bar(Tf.MatchCount); grid on;
xlabel('Match format (grouped)'); ylabel('Match count');
title('Match Format Distribution (Grouped)');
set(gca,'XTick',1:height(Tf),'XTickLabel',Tf.FormatGroup);
set(gcf,'Color','w');
exportgraphics(fig, fullfile(outFig,'Fig3_FormatDistribution.png'), 'Resolution',300);
close(fig);
writetable(Tf, fullfile(outTab,'Table_Fig3_FormatDistribution.csv'));

fprintf('Fig4...\n');
Ty = Tmeta(~isnan(Tmeta.Year), :);
Ty = groupsummary(Ty, "Year");
Ty = renamevars(Ty, "GroupCount", "MatchCount");
Ty = sortrows(Ty, "Year", "ascend");

fig = figure('Visible','off');
plot(Ty.Year, Ty.MatchCount, 'LineWidth',1.8); grid on;
xlabel('Year'); ylabel('Matches');
title('Matches by Year (All)');
set(gcf,'Color','w');
exportgraphics(fig, fullfile(outFig,'Fig4_MatchesByYear.png'), 'Resolution',300);
close(fig);
writetable(Ty, fullfile(outTab,'Table_Fig4_MatchesByYear.csv'));

fprintf('Fig5...\n');
cityVar  = pickVar(Tmeta, ["City","City_Tm","City_match_info_all_noCompetition"]);
venueVar = pickVar(Tmeta, ["Venue","Venue_Tev2","Venue_Tev","Venue_Tm"]);

if cityVar ~= ""
    v = string(Tmeta.(cityVar));
    v(ismissing(v) | strlength(strtrim(v))==0) = "UNKNOWN";
    Tv = groupsummary(table(v,'VariableNames',{'City'}), "City");
    Tv = renamevars(Tv, "GroupCount", "MatchCount");
    Tv = sortrows(Tv, "MatchCount", "descend");
    TvTop = Tv(1:min(20,height(Tv)), :);

    fig = figure('Visible','off');
    bar(TvTop.MatchCount); grid on;
    xlabel('City (Top)'); ylabel('Match count');
    title('Top Cities by Match Count');
    set(gca,'XTick',1:height(TvTop),'XTickLabel',TvTop.City,'XTickLabelRotation',45);
    set(gcf,'Color','w');
    exportgraphics(fig, fullfile(outFig,'Fig5_TopCities.png'), 'Resolution',300);
    close(fig);

    writetable(Tv, fullfile(outTab,'Table_Fig5_CityCounts.csv'));

elseif venueVar ~= ""
    v = string(Tmeta.(venueVar));
    v(ismissing(v) | strlength(strtrim(v))==0) = "UNKNOWN";
    Tv = groupsummary(table(v,'VariableNames',{'Venue'}), "Venue");
    Tv = renamevars(Tv, "GroupCount", "MatchCount");
    Tv = sortrows(Tv, "MatchCount", "descend");
    TvTop = Tv(1:min(20,height(Tv)), :);

    fig = figure('Visible','off');
    bar(TvTop.MatchCount); grid on;
    xlabel('Venue (Top)'); ylabel('Match count');
    title('Top Venues by Match Count');
    set(gca,'XTick',1:height(TvTop),'XTickLabel',TvTop.Venue,'XTickLabelRotation',45);
    set(gcf,'Color','w');
    exportgraphics(fig, fullfile(outFig,'Fig5_TopVenues.png'), 'Resolution',300);
    close(fig);

    writetable(Tv, fullfile(outTab,'Table_Fig5_VenueCounts.csv'));
else
    fprintf('Fig5 skipped (no City/Venue column found).\n');
end

fprintf('Fig6...\n');
fig = figure('Visible','off');
plot(TevC.MatchCount, 'LineWidth',1.8); grid on;
xlabel('Competition rank (sorted)'); ylabel('Match count');
title('Competition Long-Tail (Sorted by Match Count)');
set(gcf,'Color','w');
exportgraphics(fig, fullfile(outFig,'Fig6_CompetitionLongTail.png'), 'Resolution',300);
close(fig);

%% ---------------- BALL-BY-BALL STREAMING (Fig7–Fig8) ----------------
fprintf('Reading ball_by_ball via datastore...\n');

loIDs = unique(normalizeID(Tlo.MatchID));
loIDs = loIDs(~ismissing(loIDs) & strlength(strtrim(loIDs))>0);

idSet = java.util.HashSet();
for i = 1:numel(loIDs)
    idSet.add(char(loIDs(i))); %#ok<CHARTEN>
end
fprintf('Limited-overs MatchIDs in set: %d\n', idSet.size());

% Create datastore
ds = tabularTextDatastore(f_ball, ...
    'TextType','string', ...
    'ReadVariableNames',true, ...
    'Delimiter',',');

% IMPORTANT FIX: TextscanFormats must match ds.VariableNames length
allVars = string(ds.VariableNames);
fmtAll  = repmat({'%q'}, 1, numel(allVars));   % read everything as quoted text
ds.TextscanFormats = fmtAll;

% Then select only needed columns
wantVars = ["MatchID","OverNumber","IsLegalBall","TotalRuns","IsWicket","WicketsLost"];
ds.SelectedVariableNames = intersect(wantVars, allVars, 'stable');

ds.ReadSize = 200000;

maxOver = 50;
maxW    = 10;

sumRuns_byOver  = zeros(maxOver+1,1);
cntLegal_byOver = zeros(maxOver+1,1);
sumWkt_byOver   = zeros(maxOver+1,1);

nHeat = (maxOver+1)*(maxW+1);
sumRuns_heat_lin = zeros(nHeat,1);
cnt_heat_lin     = zeros(nHeat,1);

histRuns = zeros(11,1);

Nread = 0; Nkeep = 0;
reset(ds);
tBall = tic;

while hasdata(ds)
    T = read(ds);
    Nread = Nread + height(T);
    if isempty(T), continue; end

    mid = normalizeID(T.MatchID);
    goodID = ~ismissing(mid) & strlength(strtrim(mid))>0;

    keep = false(height(T),1);
    idxGood = find(goodID);
    for k = 1:numel(idxGood)
        ii = idxGood(k);
        keep(ii) = idSet.contains(char(mid(ii)));
    end

    T = T(keep,:);
    Nkeep = Nkeep + height(T);
    if isempty(T), continue; end

    ov    = str2double(string(T.OverNumber));
    wl    = str2double(string(T.WicketsLost));
    legal = str2double(string(T.IsLegalBall)) ~= 0;
    runs  = str2double(string(T.TotalRuns));
    wk    = str2double(string(T.IsWicket)) ~= 0;

    okNum = isfinite(ov) & isfinite(wl) & isfinite(runs);
    if ~any(okNum), continue; end

    ov = ov(okNum);
    wl = wl(okNum);
    legal = legal(okNum);
    runs = runs(okNum);
    wk = wk(okNum);

    ovBin = min(max(floor(ov),0),maxOver);
    wlBin = min(max(floor(wl),0),maxW);

    ok = legal & isfinite(ovBin) & isfinite(runs);
    if any(ok)
        o = ovBin(ok) + 1;
        r = runs(ok);
        w = wk(ok);

        sumRuns_byOver  = sumRuns_byOver  + accumarray(o, r, [maxOver+1,1], @sum, 0);
        cntLegal_byOver = cntLegal_byOver + accumarray(o, 1, [maxOver+1,1], @sum, 0);
        sumWkt_byOver   = sumWkt_byOver   + accumarray(o, w, [maxOver+1,1], @sum, 0);

        r2 = min(max(round(r),0),10);
        histRuns = histRuns + accumarray(r2+1, 1, [11,1], @sum, 0);
    end

    ok2 = legal & isfinite(ovBin) & isfinite(wlBin) & isfinite(runs);
    if any(ok2)
        o2 = ovBin(ok2) + 1;%%
        w2 = wlBin(ok2) + 1;
        r2 = runs(ok2);

        idxLin = sub2ind([maxOver+1, maxW+1], o2, w2);
        sumRuns_heat_lin = sumRuns_heat_lin + accumarray(idxLin, r2, [nHeat,1], @sum, 0);
        cnt_heat_lin     = cnt_heat_lin     + accumarray(idxLin, 1,  [nHeat,1], @sum, 0);
    end

    if mod(Nread, 2e6) < height(T)
        fprintf('Ball rows read=%d | kept=%d | elapsed=%.1fs\n', Nread, Nkeep, toc(tBall));
    end
end

fprintf('Ball streaming done. Read=%d | kept=%d | elapsed=%.1fs\n\n', Nread, Nkeep, toc(tBall));

sumRuns_heat = reshape(sumRuns_heat_lin, [maxOver+1, maxW+1]);
cnt_heat     = reshape(cnt_heat_lin,     [maxOver+1, maxW+1]);

%% ---------------- FIG7 ----------------
fprintf('Fig7...\n');
meanRunsOver = sumRuns_byOver ./ max(cntLegal_byOver,1);
wktRateOver  = sumWkt_byOver  ./ max(cntLegal_byOver,1);

fig = figure('Visible','off');
plot(0:maxOver, meanRunsOver, 'LineWidth',1.8); grid on;
xlabel('Over number (0-indexed)'); ylabel('Mean runs per legal ball');
title('Ball-level Scoring Rate vs Over (Limited-overs only)');
set(gcf,'Color','w');
exportgraphics(fig, fullfile(outFig,'Fig7A_MeanRunsPerBall_vs_Over.png'), 'Resolution',300);
close(fig);

fig = figure('Visible','off');
plot(0:maxOver, wktRateOver, 'LineWidth',1.8); grid on;
xlabel('Over number (0-indexed)'); ylabel('Wicket probability per legal ball');
title('Wicket Rate vs Over (Limited-overs only)');
set(gcf,'Color','w');
exportgraphics(fig, fullfile(outFig,'Fig7B_WicketRate_vs_Over.png'), 'Resolution',300);
close(fig);

fig = figure('Visible','off');
bar(0:10, histRuns); grid on;
xlabel('Total runs on a legal ball (clamped 0–10)'); ylabel('Count');
title('Distribution of Total Runs per Legal Ball (Limited-overs only)');
set(gcf,'Color','w');
exportgraphics(fig, fullfile(outFig,'Fig7C_RunDistribution_PerBall.png'), 'Resolution',300);
close(fig);

T7 = table((0:maxOver)', cntLegal_byOver, meanRunsOver, wktRateOver, ...
    'VariableNames', {'Over','LegalBallCount','MeanRunsPerBall','WicketProbPerBall'});
writetable(T7, fullfile(outTab,'Table_Fig7_OverwiseBallStats.csv'));

T7h = table((0:10)', histRuns, 'VariableNames', {'TotalRunsPerBall','Count'});
writetable(T7h, fullfile(outTab,'Table_Fig7_RunHistogram.csv'));

%% ---------------- FIG8 ----------------
fprintf('Fig8...\n');
meanHeat = sumRuns_heat ./ max(cnt_heat, 1);

fig = figure('Visible','off');
imagesc(0:maxW, 0:maxOver, meanHeat);
set(gca,'YDir','normal');
colorbar; grid on;
xlabel('Wickets lost (0–10)');
ylabel('Over number (0-indexed)');
title('Mean Runs per Legal Ball by Over and Wickets Lost (Limited-overs only)');
set(gcf,'Color','w');
exportgraphics(fig, fullfile(outFig,'Fig8_Heatmap_MeanRuns_by_Over_Wickets.png'), 'Resolution',300);
close(fig);

[OO, WW] = ndgrid(0:maxOver, 0:maxW);
Theat = table(OO(:), WW(:), meanHeat(:), cnt_heat(:), ...
    'VariableNames', {'Over','WicketsLost','MeanRunsPerBall','LegalBallCount'});
writetable(Theat, fullfile(outTab,'Table_Fig8_HeatmapData.csv'));

%% ---------------- DONE ----------------
fprintf('\nAll figures written to: %s\n', outFig);
fprintf('All tables  written to: %s\n', outTab);
fprintf('DONE.\n');

diary off;

%% ======================= LOCAL HELPERS =======================
function name = pickVar(T, candidates)
vars = string(T.Properties.VariableNames);
name = "";
for c = candidates
    if any(vars == c)
        name = c;
        return;
    end
end
end

function id = normalizeID(x)
if iscell(x), x = string(x); end
if isnumeric(x)
    id = string(round(x));
else
    id = string(x);
    id = strtrim(id);
    id(ismissing(id)) = "";
    id = regexprep(id, '\.0$', '');
end
end

function y = extractYearSmart(s)
if isdatetime(s)
    y = double(year(s));
    return;
end
if iscell(s), s = string(s); else, s = string(s); end
y = nan(size(s));
miss = ismissing(s) | strlength(strtrim(s))==0;
idx = find(~miss);
for k = 1:numel(idx)
    i = idx(k);
    txt = char(s(i));
    m = regexp(txt, '(\d{4})', 'match');
    if ~isempty(m)
        yy = str2double(m{end});
        if ~isnan(yy) && yy >= 1800 && yy <= 2100
            y(i) = yy;
        end
    end
end
end
