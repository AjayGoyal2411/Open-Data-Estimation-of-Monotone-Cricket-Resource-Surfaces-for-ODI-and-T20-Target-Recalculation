function Results=RevisedCodes_14_RunAll(settings)
if nargin<1,settings=struct;end
Results=struct;Results.SelfTests=RevisedCodes_14_SelfTests;
Results.Engine=RevisedCodes_14_01_InterruptionEngine(settings);
assert(all(Results.SelfTests.Passed)&&all(Results.Engine.Checks.Passed),'Step14 incomplete.');
fprintf('Step14 COMPLETE. Synthetic engine passed; reserved real-case evaluation remains pending.\n');
end
