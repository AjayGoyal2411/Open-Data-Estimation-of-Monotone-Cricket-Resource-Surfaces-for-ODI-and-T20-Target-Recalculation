function Checks=RevisedCodes_14_SelfTests
U=RevisedCodes_14_Utils;c=RevisedCodes_14_00_Config;H=120;[u,w]=ndgrid(0:H,0:10);
M=struct('Resource',(u/H).*(w/10),'Horizon',H,'FullStartMean',160);P=U.DefaultPolicy(M,c);Z=U.Events();
assert(istable(Z)&&height(Z)==0,'Empty event factory must return a table.');
assert(istable(U.PolicySpecification())&&istable(U.Coverage()),'Step14 report factories must return tables.');
[A,L]=U.Timeline(M,Z,1);assert(A==1&&isempty(L),'Empty timeline failed.');
E=U.Events("P","PreStartReduction",0,10,H,90,false);[A,L]=U.Timeline(M,E,2);
assert(abs(A-.75)<1e-12&&abs(L.ResourceLoss-.25)<1e-12,'Prestart reduction failed.');
E=U.Events("I","Interruption",30,8,H,90,false);A=U.Timeline(M,E,1);assert(abs(A-.8)<1e-12,'Mid-innings loss failed.');
E=U.Events(["M1","M2"],["Interruption","Interruption"],[30,45],[8,6],[120,90],[90,60],[false,false]);
A=U.Timeline(M,E,1);assert(abs(A-.65)<1e-12,'Multiple interruptions failed.');
E=U.Events("T","Termination",60,5,H,H,true);A=U.Timeline(M,E,2);assert(abs(A-.75)<1e-12,'Termination failed.');
T=U.Target(160,1,1,P);assert(T.SelectedUnroundedPar==160&&T.IntegerParScore==160&&T.WinningTarget==161,'Equal-resource target failed.');
T=U.Target(160,1,.75,P);assert(T.SelectedUnroundedPar==120&&T.WinningTarget==121,'Proportional target failed.');
T=U.Target(150,.75,1,P);assert(T.AdditiveAlternative==190&&T.RatioAlternative==200&&T.SelectedUnroundedPar==190,'Greater-resource alternatives failed.');
bad=false;try,U.Target(100,0,.5,P);catch,bad=true;end;assert(bad,'Zero A1 was not rejected.');
bad=false;try,E=U.Events("A","Interruption",10,8,H,H+1,false);U.Timeline(M,E,1);catch,bad=true;end
assert(bad,'Allocation increase was not rejected.');
bad=false;try,E=U.Events("O","NormalAllOut",80,0,H,H,true);U.Timeline(M,E,1);catch,bad=true;end
assert(bad,'Normal all-out was incorrectly treated as a weather event.');
Checks=table(["No interruption/equal resources";"Prestart reduction"; ...
 "First-innings interruption";"Multiple interruptions";"Terminal zero resource"; ...
 "Fewer-resource proportional rule";"Greater-resource additive rule"; ...
 "Ratio sensitivity retained";"Par/target/tie convention";"Zero A1 rejected"; ...
 "Allocation increase rejected";"Training-derived G definition"; ...
 "All-out excluded from weather losses";"No context target variant"],true(14,1), ...
 'VariableNames',{'Check','Passed'});
disp(Checks);fprintf('Step14 interruption-engine self-tests passed.\n');
end
