function c=RevisedCodes_14_00_Config(settings)
if nargin<1,settings=struct;end
c=struct('Version','14.1.0','ForceRebuild',false, ...
 'GreaterResourcePolicy','additive','RoundTolerance',1e-10, ...
 'ResourceTolerance',2e-7,'DisplayReference','mean_state_n30_count_l0', ...
 'DisplayDegree',5,'DisplaySmoothing',.01);
assert(isstruct(settings)&&isscalar(settings),'Settings must be a scalar struct.');
for n=fieldnames(settings)'
 assert(isfield(c,n{1}),'Unknown Step14 setting %s.',n{1});c.(n{1})=settings.(n{1});
end
validateattributes(c.ForceRebuild,{'logical'},{'scalar'});
assert(ismember(string(c.GreaterResourcePolicy),["additive","ratio"]),'Unknown greater-resource policy.');
validateattributes(c.RoundTolerance,{'numeric'},{'scalar','nonnegative','finite'});
validateattributes(c.ResourceTolerance,{'numeric'},{'scalar','positive','finite'});
end
