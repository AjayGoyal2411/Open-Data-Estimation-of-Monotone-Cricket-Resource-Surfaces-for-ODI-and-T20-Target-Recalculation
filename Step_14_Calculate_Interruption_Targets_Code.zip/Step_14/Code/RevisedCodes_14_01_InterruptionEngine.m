function Engine=RevisedCodes_14_01_InterruptionEngine(settings)
if nargin<1,settings=struct;end
c=RevisedCodes_14_00_Config(settings);U=RevisedCodes_14_Utils;V=RevisedCodes_10_Utils;W=RevisedCodes_12_Utils;U13=RevisedCodes_13_Utils;
[cfg,C,F,~,~,base]=U13.Inputs();
result13=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step13','RevisedCodes_13_01_Result.mat');
assert(isfile(result13),'Run completed Step13 before Step14.');z=load(result13,'Diagnostics');D=z.Diagnostics;
assert(all(D.Checks.Passed)&&isfile(D.PackagePath)&&isfile(result13),'Completed Step13 result required.');
assert(isequal(D.Signature.Sources,V.Stamps(D.Signature.Sources.Path)),'Step13 source changed.');
for n=1:height(D.Signature.CodeFiles)
 assert(D.Signature.CodeFiles.Content(n)==string(fileread(D.Signature.CodeFiles.Path(n))),'Step13 code changed after its result was generated.');
end
paths=unique([base;string(result13);D.PackagePath],'stable');S=U.Signature("14_01",c,paths);
root=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step14');out=fullfile(root,'RevisedCodes_14_01_Result.mat');
[reuse,Engine]=V.Cache(out,'Engine',S,c);if reuse,fprintf('14_01 valid cache reused.\n');return;end
[g,report]=V.Generation(root);Display=U13.DisplayModels(C,F,c);Targets=table;Accounting=table;Policies=table;
for j=1:height(Display)
 d=Display(j,:);if d.Family=="Compact",Q=C.Package;else,Q=F.Package;end
 M=Q.Models{d.Index};P=U.DefaultPolicy(M,c);scenarios=U.SyntheticScenarios(M.Horizon);
 score=160;if d.Format=="ODI",score=275;end
 Policies=[Policies;table(d.Format,d.Family,d.ModelID,M.FullStartMean,P.GreaterResourcePolicy, ...
  string(P.GainSource),P.FirstInningsAdjustmentRuns,string(P.FirstInningsScoreBasis), ...
  'VariableNames',{'Format','Family','ModelID','GainRunsPerFullResource', ...
  'GreaterResourcePolicy','GainSource','DeclaredScoreAdjustment','FirstInningsScoreBasis'})]; %#ok<AGROW>
 for q=1:numel(scenarios)
  X=U.Apply(M,score,scenarios(q).First,scenarios(q).Second,P);T=X.Target;originalNames=string(T.Properties.VariableNames);
  T.Format=repmat(d.Format,height(T),1);T.Family=repmat(d.Family,height(T),1);
  T.ModelID=repmat(d.ModelID,height(T),1);T.Scenario=repmat(scenarios(q).Name,height(T),1);
  T.ScenarioDescription=repmat(scenarios(q).Description,height(T),1);
  T.A1=repmat(X.A1,height(T),1);T.A2=repmat(X.A2,height(T),1);
  T=T(:,["Format","Family","ModelID","Scenario","ScenarioDescription","A1","A2",originalNames]);
  % Remove duplicate resource columns retained under their descriptive policy names.
  T(:,{'FirstInningsAllocatedResource','SecondInningsAllocatedResource'})=[];
  Targets=[Targets;T]; %#ok<AGROW>
  L=X.Accounting;
  if ~isempty(L)
   L.Format=repmat(d.Format,height(L),1);L.Family=repmat(d.Family,height(L),1);
   L.ModelID=repmat(d.ModelID,height(L),1);L.Scenario=repmat(scenarios(q).Name,height(L),1);
   L=L(:,["Format","Family","ModelID","Scenario",string(L.Properties.VariableNames(1:end-4))]);
   Accounting=[Accounting;L]; %#ok<AGROW>
  end
 end
end
assert(all(Targets.IntegerParScore+1==Targets.WinningTarget),'Par/target invariant failed.');
equal=Targets.Branch=="Equal resources";
assert(all(abs(Targets.SelectedUnroundedPar(equal)-Targets.EffectiveFirstInningsScore(equal))<=c.ResourceTolerance),'Equal-resource invariant failed.');
fewer=Targets.Branch=="Fewer second-innings resources";
assert(all(abs(Targets.SelectedUnroundedPar(fewer)-Targets.RatioAlternative(fewer))<=c.ResourceTolerance),'Fewer-resource invariant failed.');
greater=Targets.Branch=="Greater second-innings resources";
expectedGreater=Targets.RatioAlternative(greater);
if string(c.GreaterResourcePolicy)=="additive",expectedGreater=Targets.AdditiveAlternative(greater);end
greaterPassed=all(abs(Targets.SelectedUnroundedPar(greater)-expectedGreater)<=c.ResourceTolerance);
assert(greaterPassed,'Selected greater-resource branch invariant failed.');
Policy=U.PolicySpecification();Coverage=U.Coverage();
Checks=table(["Every event has before/after accounting";"Resources remain in [0,1]"; ...
 "Event losses are nonnegative";"Par plus one equals target";"Equal-resource identity"; ...
 "Fewer-resource proportional identity";"Greater-resource selected identity"; ...
 "Both greater-resource alternatives reported";"G is model training mean"; ...
 "Synthetic timelines only";"No context variant";"Policy not frozen"], ...
 [all(Accounting.ResourceLoss>=-c.ResourceTolerance);all(Targets.A1>=0&Targets.A1<=1&Targets.A2>=0&Targets.A2<=1); ...
 all(Accounting.ResourceLoss>=-c.ResourceTolerance);all(Targets.IntegerParScore+1==Targets.WinningTarget); ...
 all(abs(Targets.SelectedUnroundedPar(equal)-Targets.EffectiveFirstInningsScore(equal))<=c.ResourceTolerance); ...
 all(abs(Targets.SelectedUnroundedPar(fewer)-Targets.RatioAlternative(fewer))<=c.ResourceTolerance); ...
 greaterPassed; ...
 all(isfinite(Targets.AdditiveAlternative)&isfinite(Targets.RatioAlternative)); ...
 all(Policies.GainRunsPerFullResource>0);true;true;true], ...
 'VariableNames',{'Check','Passed'});
assert(all(Checks.Passed),'Step14 gate failed.');
items={{'14_01_TargetScenarios',Targets},{'14_02_EventAccounting',Accounting}, ...
 {'14_03_ModelPolicies',Policies},{'14_04_PolicySpecification',Policy}, ...
 {'14_05_ReviewerEditorCoverage',Coverage},{'14_06_GateChecks',Checks}};
for n=1:numel(items)
 pair=items{n};
 assert(istable(pair{2}),'Report %s must be a table; received %s.',pair{1},class(pair{2}));
end
for n=1:numel(items)
 pair=items{n};writetable(pair{2},fullfile(report,[pair{1} '.csv']));
end
pub=[V.TableExport(cfg,"Methodology","T_M14_01_InterruptionPolicy",Policy); ...
 V.TableExport(cfg,"Results","T_R14_01_SyntheticTargetScenarios",Targets); ...
 V.TableExport(cfg,"Supplementary","T_S14_01_EventResourceAccounting",Accounting)];
fig=figure('Visible','off','Color','w','Position',[100 100 1300 760]);clean=onCleanup(@()close(fig)); %#ok<NASGU>
tiledlayout(2,2,'TileSpacing','compact','Padding','compact');
for f=["ODI","T20"]
 B=Targets(Targets.Format==f,:);
 nexttile;hold on;
 cats=unique(B.Scenario,'stable');
 for k=1:numel(cats)
  K=B(B.Scenario==cats(k),:);scatter(repmat(k,height(K),1),K.SelectedUnroundedPar,28,'filled','DisplayName',char(cats(k)));
 end
 xticks(1:numel(cats));xticklabels(cats);xtickangle(20);ylabel('Unrounded par score');title(f+": synthetic policies");grid on;
 nexttile;G=Accounting(Accounting.Format==f,:);scatter(G.ResourceBefore,G.ResourceAfter,30,G.WicketsInHand,'filled');
 hold on;plot([0 1],[0 1],':k');xlabel('Resource before event');ylabel('Resource after event');title(f+": event accounting");colorbar;
end
caption="Synthetic interruption-engine audit for provisional Step12 display candidates. Each event records resource before and after a verified allocation reduction. Targets show equal, fewer-resource, greater-resource, multiple-interruption and termination branches. The additive greater-resource rule uses the format/cohort training mean as G_f; the ratio alternative is reported separately. This is neither official DLS nor real-case validation, and no model or policy is frozen.";
pub=[pub;W.FigureExport(cfg,"Results","F_M14_01_InterruptionEngine",fig,Targets,caption,report)];
package=fullfile(g,'RevisedCodes_14_InterruptionEnginePackage.mat');
InterruptionPackage=struct('Targets',Targets,'Accounting',Accounting,'Policies',Policies, ...
 'PolicySpecification',Policy,'SyntheticOnly',true,'OfficialDLS',false, ...
 'ModelSelected',false,'PolicyFrozen',false,'ReservedCasesUsed',false);
save(package,'InterruptionPackage','-v7.3');
Engine=struct('Stage',"14",'Status',"SYNTHETIC_ENGINE_COMPLETE_REAL_CASES_AND_POLICY_FREEZE_PENDING", ...
 'Checks',Checks,'PackagePath',string(package),'SyntheticOnly',true,'PolicyFrozen',false, ...
 'Packages',table("InterruptionEngine",string(package),'VariableNames',{'PackageID','Path'}));
Engine=V.Finish(cfg,'Engine',out,S,g,report,Engine,[pub;string(package)]);
end
