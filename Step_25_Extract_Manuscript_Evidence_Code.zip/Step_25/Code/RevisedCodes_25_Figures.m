function Files = RevisedCodes_25_Figures(C,S)
rows={};
rows(end+1,:)=saveWorkflow(C); %#ok<AGROW>
rows(end+1,:)=saveArchitecture(C); %#ok<AGROW>
rows(end+1,:)=makeComposite(C,S,'M25_Figure3_FrozenModel', ...
    {'FrozenResourceFigure','ContextFigure'},{'Frozen resource and support','Context interpretation'},[1 2]); %#ok<AGROW>
rows(end+1,:)=makeComposite(C,S,'M25_Figure4_HeldOutPerformance', ...
    {'Step22PerformanceFigure','Step22CalibrationFigure','Step22PhaseFigure','Step22YearFigure'}, ...
    {'Paired performance','Calibration','Phase and wicket states','Temporal stability'},[2 2]); %#ok<AGROW>
rows(end+1,:)=saveCaseEvidence(C,S); %#ok<AGROW>
rows(end+1,:)=makeComposite(C,S,'S25_Figure1_CaseDiagnostics', ...
    {'Step20TargetFigure','Step20CaseFigure','Step21InfluenceFigure'}, ...
    {'Target agreement','Case differences','Case influence'},[2 2],true); %#ok<AGROW>
rows(end+1,:)=makeComposite(C,S,'S25_Figure2_CriticalAssumptions', ...
    {'Step22FullWicketFigure','Step22PhaseFigure','ContextFigure'}, ...
    {'Full-wicket T20 sensitivity','Phase and wicket performance','Context interpretation'},[2 2],true); %#ok<AGROW>
rows(end+1,:)=saveGenderEvidence(C,S); %#ok<AGROW>
rows(end+1,:)=saveSubgroups(C,S); %#ok<AGROW>
rows(end+1,:)=saveCompetitionEra(C,S); %#ok<AGROW>
Files=cell2table(rows,'VariableNames',{'FigureID','PNG','PDF','PanelSources','Complete'});
end

function row=saveWorkflow(C)
f=figure('Visible','off','Color','w','Position',[100 100 1500 850]);
ax=axes(f,'Position',[0 0 1 1]); axis(ax,[0 1 0 1]); axis(ax,'off');
title(ax,'Study and modelling workflow','FontSize',20,'FontWeight','bold');
labels={{'A  Data and eligibility','Cricsheet YAML/JSON','ODI and T20 cohorts','Legal-delivery quality control'}, ...
{'B  State construction','Balls remaining','Wickets in hand','Remaining scoring output'}, ...
{'C  Model development','Empirical surface','Monotone reference','Compact, flexible and context models'}, ...
{'D  Locked evaluation','Temporal test','Real-match cases','Subgroups and comparators'}};
x=[.04 .28 .52 .76]; colors={[.90 .95 1],[.92 1 .94],[1 .96 .88],[.96 .92 1]};
for i=1:4
    annotation(f,'textbox',[x(i) .35 .20 .32],'String',labels{i},'FitBoxToText','off', ...
        'HorizontalAlignment','center','VerticalAlignment','middle','FontSize',14,'Interpreter','none', ...
        'LineWidth',1.5,'BackgroundColor',colors{i},'EdgeColor',[.25 .35 .5]);
    if i<4, annotation(f,'arrow',[x(i)+.20 x(i)+.24],[.51 .51],'LineWidth',2); end
end
annotation(f,'textbox',[.12 .15 .76 .09],'String', ...
    'Development and validation decisions precede model locking; Step22 test predictions are generated only through the frozen Step19 interface.', ...
    'EdgeColor','none','HorizontalAlignment','center','FontSize',13);
row=exportBoth(f,C.MainFiguresDir,'M25_Figure1_Workflow','Programmatic four-panel workflow',C.FigureResolution); close(f);
end

function row=saveArchitecture(C)
f=figure('Visible','off','Color','w','Position',[100 100 1500 1000]);
t=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');
content={{'A  Empirical estimand','', ...
'y = (final score - current score) / final score', ...
'State-cell aggregation with support n(u,w)', ...
'Mean primary; median and thresholds tested'}, ...
{'B  Monotone reference','', ...
'min  sum n(u,w)[R - R_emp]^2', ...
'0 <= R <= 1', ...
'Nondecreasing in balls and wickets', ...
'Analytical boundary anchors'}, ...
{'C  Resource models','', ...
'Six-parameter compact surface', ...
'Shape-constrained flexible benchmark', ...
'ODI and T20 fitted separately', ...
'Certified boundaries and monotonicity'}, ...
{'D  Frozen prediction','', ...
'Past-only team and opponent context', ...
'Partnership and event features', ...
'Fold-safe preprocessing', ...
'Resource ratio to continuous and operational targets'}};
for i=1:4
    ax=nexttile(t); axis(ax,'off'); rectangle(ax,'Position',[.03 .05 .94 .90], ...
        'FaceColor',[.96 .98 1],'EdgeColor',[.2 .35 .55],'LineWidth',1.5);
    text(ax,.5,.5,content{i},'HorizontalAlignment','center','VerticalAlignment','middle', ...
        'FontSize',14,'Interpreter','none');
end
title(t,'Architecture of the proposed frozen resource-estimation framework','FontSize',20,'FontWeight','bold');
row=exportBoth(f,C.MainFiguresDir,'M25_Figure2_ModelArchitecture','Programmatic four-panel architecture',C.FigureResolution); close(f);
end

function row=makeComposite(C,S,name,ids,titles,layout,isSupp)
if nargin<7, isSupp=false; end
paths={}; labels={};
for i=1:numel(ids)
    if isfield(S,ids{i}) && isfile(S.(ids{i})), paths{end+1}=S.(ids{i}); labels{end+1}=titles{i}; end %#ok<AGROW>
end
if isSupp, out=C.SuppFiguresDir; else, out=C.MainFiguresDir; end
if isempty(paths)
    row={string(name),"","",strjoin(string(ids),'; '),false}; return
end
f=figure('Visible','off','Color','w','Position',[100 100 1600 1050]);
t=tiledlayout(f,layout(1),layout(2),'Padding','compact','TileSpacing','compact');
for i=1:numel(paths)
    if numel(paths)==3 && isequal(layout,[2 2]) && i==3
        ax=nexttile(t,[1 2]);
    else
        ax=nexttile(t);
    end
    img=imread(paths{i}); image(ax,img); axis(ax,'image'); axis(ax,'off');
    title(ax,sprintf('%c  %s',char(64+i),labels{i}),'FontSize',13,'FontWeight','bold');
end
if ~(numel(paths)==3 && isequal(layout,[2 2]))
    for i=numel(paths)+1:prod(layout), ax=nexttile(t); axis(ax,'off'); end
end
title(t,humanTitle(name),'FontSize',18,'FontWeight','bold');
row=exportBoth(f,out,name,strjoin(string(paths),'; '),C.FigureResolution); close(f);
end

function row=saveCaseEvidence(C,S)
name='M25_Figure5_RealMatchCases';
if ~isfield(S,'Step22Cases') || ~isfile(S.Step22Cases)
    row={string(name),"","","Step22_RealMatchExamples.csv",false}; return
end
T=readtable(S.Step22Cases,'VariableNamingRule','preserve');
need={'Format','SelectionRule','BaselineRMSE','PrimaryResourceRMSE','RMSEGain'};
if ~all(ismember(need,T.Properties.VariableNames))
    row={string(name),"","",string(S.Step22Cases),false}; return
end
f=figure('Visible','off','Color','w','Position',[100 100 1550 950]);
t=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');
formats=["ODI","T20"];
for k=1:2
    q=T(string(T.Format)==formats(k),:);
    labels=replace(string(q.SelectionRule),["LARGEST_PRIMARY_RESOURCE_","NEAREST_MEDIAN_PRIMARY_RESOURCE_"],["Largest ","Median "]);
    labels=replace(labels,"_"," ");
    ax=nexttile(t); bar(ax,[q.BaselineRMSE q.PrimaryResourceRMSE],'grouped');
    ylabel(ax,'RMSE (runs)'); title(ax,formats(k)+" case-level RMSE");
    ax.XTick=1:height(q); ax.XTickLabel=labels; ax.XTickLabelRotation=18;
    legend(ax,{'Linear-ball baseline','Frozen resource model'},'Location','best'); grid(ax,'on');
    ax=nexttile(t); b=bar(ax,q.RMSEGain); b.FaceColor='flat';
    for j=1:height(q), if q.RMSEGain(j)>=0, b.CData(j,:)=[.20 .55 .30]; else, b.CData(j,:)=[.75 .25 .25]; end, end
    yline(ax,0,'k-'); ylabel(ax,'RMSE gain (runs)'); title(ax,formats(k)+" improvement and deterioration");
    ax.XTick=1:height(q); ax.XTickLabel=labels; ax.XTickLabelRotation=18; grid(ax,'on');
end
title(t,'Rule-selected real-match examples from the frozen temporal test','FontSize',18,'FontWeight','bold');
row=exportBoth(f,C.MainFiguresDir,name,string(S.Step22Cases),C.FigureResolution); close(f);
end

function row=saveGenderEvidence(C,S)
name='S25_Figure3_GenderEvidence';
ids={'GenderSummary','GenderEquivalence','GenderSurface','GenderPoolingGate'};
if ~all(cellfun(@(x)isfield(S,x) && isfile(S.(x)),ids))
    row={string(name),"","",strjoin(string(ids),'; '),false}; return
end
A=readtable(S.GenderSummary,'VariableNamingRule','preserve');
B=readtable(S.GenderEquivalence,'VariableNamingRule','preserve');
Cg=readtable(S.GenderSurface,'VariableNamingRule','preserve');
D=readtable(S.GenderPoolingGate,'VariableNamingRule','preserve');
f=figure('Visible','off','Color','w','Position',[100 100 1550 1000]);
t=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');
ax=nexttile(t); plotGenderBars(ax,A,'mean_FinalRuns','Mean final runs');
ax=nexttile(t); plotGenderBars(ax,A,'mean_RunsPerLegalBall','Runs per legal ball');
ax=nexttile(t); hold(ax,'on');
if all(ismember({'AdjustedWomenMinusMen','Lower95','Upper95','EquivalenceMargin','Format','Metric'},B.Properties.VariableNames))
    x=1:height(B); est=B.AdjustedWomenMinusMen./B.EquivalenceMargin;
    lo=B.Lower95./B.EquivalenceMargin; hi=B.Upper95./B.EquivalenceMargin;
    errorbar(ax,x,est,est-lo,hi-est,'o','LineWidth',1.4); yline(ax,0,'k-');
    yline(ax,-1,'--','Equivalence boundary'); yline(ax,1,'--');
    ax.XTick=x; ax.XTickLabel=string(B.Format)+' '+string(B.Metric); ax.XTickLabelRotation=20;
end
title(ax,'Adjusted difference relative to equivalence margin'); ylabel(ax,'Difference / margin'); grid(ax,'on');
ax=nexttile(t);
vals=[double(D.OutcomeEquivalence) double(D.SurfaceWithinMargin) double(D.PoolingSupported)];
imagesc(ax,vals,[0 1]); colormap(ax,[.82 .25 .25;.25 .60 .35]); colorbar(ax,'Ticks',[0 1],'TickLabels',{'No','Yes'});
ax.XTick=1:3; ax.XTickLabel={'Outcome equivalence','Surface within margin','Pooling supported'};
ax.XTickLabelRotation=18; ax.YTick=1:height(D); ax.YTickLabel=string(D.Format); title(ax,'Prespecified pooling gate');
title(t,'Gender-specific evidence and pooling decision','FontSize',18,'FontWeight','bold');
src=strjoin(string({S.GenderSummary,S.GenderEquivalence,S.GenderSurface,S.GenderPoolingGate}),'; ');
row=exportBoth(f,C.SuppFiguresDir,name,src,C.FigureResolution); close(f);
end

function plotGenderBars(ax,T,varName,yLabel)
formats=["ODI","T20"]; genders=["men","women"]; Y=nan(2,2);
for i=1:2, for j=1:2
    q=string(T.Format)==formats(i) & lower(string(T.Gender))==genders(j);
    if any(q), Y(i,j)=T.(varName)(find(q,1)); end
end, end
bar(ax,Y,'grouped'); ax.XTick=1:2; ax.XTickLabel=formats; ylabel(ax,yLabel);
legend(ax,{'Men','Women'},'Location','best'); grid(ax,'on'); title(ax,string(yLabel)+" by format");
end

function row=saveSubgroups(C,S)
name='S25_Figure4_SubgroupPerformance';
if ~isfield(S,'Step22Subgroups') || ~isfile(S.Step22Subgroups)
    row={string(name),"","","Step22_Subgroups.csv",false}; return
end
T=readtable(S.Step22Subgroups,'VariableNamingRule','preserve');
need={'Format','Role','GroupType','Group','EqualInningsRMSE','SufficientGroup'};
if ~all(ismember(need,T.Properties.VariableNames))
    row={string(name),"","",string(S.Step22Subgroups),false}; return
end
T=T(logical(T.SufficientGroup),:); roles=string(T.Role);
if any(roles=="PrimaryForecast"), T=T(roles=="PrimaryForecast",:); else, T=T(roles=="PrimaryResource",:); end
panels={"ODI","Phase";"T20","Phase";"ODI","Year";"T20","Year"};
f=figure('Visible','off','Color','w','Position',[100 100 1550 1000]);
t=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');
for i=1:4
    ax=nexttile(t); q=T(string(T.Format)==panels{i,1} & string(T.GroupType)==panels{i,2},:);
    if isempty(q), axis(ax,'off'); title(ax,panels{i,1}+" "+panels{i,2}+" unavailable"); continue; end
    bar(ax,q.EqualInningsRMSE); ax.XTick=1:height(q); ax.XTickLabel=string(q.Group); ax.XTickLabelRotation=18;
    ylabel(ax,'Equal-innings RMSE'); title(ax,panels{i,1}+" by "+lower(panels{i,2})); grid(ax,'on');
end
title(t,'Frozen-model performance across innings phase and test year','FontSize',18,'FontWeight','bold');
row=exportBoth(f,C.SuppFiguresDir,name,string(S.Step22Subgroups),C.FigureResolution); close(f);
end

function row=saveCompetitionEra(C,S)
name='S25_Figure5_CompetitionAndEra';
if ~isfield(S,'Step22Subgroups') || ~isfile(S.Step22Subgroups)
    row={string(name),"","","Step22_Subgroups.csv",false}; return
end
T=readtable(S.Step22Subgroups,'VariableNamingRule','preserve');
need={'Format','Role','GroupType','Group','Matches','EqualInningsRMSE','SufficientGroup'};
if ~all(ismember(need,T.Properties.VariableNames))
    row={string(name),"","",string(S.Step22Subgroups),false}; return
end
T=T(logical(T.SufficientGroup),:); roles=string(T.Role);
if any(roles=="PrimaryForecast"), T=T(roles=="PrimaryForecast",:); else, T=T(roles=="PrimaryResource",:); end
f=figure('Visible','off','Color','w','Position',[100 100 1650 1100]);
t=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');
formats=["ODI","T20"];
for k=1:2
    ax=nexttile(t); q=T(string(T.Format)==formats(k) & string(T.GroupType)=="EventNameAsRecorded",:);
    q=sortrows(q,'Matches','descend'); q=q(1:min(10,height(q)),:); q=flipud(q);
    if isempty(q), axis(ax,'off'); else
        barh(ax,q.EqualInningsRMSE); ax.YTick=1:height(q); ax.YTickLabel=string(q.Group);
        xlabel(ax,'Equal-innings RMSE'); title(ax,formats(k)+" recorded events with greatest support"); grid(ax,'on');
    end
    ax=nexttile(t); q=T(string(T.Format)==formats(k) & string(T.GroupType)=="Year",:);
    if isempty(q), axis(ax,'off'); else
        bar(ax,q.EqualInningsRMSE); ax.XTick=1:height(q); ax.XTickLabel=string(q.Group);
        ylabel(ax,'Equal-innings RMSE'); title(ax,formats(k)+" temporal test year"); grid(ax,'on');
    end
end
title(t,'Recorded-event and temporal diagnostics for the frozen model','FontSize',18,'FontWeight','bold');
row=exportBoth(f,C.SuppFiguresDir,name,string(S.Step22Subgroups),C.FigureResolution); close(f);
end

function row=exportBoth(f,out,name,sources,res)
if ~isfolder(out), mkdir(out); end
png=fullfile(out,[name '.png']); pdf=fullfile(out,[name '.pdf']);
exportgraphics(f,png,'Resolution',res,'BackgroundColor','white');
exportgraphics(f,pdf,'ContentType','vector','BackgroundColor','white');
row={string(name),string(png),string(pdf),string(sources),true};
end

function s=humanTitle(name)
s=regexprep(string(name),'^[MS]25_Figure\d+_','');
s=regexprep(s,'([a-z])([A-Z])','$1 $2');
s=replace(s,'_',' ');
end
