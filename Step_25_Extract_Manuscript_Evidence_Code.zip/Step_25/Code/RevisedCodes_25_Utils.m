function U = RevisedCodes_25_Utils
U.Write = @writeTable;
U.Read = @safeRead;
U.Resolve = @resolveOne;
U.Truth = @truthValue;
U.MakeDirs = @makeDirs;
U.ZipFolder = @zipFolder;
U.Copy = @verifiedCopy;
U.Rel = @relativePath;
end

function makeDirs(varargin)
for i=1:nargin
    if ~isfolder(varargin{i}), mkdir(varargin{i}); end
end
end

function writeTable(T,p)
folder=fileparts(p); if ~isfolder(folder), mkdir(folder); end
assert(istable(T),'First argument must be a table.');
writetable(T,p,'Encoding','UTF-8');
end

function T=safeRead(p)
assert(isfile(p),'Required file not found: %s',p);
o=detectImportOptions(p,'VariableNamingRule','preserve');
T=readtable(p,o);
end

function [p,candidates]=resolveOne(root,pattern)
d=dir(fullfile(root,'**',pattern)); d=d(~[d.isdir]);
if isempty(d), p=""; candidates=strings(0,1); return; end
paths=string(fullfile({d.folder},{d.name}))';
keep=~contains(lower(paths),'step25_manuscript_evidence') & ...
     ~contains(lower(paths),'failed_checks') & ~contains(lower(paths),'_failed');
d=d(keep); paths=paths(keep);
if isempty(d), p=""; candidates=strings(0,1); return; end
score=zeros(numel(d),1);
score=score+100*contains(lower(paths),'publicationready');
score=score+30*contains(lower(paths),'final');
score=score+20*contains(lower(paths),'frozen');
score=score+10*contains(lower(paths),'step2');
score=score+[d.datenum]'/max([d.datenum]'+eps);
[~,ix]=max(score);
p=paths(ix); candidates=paths;
end

function tf=truthValue(x)
if islogical(x), tf=all(x(:)); return; end
if isnumeric(x), tf=all(isfinite(x(:)) & x(:)~=0); return; end
s=lower(strtrim(string(x)));
tf=all(ismember(s,["1","true","pass","passed","yes","complete","completed","ready","enabled"]));
end

function verifiedCopy(src,dst)
assert(isfile(src),'Copy source missing: %s',src);
folder=fileparts(dst); if ~isfolder(folder), mkdir(folder); end
[ok,msg]=copyfile(src,dst,'f'); assert(ok,'Copy failed: %s',msg);
a=dir(src); b=dir(dst); assert(a.bytes==b.bytes,'Copied file size differs: %s',src);
end

function rel=relativePath(p,root)
p=string(p); root=string(root);
if startsWith(lower(p),lower(root)), rel=extractAfter(p,strlength(root)); else, rel=p; end
rel=replace(rel,"\","/"); rel=regexprep(rel,'^/+','');
end

function zipFolder(folder,zipPath)
d=dir(fullfile(folder,'**','*')); d=d(~[d.isdir]);
files=cell(numel(d),1);
for i=1:numel(d)
    files{i}=char(relativePath(fullfile(d(i).folder,d(i).name),folder));
end
if isfile(zipPath), delete(zipPath); end
zip(zipPath,files,folder);
assert(isfile(zipPath),'ZIP creation failed: %s',zipPath);
end

