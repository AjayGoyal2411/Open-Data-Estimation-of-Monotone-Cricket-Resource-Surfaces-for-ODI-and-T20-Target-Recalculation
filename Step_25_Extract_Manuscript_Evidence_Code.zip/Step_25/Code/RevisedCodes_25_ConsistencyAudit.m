function G = RevisedCodes_25_ConsistencyAudit(C,Manifest,S,E,Figures,U)
Gate=["Required scientific artifacts located";"Equation sources located"; ...
"Frozen target policy located";"Temporal test population located"; ...
"Real-match examples located";"Gender pooling decision located"; ...
"Comparator register located";"VJD worked examples verified"; ...
"Main manuscript workbook created";"Supplementary workbook created"; ...
"Core methodology figures created";"No test data refit requested"];
Passed=false(size(Gate)); Detail=strings(size(Gate));
Passed(1)=all(Manifest.Found(Manifest.Required)); Detail(1)=join(Manifest.ArtifactID(Manifest.Required & ~Manifest.Found),', ');
Passed(2)=all(E.SourcePresent); Detail(2)=join(E.Name(~E.SourcePresent),', ');
Passed(3)=isfield(S,'FrozenTargetChecks') && isfile(S.FrozenTargetChecks);
Passed(4)=isfield(S,'Step22TestPopulation') && isfile(S.Step22TestPopulation);
Passed(5)=isfield(S,'Step22Cases') && isfile(S.Step22Cases);
Passed(6)=isfield(S,'GenderPoolingGate') && isfile(S.GenderPoolingGate);
Passed(7)=isfield(S,'ComparatorRegister') && isfile(S.ComparatorRegister);
Passed(8)=checkVJD(S,U); Detail(8)="Published VJD lookup examples must all match.";
Passed(9)=isfile(C.MainWorkbook); Passed(10)=isfile(C.SuppWorkbook);
Passed(11)=height(Figures)>=2 && all(Figures.Complete(1:2));
Passed(12)=true; Detail(12)="Step25 reads frozen outputs only; no fitting function is called.";
G=table(Gate,Passed,Detail);
if C.Strict, assert(all(Passed),'Step25 consistency gate failed. See Step25_ConsistencyGates.csv.'); end
end

function tf=checkVJD(S,U)
tf=false;
if ~isfield(S,'VJDExamples') || ~isfile(S.VJDExamples), return; end
T=U.Read(S.VJDExamples);
v=find(strcmpi(T.Properties.VariableNames,'LookupMatchesPublishedExample'),1);
if isempty(v), return; end
tf=U.Truth(T{:,v});
end

