clear; clc;
here = fileparts(mfilename('fullpath'));
addpath(here);
settings = struct;
Results = RevisedCodes_25_RunAll(settings); %#ok<NASGU>

