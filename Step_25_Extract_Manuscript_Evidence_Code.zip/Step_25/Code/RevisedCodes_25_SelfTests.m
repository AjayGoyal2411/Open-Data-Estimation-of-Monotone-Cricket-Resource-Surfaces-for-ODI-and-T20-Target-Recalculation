function T = RevisedCodes_25_SelfTests(U)
Check=["Truth accepts one";"Truth accepts passed";"Truth rejects zero"; ...
       "Relative path removes root";"Relative path normalizes separators"; ...
       "Required MATLAB table support"];
Passed=false(size(Check));
Passed(1)=U.Truth(1);
Passed(2)=U.Truth("PASSED");
Passed(3)=~U.Truth(0);
r=U.Rel(fullfile('X:','project','a.csv'),fullfile('X:','project'));
Passed(4)=strcmp(r,'a.csv');
Passed(5)=~contains(r,'\');
Passed(6)=istable(table(1));
T=table(Check,Passed);
assert(all(Passed),'Step25 self-test failed.');
end

