function C = RevisedCodes_25_Config(settings)
% Configuration for the read-only manuscript-evidence extraction stage.
if nargin < 1 || isempty(settings), settings = struct; end
C = struct;
C.Here = fileparts(mfilename('fullpath'));
if isfield(settings,'ProjectRoot') && strlength(string(settings.ProjectRoot)) > 0
    C.ProjectRoot = char(settings.ProjectRoot);
else
    C.ProjectRoot = findProjectRoot(C.Here);
end
if isfield(settings,'OutputRoot') && strlength(string(settings.OutputRoot)) > 0
    C.OutputRoot = char(settings.OutputRoot);
else
    C.OutputRoot = fullfile(C.ProjectRoot,'paper_outputs_revisedcodes','step25_manuscript_evidence');
end
C.Generation = ['generation_' datestr(now,'yyyymmdd_HHMMSS_FFF')];
C.ReportDir = fullfile(C.OutputRoot,C.Generation);
C.MainTablesDir = fullfile(C.ReportDir,'MainPaper','Tables');
C.MainFiguresDir = fullfile(C.ReportDir,'MainPaper','Figures');
C.SuppTablesDir = fullfile(C.ReportDir,'Supplementary','Tables');
C.SuppFiguresDir = fullfile(C.ReportDir,'Supplementary','Figures');
C.ChecksDir = fullfile(C.ReportDir,'Checks');
C.SourceDataDir = fullfile(C.ReportDir,'SourceData');
C.MainWorkbook = fullfile(C.MainTablesDir,'Step25_MainPaperTables.xlsx');
C.SuppWorkbook = fullfile(C.SuppTablesDir,'Step25_SupplementaryTables.xlsx');
C.PackageZip = fullfile(C.OutputRoot,[C.Generation '_Step25_ManuscriptEvidence.zip']);
C.ChecksZip = fullfile(C.OutputRoot,[C.Generation '_Checks.zip']);
C.FigureResolution = 600;
C.Strict = true;
if isfield(settings,'Strict'), C.Strict = logical(settings.Strict); end
end

function root = findProjectRoot(startDir)
root = startDir;
for k = 1:8
    if isfolder(fullfile(root,'paper_outputs_revisedcodes')) || ...
            isfolder(fullfile(root,'PublicationReady')) || ...
            isfolder(fullfile(root,'final_retained_dataset'))
        return
    end
    parent = fileparts(root);
    if strcmp(parent,root), break; end
    root = parent;
end
% Normal extraction location is D:\VihaanProject1\<Step25 folder>.
root = fileparts(startDir);
end

