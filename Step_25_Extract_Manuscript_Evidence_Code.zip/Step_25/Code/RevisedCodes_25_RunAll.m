function Results = RevisedCodes_25_RunAll(settings)
if nargin<1, settings=struct; end
C=RevisedCodes_25_Config(settings); U=RevisedCodes_25_Utils;
U.MakeDirs(C.OutputRoot,C.ReportDir,C.MainTablesDir,C.MainFiguresDir, ...
    C.SuppTablesDir,C.SuppFiguresDir,C.ChecksDir,C.SourceDataDir);
fprintf('Step25 manuscript evidence extraction started %s\n',datestr(now));
try
    Tests=RevisedCodes_25_SelfTests(U); U.Write(Tests,fullfile(C.ChecksDir,'Step25_SelfTests.csv'));
    [Manifest,S]=RevisedCodes_25_Discover(C,U);
    U.Write(Manifest,fullfile(C.ChecksDir,'Step25_EvidenceManifest.csv'));
    E=RevisedCodes_25_EquationSpecification(S);
    U.Write(E,fullfile(C.MainTablesDir,'Step25_EquationRegister.csv'));
    TableFiles=RevisedCodes_25_ManuscriptTables(C,S,U,E);
    FigureFiles=RevisedCodes_25_Figures(C,S);
    U.Write(FigureFiles,fullfile(C.MainFiguresDir,'Step25_FigureManifest.csv'));
    Coverage=RevisedCodes_25_ReviewerCoverage(Manifest);
    U.Write(Coverage,fullfile(C.ChecksDir,'Step25_ReviewerCoverage.csv'));
    Gates=RevisedCodes_25_ConsistencyAudit(C,Manifest,S,E,FigureFiles,U);
    U.Write(Gates,fullfile(C.ChecksDir,'Step25_ConsistencyGates.csv'));
    Summary=table(string(C.ProjectRoot),sum(Manifest.Required),sum(Manifest.Found & Manifest.Required), ...
        height(E),height(FigureFiles),sum(Coverage.EvidencePresent),all(Gates.Passed), ...
        'VariableNames',{'ProjectRoot','RequiredArtifacts','RequiredArtifactsFound','Equations','Figures','ReviewerItemsWithEvidence','AllGatesPassed'});
    U.Write(Summary,fullfile(C.ReportDir,'Step25_CompletionSummary.csv'));
    writeReadme(C);
    U.ZipFolder(C.ReportDir,C.PackageZip);
    U.ZipFolder(C.ChecksDir,C.ChecksZip);
    fprintf('Step25 completed.\nUpload %s\n',C.ChecksZip);
    fprintf('Manuscript package %s\n',C.PackageZip);
    Results=struct('Config',C,'Manifest',Manifest,'Equations',E,'Tables',TableFiles, ...
        'Figures',FigureFiles,'Coverage',Coverage,'Gates',Gates,'Summary',Summary);
catch ME
    try
        failedZip=fullfile(C.OutputRoot,[C.Generation '_FAILED_Checks.zip']);
        U.ZipFolder(C.ReportDir,failedZip);
        fprintf(2,'Upload %s\n',failedZip);
    catch
    end
    rethrow(ME)
end
end

function writeReadme(C)
p=fullfile(C.ReportDir,'README.txt');
f=fopen(p,'wt'); assert(f>=0,'Cannot write README.'); c=onCleanup(@()fclose(f));
fprintf(f,'Step25 Manuscript Evidence Package\n\n');
fprintf(f,'This stage is read-only with respect to the scientific model.\n');
fprintf(f,'It discovers frozen Step9-Step23 evidence and produces manuscript tables, figures, equation and reviewer registers.\n');
fprintf(f,'It does not fit, refit, tune or alter any model.\n\n');
fprintf(f,'MainPaper contains proposed main-text tables and figures.\n');
fprintf(f,'Supplementary contains detailed sensitivity and subgroup evidence.\n');
fprintf(f,'Checks contains evidence discovery, reviewer coverage and consistency gates.\n');
fprintf(f,'Project root: %s\n',C.ProjectRoot);
end

