%%This is step 3%%
%% Remove Competition column from match_info_all.csv
clc; clear;

% ---- USER INPUTS ----
inCsv  = 'D:\VihaanProject1\clean_from_yaml_lossless_all\match_info_all.csv';
outCsv = 'D:\VihaanProject1\clean_from_yaml_lossless_all\match_info_all_noCompetition.csv';

% ---- CHECK FILE ----
assert(isfile(inCsv), 'Input CSV not found:\n%s', inCsv);

% ---- READ CSV ----
T = readtable(inCsv, 'TextType','string');

% ---- REMOVE COLUMN IF EXISTS ----
if ismember('Competition', T.Properties.VariableNames)
    T.Competition = [];
    fprintf('Removed column: Competition\n');
else
    warning('Column "Competition" not found. File unchanged.');
end

% ---- WRITE CLEAN CSV ----
writetable(T, outCsv);

fprintf('Clean CSV written to:\n%s\n', outCsv);
