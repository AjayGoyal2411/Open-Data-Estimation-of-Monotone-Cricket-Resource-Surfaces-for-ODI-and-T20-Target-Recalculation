%% This is step 2

%% Step J0C (ROBUST) — Extract Event/Competition from JSON ONLY for MatchIDs listed in MatchIDs.csv
% Reads MatchIDs from:
%   D:\VihaanProject1\clean_from_json\MatchIDs.csv
% (first column, header optional; supports ids like "wi_201706")
% For each MatchID:
%   - reads D:\VihaanProject1\JSONFiles\<MatchID>.json (if exists)
%   - extracts info.event.name/stage/group/match_number (+ fallbacks)
% Writes:
%   1) JSON_EventMaster_FromMatchIDs.csv
%   2) JSON_EventCounts_FromMatchIDs.csv
%   3) JSON_MissingEventList_FromMatchIDs.csv
%   4) JSON_FromMatchIDs_RunReport.txt

clc; clear;

%% -------------------- USER SETTINGS --------------------
workRoot    = 'D:\VihaanProject1';
jsonFolder  = fullfile(workRoot, 'JSONFiles');
matchIDCsv  = fullfile(workRoot, 'clean_from_json', 'MatchIDs.csv');

assert(isfile(matchIDCsv), 'MatchIDs.csv not found: %s', matchIDCsv);
assert(exist(jsonFolder,'dir')==7, 'JSON folder not found: %s', jsonFolder);

outFolder = fullfile(workRoot, 'clean_from_json');
if ~exist(outFolder,'dir'), mkdir(outFolder); end

outMasterCsv  = fullfile(outFolder, 'JSON_EventMaster_FromMatchIDs.csv');
outCountsCsv  = fullfile(outFolder, 'JSON_EventCounts_FromMatchIDs.csv');
outMissingCsv = fullfile(outFolder, 'JSON_MissingEventList_FromMatchIDs.csv');
outReportTxt  = fullfile(outFolder, 'JSON_FromMatchIDs_RunReport.txt');

BATCH = 2000;

%% -------------------- READ MATCHIDs (ROBUST TEXT READ) --------------------
lines = readlines(matchIDCsv);
lines = lines(~(strlength(strtrim(lines))==0));   % drop empty lines

if isempty(lines)
    error('MatchIDs.csv is empty: %s', matchIDCsv);
end

% Detect header: if first line contains "MatchID" (case-insensitive) as first token
first = strtrim(lines(1));
firstTok = lower(extractBefore(first + ",", ","));   % take text before first comma

hasHeader = (firstTok == "matchid" || contains(lower(first), "matchid"));

startIdx = 1;
if hasHeader
    startIdx = 2;
end

idSet = java.util.HashSet();

for i = startIdx:numel(lines)
    ln = strtrim(lines(i));
    if ln == "", continue; end

    % first column only (before first comma)
    id = extractBefore(ln + ",", ",");
    id = strtrim(id);

    if id ~= ""
        idSet.add(char(id));
    end
end

nIDs = idSet.size();
assert(nIDs > 0, 'No MatchIDs extracted from first column of: %s', matchIDCsv);

matchIDs = strings(nIDs,1);
it = idSet.iterator();
k = 1;
while it.hasNext()
    matchIDs(k) = string(it.next());
    k = k + 1;
end

fprintf('Unique MatchIDs from MatchIDs.csv: %d\n', numel(matchIDs));

%% -------------------- PREP OUTPUT (HEADER ONLY) --------------------
if isfile(outMasterCsv),  delete(outMasterCsv);  end
if isfile(outCountsCsv),  delete(outCountsCsv);  end
if isfile(outMissingCsv), delete(outMissingCsv); end
if isfile(outReportTxt),  delete(outReportTxt);  end

outHeader = { ...
    'MatchID','JSONExists','FileName', ...
    'ParseOK','ErrMsg', ...
    'MatchType','Gender','Season', ...
    'EventName','EventStage','EventGroup','EventMatchNum', ...
    'StartDateRaw','Venue','TeamsRaw' ...
};

writetable(cell2table(cell(0,numel(outHeader)),'VariableNames',outHeader), outMasterCsv);

%% -------------------- MAIN LOOP: READ JSON PER MATCHID --------------------
tStart = tic;

outBatch = table();
jsonExistsCount = 0;
parseOKCount    = 0;

for i = 1:numel(matchIDs)
    matchID = strtrim(matchIDs(i));
    if matchID == "", continue; end

    fileName = matchID + ".json";
    fpath    = fullfile(jsonFolder, fileName);

    JSONExists = isfile(fpath);
    ParseOK = false;
    ErrMsg  = "";

    MatchType = ""; Gender = ""; Season = "";
    EventName = ""; EventStage = ""; EventGroup = ""; EventMatchNum = "";
    StartDateRaw = ""; Venue = ""; TeamsRaw = "";

    if JSONExists
        jsonExistsCount = jsonExistsCount + 1;

        try
            S = jsondecode(fileread(fpath));
            ParseOK = true;
            parseOKCount = parseOKCount + 1;

            if isfield(S,'info') && isstruct(S.info)
                info = S.info;

                MatchType = lower(string(getOr(info,'match_type',"")));
                Gender    = lower(string(getOr(info,'gender',"")));
                Season    = string(getOr(info,'season',""));
                Venue     = string(getOr(info,'venue',""));

                if isfield(info,'dates')
                    StartDateRaw = coerceDateFirst(info.dates);
                end

                if isfield(info,'teams')
                    TeamsRaw = stringifyTeams(info.teams);
                end

                % Primary source
                if isfield(info,'event') && isstruct(info.event)
                    ev = info.event;
                    EventName     = string(getOr(ev,'name',""));
                    EventStage    = string(getOr(ev,'stage',""));
                    EventGroup    = string(getOr(ev,'group',""));
                    EventMatchNum = string(getOr(ev,'match_number',""));
                end

                % Fallbacks
                if strtrim(EventName)=="" && isfield(info,'competition')
                    EventName = string(getOr(info,'competition',""));
                end
                if strtrim(EventName)=="" && isfield(info,'series')
                    EventName = string(getOr(info,'series',""));
                end
            end

        catch ME
            ParseOK = false;
            ErrMsg  = string(ME.message);
        end
    else
        ErrMsg = "JSON not found";
    end

    % cleanup
    if strtrim(EventName) == "", EventName = "UNKNOWN"; end
    if strtrim(MatchType) == "", MatchType = "unknown"; end

    row = table( ...
        matchID, JSONExists, fileName, ...
        ParseOK, ErrMsg, ...
        MatchType, Gender, Season, ...
        EventName, EventStage, EventGroup, EventMatchNum, ...
        StartDateRaw, Venue, TeamsRaw, ...
        'VariableNames', outHeader);

    outBatch = [outBatch; row]; %#ok<AGROW>

    if height(outBatch) >= BATCH
        writetable(outBatch, outMasterCsv, 'WriteMode','append');
        outBatch = table();
    end

    if mod(i, 2000) == 0
        fprintf('Processed %d/%d | JSONExists=%d | ParseOK=%d | elapsed=%.1fs\n', ...
            i, numel(matchIDs), jsonExistsCount, parseOKCount, toc(tStart));
    end
end

if ~isempty(outBatch)
    writetable(outBatch, outMasterCsv, 'WriteMode','append');
end

elapsed = toc(tStart);
fprintf('\nMaster CSV written: %s\n', outMasterCsv);

%% -------------------- COUNTS + MISSING LIST --------------------
T = readtable(outMasterCsv, 'TextType','string');

Tc = groupsummary(T, "EventName");
Tc = renamevars(Tc, "GroupCount", "MatchCount");
Tc = sortrows(Tc, "MatchCount", "descend");
writetable(Tc, outCountsCsv);
fprintf('Counts CSV written: %s\n', outCountsCsv);

Tm = T(T.EventName=="UNKNOWN" | ~T.ParseOK | ~T.JSONExists, :);
writetable(Tm, outMissingCsv);
fprintf('Missing/Unknown CSV written: %s\n', outMissingCsv);

%% -------------------- RUN REPORT --------------------
fid = fopen(outReportTxt,'w');
c = onCleanup(@() fclose(fid));

fprintf(fid, 'Step J0C (ROBUST) — JSON Event/Competition Extraction for MatchIDs listed in MatchIDs.csv\n');
fprintf(fid, 'Timestamp: %s\n\n', datestr(now));
fprintf(fid, 'Inputs:\n');
fprintf(fid, '  MatchIDs.csv: %s\n', matchIDCsv);
fprintf(fid, '  JSON folder : %s\n\n', jsonFolder);

fprintf(fid, 'Stats:\n');
fprintf(fid, '  Unique MatchIDs  : %d\n', numel(matchIDs));
fprintf(fid, '  JSON exists      : %d\n', jsonExistsCount);
fprintf(fid, '  JSON parse OK    : %d\n', parseOKCount);
unk = sum(T.EventName=="UNKNOWN");
fprintf(fid, '  UNKNOWN EventName: %d (%.2f%%)\n', unk, 100*unk/max(height(T),1));
fprintf(fid, '  Elapsed (s)      : %.1f\n\n', elapsed);

fprintf(fid, 'Outputs:\n');
fprintf(fid, '  Master : %s\n', outMasterCsv);
fprintf(fid, '  Counts : %s\n', outCountsCsv);
fprintf(fid, '  Missing: %s\n', outMissingCsv);

fprintf('Run report written: %s\n', outReportTxt);
fprintf('\nDONE.\n');

%% ---------------- local helpers ----------------
function v = getOr(S, field, default)
    if isstruct(S) && isfield(S, field)
        v = S.(field);
    else
        v = default;
    end
end

function s = coerceDateFirst(d)
    s = "";
    try
        if iscell(d)
            if ~isempty(d), s = string(d{1}); end
        elseif isstring(d) || ischar(d)
            s = string(d);
        elseif isnumeric(d)
            s = string(d(1));
        else
            s = string(d);
        end
    catch
        s = "";
    end
end

function out = stringifyTeams(t)
    out = "";
    try
        if iscell(t)
            out = strjoin(string(t), " | ");
        elseif isstring(t)
            out = strjoin(t, " | ");
        elseif ischar(t)
            out = string(t);
        else
            out = string(t);
        end
    catch
        out = "";
    end
end
