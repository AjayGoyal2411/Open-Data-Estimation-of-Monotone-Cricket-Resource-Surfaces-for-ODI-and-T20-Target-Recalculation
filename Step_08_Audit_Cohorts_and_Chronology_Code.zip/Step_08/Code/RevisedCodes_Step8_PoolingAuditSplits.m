function Result = RevisedCodes_Step8_PoolingAuditSplits(userConfig)
% REVISEDCODES_STEP8_POOLINGAUDITSPLITS  Retained-data audit and model cohorts.
% MATLAB R2024b. Save this file in D:\VihaanProject1 and run:
%   Result = RevisedCodes_Step8_PoolingAuditSplits;
%
% No Steps 1--7 rerun. Retained CSVs are NEVER edited. One delivery scan is
% cached by source path/size/mtime and this file's SHA-256. Raw JSON metadata
% extraction is cached independently. Set cfg.ForceRescan=true to invalidate.
%
% IMPORTANT: revised Step 9 must consume Step8_MatchManifest.csv,
% Step8_InningsAudit.csv, Step8_DeliveryCorrections.csv and split-specific IDs.
% Original Steps 9--13 are not independent-validation code and do not apply
% these repairs. Do not copy revised pools into the old paper_outputs folder.
%
% Default protocol: men primary, women retained for sensitivity; IT20 included
% with a separate flag; TRAIN <2023, VALIDATION during 2023, TEST >=2024.
% Cutoffs are prespecified protocol choices, not tuned from model performance.
% Short genuine all-out first innings are retained without a 60/30-ball cutoff.
% Rain-truncated and unresolved first innings are retained for case auditing,
% but do not provide a completed-innings response for primary fitting.
%
% Optional overrides (all fields validated; paths also overridable):
%   cfg = struct('ForceRescan',false,'ValidationStart',datetime(2023,1,1), ...
%       'TestStart',datetime(2024,1,1),'CaseStudyMatchIDs',["1234567"]);
%   Result = RevisedCodes_Step8_PoolingAuditSplits(cfg);
% A nonempty RevisedCodes_CaseStudyMatchIDs.csv in ProjectRoot, with MatchID
% column, also reserves whole matches. No case IDs are guessed from summaries.
% Historical case matches must be reserved before fitting to be independent.
%
% OUTPUT ROOT: D:\VihaanProject1\paper_outputs_revisedcodes\step08
% tables: schema/provenance, metadata conflicts, match/innings manifests,
% corrections, eligibility/split/QC summaries and split-specific pool IDs.
% figures: descriptive eligible-match counts by calendar year and split.
% cache: delivery and raw metadata audits. runlog: diary + saved config.
% Completion is a data-preparation result, NOT validation of DLS agreement.

if nargin < 1, userConfig = struct(); end
cfg = defaults();
assert(isstruct(userConfig) && isscalar(userConfig), 'Config must be a scalar struct.');
fields = fieldnames(userConfig);
for k = 1:numel(fields)
    assert(isfield(cfg,fields{k}), 'Unknown config field: %s', fields{k});
    cfg.(fields{k}) = userConfig.(fields{k});
end
assert(isdatetime(cfg.ValidationStart) && isscalar(cfg.ValidationStart) && ...
    isdatetime(cfg.TestStart) && isscalar(cfg.TestStart) && ...
    ~isnat(cfg.ValidationStart) && ~isnat(cfg.TestStart) && ...
    cfg.ValidationStart < cfg.TestStart, 'Invalid temporal cutoffs.');
assert(ismember(string(cfg.PrimaryGender),["men","women"]), 'PrimaryGender must be men or women.');
assert(cfg.ReadSize >= 1 && mod(cfg.ReadSize,1)==0, 'ReadSize must be a positive integer.');
assert(cfg.MaxInnings >= 2 && mod(cfg.MaxInnings,1)==0, 'MaxInnings must be an integer >=2.');
assert(cfg.Folds >= 2 && mod(cfg.Folds,1)==0, 'Folds must be an integer >=2.');
assert(cfg.MinimumTrainingMatches >= 1, 'MinimumTrainingMatches must be positive.');
assert(cfg.CoverageWarning >= 0 && cfg.CoverageWarning <= 1, 'CoverageWarning must be in [0,1].');
paths = struct('match',fullfile(cfg.InputFolder,'match_info_all_noCompetition.csv'), ...
    'event',fullfile(cfg.InputFolder,'JSON_EventMaster_FromMatchIDs.csv'), ...
    'ball',fullfile(cfg.InputFolder,'ball_by_ball_all.csv'));
assert(isfile(paths.match),'Missing %s', paths.match);
assert(isfile(paths.ball),'Missing %s', paths.ball);
out = struct('root',cfg.OutputRoot,'tables',fullfile(cfg.OutputRoot,'tables'), ...
    'cache',fullfile(cfg.OutputRoot,'cache'),'runlog',fullfile(cfg.OutputRoot,'runlog'), ...
    'figures',fullfile(cfg.OutputRoot,'figures'));
for v = string(struct2cell(out))', if ~isfolder(v), mkdir(v); end, end
stamp = char(datetime('now','Format','yyyyMMdd_HHmmss'));
diary(fullfile(out.runlog,['RunLog_RevisedCodes_Step8_' stamp '.txt']));
cleanupDiary = onCleanup(@() diary('off')); %#ok<NASGU>
fprintf('Revised Step 8: retained-data audit, eligibility and splits\n');
fprintf('Input: %s\nOutput: %s\n',cfg.InputFolder,cfg.OutputRoot);
fprintf('No retained CSV is modified. Cached scans are reused when signatures match.\n');
if cfg.RunSelfTests, runSelfTests(cfg); end
[signature,provenance] = sourceSignature(paths,cfg);
put(provenance,out,'Step8_InputProvenance.csv');
T = readStrings(paths.match);
require(T,["MatchID"],paths.match);
T.MatchID = normalID(T.MatchID);
[T,badMatch] = deduplicate(T,"match_info");
if isfile(paths.event)
    E = readStrings(paths.event); require(E,"MatchID",paths.event);
    E.MatchID = normalID(E.MatchID);
    [E,badEvent] = deduplicate(E,"event_master");
else
    E = table(strings(0,1),'VariableNames',{'MatchID'});
    badEvent = emptyConflict();
    warning('Event master absent: competition context will be incomplete.');
end
put([badMatch;badEvent],out,'Step8_DuplicateIDAudit.csv');
assert(height(T)>0, 'No usable match IDs in match metadata.');
M = canonicalMetadata(T,E);
M.DuplicateConflict = ismember(M.MatchID,[badMatch.MatchID(badMatch.ConflictingRecords);badEvent.MatchID(badEvent.ConflictingRecords)]);
put(M(M.MetadataConflict | M.DuplicateConflict,:),out,'Step8_MetadataConflicts.csv');
schema = auditSchema(paths);
put(schema,out,'Step8_InputSchema.csv');
cacheFile = fullfile(out.cache,'Step8_DeliveryAudit.mat');
cacheOK = false;
if ~cfg.ForceRescan && isfile(cacheFile)
    saved = load(cacheFile,'signature','A','Corrections','Scan');
    cacheOK = isfield(saved,'signature') && isequaln(signature,saved.signature);
end
if cacheOK
    A=saved.A; Corrections=saved.Corrections; Scan=saved.Scan;
    fprintf('Reusing delivery audit cache: %s\n',cacheFile);
else
    [A,Corrections,Scan] = scanDeliveries(paths.ball,M,cfg);
    save(cacheFile,'signature','A','Corrections','Scan','-v7.3');
end
put(Corrections,out,'Step8_DeliveryCorrections.csv');
[Raw,rawInventory] = rawMetadata(M,cfg,out,signature);
put(rawInventory,out,'Step8_RawJSONInventory.csv');
put(Raw,out,'Step8_RawInningsMetadata.csv');
[A,M] = classifyInnings(A,M,Raw,rawInventory,cfg);
caseIDs = normalID(cfg.CaseStudyMatchIDs(:));
caseFile = fullfile(cfg.ProjectRoot,'RevisedCodes_CaseStudyMatchIDs.csv');
if isfile(caseFile)
    cases = readStrings(caseFile); require(cases,"MatchID",caseFile);
    caseIDs = unique([caseIDs;normalID(cases.MatchID)]);
end
caseIDs = caseIDs(strlength(caseIDs)>0);
if isempty(caseIDs)
    warning(['No case-study IDs reserved yet. Published historical cases must be ' ...
        'identified and reserved before revised Step 9 fits a model.']);
end
unmatched = setdiff(caseIDs,M.MatchID);
put(table(unmatched,'VariableNames',{'MatchID'}),out,'Step8_UnmatchedCaseIDs.csv');
M.CaseStudyReserved = ismember(M.MatchID,caseIDs);
M.Split = repmat("ineligible",height(M),1);
valid = M.MetadataEligible & M.HasDeliveries & ~isnat(M.StartDate);
M.Split(valid & M.StartDate<cfg.ValidationStart)="train";
M.Split(valid & M.StartDate>=cfg.ValidationStart & M.StartDate<cfg.TestStart)="validation";
M.Split(valid & M.StartDate>=cfg.TestStart)="test";
M.Split(M.MetadataEligible & M.HasDeliveries & isnat(M.StartDate))="date_review";
M.Split(M.CaseStudyReserved)="case_study";
M.TrainingFold=zeros(height(M),1);
previousRNG=rng; rngCleanup=onCleanup(@() rng(previousRNG)); %#ok<NASGU>
rng(cfg.Seed,'twister');
for f=["ODI","T20"]
    for g=["men","women"]
        rows=find(M.Split=="train" & M.FormatFamily==f & M.GenderCanon==g);
        [~,order]=sort(M.MatchID(rows)); rows=rows(order);
        rows=rows(randperm(numel(rows)));
        M.TrainingFold(rows)=mod((0:numel(rows)-1)',cfg.Folds)+1;
    end
end
M.PrimaryModelEligible = M.FirstInningsResponseEligible & ...
    M.GenderCanon==string(cfg.PrimaryGender) & ismember(M.Split,["train","validation","test"]);
A.Split=M.Split(A.MatchRow);
A.TrainingFold=M.TrainingFold(A.MatchRow);
A.CaseStudyReserved=M.CaseStudyReserved(A.MatchRow);
A.PrimaryModelEligible=A.ResponseEligible & A.InningsIndex==1 & ...
    M.GenderCanon(A.MatchRow)==string(cfg.PrimaryGender) & ...
    ismember(A.Split,["train","validation","test"]);
assert(isempty(intersect(M.MatchID(M.Split=="train"),M.MatchID(M.Split=="test"))), ...
    'Split leakage detected.');
assert(all(M.TrainingFold(M.Split~="train")==0),'Held-out folds must be zero.');
assert(~any(M.CaseStudyReserved & M.Split=="train"),'Case-study leakage detected.');
put(M,out,'Step8_MatchManifest.csv');
put(A,out,'Step8_InningsAudit.csv');
put(M(M.MetadataEligible,:),out,'Step8_AllCandidateMatchManifest.csv');
makePools(M,out,cfg);
Summary = summaries(M,A,Corrections,Scan,out,cfg);
put(variableDictionary(),out,'Step8_VariableDictionary.csv');
rawReady=any(M.MetadataEligible) && all(M.RawJSONStatus(M.MetadataEligible)=="parsed");
Status=table(["DeliveryScanCompleted";"RawMetadataCompleteForCandidates"; ...
    "CaseStudyReservationProvided";"RevisedStep9Required";"DLSAgreementEvaluated"], ...
    ["true";string(rawReady);string(~isempty(caseIDs));"true";"false"], ...
    'VariableNames',{'Check','Value'});
put(Status,out,'Step8_Readiness.csv');
if cfg.MakeFigure, makeFigure(M,out); end
save(fullfile(out.runlog,['Step8_Config_' stamp '.mat']),'cfg','signature','Scan','-v7');
Result=struct('Config',cfg,'OutputRoot',out.root,'Manifest',M,'InningsAudit',A, ...
    'QC',Summary,'Readiness',Status,'Scan',Scan);
save(fullfile(out.root,'RevisedCodes_Step8_Result.mat'),'Result','-v7.3');
fprintf('\nSTEP 8 COMPLETE. Primary response-eligible: %d. Corrections: %d.\n', ...
    nnz(M.PrimaryModelEligible),height(Corrections));
fprintf('Audit tables to review: Step8_Readiness, Step8_QC_Summary, Step8_SplitSummary,\n');
fprintf('Step8_MetadataConflicts and Step8_EligibilitySummary.\n');
fprintf('Use revised Step 9 next; original Step 9 does not apply repairs or splits.\n');
end

function cfg=defaults()
cfg=struct('ProjectRoot','D:\VihaanProject1', ...
    'InputFolder','D:\VihaanProject1\final_retained_dataset', ...
    'YAMLFolder','D:\VihaanProject1\clean_from_yaml', ...
    'JSONFolder','D:\VihaanProject1\clean_from_json', ...
    'OutputRoot','D:\VihaanProject1\paper_outputs_revisedcodes\step08', ...
    'PrimaryGender',"men",'IncludeIT20',true,'ValidationStart',datetime(2023,1,1), ...
    'TestStart',datetime(2024,1,1),'Seed',20260520,'Folds',5, ...
    'CaseStudyMatchIDs',strings(0,1),'ReadSize',75000,'MaxInnings',8, ...
    'ForceRescan',false,'ReadRawJSON',true,'MakeFigure',true,'RunSelfTests',true, ...
    'CoverageWarning',0.95,'MinimumTrainingMatches',30);
end

function T=readStrings(path)
opts=detectImportOptions(path,'Delimiter',',','VariableNamingRule','preserve');
opts=setvartype(opts,opts.VariableNames,'string');
T=readtable(path,opts);
for k=1:width(T), T.(k)=cleanText(T.(k)); end
end
function s=cleanText(x)
s=strtrim(string(x)); s(ismissing(s))="";
end
function s=normalID(x)
s=cleanText(x); s=regexprep(s,'\.0+$','');
s(ismember(lower(s),["nan","na","null","<missing>"]))="";
end
function require(T,names,path)
missing=setdiff(string(names),string(T.Properties.VariableNames));
assert(isempty(missing),'Missing columns in %s: %s',path,strjoin(missing,', '));
end
function x=col(T,names)
x=repmat("",height(T),1);
for name=string(names)
    if ismember(name,string(T.Properties.VariableNames)), x=cleanText(T.(name)); return; end
end
end
function C=emptyConflict()
C=table(strings(0,1),strings(0,1),zeros(0,1),false(0,1), ...
    'VariableNames',{'MatchID','Source','Rows','ConflictingRecords'});
end
function [T,C]=deduplicate(T,source)
C=emptyConflict(); empty=strlength(T.MatchID)==0;
if any(empty)
    C=[C;table("",string(source),nnz(empty),true,'VariableNames',C.Properties.VariableNames)];
    T=T(~empty,:);
end
[ids,~,group]=unique(T.MatchID); counts=accumarray(group,1);
keep=true(height(T),1);
for k=find(counts>1)'
    rows=find(group==k); distinct=unique(T(rows,:),'rows'); conflict=height(distinct)>1;
    C=[C;table(ids(k),string(source),numel(rows),conflict,'VariableNames',C.Properties.VariableNames)]; %#ok<AGROW>
    keep(rows(2:end))=false;
end
T=T(keep,:); T=sortrows(T,'MatchID');
% Exact duplicates are harmless. Conflicting duplicates are quarantined later.
% Keep both identical and conflicting duplicate groups in the audit.
end

function M=canonicalMetadata(T,E)
M=table(T.MatchID,'VariableNames',{'MatchID'}); n=height(M);
[matched,index]=ismember(M.MatchID,E.MatchID);
M.EventMasterMatched=matched;
M.RawFormat=col(T,["Format","MatchType"]); M.RawGender=col(T,["Gender","GenderCanon"]);
M.StartDateRaw=col(T,["StartDate","StartDateRaw","Date"]);
M.EventName=repmat("UNKNOWN",n,1); M.EventFormat=repmat("",n,1);
M.EventGender=repmat("",n,1); M.EventDateRaw=repmat("",n,1);
M.EventParseOK=false(n,1);
if any(matched)
    M.EventName(matched)=col(E(index(matched),:),"EventName");
    M.EventFormat(matched)=col(E(index(matched),:),["MatchType","Format"]);
    M.EventGender(matched)=col(E(index(matched),:),"Gender");
    M.EventDateRaw(matched)=col(E(index(matched),:),"StartDateRaw");
    parse=col(E(index(matched),:),"ParseOK");
    M.EventParseOK(matched)=ismember(lower(parse),["1","true","yes"]);
end
M.EventName(strlength(M.EventName)==0)="UNKNOWN";
M.FormatCanon=canonFormat(M.RawFormat); M.GenderCanon=canonGender(M.RawGender);
ef=canonFormat(M.EventFormat); eg=canonGender(M.EventGender);
M.FormatSource=repmat("match_info",n,1); M.GenderSource=M.FormatSource;
fix=M.FormatCanon=="unknown" & ef~="unknown" & M.EventParseOK;
M.FormatCanon(fix)=ef(fix); M.FormatSource(fix)="event_master";
fix=M.GenderCanon=="unknown" & eg~="unknown" & M.EventParseOK;
M.GenderCanon(fix)=eg(fix); M.GenderSource(fix)="event_master";
M.StartDate=NaT(n,1); M.DateSource=repmat("unresolved",n,1);
for k=1:n
    M.StartDate(k)=parseDate(M.StartDateRaw(k));
    if ~isnat(M.StartDate(k)), M.DateSource(k)="match_info";
    elseif M.EventParseOK(k)
        M.StartDate(k)=parseDate(M.EventDateRaw(k));
        if ~isnat(M.StartDate(k)), M.DateSource(k)="event_master"; end
    end
end
M.Year=year(M.StartDate); M.Season=col(T,"Season");
M.Team1=col(T,"Team1"); M.Team2=col(T,"Team2"); M.Venue=col(T,"Venue");
M.ResultMethod=col(T,"ResultMethod"); M.Result=col(T,"Result");
M.ScheduledOvers=str2double(col(T,"OversPerInnings"));
M.BallsPerOver=str2double(col(T,"BallsPerOver"));
M.InfoJSONInvalid=false(n,1);
info=col(T,"InfoJSON");
for k=find(strlength(info)>0)'
    try
        d=jsondecode(info(k));
        if ~isfinite(M.ScheduledOvers(k)), M.ScheduledOvers(k)=numField(d,'overs'); end
        if ~isfinite(M.BallsPerOver(k)), M.BallsPerOver(k)=numField(d,'balls_per_over'); end
        if isfield(d,'outcome') && strlength(M.ResultMethod(k))==0
            M.ResultMethod(k)=textField(d.outcome,'method');
        end
        if isnat(M.StartDate(k)) && isfield(d,'dates')
            dd=d.dates; if iscell(dd), dd=dd{1}; elseif isstring(dd), dd=dd(1); end
            M.StartDate(k)=parseDate(string(dd));
            if ~isnat(M.StartDate(k)), M.DateSource(k)="InfoJSON"; end
        end
    catch
        M.InfoJSONInvalid(k)=true;
    end
end
M.Year=year(M.StartDate); M.FormatFamily=family(M.FormatCanon);
M.IsIT20=M.FormatCanon=="it20";
M.MetadataConflict=(M.EventParseOK & ef~="unknown" & family(ef)~=M.FormatFamily & ...
    M.FormatFamily~="excluded") | ...
    (M.EventParseOK & eg~="unknown" & M.GenderCanon~="unknown" & eg~=M.GenderCanon);
M.EventDateConflict=false(n,1);
for k=find(M.EventParseOK & ~isnat(M.StartDate))'
    d=parseDate(M.EventDateRaw(k));
    M.EventDateConflict(k)=~isnat(d) && d~=M.StartDate(k);
end
M.MetadataConflict=M.MetadataConflict | M.EventDateConflict;
end
function f=canonFormat(s)
s=lower(regexprep(cleanText(s),'[\s_-]',''));
f=repmat("unknown",size(s));
f(ismember(s,["odi","onedayinternational"]))="odi";
f(ismember(s,["t20","twenty20"]))="t20";
f(ismember(s,["t20i","t20international","twenty20international"]))="t20i";
f(s=="it20")="it20"; f(s=="test")="test"; f(s=="mdm")="mdm"; f(s=="odm")="odm";
end
function f=family(s)
f=repmat("excluded",size(s)); f(s=="odi")="ODI";
f(ismember(s,["t20","t20i","it20"]))="T20";
end
function g=canonGender(s)
s=lower(cleanText(s)); g=repmat("unknown",size(s));
g(ismember(s,["male","men","mens","men's"]))="men";
g(ismember(s,["female","women","womens","women's"]))="women";
end
function d=parseDate(s)
d=NaT; s=cleanText(s); if strlength(s)==0, return; end
if ~isempty(regexp(char(s),'^\d{4}(?:/\d{2,4})?$','once')), return; end
% ISO date, including ISO strings embedded in lists.
a=regexp(char(s),'\d{4}-\d{2}-\d{2}','match','once');
if ~isempty(a)
    try, d=datetime(a,'InputFormat','yyyy-MM-dd'); return; catch, end
end
% Original SnakeYAML/Java date text; ignore time zone and preserve local date.
a=regexp(char(s),'(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s+([A-Za-z]{3})\s+(\d{1,2})\s+\d{2}:\d{2}:\d{2}\s+\S+\s+(\d{4})','tokens','once');
if ~isempty(a)
    try, d=datetime([a{2} ' ' a{1} ' ' a{3}],'InputFormat','d MMM yyyy','Locale','en_US'); return; catch, end
end
% Never turn a season or a bare year into an invented match date.
for fmt=["dd/MM/yyyy","yyyy/MM/dd","dd-MMM-yyyy"]
    try, d=datetime(s,'InputFormat',fmt,'Locale','en_US'); if ~isnat(d), return; end, catch, end
end
end

function [signature,P]=sourceSignature(paths,cfg)
source=string(fieldnames(paths)); path=string(struct2cell(paths));
bytes=nan(numel(path),1); modified=bytes; exists=false(size(bytes));
for k=1:numel(path)
    exists(k)=isfile(path(k));
    if exists(k), q=dir(path(k)); bytes(k)=q.bytes; modified(k)=q.datenum; end
end
P=table(source,path,exists,bytes,modified,'VariableNames', ...
    {'Source','Path','Exists','Bytes','ModifiedDatenum'});
P=[P;table(["clean_yaml_folder";"clean_json_folder"], ...
    string({cfg.YAMLFolder;cfg.JSONFolder}), ...
    [isfolder(cfg.YAMLFolder);isfolder(cfg.JSONFolder)],nan(2,1),nan(2,1), ...
    'VariableNames',P.Properties.VariableNames)];
self=[mfilename('fullpath') '.m'];
if ~isfile(self), self=which('RevisedCodes_Step8_PoolingAuditSplits'); end
signature=struct('Protocol','Step8_revision_1.0','Source',P(1:numel(path),:), ...
    'CodeSHA256',sha256(self),'MaxInnings',cfg.MaxInnings);
end
function h=sha256(path)
fid=fopen(path,'rb'); assert(fid>=0,'Cannot fingerprint %s',path);
c=onCleanup(@() fclose(fid)); %#ok<NASGU>
b=fread(fid,Inf,'*uint8'); md=java.security.MessageDigest.getInstance('SHA-256');
md.update(b); h=lower(string(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[])));
end
function S=auditSchema(paths)
S=table(strings(0,1),strings(0,1),false(0,1),'VariableNames',{'Source','Column','RequiredForDeliveryAudit'});
required=["MatchID","InningsIndex","TotalRuns","IsLegalBall", ...
    "DeliverySeqInInnings","WicketsLost","IsWicket","WicketTypePrimary", ...
    "WicketsJSON","DeliveryJSON","ExtrasDetailJSON","RunsOffBat","ExtrasRuns"];
for name=string(fieldnames(paths))'
    if ~isfile(paths.(name)), continue; end
    opts=detectImportOptions(paths.(name),'VariableNamingRule','preserve');
    vars=string(opts.VariableNames(:)); req=false(size(vars));
    if name=="ball", req=ismember(vars,required); end
    S=[S;table(repmat(name,numel(vars),1),vars,req,'VariableNames',S.Properties.VariableNames)]; %#ok<AGROW>
end
end

function [A,C,Scan]=scanDeliveries(path,M,cfg)
required=["MatchID","InningsIndex","TotalRuns","IsLegalBall", ...
    "DeliverySeqInInnings","WicketsLost","IsWicket","WicketTypePrimary", ...
    "WicketsJSON","DeliveryJSON","ExtrasDetailJSON","RunsOffBat","ExtrasRuns","BattingTeam"];
ds=tabularTextDatastore(path,'Delimiter',',','TextType','string','ReadVariableNames',true);
vars=string(ds.VariableNames);
missing=setdiff(required,vars);
assert(isempty(missing),'Delivery audit requires columns: %s',strjoin(missing,', '));
ds.TextscanFormats=repmat({'%q'},1,numel(vars));
ds.SelectedVariableNames=cellstr(required); ds.ReadSize=cfg.ReadSize;
n=height(M); K=cfg.MaxInnings; N=n*K;
qnames={'Rows','LegalBalls','DeliveryRuns','GenuineDismissals','StoredMaxWickets', ...
    'RetiredHurtEvents','MultipleWicketDeliveries','WicketJSONFailures', ...
    'UnknownWicketKinds','LegalityCorrections','DismissalCorrections', ...
    'SequenceErrors','NumericErrors','RunIdentityErrors','StoredWicketInconsistency'};
Q=zeros(N,numel(qnames)); lastSeq=zeros(N,1); lastStoredWickets=zeros(N,1);
lastGenuine=zeros(N,1); team=repmat("",N,1); teamConflict=false(N,1);
C=emptyCorrections(); total=0; invalidInn=0; unknownRows=0; unknownIDs=strings(0,1);
ticScan=tic;
while hasdata(ds)
    try, B=read(ds);
    catch ME
        error('Step8:CSVRead',['CSV scan failed after %d rows. No completed cache was written. ' ...
            'Check quoted/multiline CSV records. MATLAB message: %s'],total,ME.message);
    end
    if isempty(B), continue; end
    nb=height(B); record=total+(1:nb)'; total=total+nb;
    ids=normalID(B.MatchID); [known,mi]=ismember(ids,M.MatchID);
    inn=str2double(cleanText(B.InningsIndex));
    validInn=isfinite(inn) & inn>=1 & inn<=K & inn==floor(inn);
    invalidInn=invalidInn+nnz(known & ~validInn);
    unknownRows=unknownRows+nnz(~known);
    unknownIDs=unique([unknownIDs;ids(~known)]);
    take=known & validInn;
    B=B(take,:); record=record(take); mi=mi(take); inn=inn(take);
    if isempty(B), continue; end
    key=sub2ind([n K],mi,inn); nr=height(B);
    runs=str2double(cleanText(B.TotalRuns)); bat=str2double(cleanText(B.RunsOffBat));
    ext=str2double(cleanText(B.ExtrasRuns)); seq=str2double(cleanText(B.DeliverySeqInInnings));
    storedLegal=str2double(cleanText(B.IsLegalBall));
    storedEvent=str2double(cleanText(B.IsWicket)); storedW=str2double(cleanText(B.WicketsLost));
    badNum=~isfinite(runs) | runs<0 | runs~=floor(runs) | ...
        ~isfinite(bat) | bat<0 | bat~=floor(bat) | ...
        ~isfinite(ext) | ext<0 | ext~=floor(ext) | ...
        ~ismember(storedLegal,[0 1]) | ~ismember(storedEvent,[0 1]) | ...
        ~isfinite(storedW) | storedW<0 | storedW>10 | storedW~=floor(storedW);
    identity=isfinite(runs) & isfinite(bat) & isfinite(ext) & abs(runs-bat-ext)>1e-9;
    legal=storedLegal; legal(~ismember(legal,[0 1]))=0;
    ej=cleanText(B.ExtrasDetailJSON);
    illegal=~cellfun(@isempty,regexp(cellstr(ej),'"(?:wides|noballs|no_balls)"\s*:','once'));
    % Nonempty extras JSON must parse; do not silently trust malformed text.
    badExtras=false(nr,1);
    for r=find(strlength(ej)>0)'
        try
            d=jsondecode(ej(r)); assert(isstruct(d) && isscalar(d));
            if isfield(d,'wides') || isfield(d,'noballs') || isfield(d,'no_balls')
                illegal(r)=true;
            end
        catch, badExtras(r)=true;
        end
    end
    legal(illegal)=0;
    % With a parsed extras object or explicitly empty extras/no extra runs,
    % the absence of wides/no-balls proves a legal delivery.
    provenLegal=~badExtras & ((strlength(ej)>0 & ~illegal) | ...
        (strlength(ej)==0 & ext==0));
    legal(provenLegal)=1;
    legalityFix=legal~=storedLegal & isfinite(storedLegal);
    badExtras=badExtras | (ext>0 & strlength(ej)==0);
    badNum=badNum | badExtras;
    genuine=zeros(nr,1); nevents=zeros(nr,1); retired=zeros(nr,1);
    jsonFail=false(nr,1); unknownKind=false(nr,1); reason=repmat("",nr,1);
    wj=cleanText(B.WicketsJSON); dj=cleanText(B.DeliveryJSON);
    hasDeliveryEvent=~cellfun(@isempty,regexp(cellstr(dj),'"wickets?"\s*:','once'));
    needsEvent=strlength(wj)>0 | storedEvent==1 | hasDeliveryEvent;
    for r=find(needsEvent)'
        payload=[]; parsed=false;
        if hasDeliveryEvent(r)
            try
                d=jsondecode(dj(r));
                if isfield(d,'wickets'), payload=d.wickets; parsed=true;
                elseif isfield(d,'wicket'), payload=d.wicket; parsed=true; end
            catch
            end
        end
        if ~parsed && strlength(wj(r))>0
            try, payload=jsondecode(wj(r)); parsed=true; catch, end
        end
        if parsed
            [genuine(r),nevents(r),retired(r),unknownKind(r)]=countEvents(payload);
        else
            jsonFail(r)=true; reason(r)=addReason(reason(r),"wicket_payload_unresolved");
        end
        if retired(r)>0, reason(r)=addReason(reason(r),"retired_hurt_or_not_out"); end
        if nevents(r)>1, reason(r)=addReason(reason(r),"multiple_wicket_events"); end
        if unknownKind(r), reason(r)=addReason(reason(r),"unknown_wicket_kind"); end
    end
    dismissalFix=~jsonFail & ~unknownKind & genuine~=storedEvent;
    reason(dismissalFix)=appendReasons(reason(dismissalFix),"dismissal_count_repair");
    reason(legalityFix)=appendReasons(reason(legalityFix),"legal_ball_repair");
    sequenceError=false(nr,1); storedInconsistent=false(nr,1);
    for kk=unique(key)'
        rows=find(key==kk);
        expected=lastSeq(kk)+(1:numel(rows))';
        sequenceError(rows)=~isfinite(seq(rows)) | seq(rows)~=expected;
        if isfinite(seq(rows(end))), lastSeq(kk)=seq(rows(end)); end
        oldExpected=lastStoredWickets(kk)+cumsum(storedEvent(rows));
        storedInconsistent(rows)=isfinite(storedW(rows)) & storedW(rows)~=oldExpected;
        if isfinite(storedW(rows(end))), lastStoredWickets(kk)=storedW(rows(end)); end
        lastGenuine(kk)=lastGenuine(kk)+sum(genuine(rows));
        ts=unique(cleanText(B.BattingTeam(rows))); ts=ts(strlength(ts)>0);
        if numel(ts)>1, teamConflict(kk)=true; end
        if ~isempty(ts)
            if strlength(team(kk))>0 && team(kk)~=ts(1), teamConflict(kk)=true; end
            team(kk)=ts(1);
        end
    end
    review=jsonFail | unknownKind;
    emit=dismissalFix | legalityFix | retired>0 | nevents>1 | review;
    if any(emit)
        Cr=table(record(emit),M.MatchID(mi(emit)),inn(emit),seq(emit), ...
            storedLegal(emit),legal(emit),storedEvent(emit),genuine(emit), ...
            nevents(emit),retired(emit),review(emit),reason(emit), ...
            'VariableNames',C.Properties.VariableNames);
        C=[C;Cr]; %#ok<AGROW>
    end
    runs(~isfinite(runs))=0; w=storedW; w(~isfinite(w))=0;
    values=[ones(nr,1),legal,runs,genuine,w,retired,double(nevents>1), ...
        double(jsonFail),double(unknownKind),double(legalityFix),double(dismissalFix), ...
        double(sequenceError),double(badNum),double(identity),double(storedInconsistent)];
    for k=1:numel(qnames)
        if k==5
            Q(:,k)=max(Q(:,k),accumarray(key,values(:,k),[N 1],@max,0));
        else
            Q(:,k)=Q(:,k)+accumarray(key,values(:,k),[N 1],@sum,0);
        end
    end
    fprintf('Delivery rows scanned: %d | elapsed %.1f min\n',total,toc(ticScan)/60);
end
used=find(Q(:,1)>0); [matchRow,innings]=ind2sub([n K],used);
A=table(M.MatchID(matchRow),matchRow,innings,team(used),teamConflict(used), ...
    'VariableNames',{'MatchID','MatchRow','InningsIndex','BattingTeam','BattingTeamConflict'});
A=[A,array2table(Q(used,:),'VariableNames',qnames)];
A.GenuineDismissalsAboveTen=A.GenuineDismissals>10;
A=sortrows(A,{'MatchID','InningsIndex'});
Scan=struct('RowsScanned',total,'UnknownMatchRows',unknownRows, ...
    'UnknownMatchIDs',unknownIDs,'InvalidInningsRows',invalidInn, ...
    'ElapsedSeconds',toc(ticScan),'MaxInnings',K);
assert(invalidInn==0,['Invalid/out-of-range innings indices detected: %d. ' ...
    'Fix indices or increase MaxInnings; no valid completed scan cache was written.'],invalidInn);
end
function C=emptyCorrections()
C=table(zeros(0,1),strings(0,1),zeros(0,1),zeros(0,1),zeros(0,1), ...
    zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),false(0,1),strings(0,1), ...
    'VariableNames',{'CSVRecordIndex','MatchID','InningsIndex','DeliverySeqInInnings', ...
    'StoredIsLegalBall','CorrectedIsLegalBall','StoredIsWicket', ...
    'GenuineDismissalsOnDelivery','WicketEventCount','RetiredNotOutEvents', ...
    'NeedsReview','Reason'});
end
function [g,n,r,unknown]=countEvents(payload)
g=0; n=0; r=0; unknown=false;
if isempty(payload), return; end
if isstruct(payload), events=num2cell(payload);
elseif iscell(payload), events=payload;
else, unknown=true; return; end
valid=["bowled","caught","caught and bowled","lbw","stumped","run out", ...
    "hit wicket","obstructing the field","hit the ball twice","handled the ball", ...
    "timed out","retired out"];
for k=1:numel(events)
    e=events{k}; n=n+1;
    if ~isstruct(e) || ~isscalar(e), unknown=true; continue; end
    kind=lower(regexprep(textField(e,'kind'),'[_-]',' '));
    kind=regexprep(kind,'\s+',' ');
    if ismember(kind,["retired hurt","retired not out"]), r=r+1;
    elseif ismember(kind,valid), g=g+1;
    else, unknown=true; end
end
end
function s=addReason(s,t)
if strlength(s)==0, s=t; else, s=s+";"+t; end
end
function s=appendReasons(s,t)
for k=1:numel(s), s(k)=addReason(s(k),t); end
end

function [R,I]=rawMetadata(M,cfg,out,signature)
R=emptyRaw();
I=table(M.MatchID,repmat("not_found",height(M),1),repmat("",height(M),1), ...
    zeros(height(M),1),repmat("",height(M),1),'VariableNames', ...
    {'MatchID','Status','Path','MatchingFiles','Error'});
if ~cfg.ReadRawJSON
    I.Status(:)="disabled"; return;
end
if ~isfolder(cfg.JSONFolder)
    warning('JSON folder not found. Raw metadata remains unresolved.'); return;
end
files=dir(fullfile(cfg.JSONFolder,'**','*.json'));
ids=strings(numel(files),1); paths=ids;
for k=1:numel(files)
    [~,stem]=fileparts(files(k).name); ids(k)=normalID(stem);
    paths(k)=string(fullfile(files(k).folder,files(k).name));
end
fileSig=table(paths,double([files.bytes]'),double([files.datenum]'), ...
    'VariableNames',{'Path','Bytes','ModifiedDatenum'});
rawSignature=struct('Parent',signature,'Files',fileSig,'Folder',string(cfg.JSONFolder));
cache=fullfile(out.cache,'Step8_RawMetadata.mat');
if ~cfg.ForceRescan && isfile(cache)
    saved=load(cache,'rawSignature','R','I');
    if isfield(saved,'rawSignature') && isequaln(saved.rawSignature,rawSignature)
        R=saved.R; I=saved.I; fprintf('Reusing raw JSON metadata cache.\n'); return;
    end
end
fprintf('Inspecting raw JSON metadata where match-ID files are available (%d files found).\n',numel(files));
for k=1:height(M)
    if M.FormatFamily(k)=="excluded", continue; end
    found=find(ids==M.MatchID(k)); I.MatchingFiles(k)=numel(found);
    if isempty(found), continue; end
    if numel(found)>1
        I.Status(k)="duplicate_paths"; I.Error(k)="Resolve duplicate JSON paths before use."; continue;
    end
    I.Path(k)=paths(found);
    try
        d=jsondecode(fileread(paths(found)));
        assert(isstruct(d) && isfield(d,'info') && isfield(d,'innings'), ...
            'Not a full Cricsheet match JSON (info/innings absent).');
        initialOvers=numField(d.info,'overs'); bpo=numField(d.info,'balls_per_over');
        items=d.innings; if isstruct(items), items=num2cell(items); end
        assert(iscell(items),'Unexpected innings representation.');
        for j=1:numel(items)
            e=items{j}; assert(isstruct(e),'Unexpected innings item.');
            super=isfield(e,'super_over') && logicalValue(e.super_over);
            absent=0; if isfield(e,'absent_hurt'), absent=numel(e.absent_hurt); end
            pre=0; post=0;
            if isfield(e,'penalty_runs')
                p=e.penalty_runs;
                if isfield(p,'pre'), pre=numField(p,'pre'); end
                if isfield(p,'post'), post=numField(p,'post'); end
            end
            targetOvers=NaN; targetRuns=NaN;
            if isfield(e,'target'), targetOvers=numField(e.target,'overs'); targetRuns=numField(e.target,'runs'); end
            power=isfield(e,'powerplays'); miscount=isfield(e,'miscounted_overs');
            rawLegal=0; rawRuns=0; rawW=0; rawRetired=0; rawUnknown=false;
            if isfield(e,'overs')
                oo=e.overs; if isstruct(oo), oo=num2cell(oo); end
                for h=1:numel(oo)
                    over=oo{h}; deliveries=over.deliveries;
                    if isstruct(deliveries), deliveries=num2cell(deliveries); end
                    for z=1:numel(deliveries)
                        dv=deliveries{z}; isLegal=true;
                        if isfield(dv,'extras')
                            ex=dv.extras; isLegal=~(isfield(ex,'wides') || isfield(ex,'noballs'));
                        end
                        rawLegal=rawLegal+double(isLegal);
                        rawRuns=rawRuns+numField(dv.runs,'total');
                        if isfield(dv,'wickets')
                            [g,~,rr,unk]=countEvents(dv.wickets);
                            rawW=rawW+g; rawRetired=rawRetired+rr; rawUnknown=rawUnknown || unk;
                        end
                    end
                end
            else
                error('Unexpected raw JSON innings: overs absent.');
            end
            row=table(M.MatchID(k),j,textField(e,'team'),initialOvers,bpo,super, ...
                absent,pre,post,targetOvers,targetRuns,power,miscount, ...
                rawLegal,rawRuns,rawW,rawRetired,rawUnknown, ...
                'VariableNames',R.Properties.VariableNames);
            R=[R;row]; %#ok<AGROW>
        end
        I.Status(k)="parsed";
    catch ME
        R=R(R.MatchID~=M.MatchID(k),:);
        I.Status(k)="parse_failed"; I.Error(k)=string(ME.message);
    end
    if mod(k,250)==0, fprintf('Raw metadata audit: %d / %d matches\n',k,height(M)); end
end
save(cache,'rawSignature','R','I','-v7.3');
end
function R=emptyRaw()
R=table(strings(0,1),zeros(0,1),strings(0,1),zeros(0,1),zeros(0,1),false(0,1), ...
    zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),false(0,1),false(0,1), ...
    zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),false(0,1),'VariableNames', ...
    {'MatchID','InningsIndex','BattingTeam','InitialScheduledOvers','BallsPerOver', ...
    'IsSuperOver','AbsentHurtCount','PenaltyPre','PenaltyPost','TargetOvers','TargetRuns', ...
    'PowerplaysAvailable','MiscountedOvers','RawLegalBalls','RawDeliveryRuns', ...
    'RawGenuineDismissals','RawRetiredNotOutEvents','RawUnknownWicketKind'});
end
function v=numField(d,f)
v=NaN;
if isstruct(d) && isscalar(d) && isfield(d,f)
    x=d.(f); if isnumeric(x) && isscalar(x), v=double(x);
    elseif (ischar(x) || isstring(x)) && isscalar(string(x)), v=str2double(string(x)); end
end
end
function s=textField(d,f)
s="";
if isstruct(d) && isscalar(d) && isfield(d,f)
    x=d.(f); if ischar(x) || (isstring(x) && isscalar(x)), s=cleanText(x); end
end
end
function b=logicalValue(v)
if islogical(v) && isscalar(v), b=v; else, b=ismember(lower(string(v)),["1","true","yes"]); end
end

function [A,M]=classifyInnings(A,M,R,I,cfg)
n=height(M); h=height(A);
M.RawJSONStatus=I.Status; M.RawJSONPath=I.Path;
A.RawMetadataVerified=false(h,1); A.RawIntegrityMismatch=false(h,1);
A.PenaltyPre=zeros(h,1); A.PenaltyPost=zeros(h,1); A.AbsentHurtCount=zeros(h,1);
A.IsSuperOver=A.InningsIndex>2; A.MiscountedOvers=false(h,1);
A.TargetOvers=nan(h,1); A.TargetRuns=nan(h,1);
A.RawLegalBalls=nan(h,1); A.RawDeliveryRuns=nan(h,1); A.RawGenuineDismissals=nan(h,1);
A.InitialScheduledOvers=M.ScheduledOvers(A.MatchRow);
A.BallsPerOver=M.BallsPerOver(A.MatchRow);
A.RawTeamMismatch=false(h,1); A.RawScheduleConflict=false(h,1);
if ~isempty(R)
    key=A.MatchID+"|"+string(A.InningsIndex);
    rkey=R.MatchID+"|"+string(R.InningsIndex);
    assert(numel(unique(rkey))==height(R),'Duplicate raw innings keys.');
    [found,ri]=ismember(key,rkey);
    for k=find(found)'
        r=R(ri(k),:); A.RawMetadataVerified(k)=true;
        A.PenaltyPre(k)=r.PenaltyPre; A.PenaltyPost(k)=r.PenaltyPost;
        A.AbsentHurtCount(k)=r.AbsentHurtCount; A.IsSuperOver(k)=r.IsSuperOver || A.InningsIndex(k)>2;
        A.MiscountedOvers(k)=r.MiscountedOvers; A.TargetOvers(k)=r.TargetOvers;
        A.TargetRuns(k)=r.TargetRuns; A.RawLegalBalls(k)=r.RawLegalBalls;
        A.RawDeliveryRuns(k)=r.RawDeliveryRuns; A.RawGenuineDismissals(k)=r.RawGenuineDismissals;
        A.RawIntegrityMismatch(k)=r.RawUnknownWicketKind || ...
            r.RawLegalBalls~=A.LegalBalls(k) || abs(r.RawDeliveryRuns-A.DeliveryRuns(k))>1e-9 || ...
            r.RawGenuineDismissals~=A.GenuineDismissals(k) || ...
            ~isfinite(r.RawDeliveryRuns) || ~isfinite(r.PenaltyPre) || ~isfinite(r.PenaltyPost);
        A.RawTeamMismatch(k)=strlength(A.BattingTeam(k))>0 && ...
            strlength(r.BattingTeam)>0 && A.BattingTeam(k)~=r.BattingTeam;
        if isfinite(r.InitialScheduledOvers)
            A.RawScheduleConflict(k)=isfinite(A.InitialScheduledOvers(k)) && ...
                A.InitialScheduledOvers(k)~=r.InitialScheduledOvers;
            A.InitialScheduledOvers(k)=r.InitialScheduledOvers;
        end
        if isfinite(r.BallsPerOver)
            A.RawScheduleConflict(k)=A.RawScheduleConflict(k) || ...
                (isfinite(A.BallsPerOver(k)) && A.BallsPerOver(k)~=r.BallsPerOver);
            A.BallsPerOver(k)=r.BallsPerOver;
        end
    end
end
% Fill match-level schedule only from matched first-innings raw metadata.
for k=find(A.InningsIndex==1 & A.RawMetadataVerified)'
    m=A.MatchRow(k);
    if ~isfinite(M.ScheduledOvers(m)), M.ScheduledOvers(m)=A.InitialScheduledOvers(k); end
    if ~isfinite(M.BallsPerOver(m)), M.BallsPerOver(m)=A.BallsPerOver(k); end
end
M.StandardBalls=nan(n,1); M.StandardBalls(M.FormatFamily=="ODI")=300;
M.StandardBalls(M.FormatFamily=="T20")=120;
M.MetadataEligible=ismember(M.FormatFamily,["ODI","T20"]) & ...
    ismember(M.GenderCanon,["men","women"]) & ~M.MetadataConflict & ~M.DuplicateConflict;
if ~cfg.IncludeIT20, M.MetadataEligible(M.IsIT20)=false; end
M.MetadataReason=repmat("eligible",n,1);
M.MetadataReason(~ismember(M.FormatFamily,["ODI","T20"]))="excluded_format";
M.MetadataReason(M.GenderCanon=="unknown")="unknown_gender";
if ~cfg.IncludeIT20, M.MetadataReason(M.IsIT20)="it20_policy_exclusion"; end
M.MetadataReason(M.MetadataConflict)="conflicting_metadata";
M.MetadataReason(M.DuplicateConflict)="conflicting_duplicate_id";
M.HasDeliveries=false(n,1); M.HasDeliveries(unique(A.MatchRow))=true;
M.FirstInningsResponseEligible=false(n,1); M.FirstInningsClass=repmat("missing_first_innings",n,1);
M.FirstInningsReason=M.FirstInningsClass;
M.NeedsStateRepair=false(n,1); M.RawIntegrityReview=false(n,1);
A.NominalBalls=M.StandardBalls(A.MatchRow);
A.InitialAllocatedBalls=A.InitialScheduledOvers.*A.BallsPerOver;
A.ReconciledFinalScore=A.DeliveryRuns+A.PenaltyPre+A.PenaltyPost;
A.PenaltyReconciliationVerified=A.RawMetadataVerified;
A.NeedsStateRepair=A.LegalityCorrections>0 | A.DismissalCorrections>0 | ...
    A.RetiredHurtEvents>0 | A.MultipleWicketDeliveries>0 | A.PenaltyPre~=0 | A.PenaltyPost~=0;
A.RecordIntegrityOK=A.NumericErrors==0 & A.RunIdentityErrors==0 & ...
    A.SequenceErrors==0 & A.WicketJSONFailures==0 & A.UnknownWicketKinds==0 & ...
    ~A.GenuineDismissalsAboveTen & ~A.BattingTeamConflict & ...
    ~A.RawIntegrityMismatch & ~A.RawTeamMismatch & ~A.RawScheduleConflict & ...
    A.StoredWicketInconsistency==0;
A.StandardSchedule=isfinite(A.InitialAllocatedBalls) & ...
    abs(A.InitialAllocatedBalls-A.NominalBalls)<1e-9 & A.BallsPerOver==6;
A.CompletionClass=repmat("unresolved",h,1); A.EligibilityReason=repmat("needs_completion_review",h,1);
A.ResponseEligible=false(h,1);
method=lower(M.ResultMethod(A.MatchRow));
interrupted=contains(method,"d/l") | contains(method,"dls") | contains(method,"duckworth") | ...
    contains(method,"vjd");
for k=1:h
    if ~M.MetadataEligible(A.MatchRow(k))
        A.EligibilityReason(k)=M.MetadataReason(A.MatchRow(k)); continue;
    end
    if A.IsSuperOver(k), A.CompletionClass(k)="super_over"; A.EligibilityReason(k)="super_over"; continue; end
    if ~A.RecordIntegrityOK(k)
        A.CompletionClass(k)="integrity_review"; A.EligibilityReason(k)="delivery_or_raw_integrity_review"; continue;
    end
    if A.BallsPerOver(k)~=6 || ~isfinite(A.BallsPerOver(k))
        A.EligibilityReason(k)="non_six_or_unknown_balls_per_over"; continue;
    end
    if ~isfinite(A.InitialAllocatedBalls(k))
        A.EligibilityReason(k)="unknown_initial_allocation"; continue;
    end
    if ~A.StandardSchedule(k)
        A.CompletionClass(k)="nonstandard_initial_allocation";
        A.EligibilityReason(k)="shortened_schedule_separate_cohort"; continue;
    end
    if A.LegalBalls(k)>A.NominalBalls(k)
        A.CompletionClass(k)="allocation_review"; A.EligibilityReason(k)="legal_balls_exceed_nominal"; continue;
    end
    if A.InningsIndex(k)~=1
        if A.GenuineDismissals(k)==10, A.CompletionClass(k)="chase_all_out_selected";
        elseif A.LegalBalls(k)==A.NominalBalls(k), A.CompletionClass(k)="chase_full_length_selected";
        else, A.CompletionClass(k)="chase_success_or_interruption_censored"; end
        A.EligibilityReason(k)="second_innings_requires_separate_selection_analysis"; continue;
    end
    if A.LegalBalls(k)==A.NominalBalls(k)
        A.CompletionClass(k)="completed_full_length";
    elseif A.GenuineDismissals(k)==10 && ~interrupted(k)
        A.CompletionClass(k)="completed_early_all_out";
    elseif A.GenuineDismissals(k)==10 && interrupted(k)
        A.CompletionClass(k)="all_out_interrupted_allocation_review";
        A.EligibilityReason(k)="verify_first_innings_allocation_timeline"; continue;
    else
        A.CompletionClass(k)="truncated_or_unresolved_first_innings";
        A.EligibilityReason(k)="no_observed_completed_standard_innings_response"; continue;
    end
    A.ResponseEligible(k)=true;
    A.EligibilityReason(k)="eligible_completed_standard_first_innings";
end
for k=find(A.InningsIndex==1)'
    m=A.MatchRow(k); M.FirstInningsResponseEligible(m)=A.ResponseEligible(k);
    M.FirstInningsClass(m)=A.CompletionClass(k); M.FirstInningsReason(m)=A.EligibilityReason(k);
    M.NeedsStateRepair(m)=A.NeedsStateRepair(k); M.RawIntegrityReview(m)=~A.RecordIntegrityOK(k);
end
% Unknown/missing raw metadata is visible. It is not silently certified.
% CSV-full-length and non-interrupted genuine all-out evidence can provisionally
% establish response eligibility; Step9 must inspect the readiness/audit flags.
end

function makePools(M,out,cfg)
for f=["ODI","T20"]
    for g=["men","women"]
        eligible=M.FirstInningsResponseEligible & M.FormatFamily==f & M.GenderCanon==g;
        for split=["train","validation","test"]
            B=M(eligible & M.Split==split, ...
                {'MatchID','FormatFamily','GenderCanon','StartDate','Split','TrainingFold','NeedsStateRepair'});
            put(B,out,"Pool_"+f+"_"+g+"_"+split+"_MatchIDs.csv");
            if g==string(cfg.PrimaryGender) && split=="train"
                put(B,out,"Pool_"+f+"_MatchIDs.csv");
                put(B(~M.IsIT20(eligible & M.Split==split),:),out, ...
                    "Pool_"+f+"_PrimaryTrain_NoIT20_MatchIDs.csv");
            end
        end
        put(M(eligible & ismember(M.Split,["train","validation","test"]),:),out, ...
            "Pool_"+f+"_"+g+"_AllEligibleManifest.csv");
    end
end
put(M(M.CaseStudyReserved,:),out,'Step8_CaseStudyManifest.csv');
end

function Q=summaries(M,A,C,Scan,out,cfg)
metric=["DeliveryRowsScanned";"UnknownMatchRows";"UnknownMatchIDs";"InvalidInningsRows"; ...
    "MetadataMatches";"ConflictingMetadataMatches";"ConflictingDuplicateMatches"; ...
    "CandidateMatches";"CandidatesMissingDeliveries";"CandidatesWithUnknownDate"; ...
    "CompletedFirstInningsResponses";"PrimaryResponseEligibleMatches"; ...
    "EarlyAllOutFirstInningsRetained";"CorrectionRecords";"UnresolvedCorrectionRecords"; ...
    "RawIntegrityMismatchInnings";"RawMetadataVerifiedInnings";"CaseStudyMatchesReserved"; ...
    "MinimumInningsBallCutoffApplied";"ValidationStart";"TestStart"; ...
    "MinimumTrainingMatchesWarning";"CoverageWarningThreshold"];
values=[string(Scan.RowsScanned);string(Scan.UnknownMatchRows);string(numel(Scan.UnknownMatchIDs)); ...
    string(Scan.InvalidInningsRows);string(height(M));string(nnz(M.MetadataConflict)); ...
    string(nnz(M.DuplicateConflict));string(nnz(M.MetadataEligible)); ...
    string(nnz(M.MetadataEligible & ~M.HasDeliveries)); ...
    string(nnz(M.MetadataEligible & isnat(M.StartDate)));string(nnz(M.FirstInningsResponseEligible)); ...
    string(nnz(M.PrimaryModelEligible));string(nnz(A.ResponseEligible & A.CompletionClass=="completed_early_all_out")); ...
    string(height(C));string(nnz(C.NeedsReview));string(nnz(A.RawIntegrityMismatch)); ...
    string(nnz(A.RawMetadataVerified));string(nnz(M.CaseStudyReserved));"none"; ...
    string(cfg.ValidationStart,'yyyy-MM-dd');string(cfg.TestStart,'yyyy-MM-dd'); ...
    string(cfg.MinimumTrainingMatches);string(cfg.CoverageWarning)];
Q=table(metric,values,'VariableNames',{'Metric','Value'});
put(Q,out,'Step8_QC_Summary.csv');
S=groupsummary(M,{'FormatFamily','GenderCanon','Split'});
S=renamevars(S,'GroupCount','MatchCount'); put(S,out,'Step8_SplitSummary.csv');
E=groupsummary(M,{'FormatFamily','GenderCanon','FirstInningsClass','FirstInningsReason'});
E=renamevars(E,'GroupCount','MatchCount'); put(E,out,'Step8_EligibilitySummary.csv');
S=groupsummary(M(M.PrimaryModelEligible,:),{'FormatFamily','Split'});
S=renamevars(S,'GroupCount','ResponseEligibleMatches'); put(S,out,'Step8_PrimarySplitSummary.csv');
Y=groupsummary(M(M.MetadataEligible & ~isnat(M.StartDate),:),{'Year','FormatFamily','GenderCanon'});
Y=renamevars(Y,'GroupCount','MatchCount'); put(Y,out,'Step8_FormatGenderYear.csv');
E=groupsummary(M(M.MetadataEligible,:),{'FormatFamily','GenderCanon','EventName'});
E=renamevars(E,'GroupCount','MatchCount'); put(E,out,'Step8_CompetitionCounts.csv');
put(table(Scan.UnknownMatchIDs,'VariableNames',{'MatchID'}),out,'Step8_UnknownDeliveryMatchIDs.csv');
for f=["ODI","T20"]
    candidates=M.MetadataEligible & M.FormatFamily==f;
    if any(candidates)
        coverage=mean(M.HasDeliveries(candidates));
        fprintf('%s match-record presence coverage: %.2f%% (NOT legal-ball completeness).\n',f,100*coverage);
        if coverage<cfg.CoverageWarning, warning('%s record-presence coverage below reporting threshold.',f); end
    end
    for s=["train","validation","test"]
        count=nnz(M.PrimaryModelEligible & M.FormatFamily==f & M.Split==s);
        fprintf('%s primary %s response-eligible matches: %d\n',f,s,count);
        if count==0, warning('Empty %s %s pool: do not fit/evaluate that cohort.',f,s); end
        if s=="train" && count<cfg.MinimumTrainingMatches
            warning('%s training sample below warning threshold; no automatic cutoff adjustment.',f);
        end
    end
end
end
function D=variableDictionary()
name=["MatchID";"FormatCanon";"GenderCanon";"StartDate";"InitialAllocatedBalls"; ...
    "LegalBalls";"GenuineDismissals";"RetiredHurtEvents";"DeliveryRuns"; ...
    "ReconciledFinalScore";"TargetOvers";"RawMetadataVerified"; ...
    "NeedsStateRepair";"ResponseEligible";"Split";"TrainingFold"; ...
    "CSVRecordIndex";"GenuineDismissalsOnDelivery"];
meaning=["Stable match key; whole matches remain in one split"; ...
    "Exact format aliases; odm/mdm are not converted to ODI"; ...
    "Exact gender aliases; female maps to women"; ...
    "Actual calendar date, never invented from season/year"; ...
    "Initial scheduled overs times recorded balls per over; not a full interruption history"; ...
    "Count of legal deliveries, with audited wides/no-ball corrections"; ...
    "Count of dismissal events; excludes retired hurt/not out"; ...
    "Retirement events without dismissal; player availability remains a separate issue"; ...
    "Sum of per-delivery total runs including delivery extras"; ...
    "DeliveryRuns plus innings-level pre/post penalty runs when raw metadata is available"; ...
    "Target innings allocation reported in raw JSON; cannot reconstruct all earlier changes"; ...
    "Matching full raw JSON was parsed and compared against retained delivery aggregates"; ...
    "Revised Step9 must apply event/legal-ball/penalty corrections before constructing states"; ...
    "Observed completed standard first innings with passing integrity checks; no 60/30 cutoff"; ...
    "Prespecified train/validation/test or case-study reservation; review/ineligible labels excluded"; ...
    "Seeded match-grouped folds within training only; held-out matches have fold zero"; ...
    "One-based CSV data-record ordinal, excluding header; tied to source signature"; ...
    "Correct dismissal increment, not cumulative wickets lost; reconstruct cumulative states in Step9"];
D=table(name,meaning,'VariableNames',{'Variable','Definition'});
end
function makeFigure(M,out)
F=figure('Visible','off','Color','w','Position',[100 100 1100 430]);
c=onCleanup(@() close(F)); %#ok<NASGU>
tiledlayout(1,2,'TileSpacing','compact');
for f=["ODI","T20"]
    nexttile; hold on;
    base=M.PrimaryModelEligible & M.FormatFamily==f;
    yy=unique(M.Year(base));
    if isempty(yy), title(f+": no eligible primary matches"); continue; end
    counts=zeros(numel(yy),3); splits=["train","validation","test"];
    for k=1:3
        for j=1:numel(yy), counts(j,k)=nnz(base & M.Split==splits(k) & M.Year==yy(j)); end
    end
    bar(yy,counts,'stacked'); xlabel('Calendar year'); ylabel('Response-eligible matches');
    title(f+" primary cohort"); legend(splits,'Location','northwest'); grid on;
end
exportgraphics(F,fullfile(out.figures,'Fig_Step8_PrimaryTemporalCohorts.png'),'Resolution',300);
exportgraphics(F,fullfile(out.figures,'Fig_Step8_PrimaryTemporalCohorts.pdf'),'ContentType','vector');
end
function put(T,out,name)
writetable(T,fullfile(out.tables,char(name)));
end


function runSelfTests(cfg)
% Small preflight checks run in MATLAB before any expensive scan.
assert(isequal(canonGender(["male";"female";"men";"women"]), ...
    ["men";"women";"men";"women"]),'Gender canonicalization regression.');
assert(isequal(family(canonFormat(["odi";"odm";"mdm";"it20"])), ...
    ["ODI";"excluded";"excluded";"T20"]),'Format canonicalization regression.');
assert(parseDate("Thu Nov 03 05:30:00 IST 2016")==datetime(2016,11,3), ...
    'Java date parsing regression.');
assert(parseDate("2024-06-15")==datetime(2024,6,15),'ISO date regression.');
assert(isnat(parseDate("2024")) && isnat(parseDate("2023/24")), ...
    'Seasons/years must not become invented dates.');
[g,n,r,u]=countEvents(jsondecode('{"kind":"retired hurt","player_out":"A"}'));
assert(g==0 && n==1 && r==1 && ~u,'Retired hurt incorrectly treated as dismissal.');
[g,n,r,u]=countEvents(jsondecode( ...
    '[{"kind":"caught","player_out":"A"},{"kind":"retired hurt","player_out":"B"}]'));
assert(g==1 && n==2 && r==1 && ~u,'Multiple-event dismissal handling regression.');
[g,~,~,u]=countEvents(jsondecode('{"kind":"unknown kind","player_out":"A"}'));
assert(g==0 && u,'Unknown dismissal kinds must trigger review.');
D=table(["1";"1";"2";"2"],["same";"same";"x";"y"], ...
    'VariableNames',{'MatchID','Value'});
[DD,DC]=deduplicate(D,"fixture");
assert(height(DD)==2 && height(DC)==2 && nnz(DC.ConflictingRecords)==1, ...
    'Duplicate-key audit regression.');
T=table(["a";"b";"c"],repmat("odi",3,1),repmat("male",3,1), ...
    repmat("2022-01-01",3,1),repmat("50",3,1),repmat("6",3,1), ...
    'VariableNames',{'MatchID','Format','Gender','StartDate','OversPerInnings','BallsPerOver'});
E=table(strings(0,1),'VariableNames',{'MatchID'});
M=canonicalMetadata(T,E); M.DuplicateConflict=false(3,1);
A=table(T.MatchID,(1:3)',ones(3,1),repmat("Batting team",3,1),false(3,1), ...
    'VariableNames',{'MatchID','MatchRow','InningsIndex','BattingTeam','BattingTeamConflict'});
vars=["Rows","LegalBalls","DeliveryRuns","GenuineDismissals","StoredMaxWickets", ...
    "RetiredHurtEvents","MultipleWicketDeliveries","WicketJSONFailures", ...
    "UnknownWicketKinds","LegalityCorrections","DismissalCorrections", ...
    "SequenceErrors","NumericErrors","RunIdentityErrors","StoredWicketInconsistency"];
for v=vars, A.(v)=zeros(3,1); end
A.Rows=[40;90;300]; A.LegalBalls=A.Rows; A.DeliveryRuns=[50;80;200];
A.GenuineDismissals=[10;7;8]; A.GenuineDismissalsAboveTen=false(3,1);
I=table(T.MatchID,repmat("not_found",3,1),repmat("",3,1), ...
    'VariableNames',{'MatchID','Status','Path'});
[AA,MM]=classifyInnings(A,M,emptyRaw(),I,cfg);
assert(isequal(AA.ResponseEligible,[true;false;true]), ...
    'Early all-out must be retained; truncated innings must be excluded.');
assert(MM.FirstInningsResponseEligible(1),'Short all-out threshold regression.');
M.ResultMethod(1)="DLS";
[AA,~]=classifyInnings(A,M,emptyRaw(),I,cfg);
assert(~AA.ResponseEligible(1),'Interrupted all-out needs allocation review.');
A.RunIdentityErrors(3)=1;
[AA,~]=classifyInnings(A,M,emptyRaw(),I,cfg);
assert(~AA.ResponseEligible(3),'Run reconciliation errors must prevent fitting.');
fprintf('Preflight self-tests passed: aliases, dates, retirements, duplicates and eligibility.\n');
end
