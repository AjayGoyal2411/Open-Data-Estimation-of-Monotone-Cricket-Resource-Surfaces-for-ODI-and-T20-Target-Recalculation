function Check = RevisedCodes_Step8A_PrerequisiteAudit
% Save in D:\VihaanProject1. Run:
%   Check = RevisedCodes_Step8A_PrerequisiteAudit;
% Supplements completed Step8 using original YAML files and existing audits.
% Does not scan ball_by_ball_all.csv or rerun Steps1--7. YAML fallback reads
% only candidate matches lacking JSON, plus unmatched delivery IDs. Results
% are cached. It uses the SAME SnakeYAML jar used in the original Step1.
% All original retained data and Step8 outputs remain unchanged.
% New Step9 must use step08_prerequisites, not unsupplemented Step8 pools.
% Known team alias is applied only with matching raw aggregate checks.
% Unresolved integrity/allocation exceptions remain excluded and documented.
% Case IDs below were matched by teams/date to the uploaded manifest. This
% establishes identity, NOT independent verification of interruption targets.
% Full interruption ledgers and dated strength features remain future work.

root='D:\VihaanProject1';
base=fullfile(root,'paper_outputs_revisedcodes','step08');
yamlFolder=fullfile(root,'ALLYAML');
out=fullfile(root,'paper_outputs_revisedcodes','step08_prerequisites');
tab=fullfile(out,'tables'); cacheFolder=fullfile(out,'cache');
assert(isfolder(yamlFolder),'Missing YAML folder: %s',yamlFolder);
assert(isfile(fullfile(base,'RevisedCodes_Step8_Result.mat')), ...
    'Completed Step8 Result MAT file is required.');
for p=string({out,tab,cacheFolder}), if ~isfolder(p), mkdir(p); end, end
logFile=fullfile(out,['RunLog_Step8A_' char(datetime('now','Format','yyyyMMdd_HHmmss')) '.txt']);
diary(logFile); cleanup=onCleanup(@() diary('off')); %#ok<NASGU>
S=load(fullfile(base,'RevisedCodes_Step8_Result.mat'),'Result');
M=S.Result.Manifest; A=S.Result.InningsAudit; cfg=S.Result.Config;
M.MatchID=string(M.MatchID); A.MatchID=string(A.MatchID);
R=readtable(fullfile(base,'tables','Step8_RawInningsMetadata.csv'), ...
    'Delimiter',',','ReadVariableNames',true,'VariableNamingRule','preserve','TextType','string');
R.MatchID=string(R.MatchID);
U=readMatchIDFile(fullfile(base,'tables','Step8_UnknownDeliveryMatchIDs.csv'));
% Fail if retained sources have changed since the completed delivery audit.
C=load(fullfile(base,'cache','Step8_DeliveryAudit.mat'),'signature');
P=C.signature.Source;
for k=1:height(P)
    if ~P.Exists(k), continue; end
    d=dir(char(P.Path(k)));
    assert(numel(d)==1 && d.bytes==P.Bytes(k) && d.datenum==P.ModifiedDatenum(k), ...
        'Retained source changed since Step8: %s. Stop and reconcile provenance.',P.Path(k));
end
fprintf('Reusing completed Step8. No delivery CSV scan.\n');
files=[dir(fullfile(yamlFolder,'**','*.yaml'));dir(fullfile(yamlFolder,'**','*.yml'))];
fileID=strings(numel(files),1); filePath=fileID;
for k=1:numel(files)
    [~,stem]=fileparts(files(k).name); fileID(k)=string(stem);
    filePath(k)=string(fullfile(files(k).folder,files(k).name));
end
wanted=unique([M.MatchID(M.MetadataEligible & M.RawJSONStatus~="parsed");U.MatchID]);
Inventory=table(wanted,repmat("not_found",numel(wanted),1),repmat("",numel(wanted),1), ...
    zeros(numel(wanted),1),repmat("",numel(wanted),1), ...
    'VariableNames',{'MatchID','Status','Path','MatchingFiles','Error'});
for k=1:height(Inventory)
    ix=find(fileID==Inventory.MatchID(k)); Inventory.MatchingFiles(k)=numel(ix);
    if numel(ix)==1, Inventory.Path(k)=filePath(ix); Inventory.Status(k)="found";
    elseif numel(ix)>1, Inventory.Status(k)="duplicate_paths"; end
end
fprintf('YAML files found: %d. Required match files found uniquely: %d / %d.\n', ...
    numel(files),nnz(Inventory.Status=="found"),height(Inventory));
selected=ismember(fileID,Inventory.MatchID(Inventory.Status=="found"));
fingerprint=table(filePath(selected),double([files(selected).bytes]'), ...
    double([files(selected).datenum]'),'VariableNames',{'Path','Bytes','ModifiedDatenum'});
cacheFile=fullfile(cacheFolder,'Step8A_YAMLAudit.mat');
cacheSignature=struct('Version','1.1','Files',fingerprint,'Wanted',wanted);
reuse=false;
if isfile(cacheFile)
    old=load(cacheFile,'cacheSignature','Y','Meta','Inventory');
    reuse=isfield(old,'cacheSignature') && isequaln(cacheSignature,old.cacheSignature);
end
if reuse
    Y=old.Y; Meta=old.Meta; Inventory=old.Inventory;
    fprintf('Reusing YAML fallback audit cache.\n');
else
    Y=emptyYAML(); Meta=emptyMetadata();
    if any(Inventory.Status=="found")
        jars=dir(fullfile(root,'lib','*.jar')); cp=string(javaclasspath('-all'));
        for k=1:numel(jars)
            path=fullfile(jars(k).folder,jars(k).name);
            if ~any(cp==string(path)), javaaddpath(path); end
        end
        try, parser=javaObject('org.yaml.snakeyaml.Yaml');
        catch
            error('SnakeYAML unavailable. Keep the original Step1 jar in D:\VihaanProject1\lib.');
        end
        parserSelfTest(parser);
        start=tic;
        rows=find(Inventory.Status=="found");
        for pos=1:numel(rows)
            k=rows(pos); id=Inventory.MatchID(k);
            try
                node=parser.load(java.io.StringReader(fileread(Inventory.Path(k))));
                [yy,mm]=parseMatch(node,id);
                Y=[Y;yy]; Meta=[Meta;mm]; %#ok<AGROW>
                Inventory.Status(k)="parsed";
            catch ME
                Inventory.Status(k)="parse_failed"; Inventory.Error(k)=string(ME.message);
            end
            if mod(pos,100)==0 || pos==numel(rows)
                fprintf('YAML fallback %d / %d | %.1f min\n',pos,numel(rows),toc(start)/60);
            end
        end
    end
    save(cacheFile,'cacheSignature','Y','Meta','Inventory','-v7.3');
end
writetable(Inventory,fullfile(tab,'Step8A_YAMLInventory.csv'));
writetable(Y,fullfile(tab,'Step8A_YAMLInningsAudit.csv'));
writetable(Meta,fullfile(tab,'Step8A_RecoveredMetadata.csv'));
A.YAMLVerified=false(height(A),1); A.YAMLMismatch=false(height(A),1);
A.RawVerificationSource=repmat("unverified",height(A),1);
A.RawVerificationSource(A.RawMetadataVerified)="JSON";
keys=A.MatchID+"|"+string(A.InningsIndex); ykeys=Y.MatchID+"|"+string(Y.InningsIndex);
assert(numel(unique(ykeys))==height(Y),'Duplicate YAML innings keys.');
[found,yi]=ismember(keys,ykeys);
for k=find(found)'
    y=Y(yi(k),:);
    mismatch=y.InvalidRawValues || y.LegalBalls~=A.LegalBalls(k) || ...
        y.DeliveryRuns~=A.DeliveryRuns(k) || y.GenuineDismissals~=A.GenuineDismissals(k) || ...
        y.RetiredNotOutEvents~=A.RetiredHurtEvents(k) || ...
        aliasTeam(y.BattingTeam)~=aliasTeam(string(A.BattingTeam(k))) || ...
        (isfinite(y.BallsPerOver) && y.BallsPerOver~=A.BallsPerOver(k)) || ...
        (isfinite(y.ScheduledOvers) && y.ScheduledOvers~=A.InitialScheduledOvers(k));
    A.YAMLMismatch(k)=mismatch; A.YAMLVerified(k)=~mismatch;
    if ~mismatch
        A.RawVerificationSource(k)="YAML";
        A.PenaltyPre(k)=y.PenaltyPre; A.PenaltyPost(k)=y.PenaltyPost;
        A.ReconciledFinalScore(k)=A.DeliveryRuns(k)+y.PenaltyPre+y.PenaltyPost;
        A.PenaltyReconciliationVerified(k)=true;
        A.NeedsStateRepair(k)=A.NeedsStateRepair(k) || y.PenaltyPre~=0 || y.PenaltyPost~=0;
        A.MiscountedOvers(k)=A.MiscountedOvers(k) || y.MiscountedOvers;
    end
end
% Exact documented alias, with matching match-level raw aggregates.
AliasLog=table(strings(0,1),zeros(0,1),strings(0,1),strings(0,1), ...
    'VariableNames',{'MatchID','InningsIndex','RetainedTeam','RawTeam'});
rkeys=R.MatchID+"|"+string(R.InningsIndex); [rf,ri]=ismember(keys,rkeys);
for k=find(A.RawTeamMismatch & rf)'
    rawTeam=string(R.BattingTeam(ri(k))); oldTeam=string(A.BattingTeam(k));
    if aliasTeam(rawTeam)==aliasTeam(oldTeam) && ~A.RawIntegrityMismatch(k)
        AliasLog=[AliasLog;table(A.MatchID(k),A.InningsIndex(k),oldTeam,rawTeam, ...
            'VariableNames',AliasLog.Properties.VariableNames)]; %#ok<AGROW>
        A.BattingTeam(k)=rawTeam; A.RawTeamMismatch(k)=false;
    end
end
writetable(AliasLog,fullfile(tab,'Step8A_TeamAliasRepairs.csv'));
% Preserve conservative exclusions; recover only the exact alias-only cases.
A.RecordIntegrityOK=A.NumericErrors==0 & A.RunIdentityErrors==0 & ...
    A.SequenceErrors==0 & A.WicketJSONFailures==0 & A.UnknownWicketKinds==0 & ...
    ~A.GenuineDismissalsAboveTen & ~A.BattingTeamConflict & ~A.RawIntegrityMismatch & ...
    ~A.RawTeamMismatch & ~A.RawScheduleConflict & A.StoredWicketInconsistency==0 & ~A.YAMLMismatch;
for k=1:height(A)
    if A.YAMLMismatch(k)
        A.ResponseEligible(k)=false; A.CompletionClass(k)="integrity_review";
        A.EligibilityReason(k)="yaml_aggregate_mismatch";
    elseif A.CompletionClass(k)=="integrity_review" && A.RecordIntegrityOK(k) && ...
            A.InningsIndex(k)==1 && A.StandardSchedule(k) && ~A.IsSuperOver(k)
        method=lower(string(M.ResultMethod(A.MatchRow(k))));
        interrupted=contains(method,"d/l") || contains(method,"dls") || ...
            contains(method,"duckworth") || contains(method,"vjd");
        if A.LegalBalls(k)==A.NominalBalls(k)
            A.ResponseEligible(k)=true; A.CompletionClass(k)="completed_full_length";
            A.EligibilityReason(k)="eligible_completed_standard_first_innings";
        elseif A.LegalBalls(k)<A.NominalBalls(k) && A.GenuineDismissals(k)==10 && ~interrupted
            A.ResponseEligible(k)=true; A.CompletionClass(k)="completed_early_all_out";
            A.EligibilityReason(k)="eligible_completed_standard_first_innings";
        end
    end
end
% Reserve 35 case identities matched to supplied data. Preserve user IDs too.
caseIDs=string([1370353;1298169;1298170;1298154;1415734;1384634;1322277; ...
    1359476;1355720;1233954;1188622;1144990;1072322;1119501;829807;682961; ...
    412685;1384426;1389389;1388410;1388398;1412541;1188626;1188625;65272; ...
    352665;1317902;1307296;1263161;1262757;1262346;1144169;1317912;1122282;1115802]);
caseFile=fullfile(root,'RevisedCodes_CaseStudyMatchIDs.csv');
if isfile(caseFile)
    existing=readMatchIDFile(caseFile);
    caseIDs=unique([caseIDs;string(existing.MatchID)]);
end
caseIDs=unique(caseIDs(~ismissing(caseIDs) & strlength(caseIDs)>0));
writetable(table(caseIDs,'VariableNames',{'MatchID'}),caseFile);
M.CaseStudyReserved=ismember(M.MatchID,caseIDs);
M.Split(M.CaseStudyReserved)="case_study"; M.TrainingFold(M.CaseStudyReserved)=0;
M.FirstInningsResponseEligible(:)=false;
M.FirstInningsRawVerified=false(height(M),1);
for k=find(A.InningsIndex==1)'
    m=A.MatchRow(k); M.FirstInningsResponseEligible(m)=A.ResponseEligible(k);
    M.FirstInningsClass(m)=A.CompletionClass(k); M.FirstInningsReason(m)=A.EligibilityReason(k);
    M.NeedsStateRepair(m)=A.NeedsStateRepair(k); M.RawIntegrityReview(m)=~A.RecordIntegrityOK(k);
    M.FirstInningsRawVerified(m)=A.RawMetadataVerified(k) || A.YAMLVerified(k);
end
M.PrimaryModelEligible=M.FirstInningsResponseEligible & ...
    string(M.GenderCanon)==string(cfg.PrimaryGender) & ismember(string(M.Split),["train","validation","test"]);
M.StrictVerifiedPrimaryEligible=M.PrimaryModelEligible & M.FirstInningsRawVerified;
A.Split=M.Split(A.MatchRow); A.TrainingFold=M.TrainingFold(A.MatchRow);
A.CaseStudyReserved=M.CaseStudyReserved(A.MatchRow);
A.PrimaryModelEligible=A.ResponseEligible & A.InningsIndex==1 & ...
    string(M.GenderCanon(A.MatchRow))==string(cfg.PrimaryGender) & ...
    ismember(string(A.Split),["train","validation","test"]);
A.StrictVerifiedPrimaryEligible=A.PrimaryModelEligible & (A.RawMetadataVerified | A.YAMLVerified);
assert(~any(M.CaseStudyReserved & M.Split=="train"),'Case-study leakage.');
assert(~any(A.PrimaryModelEligible & ~A.RecordIntegrityOK),'Integrity failure in primary cohort.');
writetable(M,fullfile(tab,'Step8_MatchManifest.csv'));
writetable(A,fullfile(tab,'Step8_InningsAudit.csv'));
writetable(M(M.CaseStudyReserved,:),fullfile(tab,'Step8A_CaseStudyManifest.csv'));
writetable(M(M.PrimaryModelEligible & ~M.FirstInningsRawVerified,:), ...
    fullfile(tab,'Step8A_UnverifiedPrimaryMatches.csv'));
writetable(A(A.InningsIndex==1 & ~A.ResponseEligible,:),fullfile(tab,'Step8A_ExcludedFirstInnings.csv'));
writetable(A(A.InningsIndex==1 & A.LegalBalls>A.NominalBalls,:), ...
    fullfile(tab,'Step8A_MiscountedOversReview.csv'));
writetable(Meta(ismember(Meta.MatchID,U.MatchID),:),fullfile(tab,'Step8A_UnmatchedIDMetadata.csv'));
missingCases=["T20 Afghanistan-Bangladesh 25-Jun-2024"; ...
    "T20 Bangladesh-Afghanistan 16-Jul-2023";"T20 Afghanistan-Ireland 17-Aug-2022"; ...
    "ODI Bangladesh-Afghanistan 2023";"ODI Bangladesh-Australia 09-Jun-2026"];
writetable(table(missingCases,repmat("Not matched in uploaded manifest; locate source and confirm identity",5,1), ...
    'VariableNames',{'Case','Action'}),fullfile(tab,'Step8A_UnmatchedCaseDescriptions.csv'));
for f=["ODI","T20"]
    for g=["men","women"]
        for split=["train","validation","test"]
            mask=M.FirstInningsResponseEligible & string(M.FormatFamily)==f & string(M.GenderCanon)==g & string(M.Split)==split;
            writetable(M(mask,:),fullfile(tab,char("Pool_"+f+"_"+g+"_"+split+"_MatchIDs.csv")));
            if g==string(cfg.PrimaryGender) && split=="train"
                writetable(M(mask,:),fullfile(tab,char("Pool_"+f+"_MatchIDs.csv")));
            end
            writetable(M(mask & M.FirstInningsRawVerified,:), ...
                fullfile(tab,char("Pool_"+f+"_"+g+"_"+split+"_StrictVerified.csv")));
        end
    end
end
Summary=groupsummary(M(M.PrimaryModelEligible,:),{'FormatFamily','Split'});
Summary=renamevars(Summary,'GroupCount','ResponseEligibleMatches');
writetable(Summary,fullfile(tab,'Step8A_PrimarySplitSummary.csv'));
Eligibility=groupsummary(M,{'FormatFamily','GenderCanon','FirstInningsClass','FirstInningsReason'});
writetable(Eligibility,fullfile(tab,'Step8A_EligibilitySummary.csv'));
QC=table(["YAMLFilesFound";"YAMLMatchesParsed";"YAMLVerifiedInnings";"YAMLMismatchInnings"; ...
    "AliasRepairedInnings";"ReservedCasesInManifest";"PrimaryEligibleMatches"; ...
    "UnverifiedPrimaryMatches";"UnmatchedDeliveryIDsRecoveredMetadata";"RemainingIntegrityReviewFirstInnings"], ...
    string([numel(files);nnz(Inventory.Status=="parsed");nnz(A.YAMLVerified);nnz(A.YAMLMismatch); ...
    height(AliasLog);nnz(M.CaseStudyReserved);nnz(M.PrimaryModelEligible); ...
    nnz(M.PrimaryModelEligible & ~M.FirstInningsRawVerified); ...
    nnz(ismember(Meta.MatchID,U.MatchID));nnz(A.InningsIndex==1 & A.CompletionClass=="integrity_review")]), ...
    'VariableNames',{'Metric','Value'});
writetable(QC,fullfile(tab,'Step8A_QC_Summary.csv'));
ready=nnz(M.PrimaryModelEligible)>0 && ~any(M.PrimaryModelEligible & ~M.FirstInningsRawVerified) && ...
    nnz(M.CaseStudyReserved)>=35;
for f=["ODI","T20"]
    for split=["train","validation","test"]
        ready=ready && any(M.PrimaryModelEligible & string(M.FormatFamily)==f & string(M.Split)==split);
    end
end
Readiness=table(["PrimaryResponsesRawVerified";"CasesReserved";"Step9MustApplyCorrections"; ...
    "AllFortyCaseLedgersVerified";"ReadyForPrimaryStateConstruction";"DLSComparisonCompleted"], ...
    [string(~any(M.PrimaryModelEligible & ~M.FirstInningsRawVerified));string(nnz(M.CaseStudyReserved)); ...
    "true";"false";string(ready);"false"],'VariableNames',{'Check','Value'});
writetable(Readiness,fullfile(tab,'Step8A_Readiness.csv'));
copyfile(fullfile(base,'tables','Step8_DeliveryCorrections.csv'),fullfile(tab,'Step8_DeliveryCorrections.csv'));
Check=struct('Manifest',M,'InningsAudit',A,'QC',QC,'Readiness',Readiness, ...
    'Config',cfg,'OutputRoot',out,'OriginalStep8Root',base,'YAMLFolder',yamlFolder);
save(fullfile(out,'RevisedCodes_Step8A_Result.mat'),'Check','-v7.3');
reports={'Step8A_QC_Summary.csv','Step8A_Readiness.csv','Step8A_PrimarySplitSummary.csv', ...
    'Step8A_YAMLInventory.csv','Step8A_TeamAliasRepairs.csv','Step8A_UnmatchedIDMetadata.csv', ...
    'Step8A_UnverifiedPrimaryMatches.csv','Step8A_MiscountedOversReview.csv', ...
    'Step8A_ExcludedFirstInnings.csv','Step8A_CaseStudyManifest.csv','Step8A_UnmatchedCaseDescriptions.csv'};
zipFile=fullfile(root,'RevisedCodes_Step8A_Checks.zip'); zip(zipFile,reports,tab);
disp(QC); disp(Readiness);
fprintf('\nUpload: %s\nUse step08_prerequisites for revised Step9 after review.\n',zipFile);
end

function Y=emptyYAML()
Y=table(strings(0,1),zeros(0,1),strings(0,1),zeros(0,1),zeros(0,1),zeros(0,1), ...
    zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),false(0,1),false(0,1), ...
    'VariableNames',{'MatchID','InningsIndex','BattingTeam','LegalBalls','DeliveryRuns', ...
    'GenuineDismissals','RetiredNotOutEvents','PenaltyPre','PenaltyPost','BallsPerOver', ...
    'ScheduledOvers','MiscountedOvers','InvalidRawValues'});
end
function M=emptyMetadata()
M=table(strings(0,1),strings(0,1),strings(0,1),strings(0,1),strings(0,1), ...
    strings(0,1),zeros(0,1),zeros(0,1),'VariableNames', ...
    {'MatchID','Format','Gender','Team1','Team2','DateRaw','BallsPerOver','ScheduledOvers'});
end
function [Y,M]=parseMatch(node,id)
Y=emptyYAML(); M=emptyMetadata(); info=get(node,'info'); assert(~isempty(info),'YAML info missing.');
teams=items(get(info,'teams')); assert(numel(teams)>=2,'Teams absent.');
dates=items(get(info,'dates')); date=""; if ~isempty(dates), date=txt(dates{1}); end
bpo=num(get(info,'balls_per_over')); overs=num(get(info,'overs'));
M=table(id,txt(get(info,'match_type')),txt(get(info,'gender')),txt(teams{1}),txt(teams{2}), ...
    date,bpo,overs,'VariableNames',M.Properties.VariableNames);
innings=items(get(node,'innings')); assert(~isempty(innings),'YAML innings missing.');
for k=1:numel(innings)
    item=innings{k};
    if isempty(get(item,'deliveries'))
        entries=item.entrySet().iterator(); assert(entries.hasNext(),'Empty innings wrapper.');
        entry=entries.next(); item=entry.getValue();
    end
    deliveryItems=items(get(item,'deliveries')); assert(~isempty(deliveryItems),'YAML deliveries missing.');
    legal=0; runs=0; wickets=0; retired=0; invalid=false;
    for j=1:numel(deliveryItems)
        iterator=deliveryItems{j}.entrySet().iterator();
        assert(iterator.hasNext(),'Empty delivery wrapper.'); entry=iterator.next(); d=entry.getValue();
        ex=get(d,'extras'); isLegal=isempty(get(ex,'wides')) && isempty(get(ex,'noballs'));
        legal=legal+double(isLegal); rr=get(d,'runs'); total=num(get(rr,'total'));
        bat=num(get(rr,'batter')); if isnan(bat), bat=num(get(rr,'batsman')); end
        extra=num(get(rr,'extras')); if isnan(extra), extra=0; end
        invalid=invalid || ~isfinite(total) || total<0 || total~=floor(total) || ...
            ~isfinite(bat) || bat<0 || bat~=floor(bat) || extra<0 || extra~=floor(extra) || total~=bat+extra;
        runs=runs+total;
        ww=get(d,'wickets'); if isempty(ww), ww=get(d,'wicket'); end
        events=items(ww);
        for e=1:numel(events)
            kind=lower(txt(get(events{e},'kind')));
            if ismember(kind,["retired hurt","retired not out"]), retired=retired+1;
            elseif ismember(kind,["bowled","caught","caught and bowled","lbw","stumped", ...
                    "run out","hit wicket","obstructing the field","hit the ball twice", ...
                    "handled the ball","timed out","retired out"]), wickets=wickets+1;
            else, invalid=true; end
        end
    end
    penalty=get(item,'penalty_runs'); pp=get(penalty,'pre'); po=get(penalty,'post');
    pre=0; post=0; if ~isempty(pp), pre=num(pp); end, if ~isempty(po), post=num(po); end
    invalid=invalid || ~isfinite(pre) || ~isfinite(post) || ...
        pre<0 || post<0 || pre~=floor(pre) || post~=floor(post);
    miscount=~isempty(get(item,'miscounted_overs'));
    Y=[Y;table(id,k,txt(get(item,'team')),legal,runs,wickets,retired,pre,post,bpo,overs, ...
        miscount,invalid,'VariableNames',Y.Properties.VariableNames)]; %#ok<AGROW>
end
end
function value=get(node,key)
value=[];
if isa(node,'java.util.Map')
    value=node.get(java.lang.String(char(key)));
end
end
function c=items(node)
if isempty(node), c={};
elseif isa(node,'java.util.List')
    c=cell(double(node.size()),1); for k=1:numel(c), c{k}=node.get(k-1); end
elseif isa(node,'java.util.Map'), c={node};
else, c={node}; end
end
function s=txt(node)
if isempty(node), s="";
elseif isjava(node), s=string(char(node.toString()));
else, s=string(node); end
end
function n=num(node)
if isempty(node), n=NaN; else, n=str2double(txt(node)); end
end
function s=aliasTeam(s)
s=lower(strtrim(string(s))); s(s=="dhaka capital")="dhaka capitals";
end


function T=readMatchIDFile(path)
% Do not let readtable infer header/delimiter for a single text column.
% Explicitly preserve numeric-looking and wi_ prefixed IDs as strings.
fid=fopen(path,'r','n','UTF-8'); assert(fid>=0,'Cannot open %s',path);
c=onCleanup(@() fclose(fid)); %#ok<NASGU>
header=fgetl(fid); assert(ischar(header),'Empty MatchID CSV: %s',path);
header=erase(string(header),string(char(65279)));
header=strtrim(erase(header,'"'));
assert(header=="MatchID",'Expected single-column MatchID header in %s; found: %s',path,header);
data=textscan(fid,'%q','Delimiter',',','Whitespace','', ...
    'ReturnOnError',false,'EndOfLine','\n');
ids=strtrim(string(data{1})); ids=erase(ids,string(char(13)));
ids=regexprep(ids,'\.0+$','');
ids=ids(~ismissing(ids) & strlength(ids)>0);
T=table(ids,'VariableNames',{'MatchID'});
end


function parserSelfTest(parser)
% Exercise the actual Java-to-table parser before thousands of files are read.
fixture=sprintf(['info:\n' ...
    '  teams: [Team A, Team B]\n' ...
    '  dates: [2023-01-01]\n' ...
    '  match_type: T20\n' ...
    '  gender: male\n' ...
    '  balls_per_over: 6\n' ...
    '  overs: 20\n' ...
    'innings:\n' ...
    '  - 1st innings:\n' ...
    '      team: Team A\n' ...
    '      penalty_runs: {post: 5}\n' ...
    '      deliveries:\n' ...
    '        - 0.1:\n' ...
    '            runs: {batsman: 0, extras: 0, total: 0}\n' ...
    '            wickets:\n' ...
    '              - {kind: caught, player_out: Player A}\n' ...
    '              - {kind: retired hurt, player_out: Player B}\n']);
try
    node=parser.load(java.io.StringReader(fixture));
    [Y,M]=parseMatch(node,"self_test");
    assert(height(Y)==1 && height(M)==1 && Y.LegalBalls==1 && ...
        Y.GenuineDismissals==1 && Y.RetiredNotOutEvents==1 && ...
        Y.PenaltyPost==5 && ~Y.InvalidRawValues && M.BallsPerOver==6, ...
        'Unexpected parser self-test result.');
catch ME
    error('Step8A:ParserSelfTest','YAML parser preflight failed before the audit: %s', ...
        getReport(ME,'extended','hyperlinks','off'));
end
fprintf('YAML parser preflight passed: metadata, deliveries, retirement and penalties.\n');
end
