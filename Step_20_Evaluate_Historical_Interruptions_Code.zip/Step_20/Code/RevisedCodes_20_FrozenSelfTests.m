function T=RevisedCodes_20_FrozenSelfTests(C)
% Locked anchor checks copied from the accepted Step19 target-policy audit.
codeDir=fullfile(C.FrozenRoot,'code'); addpath(codeDir,'-end'); cleaner=onCleanup(@()rmpath(codeDir)); %#ok<NASGU>
z=load(fullfile(C.FrozenRoot,'RevisedCodes_19_FrozenModels.mat'),'Frozen'); F=z.Frozen;
Q=table([300;290;280],[10;10;10],'VariableNames',{'BallsRemaining','WicketsInHand'});
[~,I]=RevisedCodes_19_PredictFrozen(F,"ODI","PrimaryResource",Q); odi=double(I.NormalizedCapacity);
Q=table([120;110;100],[10;10;10],'VariableNames',{'BallsRemaining','WicketsInHand'});
[~,I]=RevisedCodes_19_PredictFrozen(F,"T20","PrimaryResource",Q); t20=double(I.NormalizedCapacity);
expectedODI=[1;0.990795039932031;0.980874742630428];
expectedT20=[1;0.951130071160258;0.897732255667428];
Check=["ODI frozen resource anchors";"T20 frozen resource anchors";"ODI fewer-resource target anchor"; ...
    "T20 fewer-resource target anchor";"Frozen bundle not independently evaluated"];
Passed=[max(abs(odi-expectedODI))<1e-12;max(abs(t20-expectedT20))<1e-12; ...
    floor(250.989825581395*odi(2))+1==249;floor(158.28323782235*t20(2))+1==151; ...
    F.PolicyFrozen&&~F.IndependentPerformanceEvaluated];
T=table(Check,Passed); assert(all(Passed),'Frozen Step19 interface/policy anchor failed.');
end
