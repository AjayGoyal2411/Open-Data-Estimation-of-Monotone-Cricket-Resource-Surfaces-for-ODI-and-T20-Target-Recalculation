function [Overlap,Inventory]=RevisedCodes_Pre20H_Membership(c,C)
% Read small membership/error tables only; never scan delivery CSV content.
U=RevisedCodes_Pre20H_Utils;
z=load(fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','step19_final','RevisedCodes_19_02_Result.mat'),'Result');R=z.Result;
U.Require(R.Hashes,["Path","SHA256"]);
for j=1:height(R.Hashes)
 assert(U.Hash(string(R.Hashes.Path(j)))==string(R.Hashes.SHA256(j)),'Frozen manifest hash mismatch.');
end
frozenHistory=string(fullfile(fileparts(R.FrozenModelPath),'Frozen_TrainingHistory.csv'));
assert(any(string(R.Hashes.Path)==frozenHistory),'Frozen history not covered by manifest.');
L=dir(fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','**','*.csv'));
paths=strings(0,1);
for j=1:numel(L)
 name=string(L(j).name);path=string(fullfile(L(j).folder,L(j).name));
 eligible=~isempty(regexp(char(name),'^(09_|1[0-9]_).*?(Membership|HistorySourceLedger|MatchErrors|MatchInfluence|TrainingHistory).*\.csv$','once'));
 if eligible&&~contains(lower(path),'pre20')&&~contains(lower(path),'input_snapshot'),paths(end+1,1)=path;end %#ok<AGROW>
end
paths=unique([frozenHistory;paths],'stable');
Inventory=table;Overlap=table;
for j=1:numel(paths)
 p=paths(j);d=dir(p);status="READ";ids=strings(0,1);count=0;h="";
 if isempty(d),status="MISSING";
 elseif d.bytes>c.MaxMembershipMB*1024^2,status="TOO_LARGE_FOR_METADATA_AUDIT";
 else
  h=U.Hash(p);
  try
   T=U.Read(p);count=height(T);
   if ismember('MatchID',T.Properties.VariableNames)
    ids=unique(strtrim(string(T.MatchID)));ids=ids(~ismissing(ids)&ids~="");
    if any(cellfun(@isempty,regexp(cellstr(ids),'^\d+$','once'))),status="INVALID_ID_SCHEMA";ids=strings(0,1);end
   else,status="NO_EXACT_MATCHID_COLUMN";
   end
  catch err,status="IMPORT_ERROR: "+string(err.message);
  end
 end
 if p==frozenHistory,assert(status=="READ",'Cannot audit frozen history: %s',status);end
 role="UNCLASSIFIED_DEVELOPMENT_RECORD";
 if contains(p,'HistorySourceLedger'),role="CONTEXT_HISTORY_RECORD";
 elseif contains(p,'Membership'),role="MEMBERSHIP_REQUIRES_ROLE_REVIEW";
 elseif contains(p,'MatchErrors')||contains(p,'MatchInfluence'),role="ASSESSMENT_OR_DIAGNOSTIC_RECORD";
 elseif p==frozenHistory,role="FROZEN_REFIT";end
 Inventory=[Inventory;table(p,h,role,count,numel(ids),status,'VariableNames',{'Path','SHA256','RoleHint','Rows','UniqueMatchIDs','ReadStatus'})]; %#ok<AGROW>
 for k=1:height(C)
  Overlap=[Overlap;table(C.MatchID(k),p,role,ismember(C.MatchID(k),ids),status=="READ", ...
   'VariableNames',{'MatchID','Path','RoleHint','Present','ReadableMembership'})]; %#ok<AGROW>
 end
end
U.Write(Inventory,fullfile(c.Report,'Pre20H_MembershipInventory.csv'));
U.Write(Overlap,fullfile(c.Report,'Pre20H_ObservedOverlap.csv'));
roles=["PREPROCESSING_SELECTION";"EMPIRICAL_ESTIMATION";"CONTEXT_HISTORY";"TUNING";"SENSITIVITY_ASSESSMENT";"CONFIRMATION";"FROZEN_REFIT";"TEMPORAL_TEST"];
status=repmat("MANIFEST_COVERAGE_REVIEW_REQUIRED",numel(roles),1);status(roles=="FROZEN_REFIT")="HASH_VERIFIED_HISTORY_READ";
U.Write(table(roles,status,'VariableNames',{'Role','CoverageStatus'}),fullfile(c.Report,'Pre20H_RoleCoverage.csv'));
end
