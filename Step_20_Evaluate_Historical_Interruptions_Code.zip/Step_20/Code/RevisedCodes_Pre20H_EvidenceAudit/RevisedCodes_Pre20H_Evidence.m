function [C,V]=RevisedCodes_Pre20H_Evidence(c,C,E,S,O)
U=RevisedCodes_Pre20H_Utils;V=U.Read(fullfile(c.Input,'FieldEvidence.csv'));
U.Require(V,["MatchID","EventOrder","Field","SubmittedValue","Status","EvidenceType","SourceURL","SourceLocation","ReviewNote"]);
assert(all(ismember(V.MatchID,C.MatchID)),'Unknown evidence match.');
assert(numel(unique(V.MatchID+"|"+V.EventOrder+"|"+V.Field))==height(V),'Duplicate evidence field.');
V.RawStateCorroborated=false(height(V),1);
for j=1:height(V)
 q=E.MatchID==V.MatchID(j)&E.EventOrder==U.Number(V.EventOrder(j));
 if ismember(V.Field(j),["OversBowled","Score","WicketsLost","InningsIndex"])&&nnz(q)==1
  V.RawStateCorroborated(j)=E.SnapshotStateMatched(q);
 end
end
% The release contains submissions and partial corroboration, not signed-off timelines.
% Never derive external-source verification from raw state presence.
C.CanonicalRawSelected=false(height(C),1);C.AnyObservedOverlap=false(height(C),1);
C.CalculationEligible=false(height(C),1);C.OperationalComparisonEligible=false(height(C),1);
C.IndependentEvaluationEligible=false(height(C),1);C.Blockers=strings(height(C),1);
for j=1:height(C)
 id=C.MatchID(j);q=V.MatchID==id;s=S.MatchID==id;o=O.MatchID==id;
 C.CanonicalRawSelected(j)=S.RawSelected(s);C.AnyObservedOverlap(j)=any(O.Present(o));
 fields=V.Field(q);st=V.Status(q);caseRows=V.EventOrder(q)=="0";
 caseOK=all(ismember(["Identity","InitialAllocations","CompleteTimeline","PenaltyConvention","FirstInningsScoreBasis"],fields(caseRows)))&&all(st(caseRows)=="VERIFIED");
 eventRows=~caseRows&fields~="TargetRunsClaim";
 eventsOK=any(eventRows)&&all(st(eventRows)=="VERIFIED");
 arithmetic=all(E.ArithmeticConsistent(E.MatchID==id));
 C.CalculationEligible(j)=caseOK&&eventsOK&&arithmetic;
 targets=fields=="TargetRunsClaim"&st~="NOT_APPLICABLE";
 C.OperationalComparisonEligible(j)=C.CalculationEligible(j)&&any(targets)&&all(st(targets)=="VERIFIED");
 % Observed absence never certifies completeness of automatic manifest discovery.
 issues="FULL_DEVELOPMENT_ROLE_COVERAGE_PENDING";
 if ~caseOK||~eventsOK,issues=issues+";SOURCE_FIELDS_OR_COMPLETE_TIMELINE_PENDING";end
 if ~C.CanonicalRawSelected(j),issues=issues+";NO_REVIEWED_LOCAL_RAW";end
 if C.AnyObservedOverlap(j),issues=issues+";OBSERVED_MEMBERSHIP_REQUIRES_ROLE_ADJUDICATION";end
 if ~arithmetic,issues=issues+";ARITHMETIC_CONFLICT";end
 C.Blockers(j)=issues;
end
U.Write(V,fullfile(c.Report,'Pre20H_FieldEvidence.csv'));
U.Write(C,fullfile(c.Report,'Pre20H_EndpointEligibility.csv'));
% Source-linked dossiers are generated for every case, including exclusions.
d=fullfile(c.Report,'case_dossiers');mkdir(d);
for j=1:height(C)
 p=fullfile(d,"CASE_"+C.MatchID(j)+".md");f=fopen(p,'wt');assert(f>=0,'Cannot write dossier.');clean=onCleanup(@()fclose(f));
 fprintf(f,'# Case %s\n\n%s\n\nSubmitted source: %s\n\n',C.MatchID(j),C.Title(j),C.SourceURL(j));
 fprintf(f,'Canonical reviewed raw selected: %d\n\nCalculation eligible: %d\n\nOperational comparison eligible: %d\n\nIndependent evaluation eligible: %d\n\nOutstanding: %s\n\n',C.CanonicalRawSelected(j),C.CalculationEligible(j),C.OperationalComparisonEligible(j),C.IndependentEvaluationEligible(j),C.Blockers(j));
 q=find(V.MatchID==C.MatchID(j));
 for k=reshape(q,1,[])
  fprintf(f,'- Event %s; %s: %s. Evidence status: %s. Raw state corroborated: %d.\n',V.EventOrder(k),V.Field(k),V.SubmittedValue(k),V.Status(k),V.RawStateCorroborated(k));
 end
 clear clean
end
end
