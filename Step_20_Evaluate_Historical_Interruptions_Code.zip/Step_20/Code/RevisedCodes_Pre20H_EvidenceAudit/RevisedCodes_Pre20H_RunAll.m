function Results=RevisedCodes_Pre20H_RunAll(settings)
if nargin<1,settings=struct;end
assert(isstruct(settings)&&isscalar(settings),'Settings must be a scalar struct.');
assert(all(ismember(fieldnames(settings),{'ProjectRoot','RawFolders','MaxMembershipMB'})),'Unknown setting.');
c.ProjectRoot="D:\VihaanProject1";c.MaxMembershipMB=25;
if isfield(settings,'ProjectRoot'),c.ProjectRoot=string(settings.ProjectRoot);end
if isfield(settings,'MaxMembershipMB'),c.MaxMembershipMB=settings.MaxMembershipMB;end
assert(isscalar(c.MaxMembershipMB)&&isfinite(c.MaxMembershipMB)&&c.MaxMembershipMB>0,'Invalid file size limit.');
assert(isscalar(c.ProjectRoot)&&isfolder(c.ProjectRoot),'Project root missing.');
c.RawFolders=fullfile(c.ProjectRoot,["JSONFiles","ALLYAML","clean_from_json","clean_from_yaml"]);
if isfield(settings,'RawFolders'),c.RawFolders=string(settings.RawFolders);end
c.Input=fullfile(fileparts(mfilename('fullpath')),'input');U=RevisedCodes_Pre20H_Utils;
H=U.Read(fullfile(c.Input,'InputHashes.csv'));
for j=1:height(H),assert(U.Hash(fullfile(c.Input,H.File(j)))==H.SHA256(j),'Packaged input changed: %s',H.File(j));end
base=fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','pre20h_evidence_audit');if ~isfolder(base),mkdir(base);end
c.Report=string(tempname(base));mkdir(c.Report);diary(fullfile(c.Report,'RunLog.txt'));clean=onCleanup(@()diary('off')); %#ok<NASGU>
fprintf('Pre20H v1: explicit reviewed source selection and evidence audit.\n');
try
 Checks=RevisedCodes_Pre20H_SelfTests;U.Write(Checks,fullfile(c.Report,'Pre20H_SelfTests.csv'));
 before=U.Freeze(c.ProjectRoot);C=U.Read(fullfile(c.Input,'CaseRegister.csv'));E=U.Read(fullfile(c.Input,'EventLedger.csv'));
 assert(height(C)==40&&numel(unique(C.MatchID))==40,'Expected 40 unique cases.');
 fprintf('Selecting reviewed raw sources...\n');[F,~]=RevisedCodes_Pre20H_RawAudit(c,C);
 S=RevisedCodes_Pre20H_SelectSources(c,C,F);
 E=RevisedCodes_Pre20H_LedgerAudit(c,C,E);
 fprintf('Auditing available small development-membership tables...\n');[O,I]=RevisedCodes_Pre20H_Membership(c,C);
 [C,V]=RevisedCodes_Pre20H_Evidence(c,C,E,S,O);
 after=U.Freeze(c.ProjectRoot);assert(isequal(before,after),'Frozen files changed.');
 U.Write(after,fullfile(c.Report,'Pre20H_FrozenHashes.csv'));
 Summary=table(height(C),nnz(S.RawSelected),nnz(E.SnapshotStateMatched),height(I),nnz(C.AnyObservedOverlap), ...
 nnz(C.CalculationEligible),nnz(C.OperationalComparisonEligible),nnz(C.IndependentEvaluationEligible), ...
 'VariableNames',{'Cases','CanonicalRawSelected','MatchedEventStates','MembershipTablesInventoried','CasesWithObservedMembership','CalculationEligible','OperationalComparisonEligible','IndependentEvaluationEligible'});
 U.Write(Summary,fullfile(c.Report,'Pre20H_Summary.csv'));
 Gates=table(["Input hashes verified";"Cases retained";"Canonical sources explicitly selected";"Frozen artifacts unchanged"],true(4,1),'VariableNames',{'Check','Passed'});
 U.Write(Gates,fullfile(c.Report,'Pre20H_ExecutionGates.csv'));
 copyfile(c.Input,fullfile(c.Report,'input_snapshot'));
 code=dir(fullfile(fileparts(mfilename('fullpath')),'*.m'));CodeHashes=table;
 for j=1:numel(code)
  CodeHashes=[CodeHashes;table(string(code(j).name),U.Hash(fullfile(code(j).folder,code(j).name)),'VariableNames',{'File','SHA256'})]; %#ok<AGROW>
 end
 U.Write(CodeHashes,fullfile(c.Report,'Pre20H_CodeHashes.csv'));
 Results=struct('Status',"AUDIT_COMPLETE_EXTERNAL_EVIDENCE_AND_ROLE_COVERAGE_PENDING",'Settings',c,'Summary',Summary,'Cases',C,'Sources',S,'Events',E,'Evidence',V,'MembershipInventory',I,'Overlap',O);
 save(fullfile(c.Report,'RevisedCodes_Pre20H_Result.mat'),'Results');disp(Summary);
 fprintf('Execution complete. Full source verification and complete role coverage remain pending.\n');
 diary off;zip(c.Report+"_Checks.zip",{'*'},c.Report);fprintf('Upload %s\n',c.Report+"_Checks.zip");
catch err
 diary off;zip(c.Report+"_FAILED_Checks.zip",{'*'},c.Report);fprintf('Upload %s\n',c.Report+"_FAILED_Checks.zip");rethrow(err);
end
end
