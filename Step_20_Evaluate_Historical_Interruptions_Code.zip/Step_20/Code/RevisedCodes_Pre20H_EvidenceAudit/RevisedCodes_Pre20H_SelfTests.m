function Checks=RevisedCodes_Pre20H_SelfTests
U=RevisedCodes_Pre20H_Utils;
actual=U.Overs(["21.3","19.5","0.0"]);
assert(isequal(actual,[129 119 0]),'Overs row conversion returned %s; expected [129 119 0].',mat2str(actual));
assert(isequal(U.Overs(["21.3";"19.5";"0.0"]),[129;119;0]));
assert(isequal(U.Overs(["14.3","12.5","30.1","18.4","50","20.0"]),[87 77 181 112 300 120]));
assert(isequal(U.Overs(["0.0","1.5";"2","3.1"]),[0 11;12 19]));
assert(isequal(U.Overs(["0.0","0.1","0.2","0.3","0.4","0.5"]),0:5));
for s=["21.6","21.30","-1","NaN","",".3","21.","1.2.3","1e2","Inf"]
 rejected=false;try,U.Overs(s);catch,rejected=true;end;assert(rejected,'Invalid notation accepted.');
end
assert(U.Ready(true,true,true,true,true,true,true));
for j=1:7
 flags=true(1,7);flags(j)=false;
 assert(~U.Ready(flags(1),flags(2),flags(3),flags(4),flags(5),flags(6),flags(7)));
end
p=[tempname '.csv'];cleanup=onCleanup(@()delete(p)); %#ok<NASGU>
T=table(["00123";"1298154"],["a,b";"c"],'VariableNames',{'MatchID','Note'});U.Write(T,p);V=U.Read(p);
assert(isequal(V.MatchID,T.MatchID)&&isequal(V.Note,T.Note));
assert(~U.Ready(true,true,true,false,false,false,false),'State existence promoted to source verification.');
% Exercise the actual ledger routine on terminal and invalid restart fixtures.
d=tempname;mkdir(d);cleanDir=onCleanup(@()rmdir(d,'s')); %#ok<NASGU>
c=struct('Input',d,'Report',d);
S=table("900001",2,1,87,105,5,"test",'VariableNames', ...
 {'MatchID','InningsIndex','DeliverySequence','LegalBalls','Score','WicketsLost','RawSHA256'});
U.Write(S,fullfile(d,'ReviewedRawStates.csv'));
C=table("CASE_900001","900001","T20",'VariableNames',{'CaseID','MatchID','Format'});
E=table("CASE_900001","900001",1,2,"terminal_abandonment","14.3",105,5,"14.3",111, ...
 'VariableNames',{'CaseID','MatchID','EventOrder','InningsIndex','EventType','OversBowled','Score','WicketsLost','NewOversClaim','TargetRunsClaim'});
F=RevisedCodes_Pre20H_LedgerAudit(c,C,E);
assert(F.ArithmeticConsistent&&F.SnapshotStateMatched&&F.RemainingBallsAfterEvent==0);
assert(isnan(F.PreviousAllocationClaimBalls),'Unknown initial allocation invented.');
E.EventType="interruption";F=RevisedCodes_Pre20H_LedgerAudit(c,C,E);
assert(~F.ArithmeticConsistent,'Restart with no balls left accepted.');
% A different YAML hash must not invalidate a reviewed JSON source.
F=table(["900001";"900001"],["reviewed.json";"alternate.yaml"],[".json";".yaml"],["good";"other"],[true;false], ...
 'VariableNames',{'MatchID','Path','Extension','SHA256','MatchesReviewedHash'});
Selected=RevisedCodes_Pre20H_SelectSources(c,C,F);
assert(Selected.RawSelected&&Selected.SelectedPath=="reviewed.json"&&Selected.AlternateFiles==1);
F.MatchesReviewedHash(:)=false;Selected=RevisedCodes_Pre20H_SelectSources(c,C,F);
assert(~Selected.RawSelected&&Selected.SelectedPath=="");
F.MatchesReviewedHash(:)=true;rejected=false;
try,RevisedCodes_Pre20H_SelectSources(c,C,F);catch,rejected=true;end
assert(rejected,'Two distinct reviewed versions must require adjudication.');
Checks=table(["Cricket notation row shape";"Cricket notation column shape";"Whole overs and case-event notation";"Matrix shape preserved";"All six legal ball digits";"Invalid notation rejected";"Every readiness gate required";"CSV exact IDs and quoted fields";"State match cannot verify source";"Terminal event and unknown allocation";"Invalid restart rejected";"Reviewed source survives alternate format";"Unreviewed-only sources rejected";"Conflicting reviewed versions rejected"],true(14,1),'VariableNames',{'Check','Passed'});
disp(Checks);
end
