function [Files,Raw]=RevisedCodes_Pre20H_RawAudit(c,C)
U=RevisedCodes_Pre20H_Utils;expected=U.Read(fullfile(c.Input,'ReviewedRawSources.csv'));
Files=table(strings(0,1),strings(0,1),strings(0,1),strings(0,1),false(0,1), ...
 'VariableNames',{'MatchID','Path','Extension','SHA256','MatchesReviewedHash'});
for root=reshape(c.RawFolders,1,[])
 if ~isfolder(root),fprintf('Raw folder absent: %s\n',root);continue;end
 listing=dir(fullfile(root,'**','*'));listing=listing(~[listing.isdir]);
 for j=1:numel(listing)
  [~,stem,ext]=fileparts(listing(j).name);id=string(stem);
  if ~ismember(lower(string(ext)),[".json",".yaml",".yml"])||~ismember(id,C.MatchID),continue;end
  path=string(fullfile(listing(j).folder,listing(j).name));h=U.Hash(path);
  good=any(expected.MatchID==id&expected.SHA256==h);
  Files(end+1,:)={id,path,string(ext),h,good}; %#ok<AGROW>
 end
end
Files=unique(Files,'rows','stable');Raw=table;
for j=1:height(C)
 id=C.MatchID(j);F=Files(Files.MatchID==id,:);known=expected(expected.MatchID==id,:);
 status="MISSING_LOCAL_RAW";
 if ~isempty(F),status="PRESENT_UNREVIEWED_VERSION";end
 if any(F.MatchesReviewedHash),status="REVIEWED_HASH_FOUND";end
 if any(F.MatchesReviewedHash)&&any(~F.MatchesReviewedHash),status="REVIEWED_AND_UNREVIEWED_VERSIONS";end
 Raw=[Raw;table(id,height(F),height(known),any(F.MatchesReviewedHash),any(~F.MatchesReviewedHash),status, ...
 'VariableNames',{'MatchID','LocalFiles','ReviewedSnapshots','ReviewedHashFound','UnreviewedVersionPresent','RawStatus'})]; %#ok<AGROW>
end
U.Write(Files,fullfile(c.Report,'Pre20H_LocalRawFiles.csv'));U.Write(Raw,fullfile(c.Report,'Pre20H_RawAvailability.csv'));
end
