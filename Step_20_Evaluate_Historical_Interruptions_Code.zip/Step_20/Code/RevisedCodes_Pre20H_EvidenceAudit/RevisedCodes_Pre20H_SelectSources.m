function S=RevisedCodes_Pre20H_SelectSources(c,C,F)
U=RevisedCodes_Pre20H_Utils;S=table;
F.Selected=false(height(F),1);F.AlternateStatus=repmat("UNREVIEWED_CONTENT_NOT_COMPARED",height(F),1);
for j=1:height(C)
 id=C.MatchID(j);ix=find(F.MatchID==id&F.MatchesReviewedHash);
 path="";hash="";status="NO_REVIEWED_SOURCE_FOUND";
 if ~isempty(ix)
  % Explicit deterministic selection among reviewed hashes only.
  hashes=unique(F.SHA256(ix));assert(numel(hashes)==1,'Multiple reviewed versions require adjudication: %s',id);
  [~,o]=sort(F.Path(ix));k=ix(o(1));path=F.Path(k);hash=F.SHA256(k);
  F.Selected(k)=true;F.AlternateStatus(ix)="REVIEWED_IDENTICAL_BYTES";
  F.AlternateStatus(k)="SELECTED_REVIEWED_SOURCE";status="REVIEWED_SOURCE_SELECTED";
 end
 S=[S;table(id,path,hash,~isempty(ix),nnz(F.MatchID==id&~F.Selected),status, ...
  'VariableNames',{'MatchID','SelectedPath','SelectedSHA256','RawSelected','AlternateFiles','SelectionStatus'})]; %#ok<AGROW>
end
U.Write(S,fullfile(c.Report,'Pre20H_CanonicalRawSources.csv'));
U.Write(F,fullfile(c.Report,'Pre20H_AlternateSourceAudit.csv'));
end
