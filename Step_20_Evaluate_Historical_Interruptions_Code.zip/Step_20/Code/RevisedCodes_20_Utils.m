function U = RevisedCodes_20_Utils
U.Hash = @hashFile; U.Read = @readCSV; U.Write = @writeCSV;
U.Require = @requireColumns; U.Bool = @toLogical;
U.OversToBalls = @oversToBalls; U.BallsToOvers = @ballsToOvers;
U.Percentile = @percentile; U.SafeName = @safeName;
end

function T = readCSV(path)
assert(isfile(path),'Required file missing: %s',path);
f=fopen(path,'rt','n','UTF-8'); assert(f>=0); c=onCleanup(@()fclose(f)); h=fgetl(f); clear c
assert(ischar(h),'Empty CSV: %s',path); h=strrep(h,char(65279),'');
names=strip(erase(split(string(h),','),'"'))';
o=delimitedTextImportOptions('NumVariables',numel(names)); o.Delimiter=',';
o.DataLines=[2 Inf]; o.VariableNames=cellstr(names); o.VariableTypes=repmat({'string'},1,numel(names));
o.ExtraColumnsRule='error'; o.EmptyLineRule='skip'; T=readtable(path,o);
assert(isequal(string(T.Properties.VariableNames),names),'Header changed: %s',path);
for k=1:width(T), n=T.Properties.VariableNames{k}; T.(n)=strtrim(string(T.(n))); T.(n)(ismissing(T.(n)))=""; end
end

function writeCSV(T,path)
assert(istable(T)); writetable(T,path);
end

function h = hashFile(path)
f=fopen(path,'rb'); assert(f>=0,'Cannot hash %s',path); c=onCleanup(@()fclose(f));
md=java.security.MessageDigest.getInstance('SHA-256');
while ~feof(f), b=fread(f,1048576,'*uint8'); md.update(typecast(b,'int8')); end
h=lower(string(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[]))); clear c
end

function requireColumns(T,names)
missing=setdiff(string(names),string(T.Properties.VariableNames));
assert(isempty(missing),'Missing columns: %s',strjoin(missing,', '));
end

function x = toLogical(v)
if islogical(v), x=v; return; end
s=lower(strtrim(string(v))); assert(all(ismember(s,["0","1","false","true","yes","no"])));
x=ismember(s,["1","true","yes"]);
end

function b = oversToBalls(v)
s=strtrim(string(v)); b=nan(size(s));
for i=1:numel(s)
    p=split(s(i),'.'); assert(numel(p)>=1 && numel(p)<=2 && p(1)~="",'Invalid cricket overs: %s',s(i));
    q=str2double(p(1)); assert(isfinite(q)&&q>=0&&fix(q)==q,'Invalid cricket overs: %s',s(i));
    if numel(p)==1, r=0; else, r=str2double(p(2)); assert(strlength(p(2))==1&&isfinite(r)&&r>=0&&r<=5&&fix(r)==r,'Invalid cricket overs: %s',s(i)); end
    b(i)=6*q+r;
end
end

function s = ballsToOvers(b)
b=double(b); assert(all(isfinite(b)&b>=0&fix(b)==b)); q=floor(b/6); r=mod(b,6);
s=string(q); j=r~=0; s(j)=string(q(j))+"."+string(r(j));
end

function q = percentile(x,p)
x=sort(double(x(isfinite(x)))); assert(~isempty(x));
if numel(x)==1, q=x; return; end
t=1+(numel(x)-1)*double(p)/100; lo=floor(t); hi=ceil(t);
q=x(lo)+(t-lo)*(x(hi)-x(lo));
end

function s = safeName(v)
s=regexprep(lower(string(v)),'[^a-z0-9]+','_'); s=strip(s,'_');
end
