function Checks=RevisedCodes_Pre20J_SelfTests
name=["Strict status promotion";"Eligibility conjunction";"Exact ID matching";"External evidence cannot be inferred from raw state";"Hash function deterministic";"Quoted YAML date normalized";"Not-applicable is not target verification"];
passed=false(7,1); U=RevisedCodes_Pre20J_Utils;
passed(1)=U.Verified("VERIFIED")&&~U.Verified("PARTIALLY_CORROBORATED")&&~U.Verified("PENDING");
v=[true true true true true true true]; passed(2)=all(v)&&~all([v false]);
passed(3)=ismember("123",["123","0123"])&&~ismember("123",["1230","0123"]);
passed(4)=~U.Verified("PARTIALLY_CORROBORATED");
p=mfilename('fullpath'); passed(5)=U.Hash([p '.m'])==U.Hash([p '.m']);
folder=string(tempname); mkdir(folder); raw=fullfile(folder,'65272.yaml');
f=fopen(raw,'wt','n','UTF-8'); assert(f>=0,'Cannot create YAML test fixture.');
fprintf(f,'info:\n  dates:\n  - ''2003-03-03''\n  match_type: ODI\n  teams:\n  - Sri Lanka\n  - South Africa\n  toss:\n    decision: bat\n'); fclose(f);
R=table("65272",U.Hash(raw),"65272.yaml","COPIED_HASH_VERIFIED",'VariableNames',{'MatchID','SHA256','BundlePath','Status'});
Q=RevisedCodes_Pre20J_ParseRaw(folder,R,U); passed(6)=Q.RawDate=="2003-03-03";
delete(raw); rmdir(folder);
passed(7)=~U.Verified("NOT_APPLICABLE");
Checks=table(name,passed,'VariableNames',{'Check','Passed'}); assert(all(passed),'Pre20J self-test failed.');
end
