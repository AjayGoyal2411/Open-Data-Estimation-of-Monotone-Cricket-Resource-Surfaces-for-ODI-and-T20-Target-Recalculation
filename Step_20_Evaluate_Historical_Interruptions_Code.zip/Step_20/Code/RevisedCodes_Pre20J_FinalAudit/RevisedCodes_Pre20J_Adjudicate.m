function [Cases,Events,Gaps,Step20]=RevisedCodes_Pre20J_Adjudicate(C,E,F,RawFacts,MembershipAudit,RoleCoverage,U)
U.Require(C,["MatchID","Format","RawReviewedDate","LastSubmittedWinningTarget"]);
U.Require(E,["MatchID","EventOrder","ArithmeticConsistent","SnapshotStateMatched"]);
U.Require(F,["MatchID","EventOrder","Field","Status"]);
n=height(C); MatchID=C.MatchID; IdentityVerified=false(n,1); StateVerified=false(n,1);
ArithmeticVerified=false(n,1); InitialAllocationsVerified=false(n,1); TimelineComplete=false(n,1);
PenaltyConventionVerified=false(n,1); FirstInningsScoreBasisVerified=false(n,1);
PublishedTargetVerified=false(n,1); NoObservedOverlap=false(n,1); CompleteSeparationCertified=false(n,1);
CalculationEligible=false(n,1); OperationalComparisonEligible=false(n,1); IndependentEvaluationEligible=false(n,1);
RawParseStatus=strings(n,1); Blockers=strings(n,1);
coverageStatus=upper(RoleCoverage.CoverageStatus);
allCoverage=all(ismember(coverageStatus,["COMPLETE","HASH_VERIFIED_HISTORY_READ"]));
noHits=all(U.Num(MembershipAudit.CaseHitRows)==0);
for k=1:n
 id=MatchID(k); r=find(RawFacts.MatchID==id,1); rawOK=false;
 if ~isempty(r)
  RawParseStatus(k)=RawFacts.ParseStatus(r); rawDate=U.Date(RawFacts.RawDate(r)); claimDate=U.Date(C.RawReviewedDate(k));
  dateOK=~isnat(rawDate)&&~isnat(claimDate)&&rawDate==claimDate;
  formatOK=upper(strtrim(RawFacts.Format(r)))==upper(strtrim(C.Format(k)));
  rawOK=any(startsWith(RawFacts.ParseStatus(r),["JSON_PARSED","YAML_IDENTITY_PARSED"]));
  IdentityVerified(k)=rawOK&&dateOK&&formatOK;
 else, RawParseStatus(k)="NO_COLLECTION_ROW"; end
 ev=E.MatchID==id; assert(any(ev),'Every case must retain at least one event.');
 ArithmeticVerified(k)=all(U.Bool(E.ArithmeticConsistent(ev)));
 StateVerified(k)=rawOK&&all(U.Bool(E.SnapshotStateMatched(ev)));
 InitialAllocationsVerified(k)=fieldOK(F,id,"InitialAllocations",U);
 TimelineComplete(k)=fieldOK(F,id,"CompleteTimeline",U);
 PenaltyConventionVerified(k)=fieldOKorNA(F,id,"PenaltyConvention",U);
 FirstInningsScoreBasisVerified(k)=fieldOK(F,id,"FirstInningsScoreBasis",U);
 targetRows=F.MatchID==id&F.EventOrder=="0"&F.Field=="PublishedWinningTarget";
 PublishedTargetVerified(k)=nnz(targetRows)==1&&all(U.Verified(F.Status(targetRows)));
 NoObservedOverlap(k)=noHits;
 CompleteSeparationCertified(k)=noHits&&allCoverage;
 CalculationEligible(k)=IdentityVerified(k)&&StateVerified(k)&&ArithmeticVerified(k)&&InitialAllocationsVerified(k)&&TimelineComplete(k)&&PenaltyConventionVerified(k)&&FirstInningsScoreBasisVerified(k);
 OperationalComparisonEligible(k)=CalculationEligible(k)&&PublishedTargetVerified(k);
 IndependentEvaluationEligible(k)=OperationalComparisonEligible(k)&&CompleteSeparationCertified(k);
 b=strings(0,1);
 if ~IdentityVerified(k),b(end+1)="IDENTITY_NOT_VERIFIED";end
 if ~StateVerified(k),b(end+1)="EVENT_STATE_NOT_VERIFIED";end
 if ~ArithmeticVerified(k),b(end+1)="EVENT_ARITHMETIC_FAILED";end
 if ~InitialAllocationsVerified(k),b(end+1)="INITIAL_ALLOCATIONS_NOT_SOURCE_VERIFIED";end
 if ~TimelineComplete(k),b(end+1)="COMPLETE_TIMELINE_NOT_SOURCE_VERIFIED";end
 if ~PenaltyConventionVerified(k),b(end+1)="PENALTY_CONVENTION_NOT_VERIFIED";end
 if ~FirstInningsScoreBasisVerified(k),b(end+1)="FIRST_INNINGS_SCORE_BASIS_NOT_VERIFIED";end
 if ~PublishedTargetVerified(k),b(end+1)="PUBLISHED_TARGET_NOT_SOURCE_VERIFIED";end
 if ~CompleteSeparationCertified(k),b(end+1)="FULL_DEVELOPMENT_ROLE_COVERAGE_INCOMPLETE";end
 Blockers(k)=U.Join(b);
end
Cases=table(MatchID,C.Format,C.RawReviewedDate,RawParseStatus,IdentityVerified,StateVerified,ArithmeticVerified, ...
 InitialAllocationsVerified,TimelineComplete,PenaltyConventionVerified,FirstInningsScoreBasisVerified,PublishedTargetVerified, ...
 NoObservedOverlap,CompleteSeparationCertified,CalculationEligible,OperationalComparisonEligible,IndependentEvaluationEligible,Blockers, ...
 'VariableNames',{'MatchID','Format','ClaimedDate','RawParseStatus','IdentityVerified','StateVerified','ArithmeticVerified', ...
 'InitialAllocationsVerified','TimelineComplete','PenaltyConventionVerified','FirstInningsScoreBasisVerified','PublishedTargetVerified', ...
 'NoObservedOverlap','CompleteSeparationCertified','CalculationEligible','OperationalComparisonEligible','IndependentEvaluationEligible','Blockers'});
Events=E; Events.RawStateUsable=false(height(E),1); Events.SourceTimelineUsable=false(height(E),1);
for j=1:height(E)
 k=find(MatchID==E.MatchID(j),1); Events.RawStateUsable(j)=StateVerified(k)&&U.Bool(E.SnapshotStateMatched(j));
 Events.SourceTimelineUsable(j)=TimelineComplete(k)&&fieldEventOK(F,E.MatchID(j),E.EventOrder(j),U);
end
Gaps=Cases(:,{'MatchID','Format','Blockers'}); Gaps.RequiredAction=strings(height(Gaps),1);
for k=1:height(Gaps)
 Gaps.RequiredAction(k)="Supply field-level source evidence and complete missing role manifests; do not set flags without review.";
end
Step20=Cases(CalculationEligible,:);
end

function q=fieldOK(F,id,name,U)
ix=F.MatchID==id&F.EventOrder=="0"&F.Field==name; q=any(ix)&&all(U.Verified(F.Status(ix)));
end
function q=fieldOKorNA(F,id,name,U)
ix=F.MatchID==id&F.EventOrder=="0"&F.Field==name; q=any(ix)&&all(U.Verified(F.Status(ix))|upper(F.Status(ix))=="NOT_APPLICABLE");
end
function q=fieldEventOK(F,id,eventOrder,U)
ix=F.MatchID==id&F.EventOrder==eventOrder&ismember(F.Field,["EventType","InningsIndex","OversBowled","Score","WicketsLost","NewOversClaim"]);
q=any(ix)&&all(U.Verified(F.Status(ix))|upper(F.Status(ix))=="NOT_APPLICABLE");
end
