function Facts=RevisedCodes_Pre20J_ParseRaw(inputDir,RawCollection,U)
% Extract only facts represented explicitly in the collected raw record.
U.Require(RawCollection,["MatchID","SHA256","BundlePath","Status"]);
n=height(RawCollection); MatchID=strings(n,1); ParseStatus=strings(n,1); RawDate=strings(n,1);
Format=strings(n,1); Teams=strings(n,1); Method=strings(n,1); TargetRuns=NaN(n,1); TargetOvers=NaN(n,1);
for k=1:n
 MatchID(k)=RawCollection.MatchID(k); ParseStatus(k)="NO_REVIEWED_RAW";
 if RawCollection.Status(k)~="COPIED_HASH_VERIFIED", continue; end
 path=fullfile(inputDir,RawCollection.BundlePath(k)); assert(isfile(path),'Collected raw file missing: %s',path);
 assert(U.Hash(path)==RawCollection.SHA256(k),'Collected raw hash mismatch: %s',path);
 [~,~,ext]=fileparts(path);
 try
  if strcmpi(ext,'.json')
   J=jsondecode(fileread(path)); info=J.info;
   if isfield(info,'dates'), RawDate(k)=firstText(info.dates); end
   if isfield(info,'match_type'), Format(k)=upper(string(info.match_type)); end
   if isfield(info,'teams'), Teams(k)=strjoin(string(info.teams),' | '); end
   if isfield(info,'outcome')&&isfield(info.outcome,'method'), Method(k)=string(info.outcome.method); end
   if isfield(J,'innings')
    for z=1:numel(J.innings)
     if isfield(J.innings(z),'target')
      t=J.innings(z).target;
      if isfield(t,'runs'), TargetRuns(k)=double(t.runs); end
      if isfield(t,'overs'), TargetOvers(k)=double(t.overs); end
     end
    end
   end
   ParseStatus(k)="JSON_PARSED_HASH_VERIFIED";
  elseif any(strcmpi(ext,{'.yaml','.yml'}))
   txt=string(fileread(path));
   RawDate(k)=capture(txt,'(?m)^\s{2}dates:\s*\r?\n\s*-\s*([^\r\n]+)');
   Format(k)=upper(capture(txt,'(?m)^\s{2}match_type:\s*([^\r\n]+)'));
   teamBlock=capture(txt,'(?ms)^\s{2}teams:\s*\r?\n(.*?)(?=^\s{2}[A-Za-z_]+:)');
   teamTokens=regexp(char(teamBlock),'(?m)^\s*-\s*([^\r\n]+)','tokens');
   if ~isempty(teamTokens), Teams(k)=strjoin(string(cellfun(@(c)c{1},teamTokens,'UniformOutput',false)),' | '); end
   Method(k)=capture(txt,'(?m)^\s{4}method:\s*([^\r\n]+)');
   ParseStatus(k)="YAML_IDENTITY_PARSED_HASH_VERIFIED";
  else
   ParseStatus(k)="UNSUPPORTED_EXTENSION";
  end
 catch err
  ParseStatus(k)="PARSE_FAILED: "+string(err.message);
 end
end
Facts=table(MatchID,ParseStatus,RawDate,Format,Teams,Method,TargetRuns,TargetOvers);
end

function s=firstText(v)
if iscell(v), v=v{1}; elseif numel(v)>1, v=v(1); end
s=string(v);
end

function s=capture(txt,pattern)
t=regexp(char(txt),pattern,'tokens','once');
if isempty(t)
 s="";
else
 s=strtrim(string(t{1})); c=char(s);
 if numel(c)>=2&&((c(1)==''''&&c(end)=='''')||(c(1)=='"'&&c(end)=='"'))
  s=string(c(2:end-1));
 end
end
end
