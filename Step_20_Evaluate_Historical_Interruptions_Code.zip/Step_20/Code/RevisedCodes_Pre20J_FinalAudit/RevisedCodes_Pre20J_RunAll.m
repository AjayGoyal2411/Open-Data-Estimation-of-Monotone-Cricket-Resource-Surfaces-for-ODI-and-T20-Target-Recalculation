function Results=RevisedCodes_Pre20J_RunAll(settings)
% Final Pre20 audit. It does not refit, tune, calculate targets, or promote unsupported evidence.
if nargin<1,settings=struct;end
assert(isstruct(settings)&&isscalar(settings),'Settings must be a scalar struct.');
assert(all(ismember(fieldnames(settings),{'ProjectRoot','VerifyFrozenFiles','ExternalEvidenceFile','ExternalRoleManifestFile'})),'Unknown setting.');
c.ProjectRoot="D:\VihaanProject1"; c.VerifyFrozenFiles=true; c.ExternalEvidenceFile=""; c.ExternalRoleManifestFile="";
for n=reshape(string(fieldnames(settings)),1,[]),c.(n)=settings.(n);end
c.ProjectRoot=string(c.ProjectRoot); c.ExternalEvidenceFile=string(c.ExternalEvidenceFile); c.ExternalRoleManifestFile=string(c.ExternalRoleManifestFile);
assert(isscalar(c.ProjectRoot)&&isscalar(c.ExternalEvidenceFile)&&isscalar(c.ExternalRoleManifestFile),'Path settings must be scalar.');
assert(isscalar(c.VerifyFrozenFiles)&&islogical(c.VerifyFrozenFiles),'VerifyFrozenFiles must be logical.');
U=RevisedCodes_Pre20J_Utils; here=fileparts(mfilename('fullpath')); input=fullfile(here,'input');
M=U.Read(fullfile(input,'InputHashes.csv'));
for k=1:height(M), p=fullfile(input,M.File(k)); assert(U.Hash(p)==M.SHA256(k),'Packaged input changed: %s',p); end
base=fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','pre20j_final_audit'); if ~isfolder(base),mkdir(base);end
report=string(tempname(base)); mkdir(report); diary(fullfile(report,'RunLog.txt')); cleanup=onCleanup(@()diary('off')); %#ok<NASGU>
try
 Checks=RevisedCodes_Pre20J_SelfTests; U.Write(Checks,fullfile(report,'Pre20J_SelfTests.csv'));
 C=U.Read(fullfile(input,'Pre20H_EndpointEligibility.csv')); E=U.Read(fullfile(input,'Pre20H_RevisedEventLedger.csv'));
 F=augmentPublishedTargetEvidence(U.Read(fullfile(input,'Pre20H_FieldEvidence.csv')),C);
 evidencePath=string(fullfile(input,'Pre20H_FieldEvidence.csv')); evidenceMode="PACKAGED_PRE20H_PLUS_LOCKED_TARGET_ROWS";
 if c.ExternalEvidenceFile~=""
  assert(isfile(c.ExternalEvidenceFile),'ExternalEvidenceFile does not exist.'); reviewed=U.Read(c.ExternalEvidenceFile);
  assert(isequal(string(reviewed.Properties.VariableNames),string(F.Properties.VariableNames)),'External evidence schema differs from the locked field-evidence schema.');
  assert(height(reviewed)==height(F),'External evidence must retain every locked evidence row.');
  key0=F.MatchID+"|"+F.EventOrder+"|"+F.Field; key1=reviewed.MatchID+"|"+reviewed.EventOrder+"|"+reviewed.Field;
  assert(isequal(key0,key1),'External evidence row keys/order changed.');
  assert(isequal(F.SubmittedValue,reviewed.SubmittedValue),'Submitted values must remain locked.'); F=reviewed;
  accepted=["PENDING","NOT_APPLICABLE","PARTIALLY_CORROBORATED","VERIFIED","SOURCE_VERIFIED","CONFIRMED","VERIFIED_EXTERNAL_SOURCE"];
  assert(all(ismember(upper(strtrim(F.Status)),accepted)),'External evidence contains an unsupported status.');
  evidencePath=c.ExternalEvidenceFile; evidenceMode="EXTERNAL_REVIEWED_FILE";
 end
 R=U.Read(fullfile(input,'Pre20I_RawCollection.csv'));
 MC=U.Read(fullfile(input,'Pre20I_MembershipCollection.csv')); RC=U.Read(fullfile(input,'Pre20H_RoleCoverage.csv'));
 ExternalRoleAudit=table;
 if c.ExternalRoleManifestFile~=""
  [MC,RC,ExternalRoleAudit]=applyExternalRoleManifest(MC,RC,c.ExternalRoleManifestFile,U,C.MatchID);
 end
 assert(height(C)==40&&numel(unique(C.MatchID))==40,'Expected exactly 40 unique cases.');
 assert(height(E)==51,'Expected exactly 51 retained events.');
 RawFacts=RevisedCodes_Pre20J_ParseRaw(input,R,U); U.Write(RawFacts,fullfile(report,'Pre20J_RawFacts.csv'));
 [MembershipAudit,RoleSummary]=RevisedCodes_Pre20J_MembershipAudit(input,MC,C.MatchID,U);
 U.Write(MembershipAudit,fullfile(report,'Pre20J_MembershipAudit.csv')); U.Write(RoleSummary,fullfile(report,'Pre20J_RoleSummary.csv'));
 if ~isempty(ExternalRoleAudit),U.Write(ExternalRoleAudit,fullfile(report,'Pre20J_ExternalRoleManifestAudit.csv'));end
 [Cases,Events,Gaps,Step20]=RevisedCodes_Pre20J_Adjudicate(C,E,F,RawFacts,MembershipAudit,RC,U);
 U.Write(Cases,fullfile(report,'Pre20J_CaseDisposition.csv')); U.Write(Events,fullfile(report,'Pre20J_EventDisposition.csv'));
 U.Write(Gaps,fullfile(report,'Pre20J_GapRegister.csv')); U.Write(Step20,fullfile(report,'Pre20J_Step20_CaseInput_RELEASE_ONLY_IF_NONEMPTY.csv'));
 frozen=U.Read(fullfile(input,'Pre20H_FrozenHashes.csv')); frozenVerified=false(height(frozen),1);
 if c.VerifyFrozenFiles
  for k=1:height(frozen)
   assert(isfile(frozen.Path(k)),'Frozen file missing: %s',frozen.Path(k));
   frozenVerified(k)=U.Hash(frozen.Path(k))==frozen.SHA256(k); assert(frozenVerified(k),'Frozen file changed: %s',frozen.Path(k));
  end
 end
 FrozenCheck=table(frozen.Path,frozen.SHA256,repmat(c.VerifyFrozenFiles,height(frozen),1),frozenVerified, ...
  'VariableNames',{'Path','ExpectedSHA256','VerificationRequested','HashMatched'}); U.Write(FrozenCheck,fullfile(report,'Pre20J_FrozenVerification.csv'));
 Summary=table(height(C),height(E),nnz(Cases.IdentityVerified),nnz(Cases.StateVerified), ...
  nnz(Cases.NoObservedOverlap),nnz(Cases.CalculationEligible),nnz(Cases.OperationalComparisonEligible),nnz(Cases.IndependentEvaluationEligible), ...
  'VariableNames',{'Cases','Events','IdentityVerified','StateVerified','NoObservedOverlap','CalculationEligible','OperationalComparisonEligible','IndependentEvaluationEligible'});
 U.Write(Summary,fullfile(report,'Pre20J_Summary.csv'));
 Gates=table(["Packaged hashes verified";"Forty cases retained";"Fifty-one events retained";"Frozen files unchanged";"Step20 release available"], ...
  [true;height(C)==40;height(E)==51;~c.VerifyFrozenFiles||all(frozenVerified);height(Step20)>0],'VariableNames',{'Gate','Passed'});
 U.Write(Gates,fullfile(report,'Pre20J_ExecutionGates.csv'));
 effectiveEvidencePath=fullfile(report,'Pre20J_ExternalEvidenceReviewTemplate.csv'); U.Write(F,effectiveEvidencePath);
 EvidenceProvenance=table(evidenceMode,evidencePath,U.Hash(evidencePath),U.Hash(effectiveEvidencePath),height(F), ...
  'VariableNames',{'Mode','SourcePath','SourceSHA256','EffectiveEvidenceSHA256','EffectiveRows'});
 U.Write(EvidenceProvenance,fullfile(report,'Pre20J_EvidenceInputProvenance.csv'));
 code=dir(fullfile(here,'*.m')); CodeHashes=table;
 for k=1:numel(code),CodeHashes=[CodeHashes;table(string(code(k).name),U.Hash(fullfile(code(k).folder,code(k).name)),'VariableNames',{'File','SHA256'})];end %#ok<AGROW>
 U.Write(CodeHashes,fullfile(report,'Pre20J_CodeHashes.csv')); copyfile(input,fullfile(report,'input_snapshot'));
 status="PRE20_CODE_COMPLETE_EVIDENCE_GATES_OPEN"; if height(Step20)>0,status="STEP20_INPUT_RELEASED";end
 Results=struct('Status',status,'Settings',c,'Summary',Summary,'Gates',Gates,'Cases',Cases,'Events',Events);
 save(fullfile(report,'RevisedCodes_Pre20J_Result.mat'),'Results'); disp(Summary); disp(Gates);
 diary off; zip(report+"_Checks.zip",{'*'},report); fprintf('Upload %s\n',report+"_Checks.zip");
catch err
 diary off; zip(report+"_FAILED_Checks.zip",{'*'},report); fprintf('Upload %s\n',report+"_FAILED_Checks.zip"); rethrow(err);
end
end

function F=augmentPublishedTargetEvidence(F,C)
% A target that is not applicable to an interruption row is not evidence that
% the final published winning target was verified. Add one locked case-level row.
required=["MatchID","EventOrder","Field","SubmittedValue","Status","EvidenceType","SourceURL","SourceLocation","ReviewNote","RawStateCorroborated"];
assert(isequal(string(F.Properties.VariableNames),required),'Unexpected field-evidence schema.');
for k=1:height(C)
 value=strtrim(C.LastSubmittedWinningTarget(k));
 if value==""||ismissing(value),continue;end
 row=table(C.MatchID(k),"0","PublishedWinningTarget",value,"PENDING","SUBMISSION",C.SourceURL(k), ...
  "Corrected case document","Requires independent field-specific evidence for the published par/winning target.","0", ...
  'VariableNames',cellstr(required));
 F=[F;row]; %#ok<AGROW>
end
assert(numel(unique(F.MatchID(F.Field=="PublishedWinningTarget")))==40,'Expected one published-target evidence row per case.');
end

function [Collection,Coverage,Audit]=applyExternalRoleManifest(Collection,Coverage,path,U,caseIDs)
assert(isfile(path),'ExternalRoleManifestFile does not exist.'); M=U.Read(path);
U.Require(M,["Role","Path","SHA256","CoverageStatus"]);
required=upper(Coverage.Role); assert(all(ismember(upper(M.Role),required)),'External role manifest contains an unknown role.');
Audit=table; rowsToAdd=table;
for k=1:height(M)
 p=M.Path(k); assert(isfile(p),'External role file missing: %s',p); actual=U.Hash(p);
 assert(actual==lower(M.SHA256(k)),'External role file hash mismatch: %s',p);
 T=U.Read(p); U.Require(T,"MatchID"); ids=string(T.MatchID); hits=unique(ids(ismember(ids,caseIDs)),'stable');
 Audit=[Audit;table(upper(M.Role(k)),p,actual,height(T),numel(unique(ids)),numel(hits),U.Join(hits),upper(M.CoverageStatus(k)), ...
  'VariableNames',{'Role','Path','SHA256','Rows','UniqueMatchIDs','CaseMatches','CaseHitIDs','CoverageStatus'})]; %#ok<AGROW>
 rowsToAdd=[rowsToAdd;table(p,actual,p,"EXTERNAL_HASH_VERIFIED",'VariableNames',{'SourcePath','SHA256','BundlePath','Status'})]; %#ok<AGROW>
end
assert(all(ismember(upper(M.CoverageStatus),["COMPLETE","PARTIAL"])),'CoverageStatus must be COMPLETE or PARTIAL.');
for j=1:height(Coverage)
 ix=upper(M.Role)==upper(Coverage.Role(j));
 if any(ix)&&all(upper(M.CoverageStatus(ix))=="COMPLETE"),Coverage.CoverageStatus(j)="COMPLETE";end
end
Collection=[Collection;rowsToAdd];
end
