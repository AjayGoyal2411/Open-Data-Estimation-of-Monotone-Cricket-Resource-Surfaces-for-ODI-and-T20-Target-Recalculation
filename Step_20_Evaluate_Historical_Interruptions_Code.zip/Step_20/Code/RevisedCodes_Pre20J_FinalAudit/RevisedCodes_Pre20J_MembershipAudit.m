function [Audit,RoleSummary]=RevisedCodes_Pre20J_MembershipAudit(inputDir,Collection,caseIDs,U)
U.Require(Collection,["SHA256","BundlePath","Status"]); Audit=table; RoleSummary=table;
caseIDs=string(caseIDs); seen=strings(0,1);
for k=1:height(Collection)
 if Collection.Status(k)=="DUPLICATE_HASH_ALREADY_COLLECTED", continue; end
 path=Collection.BundlePath(k); if ~isfile(path),path=string(fullfile(inputDir,path));end
 assert(isfile(path),'Membership table missing: %s',path);
 assert(U.Hash(path)==Collection.SHA256(k),'Membership table hash mismatch: %s',path);
 assert(~ismember(Collection.SHA256(k),seen),'Unexpected duplicate membership hash.'); seen(end+1,1)=Collection.SHA256(k); %#ok<AGROW>
 T=U.Read(path); U.Require(T,"MatchID"); ids=strtrim(string(T.MatchID));
 assert(all(ids~=""&~ismissing(ids)),'Missing MatchID in %s.',path);
 hit=ismember(ids,caseIDs); hitIDs=unique(ids(hit),'stable');
 Audit=[Audit;table(Collection.BundlePath(k),Collection.SHA256(k),height(T),numel(unique(ids)),nnz(hit),U.Join(hitIDs), ...
  'VariableNames',{'Table','SHA256','Rows','UniqueMatchIDs','CaseHitRows','CaseHitIDs'})]; %#ok<AGROW>
 fold=repmat("UNSPECIFIED",height(T),1); role=repmat("UNSPECIFIED",height(T),1);
 if ismember('FoldID',T.Properties.VariableNames), fold=string(T.FoldID); end
 if ismember('Role',T.Properties.VariableNames), role=lower(string(T.Role)); end
 [g,foldName,roleName]=findgroups(fold,role); rows=splitapply(@numel,ids,g); matches=splitapply(@(x)numel(unique(x)),ids,g);
 cases=splitapply(@(x)numel(unique(x(ismember(x,caseIDs)))),ids,g);
 file=repmat(Collection.BundlePath(k),numel(rows),1);
 RoleSummary=[RoleSummary;table(file,foldName,roleName,rows,matches,cases, ...
  'VariableNames',{'Table','FoldID','Role','Rows','UniqueMatchIDs','CaseMatches'})]; %#ok<AGROW>
end
end
