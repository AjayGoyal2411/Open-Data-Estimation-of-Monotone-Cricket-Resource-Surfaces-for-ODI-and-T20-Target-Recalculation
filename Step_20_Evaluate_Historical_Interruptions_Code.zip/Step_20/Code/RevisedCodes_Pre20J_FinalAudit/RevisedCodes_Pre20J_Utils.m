function U=RevisedCodes_Pre20J_Utils
U.Read=@readCSV; U.Write=@writeCSV; U.Hash=@hashFile; U.Num=@toNumber;
U.Bool=@toLogical; U.Require=@requireColumns; U.Date=@toDate;
U.Text=@cleanText; U.Join=@joinNonempty; U.Verified=@verifiedStatus;
end

function T=readCSV(path)
assert(isfile(path),'Required file is missing: %s',path);
f=fopen(path,'rt','n','UTF-8'); assert(f>=0,'Cannot read %s.',path);
c=onCleanup(@()fclose(f)); header=fgetl(f); clear c;
assert(ischar(header),'Empty CSV: %s',path); header=strrep(header,char(65279),'');
names=strip(erase(split(string(header),','),'"'))';
assert(numel(unique(names))==numel(names)&&all(strlength(names)>0),'Invalid CSV header: %s',path);
o=delimitedTextImportOptions('NumVariables',numel(names)); o.Delimiter=','; o.DataLines=[2 Inf];
o.VariableNames=cellstr(names); o.VariableTypes=repmat({'string'},1,numel(names));
o.ExtraColumnsRule='error'; o.EmptyLineRule='skip'; T=readtable(path,o);
assert(isequal(string(T.Properties.VariableNames),names),'Header changed while reading %s.',path);
end

function writeCSV(T,path)
assert(istable(T),'Only tables may be written as CSV.');
writetable(T,path);
end

function h=hashFile(path)
f=fopen(path,'rb'); assert(f>=0,'Cannot hash %s.',path); c=onCleanup(@()fclose(f)); %#ok<NASGU>
md=java.security.MessageDigest.getInstance('SHA-256');
while ~feof(f), bytes=fread(f,1048576,'*uint8'); md.update(typecast(bytes,'int8')); end
h=lower(string(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[])));
end

function x=toNumber(v)
if isnumeric(v), x=double(v); else, x=str2double(string(v)); end
end

function x=toLogical(v)
if islogical(v), x=v; return; end
s=lower(strtrim(string(v))); assert(all(ismember(s,["0","1","false","true","yes","no"])),'Invalid logical value.');
x=ismember(s,["1","true","yes"]);
end

function requireColumns(T,names)
missing=string(names); missing=missing(~ismember(missing,string(T.Properties.VariableNames)));
assert(isempty(missing),'Missing required columns: %s',strjoin(missing,', '));
end

function d=toDate(v)
s=strtrim(string(v)); d=NaT(size(s));
for fmt=["yyyy-MM-dd","dd-MMM-yyyy","MM/dd/yyyy"]
 for k=find(isnat(d)&~ismissing(s)&s~="")'
  try, d(k)=datetime(s(k),'InputFormat',fmt); catch, end
 end
end
end

function s=cleanText(v)
s=lower(strtrim(string(v))); s=regexprep(s,'[^a-z0-9]+',' '); s=regexprep(s,'\s+',' ');
end

function s=joinNonempty(v,delimiter)
if nargin<2, delimiter=';'; end
v=string(v); v=v(~ismissing(v)&strlength(strtrim(v))>0); v=unique(v,'stable');
if isempty(v), s=""; else, s=strjoin(v,delimiter); end
end

function q=verifiedStatus(v)
s=upper(strtrim(string(v)));
q=ismember(s,["VERIFIED","SOURCE_VERIFIED","CONFIRMED","VERIFIED_EXTERNAL_SOURCE"]);
end
