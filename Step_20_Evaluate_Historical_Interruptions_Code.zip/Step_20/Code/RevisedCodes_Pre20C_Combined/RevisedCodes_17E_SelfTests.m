function Checks=RevisedCodes_17E_SelfTests
U=RevisedCodes_17E_Utils;
S=table(["initial";"delivery";"delivery";"terminal";"delivery";"delivery"], ...
 [0;1;0;0;1;1],[6;6;5;0;4;3],[10;10;10;0;9.5;9],zeros(6,1),[10;10;10;10;10;-1], ...
 'VariableNames',{'StateType','CorrectedIsLegalBall','BallsRemaining','WicketsInHand','DeliveryScoreBefore','FinalDeliveryRuns'});
assert(isequal(U.Canonical(S),[false;true;false;false;false;false]));
M=table([10;20],'VariableNames',{'DeliveryRuns'});
C=struct('MetaRow',[1;1;2],'U',[2;1;2],'W',[10;10;10],'Outcome',[10;5;20]);
[sy,wt,meta]=U.CellData(C,M,true(2,1),2);
assert(abs(sum(wt)-2)<1e-12&&meta.Scale==15,'Each innings must have total fitting weight one.');
assert(abs(sum(sy)-(7.5+20)/15)<1e-12);
[a,lo,hi,l90,h90]=U.Pair([1;4;9],[1;4;9],["A";"A";"B"],500,7);
assert(all([a lo hi l90 h90]==0));
[a,lo,hi]=U.Pair([4;4;4],[1;1;1],["A";"A";"B"],500,7);assert(all(abs([a lo hi]-1)<1e-12));
failed=false;try,U.Pair([1;NaN],[1;2],["A";"A"],500,7);catch,failed=true;end;assert(failed);
% Actual small-grid QPs exercise boundaries, monotonicity and zero-coupling nesting.
H=4;[u,w]=ndgrid(0:H,0:10);target=(u/H).*(w/10);weights=ones(numel(target),1);
x=U.FitSurface(target(:).*weights,weights,H,1e-4);
assert(max(abs(x(1,:)))<2e-7&&max(abs(x(:,1)))<2e-7&&abs(x(end,end)-1)<2e-7);
assert(min(diff(x,1,1),[],'all')>=-2e-7&&min(diff(x,1,2),[],'all')>=-2e-7);
[xm,xw]=U.FitJoint(target(:),weights,target(:),weights,H,1e-4,0);
assert(max(abs(xm-x),[],'all')<1e-5&&max(abs(xw-x),[],'all')<1e-5);
model=struct('Format',"T20",'Pooled',repmat((0:120)'/120,1,11),'PooledScale',100, ...
 'MenScale',120,'WomenScale',90);D=struct('U',60,'W',10);
assert(abs(U.Predict(D,true,model,"Pooled","women")-50)<1e-12);
assert(abs(U.Predict(D,true,model,"PooledShape","women")-45)<1e-12);
assert(isequal(U.Gender(["male";"female"]),["men";"women"]));
% Test the actual table summarizer with intentionally reversed model row order.
E=table;names=["Pooled","PooledShape","Separate","Partial"];
for name=names
 T=table(repmat("T20",4,1),repmat("AllEligible",4,1),["Fold_2020";"Fold_2020";"Fold_2021";"Fold_2021"], ...
  repmat("women",4,1),repmat(name,4,1),["001";"002";"003";"004"],repmat("unclassified",4,1), ...
  ones(4,1),[1;1;9;9],ones(4,1),zeros(4,1), ...
  'VariableNames',{'Format','Scope','Fold','Gender','Model','MatchID','CompetitionClass','States','MSE','MAE','Bias'});
 if name=="Partial",T=T(end:-1:1,:);end
 E=[E;T]; %#ok<AGROW>
end
cfg=struct('BootstrapReplicates',500,'Seed',7,'EquivalenceMarginRuns',1);
[sc,pa]=U.Summarize(E,cfg);assert(all(pa.RMSEGain==0)&&all(pa.ExploratoryWithinMargin));
assert(all(abs(sc.RMSE(sc.Fold=="Pooled2020_2022")-sqrt(5))<1e-12),'Do not average fold RMSEs.');
E.MatchID(E.Model=="Partial"&E.MatchID=="001")="999";
failed=false;try,U.Summarize(E,cfg);catch,failed=true;end;assert(failed,'Mismatched pairs must fail.');
Checks=table(["Canonical row selection";"Equal-innings fitting weights";"Identical paired errors"; ...
 "Paired gain direction";"Nonfinite errors rejected";"Actual QP boundaries and order"; ...
 "Zero-coupling nesting";"Shared shape versus shared scoring scale";"Gender aliases";"Pooled RMSE and row-order pairing";"Mismatched match IDs rejected"], ...
 true(11,1),'VariableNames',{'Check','Passed'});disp(Checks);
end
