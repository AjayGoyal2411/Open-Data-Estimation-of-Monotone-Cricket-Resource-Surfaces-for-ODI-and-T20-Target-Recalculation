function T=RevisedCodes_Pre20C_ImportTests(inputs)
U=RevisedCodes_Pre20C_Utils;
S=U.Read(fullfile(inputs,'17D_SourceHashes.csv'));
assert(all(ismember({'Path','SHA256'},S.Properties.VariableNames))&&height(S)>2);
assert(isstring(S.Path)&&all(strlength(S.SHA256)==64));
assert(nnz(endsWith(S.Path,'09_04_SensitivityEligibility.csv'))==1);
assert(nnz(endsWith(S.Path,'RevisedCodes_09_Result.mat'))==1);
F=U.Read(fullfile(inputs,'17D_FoldCoverage.csv'));assert(isnumeric(F.Year)&&isnumeric(F.Lambda)&&height(F)==15);
E=U.Read(fullfile(inputs,'17D_MatchErrors.csv'));assert(isstring(E.MatchID)&&isnumeric(E.MSE)&&all(isfinite(E.MSE)));
R=U.Read(fullfile(inputs,'Reviewed172.csv'));assert(height(R)==172&&isstring(R.MatchID));
T=table(["Explicit source CSV schema";"Path and hash text types";"Unique input paths";"Numeric fold fields";"Text IDs and numeric errors";"Reviewed172 rows"],true(6,1),'VariableNames',{'Check','Passed'});
disp(T);
end
