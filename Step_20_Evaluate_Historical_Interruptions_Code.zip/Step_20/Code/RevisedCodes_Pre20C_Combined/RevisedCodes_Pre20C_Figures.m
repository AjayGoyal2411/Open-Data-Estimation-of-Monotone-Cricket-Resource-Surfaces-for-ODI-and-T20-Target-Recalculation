function RevisedCodes_Pre20C_Figures(E,B,I,before,c)
% Four-panel audit: coverage, fixed-assessment forecast changes, provenance.
V=RevisedCodes_17E_Utils;
names=["Pooled","PooledShape","Separate","Partial"];
T=table;
for gender=["men","women"]
 for model=names
  q=E.Format=="T20"&E.Scope=="Class:international"&E.Gender==gender&E.Model==model;
  old=B.Format=="T20"&B.Scope=="Class:international"&B.Gender==gender&B.Model==model;
  a=sqrt(mean(B.MSE(old)));b=sqrt(mean(E.MSE(q)));
  row=table(gender,model,nnz(q),a,b,b-a,'VariableNames',{'Gender','Model','Matches','PreviousRMSE','AmendedRMSE','AmendedMinusPrevious'});T=[T;row]; %#ok<AGROW>
 end
end
V.Write(T,fullfile(c.Report,'17E_AmendmentComparison.csv'));
f=figure('Visible','off','Color','w','Position',[50 50 1300 850]);guard=onCleanup(@()close(f)); %#ok<NASGU>
tiledlayout(2,2,'TileSpacing','compact');
nexttile;counts=[nnz(before),height(I)-nnz(before);nnz(I.ClassVerified),nnz(~I.ClassVerified)];
bar(counts,'stacked');xticks(1:2);xticklabels({'Previous','Amended'});ylabel('Eligible innings');title('Classification coverage');legend({'Verified','Unclassified'},'Location','best');
for gender=["men","women"]
 nexttile;q=T.Gender==gender;bar([T.PreviousRMSE(q),T.AmendedRMSE(q)]);xticks(1:4);xticklabels(cellstr(names));ylabel('Equal-innings RMSE (runs)');title("T20 international: "+gender);legend({'Previous','Amended'},'Location','best');grid on;
end
nexttile;bar([132 40]);xticks(1:2);xticklabels({'Men','Women'});ylabel('Added historical training innings');title('Assessment matches unchanged');
exportgraphics(f,fullfile(c.Figures,'Pre20C_Amendment.png'),'Resolution',300);
exportgraphics(f,fullfile(c.Figures,'Pre20C_Amendment.pdf'),'ContentType','vector');savefig(f,fullfile(c.Figures,'Pre20C_Amendment.fig'));
V.Write(table(["Previous";"Amended"],counts(:,1),counts(:,2),'VariableNames',{'Version','Verified','Unclassified'}),fullfile(c.Report,'Pre20C_CoveragePanel.csv'));
end
