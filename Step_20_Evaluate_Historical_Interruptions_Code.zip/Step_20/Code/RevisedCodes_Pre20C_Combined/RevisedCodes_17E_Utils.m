function U=RevisedCodes_17E_Utils
% Isolated corrected auxiliary analysis. Does not write legacy or Step19 outputs.
U.Fit=@fitGenderModels; U.Predict=@predictRows; U.Pair=@paired;
U.CellData=@cellData; U.FitSurface=@fitQP; U.FitJoint=@fitJoint;
U.Number=@number; U.Logical=@logicalNumber; U.Date=@toDate; U.Gender=@gender;
U.Canonical=@canonical; U.Errors=@errors; U.Summarize=@summarize;
U.Write=@writeTable; U.Hash=@hashFile;
end
function Models=fitGenderModels(C,M,metaMask,fmt,lambda,c)
Umax=horizon(fmt); base=metaMask&M.Format==fmt&M.CacheEligible;
men=base&M.Gender=="men"; women=base&M.Gender=="women";
assert(nnz(men)>=50&&nnz(women)>=20,'Insufficient %s gender-specific fitting innings.',fmt);
[sm,wm,mm]=cellData(C,M,men,Umax); [sw,ww,mw]=cellData(C,M,women,Umax);
[sp,wp,mp]=cellData(C,M,base,Umax);
Models=struct('Format',string(fmt),'Lambda',lambda);
Models.Pooled=fitQP(sp,wp,Umax,c.Roughness); Models.PooledScale=mp.Scale;
Models.SeparateMen=fitQP(sm,wm,Umax,c.Roughness); Models.SeparateWomen=fitQP(sw,ww,Umax,c.Roughness);
Models.MenScale=mm.Scale; Models.WomenScale=mw.Scale;
[Models.PartialMen,Models.PartialWomen]=fitJoint(sm,wm,sw,ww,Umax,c.Roughness,lambda);
Models.Support=table(["pooled";"men";"women"],[mp.Innings;mm.Innings;mw.Innings], ...
 [nnz(wp);nnz(wm);nnz(ww)],'VariableNames',{'Group','Innings','SupportedCells'});
end

function Model=fitSingle(C,M,metaMask,fmt,c)
Umax=horizon(fmt); base=metaMask&M.Format==fmt&M.CacheEligible;
[s,w,m]=cellData(C,M,base,Umax);
Model=struct('Format',string(fmt),'Surface',fitQP(s,w,Umax,c.Roughness), ...
 'Scale',m.Scale,'Innings',m.Innings,'SupportedCells',nnz(w));
end

function [sumY,weights,meta]=cellData(C,M,metaMask,Umax)
ids=find(metaMask); assert(~isempty(ids),'Empty fitting cohort.');
flag=false(height(M),1); flag(ids)=true; rows=flag(double(C.MetaRow))&double(C.U)<=Umax;
scale=mean(number(M.DeliveryRuns(ids)),'omitnan'); assert(isfinite(scale)&&scale>0,'Invalid full-start scale.');
idx=double(C.U(rows))+1+(Umax+1)*double(C.W(rows)); n=(Umax+1)*11;
mid=double(C.MetaRow(rows)); counts=accumarray(mid,1,[height(M),1]);
stateWeight=1./counts(mid);
weights=accumarray(idx,stateWeight,[n 1],@sum,0);
sumY=accumarray(idx,stateWeight.*double(C.Outcome(rows))/scale,[n 1],@sum,0);
meta=struct('Scale',scale,'Innings',numel(ids),'States',nnz(rows));
end

function x=fitQP(sumY,w,Umax,rho)
n=(Umax+1)*11; [A,b,Aeq,beq,D]=constraints(Umax);
H=spdiags(2*w,0,n,n)+2*(rho*max(1,sum(w))/n)*(D'*D)+speye(n)*1e-10;
f=-2*sumY; opts=optimoptions('quadprog','Display','off','Algorithm','interior-point-convex', ...
 'ConstraintTolerance',1e-9,'OptimalityTolerance',1e-9,'MaxIterations',2000);
[x,~,exitflag]=quadprog((H+H')/2,f,A,b,Aeq,beq,zeros(n,1),ones(n,1),[],opts);
assert(exitflag>0&&all(isfinite(x)),'Resource QP failed.'); auditSurface(x,Umax);
x=reshape(x,Umax+1,11);
end

function [xm,xw]=fitJoint(sm,wm,sw,ww,Umax,rho,lambda)
n=(Umax+1)*11; [A,b,Aeq,beq,D]=constraints(Umax);
Hm=spdiags(2*wm,0,n,n)+2*(rho*max(1,sum(wm))/n)*(D'*D)+speye(n)*1e-10;
Hw=spdiags(2*ww,0,n,n)+2*(rho*max(1,sum(ww))/n)*(D'*D)+speye(n)*1e-10;
v=[wm(wm>0);ww(ww>0)]; if isempty(v),strength=0;else,strength=lambda*mean(v);end
K=speye(n); H=blkdiag(Hm,Hw)+2*strength*[K -K;-K K]; f=-2*[sm;sw];
AA=blkdiag(A,A); bb=[b;b]; EE=blkdiag(Aeq,Aeq); ee=[beq;beq];
opts=optimoptions('quadprog','Display','off','Algorithm','interior-point-convex', ...
 'ConstraintTolerance',1e-9,'OptimalityTolerance',1e-9,'MaxIterations',2500);
[x,~,exitflag]=quadprog((H+H')/2,f,AA,bb,EE,ee,zeros(2*n,1),ones(2*n,1),[],opts);
assert(exitflag>0&&all(isfinite(x)),'Partial-pooling QP failed.');
auditSurface(x(1:n),Umax); auditSurface(x(n+1:end),Umax);
xm=reshape(x(1:n),Umax+1,11); xw=reshape(x(n+1:end),Umax+1,11);
end

function [A,b,Aeq,beq,D]=constraints(Umax)
n=(Umax+1)*11; I=[]; J=[]; V=[]; r=0;
for ww=0:10
 for uu=0:Umax-1
  r=r+1; a=index(uu,ww,Umax); q=index(uu+1,ww,Umax);
  I=[I;r;r]; J=[J;a;q]; V=[V;1;-1]; %#ok<AGROW>
 end
end
for ww=0:9
 for uu=0:Umax
  r=r+1; a=index(uu,ww,Umax); q=index(uu,ww+1,Umax);
  I=[I;r;r]; J=[J;a;q]; V=[V;1;-1]; %#ok<AGROW>
 end
end
A=sparse(I,J,V,r,n); b=zeros(r,1);
eq=unique([arrayfun(@(x)index(0,x,Umax),0:10), ...
 arrayfun(@(x)index(x,0,Umax),0:Umax),index(Umax,10,Umax)]);
Aeq=sparse(1:numel(eq),eq,1,numel(eq),n); beq=zeros(numel(eq),1);
beq(eq==index(Umax,10,Umax))=1; D=A;
end

function k=index(u,w,Umax), k=u+1+(Umax+1)*w; end

function auditSurface(x,Umax)
R=reshape(x,Umax+1,11); tol=2e-7;
assert(max(abs(R(1,:)))<tol&&max(abs(R(:,1)))<tol&&abs(R(end,end)-1)<tol,'Boundary failure.');
assert(min(diff(R,1,1),[],'all')>=-tol&&min(diff(R,1,2),[],'all')>=-tol,'Monotonicity failure.');
assert(min(R,[],'all')>=-tol&&max(R,[],'all')<=1+tol,'Range failure.');
end

function p=predictRows(C,rows,Models,name,gg)
Umax=horizon(Models.Format); u=double(C.U(rows)); w=double(C.W(rows)); idx=u+1+(Umax+1)*w;
switch string(name)
 case "Pooled", R=Models.Pooled; scale=Models.PooledScale;
 case "PooledShape"
  R=Models.Pooled;if gg=="men",scale=Models.MenScale;else,scale=Models.WomenScale;end
 case "Separate"
  if gg=="men",R=Models.SeparateMen;scale=Models.MenScale;else,R=Models.SeparateWomen;scale=Models.WomenScale;end
 case "Partial"
  if gg=="men",R=Models.PartialMen;scale=Models.MenScale;else,R=Models.PartialWomen;scale=Models.WomenScale;end
 otherwise,error('Unknown gender model.');
end
p=R(idx)*scale;
end

function U=horizon(fmt)
if string(fmt)=="ODI",U=300;elseif string(fmt)=="T20",U=120;else,error('Unsupported format.');end
end
function g=gender(x)
g=lower(strtrim(string(x)));g(ismember(g,["male","m","mens","men's"]))="men";
g(ismember(g,["female","f","womens","women's"]))="women";g(ismissing(g)|g=="")="unknown";
end
function d=toDate(x)
if isdatetime(x),d=x;return;end
d=NaT(numel(x),1);s=string(x);fm=["yyyy-MM-dd","dd-MMM-yyyy","MM/dd/yyyy"];
for f=fm
 t=isnat(d)&~ismissing(s)&s~="";if any(t),try,d(t)=datetime(s(t),'InputFormat',f);catch,end,end
end
t=isnat(d)&~ismissing(s)&s~="";if any(t),try,d(t)=datetime(s(t));catch,end,end
end
function v=logicalNumber(x)
if islogical(x),v=x;elseif isnumeric(x),v=isfinite(x)&x~=0;else,v=ismember(lower(strtrim(string(x))),["1","true","yes"]);end
end
function y=number(x),if isnumeric(x),y=double(x);else,y=str2double(string(x));end,end
function requireVars(T,n),n=string(n);m=n(~ismember(n,string(T.Properties.VariableNames)));assert(isempty(m),'Missing variables: %s',strjoin(m,', '));end
function ensure(p),if ~isfolder(p),mkdir(p);end,end
function writeTable(T,p),assert(istable(T),'First argument must be a table.');ensure(fileparts(p));writetable(T,p);end


function keep=canonical(S)
requireVars(S,["StateType","CorrectedIsLegalBall","BallsRemaining","WicketsInHand","DeliveryScoreBefore","FinalDeliveryRuns"]);
u=number(S.BallsRemaining);w=number(S.WicketsInHand);
y=number(S.FinalDeliveryRuns)-number(S.DeliveryScoreBefore);
keep=string(S.StateType)=="delivery"&number(S.CorrectedIsLegalBall)==1& ...
 isfinite(u)&u>0&u==floor(u)&isfinite(w)&w>0&w<=10&w==floor(w)&isfinite(y)&y>=0;
end

function E=errors(C,M,mask,fmt,model,fold,scope)
E=table;
for g=["men","women"]
 rows=mask(double(C.MetaRow))&M.Format(double(C.MetaRow))==fmt&M.Gender(double(C.MetaRow))==g;
 if ~any(rows),continue;end
 [ids,~,loc]=unique(double(C.MetaRow(rows)));n=accumarray(loc,1);
 for name=["Pooled","PooledShape","Separate","Partial"]
  e=predictRows(C,rows,model,name,g)-double(C.Outcome(rows));
  a=table(repmat(fmt,numel(ids),1),repmat(scope,numel(ids),1),repmat(fold,numel(ids),1), ...
   repmat(g,numel(ids),1),repmat(name,numel(ids),1),M.MatchID(ids),M.CompetitionClass(ids),n, ...
   accumarray(loc,e.^2)./n,accumarray(loc,abs(e))./n,accumarray(loc,e)./n, ...
   'VariableNames',{'Format','Scope','Fold','Gender','Model','MatchID','CompetitionClass','States','MSE','MAE','Bias'});
  E=[E;a]; %#ok<AGROW>
 end
end
end

function [gain,lo,hi,lo90,hi90]=paired(a,b,fold,B,seed)
% a/b are aligned per-match MSEs. Stratified paired match bootstrap.
a=double(a(:));b=double(b(:));fold=string(fold(:));
assert(numel(a)==numel(b)&&numel(a)==numel(fold)&&numel(a)>=2,'Need at least two paired matches.');
assert(all(isfinite(a)&isfinite(b)&a>=0&b>=0),'Invalid paired MSE.');
gain=sqrt(mean(a))-sqrt(mean(b));v=zeros(B,1);rs=RandStream('mt19937ar','Seed',seed);
[~,~,g]=unique(fold);ix=cell(max(g),1);for k=1:max(g),ix{k}=find(g==k);end
for r=1:B
 q=zeros(numel(a),1);start=0;
 for k=1:numel(ix),j=ix{k};m=numel(j);q(start+(1:m))=j(randi(rs,m,m,1));start=start+m;end
 v(r)=sqrt(mean(a(q)))-sqrt(mean(b(q)));
end
z=prctile(v,[2.5 97.5 5 95]);lo=z(1);hi=z(2);lo90=z(3);hi90=z(4);
end

function [S,P]=summarize(E,c)
S=table;P=table;if isempty(E),return;end
for fmt=unique(E.Format)'
 for scope=unique(E.Scope(E.Format==fmt))'
  for g=["men","women"]
   base=E(E.Format==fmt&E.Scope==scope&E.Gender==g,:);if isempty(base),continue;end
   for fold=[unique(base.Fold);"Pooled2020_2022"]'
    T=base;if fold~="Pooled2020_2022",T=T(T.Fold==fold,:);end
    for name=unique(T.Model)'
     A=T(T.Model==name,:);assert(numel(unique(A.MatchID))==height(A),'Repeated assessment match.');
     s=table(fmt,scope,g,fold,name,height(A),sum(A.States),sqrt(mean(A.MSE)),mean(A.MAE),mean(A.Bias), ...
      'VariableNames',{'Format','Scope','Gender','Fold','Model','Innings','States','RMSE','MAE','Bias'});S=[S;s]; %#ok<AGROW>
    end
    comparisons=["Separate","Pooled";"Separate","PooledShape";"Separate","Partial";"PooledShape","Partial"];
    for j=1:size(comparisons,1)
     A=T(T.Model==comparisons(j,1),:);D=T(T.Model==comparisons(j,2),:);
     [ok,k]=ismember(A.MatchID,D.MatchID);assert(all(ok)&&height(A)==height(D),'Unpaired model assessment.');D=D(k,:);
     assert(isequal(A.States,D.States)&&isequal(A.Fold,D.Fold),'Pairing contract failed.');
     if height(A)<2,continue;end
     [gain,lo,hi,l90,h90]=paired(A.MSE,D.MSE,A.Fold,c.BootstrapReplicates,c.Seed);
     equivalent=l90>-c.EquivalenceMarginRuns&&h90<c.EquivalenceMarginRuns;
     row=table(fmt,scope,g,fold,comparisons(j,1),comparisons(j,2),height(A),gain,lo,hi,l90,h90, ...
      c.EquivalenceMarginRuns,equivalent, ...
      'VariableNames',{'Format','Scope','Gender','Fold','Reference','Candidate','Matches','RMSEGain','CI95Low','CI95High', ...
      'CI90Low','CI90High','ExploratoryEquivalenceMarginRuns','ExploratoryWithinMargin'});P=[P;row]; %#ok<AGROW>
    end
   end
  end
 end
end
end

function h=hashFile(p)
f=fopen(p,'rb');assert(f>=0,'Cannot hash %s',p);cl=onCleanup(@()fclose(f));
md=java.security.MessageDigest.getInstance('SHA-256');
while ~feof(f),b=fread(f,1048576,'*uint8');md.update(typecast(b,'int8'));end
h=lower(string(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[])));
end
