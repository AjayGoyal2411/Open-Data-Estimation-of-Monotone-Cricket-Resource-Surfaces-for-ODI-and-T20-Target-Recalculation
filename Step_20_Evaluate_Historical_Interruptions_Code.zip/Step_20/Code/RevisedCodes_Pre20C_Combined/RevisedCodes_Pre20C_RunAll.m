function Results=RevisedCodes_Pre20C_RunAll(settings)
% Mapping amendment + targeted auxiliary refit + case-readiness publication.
if nargin<1,settings=struct;end
assert(isstruct(settings)&&isscalar(settings));
assert(all(ismember(fieldnames(settings),{'ProjectRoot','EligibilityFile','StateManifest','Step19AuditFile'})),'Only input-path overrides are allowed; numerical settings are fixed.');
root='D:\VihaanProject1';if isfield(settings,'ProjectRoot'),root=char(settings.ProjectRoot);end
assert(isfolder(root),'Project root missing.');oldPath=path;addpath(root);cleanup=onCleanup(@()path(oldPath)); %#ok<NASGU>
here=fileparts(mfilename('fullpath'));inputs=fullfile(here,'input');
U=RevisedCodes_Pre20C_Utils;V=RevisedCodes_17E_Utils;
Checks=RevisedCodes_17E_SelfTests;
F0=U.Freeze(root);
baseSources=U.Read(fullfile(inputs,'17D_SourceHashes.csv'));
assert(all(ismember({'Path','SHA256'},baseSources.Properties.VariableNames)),'Source-hash CSV requires Path and SHA256 columns.');
ImportChecks=RevisedCodes_Pre20C_ImportTests(inputs);
% Explicit old eligibility avoids ambiguity between output generations.
if ~isfield(settings,'EligibilityFile'),settings.EligibilityFile=baseSources.Path(endsWith(baseSources.Path,'09_04_SensitivityEligibility.csv'));end
if ~isfield(settings,'StateManifest'),settings.StateManifest=baseSources.Path(endsWith(baseSources.Path,'RevisedCodes_09_Result.mat'));end
assert(isscalar(string(settings.EligibilityFile))&&isscalar(string(settings.StateManifest)),'Expected exactly one eligibility and state-manifest path.');
settings.ClassificationFile=fullfile(inputs,'Pre20_ClassifiedInnings.csv');
c=RevisedCodes_17E_Config(settings);c.Seed=170019;
files=dir(fullfile(here,'*.m'));Code=table;
for k=1:numel(files),p=string(fullfile(files(k).folder,files(k).name));Code=[Code;table(p,U.Hash(p),'VariableNames',{'Path','SHA256'})];end %#ok<AGROW>
U.Write(Code,fullfile(c.Report,'Pre20C_CodeHashes.csv'));
U.Write(table(string(version),string(computer),'VariableNames',{'MATLABVersion','Platform'}),fullfile(c.Report,'Pre20C_Environment.csv'));
U.Write(ImportChecks,fullfile(c.Report,'Pre20C_ImportTests.csv'));
U.Write(Checks,fullfile(c.Report,'17E_SelfTests.csv'));U.Write(F0,fullfile(c.Report,'FrozenBefore.csv'));
I=U.Read(settings.ClassificationFile);R=U.Read(fullfile(inputs,'Reviewed172.csv'));
assert(height(R)==172&&numel(unique(R.MatchID))==172,'Expected172 unique reviewed IDs.');
assert(height(I)==9732&&numel(unique(I.MatchID))==9732,'Baseline inventory differs.');
before=V.Logical(I.ClassVerified);assert(nnz(before)==5953,'Unexpected baseline classification count.');
[ok,ix]=ismember(R.MatchID,I.MatchID);assert(all(ok)&&~any(before(ix)),'Amendment IDs absent or already classified.');
for k=1:height(R)
 d=jsondecode(fileread(fullfile(here,'evidence',char(R.MatchID(k)+".json"))));
 assert(string(d.match_type)=="IT20"&&d.overs==20&&d.balls_per_over==6&&string(d.team_type)=="international",'Reviewed metadata mismatch.');
 assert(I.Format(ix(k))=="T20"&&V.Gender(d.gender)==I.Gender(ix(k)),'Format/gender mismatch.');
 assert(any(V.Date(string(d.dates))==V.Date(I.Date(ix(k)))),'Date mismatch.');
 assert(U.Hash(R.SourcePath(k))==R.SHA256(k),'Source changed since review: %s',R.MatchID(k));
end
I.CompetitionClass(ix)="international";I.ClassVerified=before;I.ClassVerified(ix)=true;
I.EventClassificationStatus(ix)="verified";I.ClassificationSource(ix)=R.SourcePath+"#info.team_type;reviewed_IT20_alias";
assert(nnz(I.ClassVerified)==6125&&nnz(I.ClassVerified~=before)==172);
assert(all(V.Date(I.Date(ix))<datetime(2019,1,1)),'Expected historical-only amendment.');
classification=fullfile(c.Report,'Pre20C_ClassifiedInnings.csv');U.Write(I,classification);c.ClassificationFile=classification;
R.AppliedClass=repmat("international",height(R),1);R.NormalizedFormat=repmat("T20",height(R),1);U.Write(R,fullfile(c.Report,'Pre20C_AppliedMapping.csv'));
[C,M,Audit,Sources]=RevisedCodes_17E_Data(c);
% Reuse unaffected predictions only if all original state/eligibility bytes match.
old=baseSources(~endsWith(baseSources.Path,'Pre20_ClassifiedInnings.csv'),:);
[ok,loc]=ismember(old.Path,Sources.Path);assert(all(ok)&&all(old.SHA256==Sources.SHA256(loc)),'Baseline state/eligibility provenance changed; cannot reuse predictions.');
oldM=U.Read(fullfile(inputs,'17D_EligibleInnings.csv'));oldM.MatchID=string(oldM.MatchID);
now=M(M.CacheEligible,{'MatchID','Format','Gender','Date','CompetitionClass','ClassVerified','CanonicalStates','DeliveryRuns'});
[ok,loc]=ismember(oldM.MatchID,now.MatchID);assert(all(ok)&&height(oldM)==height(now));
assert(all(oldM.CanonicalStates==now.CanonicalStates(loc))&&all(oldM.DeliveryRuns==now.DeliveryRuns(loc)),'Observation population changed.');
Errors=U.Read(fullfile(inputs,'17D_MatchErrors.csv'));oldErrors=Errors;
affected=Errors.Format=="T20"&Errors.Scope=="Class:international";Errors=Errors(~affected,:);
Coverage=U.Read(fullfile(inputs,'17D_FoldCoverage.csv'));previousCoverage=Coverage;
q=Coverage.Format=="T20"&Coverage.Scope=="Class:international";fixedLambda=unique(Coverage.Lambda(q));assert(isscalar(fixedLambda)&&fixedLambda==10,'Unexpected previous pooling strength.');Coverage=Coverage(~q,:);
Models=struct;Support=table;cohort=M.CacheEligible&M.Format=="T20"&M.ClassVerified&M.CompetitionClass=="international";
for yr=2020:2022
 fit=cohort&M.Date<datetime(yr,1,1);test=cohort&year(M.Date)==yr;
 oldrow=previousCoverage(previousCoverage.Format=="T20"&previousCoverage.Scope=="Class:international"&previousCoverage.Year==yr,:);
 assert(height(oldrow)==1&&nnz(test&M.Gender=="men")==oldrow.AssessmentMen&&nnz(test&M.Gender=="women")==oldrow.AssessmentWomen,'Assessment counts changed.');
 assert(nnz(fit&M.Gender=="men")==oldrow.FitMen+132&&nnz(fit&M.Gender=="women")==oldrow.FitWomen+40,'Unexpected fit change.');
 assert(max(M.Date(fit))<min(M.Date(test))&&~any(ismember(M.MatchID(fit),M.MatchID(test))));
 fprintf('Step17E T20 international %d: refitting with fixed lambda %.3g\n',yr,fixedLambda);
 model=V.Fit(C,M,fit,"T20",fixedLambda,c);fold="Fold_"+string(yr);
 E=V.Errors(C,M,test,"T20",model,fold,"Class:international");
 previous=oldErrors(oldErrors.Format=="T20"&oldErrors.Scope=="Class:international"&oldErrors.Fold==fold,:);
 keys=@(T)sort(T.MatchID+"|"+T.Model+"|"+T.Gender);
 assert(isequal(keys(E),keys(previous)),'Assessment identity/model membership changed.');
 Errors=[Errors;E]; %#ok<AGROW>
 row=oldrow;row.FitMen=nnz(fit&M.Gender=="men");row.FitWomen=nnz(fit&M.Gender=="women");row.LambdaRule="Prior selected lambda retained; no retuning";Coverage=[Coverage;row]; %#ok<AGROW>
 Models.(char(fold))=model;s=model.Support;s.Fold=repmat(fold,height(s),1);Support=[Support;s]; %#ok<AGROW>
end
[Scores,Paired]=V.Summarize(Errors,c);
OldScores=U.Read(fullfile(inputs,'17D_Scores.csv'));
U.Write(Sources,fullfile(c.Report,'17E_SourceHashes.csv'));U.Write(Audit,fullfile(c.Report,'17E_ObservationAudit.csv'));
U.Write(Errors,fullfile(c.Report,'17E_MatchErrors.csv'));U.Write(Scores,fullfile(c.Report,'17E_Scores.csv'));U.Write(Paired,fullfile(c.Report,'17E_PairedComparisons.csv'));
U.Write(Coverage,fullfile(c.Report,'17E_FoldCoverage.csv'));U.Write(Support,fullfile(c.Report,'17E_AffectedSupport.csv'));
U.Write(now,fullfile(c.Report,'17E_EligibleInnings.csv'));U.Write(OldScores,fullfile(c.Report,'17E_PreviousScores.csv'));
% Separate amended numerical results from unchanged baseline evidence.
Errors.ResultOrigin=repmat("reused_verified_baseline",height(Errors),1);Errors.ResultOrigin(Errors.Format=="T20"&Errors.Scope=="Class:international")="refitted_mapping_amendment";
U.Write(Errors,fullfile(c.Report,'17E_PredictionProvenance.csv'));
RevisedCodes_Pre20C_GroupEvidence(now,c);
Cases=U.Read(fullfile(inputs,'CaseEvidenceRegister.csv'));assert(height(Cases)==40&&numel(unique(Cases.CaseID))==40);
Cases.FullTimelineVerified=false(height(Cases),1);Cases.EvaluationEligible=false(height(Cases),1);
U.Write(Cases,fullfile(c.Report,'Pre20C_CaseReadiness.csv'));
for name=["CaseCorrectionLedger.csv","ExternalSourceRegister.csv","Pre20_CasePointReconciliation.csv"]
 copyfile(fullfile(inputs,name),fullfile(c.Report,name));
end
Gates=table(["Exactly172 classifications amended";"All3779 historical identities previously audited";"Unchanged assessment identities";"Frozen files unchanged";"All historical classes verified";"All case timelines verified";"External comparator examples reproduced"], ...
 [true;true;true;true;false;false;false],'VariableNames',{'Gate','Passed'});
F1=U.Freeze(root);assert(isequal(F0,F1),'Step19 frozen bytes changed.');U.Write(F1,fullfile(c.Report,'FrozenAfter.csv'));U.Write(Gates,fullfile(c.Report,'Pre20C_Gates.csv'));
% Save fitted results before publication rendering, so computation is recoverable.
Results=struct('Config',c,'Scores',Scores,'Paired',Paired,'Models',Models,'Gates',Gates);
save(fullfile(c.Root,'RevisedCodes_Pre20C_Result.mat'),'Results','-v7.3');
RevisedCodes_Pre20C_Figures(Errors,oldErrors,I,before,c);
U.Write(table("MAPPING_AND_AUXILIARY_COMPLETE_CASE_REVIEW_PENDING",'VariableNames',{'Status'}),fullfile(c.Report,'Pre20C_Status.csv'));
zipPath=fullfile(c.Root,'RevisedCodes_Pre20C_Checks.zip');zip(zipPath,{'reports','figures'},c.Root);Results.ChecksZip=zipPath;
fprintf('\nUpload: %s\n',zipPath);disp(Gates);
end
