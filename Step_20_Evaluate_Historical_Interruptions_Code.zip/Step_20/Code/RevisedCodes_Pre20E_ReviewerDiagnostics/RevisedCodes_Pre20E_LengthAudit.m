function [T,Short,Existing]=RevisedCodes_Pre20E_LengthAudit(c)
U=RevisedCodes_Pre20E_Utils;M=U.Read(c.EligibilityFile);
U.Require(M,["LegalBalls","InningsIndex","Format","Date","CaseStudyReserved","RecordIntegrityOK", ...
 "ResponseEligible","CachedStateAvailable","CachedReconstructionPassed","PrimaryModelEligible","CachedPrimary","InitialAllocatedBalls","BallsPerOver","CompletionClass","EligibilityReason"]);
d=U.Date(M.Date);fmt=upper(M.Format);balls=U.Number(M.LegalBalls);
base=U.Number(M.InningsIndex)==1&ismember(fmt,["ODI","T20"])&~isnat(d)&d<datetime(2023,1,1)&~U.Logical(M.CaseStudyReserved);
T=table;keepShort=false(height(M),1);
for f=["ODI","T20"]
 H=120;cut=[15 30 45];nominal=30;if f=="ODI",H=300;cut=[30 60 90];nominal=60;end
 q=base&fmt==f;keepShort=keepShort|(q&isfinite(balls)&balls<nominal);
 stages=["CandidateLedger","Integrity","Response","FullAllocationSixBalls","CacheAvailable","CacheReconstructed","PrimaryFlag","CachedPrimaryFlag"];
 masks=cell(8,1);masks{1}=q;masks{2}=q&U.Logical(M.RecordIntegrityOK);
 masks{3}=masks{2}&U.Logical(M.ResponseEligible);
 masks{4}=masks{3}&U.Number(M.InitialAllocatedBalls)==H&U.Number(M.BallsPerOver)==6;
 masks{5}=masks{4}&U.Logical(M.CachedStateAvailable);masks{6}=masks{5}&U.Logical(M.CachedReconstructionPassed);
 masks{7}=masks{6}&U.Logical(M.PrimaryModelEligible);masks{8}=masks{7}&U.Logical(M.CachedPrimary);
 for k=1:numel(stages)
  for v=cut
   mask=masks{k};valid=mask&isfinite(balls)&balls>=0;
   a=table(f,stages(k),v,nnz(mask),nnz(mask&~valid),nnz(valid&balls<v),nnz(valid&balls>=v), ...
    'VariableNames',{'Format','CumulativeAuditStage','CutoffBalls','Innings','UnknownLength','BelowCutoff','AtOrAboveCutoff'});
   T=[T;a]; %#ok<AGROW>
  end
 end
end
Short=M(keepShort,:);Short.AuditMeaning=repmat("Review existing exclusion reasons; no automatic inclusion or refit",height(Short),1);
Existing=U.Read(fullfile(c.Input,'16_RefitScores.csv'));
Existing=Existing(Existing.Dimension=="Length",:);
Existing.CohortChanged=U.Number(Existing.RemovedTrainingInnings)>0;
Existing.AuditMeaning=repmat("No removals means no changed-cohort test at this cutoff",height(Existing),1);
U.Write(T,fullfile(c.Report,'Pre20E_LengthAttrition.csv'));
U.Write(Short,fullfile(c.Report,'Pre20E_ShortInningsReview.csv'));
U.Write(Existing,fullfile(c.Report,'Pre20E_ExistingLengthExperiments.csv'));
end
