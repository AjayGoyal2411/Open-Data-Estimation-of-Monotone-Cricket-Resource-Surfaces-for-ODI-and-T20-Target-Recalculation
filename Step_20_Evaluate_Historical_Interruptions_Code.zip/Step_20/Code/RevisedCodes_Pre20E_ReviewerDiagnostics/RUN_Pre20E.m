% Run this script after extracting the complete package, including input/.
addpath(fileparts(mfilename('fullpath')),'-begin');
rehash;
ResultsPre20E = RevisedCodes_Pre20E_RunAll;
