function Checks=RevisedCodes_Pre20E_SelfTests
U=RevisedCodes_Pre20E_Utils;p=[tempname '.csv'];cl=onCleanup(@()remove(p)); %#ok<NASGU>
writecell({'MatchID','Path','Flag';'00123','D:\a,b\x.mat','true'},p);
T=U.Read(p);assert(isequal(T.Properties.VariableNames,{'MatchID','Path','Flag'}));
assert(T.MatchID=="00123"&&T.Path=="D:\a,b\x.mat"&&U.Logical(T.Flag));
S=table(["delivery";"initial";"terminal";"delivery"],[1;1;1;0],[120;120;0;119], ...
 [10;10;0;10],[0;0;80;1],[80;80;80;80], ...
 'VariableNames',{'StateType','CorrectedIsLegalBall','BallsRemaining','WicketsInHand','DeliveryScoreBefore','FinalDeliveryRuns'});
assert(isequal(U.Canonical(S),[true;false;false;false]));
E=table(["a";"b"],[2020;2020],["x";"x"],["All";"All"], ...
 ["unclassified";"unclassified"],["men";"men"],[1;10],[0;4],[0;16],[0;4],[1;1], ...
 'VariableNames',{'MatchID','Year','Model','Phase','CompetitionClass','Gender','States','Bias','MSE','MAE','SupportedFraction'});
A=U.Summary(E,50,1);q=A.Year==0&A.Scope=="All"&A.Phase=="All";
assert(nnz(q)==1&&A.Bias(q)==2&&abs(A.RMSE(q)-sqrt(8))<1e-12);
q=A.Year==2021&A.Scope=="All"&A.Phase=="All";assert(A.Matches(q)==0&&isnan(A.Bias(q)));
Checks=table(["Explicit CSV headers and leading-zero IDs";"Quoted commas in paths"; ...
 "Canonical legal pre-delivery states";"Equal-innings aggregation";"Empty subgroup disclosure"],true(5,1), ...
 'VariableNames',{'Check','Passed'});disp(Checks);
end
function remove(p)
if isfile(p),delete(p);end
end
