function U=RevisedCodes_Pre20E_Utils
U.Read=@readCSV;U.Hash=@hashFile;U.Number=@number;U.Logical=@bool;
U.Date=@toDate;U.Gender=@gender;U.Canonical=@canonical;U.Freeze=@freeze;
U.Require=@require;U.Write=@write;U.Summary=@summarize;
end
function T=readCSV(p)
f=fopen(p,'rt','n','UTF-8');assert(f>=0,'Cannot read %s.',p);
c=onCleanup(@()fclose(f));h=fgetl(f);clear c;
assert(ischar(h),'Empty CSV %s.',p);h=strrep(h,char(65279),'');
names=strip(erase(split(string(h),','),'"'))';
assert(numel(unique(names))==numel(names)&&all(strlength(names)>0),'Invalid header: %s',p);
o=delimitedTextImportOptions('NumVariables',numel(names));o.Delimiter=',';o.DataLines=[2 Inf];
o.VariableNames=cellstr(names);o.VariableTypes=repmat({'string'},1,numel(names));
o.ExtraColumnsRule='error';o.EmptyLineRule='skip';T=readtable(p,o);
assert(isequal(string(T.Properties.VariableNames),names),'Header changed in %s.',p);
end
function y=number(x)
if isnumeric(x),y=double(x);else,y=str2double(string(x));end
end
function v=bool(x)
if islogical(x),v=x;return;end
s=lower(strtrim(string(x)));assert(all(ismember(s,["0","1","false","true","yes","no"])), 'Unrecognized boolean CSV value.');
v=ismember(s,["1","true","yes"]);
end
function d=toDate(x)
if isdatetime(x),d=x;return;end
s=string(x);d=NaT(size(s));
for f=["dd-MMM-yyyy","yyyy-MM-dd","MM/dd/yyyy"]
 for j=find(isnat(d)&~ismissing(s)&s~="")'
  try,d(j)=datetime(s(j),'InputFormat',f);catch,end
 end
end
end
function g=gender(x)
g=lower(strtrim(string(x)));g(ismember(g,["male","m","mens","men's"]))="men";
g(ismember(g,["female","f","womens","women's"]))="women";g(ismissing(g)|g=="")="unknown";
end
function require(T,n)
m=string(n);m=m(~ismember(m,string(T.Properties.VariableNames)));assert(isempty(m),'Missing columns: %s',strjoin(m,', '));
end
function q=canonical(S)
require(S,["StateType","CorrectedIsLegalBall","BallsRemaining","WicketsInHand","DeliveryScoreBefore","FinalDeliveryRuns"]);
u=number(S.BallsRemaining);w=number(S.WicketsInHand);y=number(S.FinalDeliveryRuns)-number(S.DeliveryScoreBefore);
q=string(S.StateType)=="delivery"&number(S.CorrectedIsLegalBall)==1&isfinite(u)&u>0&u==floor(u)& ...
 isfinite(w)&w>0&w<=10&w==floor(w)&isfinite(y)&y>=0;
end
function h=hashFile(p)
f=fopen(p,'rb');assert(f>=0,'Cannot hash %s.',p);c=onCleanup(@()fclose(f)); %#ok<NASGU>
md=java.security.MessageDigest.getInstance('SHA-256');
while ~feof(f),b=fread(f,1048576,'*uint8');md.update(typecast(b,'int8'));end
h=lower(string(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[])));
end
function T=freeze(root)
d=dir(fullfile(root,'paper_outputs_revisedcodes','step19_final','frozen','**','*'));d=d(~[d.isdir]);
assert(~isempty(d),'Step19 frozen folder missing.');T=table(strings(0,1),strings(0,1),'VariableNames',{'Path','SHA256'});
for j=1:numel(d),p=string(fullfile(d(j).folder,d(j).name));T(end+1,:)={p,hashFile(p)};end
T=sortrows(T,'Path');
end
function write(T,p)
assert(istable(T),'Report must be a table.');writetable(T,p);
end
function S=summarize(E,B,seed)
% Equal-innings summaries. Bootstrap within year preserves fold composition.
S=table;stream=RandStream('mt19937ar','Seed',seed);
scopes=["All";"Class:"+unique(E.CompetitionClass);"Gender:"+unique(E.Gender)];
for model=unique(E.Model)'
 for yr=[0 2020 2021 2022]
  for scope=scopes'
   for phase=["All","Early","Middle","Late"]
    q=E.Model==model;if yr>0,q=q&E.Year==yr;end
    if startsWith(scope,"Class:"),q=q&E.CompetitionClass==extractAfter(scope,"Class:");end
    if startsWith(scope,"Gender:"),q=q&E.Gender==extractAfter(scope,"Gender:");end
    q=q&E.Phase==phase;D=E(q,:);n=height(D);bias=NaN;rmse=NaN;mae=NaN;lo=NaN;hi=NaN;support=NaN;
    label="NO_FULL_WICKET_OBSERVATIONS";
    if n>0
     assert(numel(unique(D.MatchID))==n,'Duplicate match clusters in summary.');
     bias=mean(D.Bias);rmse=sqrt(mean(D.MSE));mae=mean(D.MAE);support=mean(D.SupportedFraction);
     label="DESCRIPTIVE_SMALL_GROUP";
     if n>=2
      v=zeros(B,1);
      for b=1:B
       ix=zeros(0,1);
       for y=unique(D.Year)',a=find(D.Year==y);ix=[ix;a(randi(stream,numel(a),numel(a),1))];end %#ok<AGROW>
       v(b)=mean(D.Bias(ix));
      end
      ci=quantile(v,[.025 .975]);lo=ci(1);hi=ci(2);
      if n>=20,label="EXPLORATORY_POINTWISE_INTERVAL";end
     end
    end
    a=table(model,yr,scope,phase,n,sum(D.States),bias,lo,hi,rmse,mae,support,label, ...
     'VariableNames',{'Model','Year','Scope','Phase','Matches','States','Bias','BiasLower95','BiasUpper95','RMSE','MAE','SupportedFraction','Interpretation'});
    S=[S;a]; %#ok<AGROW>
   end
  end
 end
end
end
