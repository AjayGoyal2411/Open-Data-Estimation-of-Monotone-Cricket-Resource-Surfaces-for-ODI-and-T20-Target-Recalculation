function [E,S,G,Audit,Sources]=RevisedCodes_Pre20E_FullWicket(c)
U=RevisedCodes_Pre20E_Utils;
assert(exist('RevisedCodes_15_16_Utils','file')==2,'Existing Step15/16 utilities are not on the MATLAB path.');
V=RevisedCodes_15_16_Utils;I=V.Inputs();
assert(string(I.cfg.ProjectRoot)==string(c.ProjectRoot),'Existing model project differs from requested root.');
c.StateManifest=string(fullfile(I.cfg.OutputRoot,'RevisedCodes_09_Result.mat'));c.Step19AuditFile="";
[C,M,Audit,Sources]=RevisedCodes_Pre20E_Data(c);
for source=reshape(string(I.Paths),1,[])
 assert(isfile(source),'Missing model source %s.',source);
 Sources=[Sources;table(source,U.Hash(source),'VariableNames',{'Path','SHA256'})]; %#ok<AGROW>
end
D=U.Read(fullfile(c.Input,'19_00_DevelopmentSelection.csv'));
row=D(D.Format=="T20"&D.Track=="Resource",:);assert(height(row)==1,'Expected one T20 resource development choice.');
modelIDs=unique(["B0_LinearBalls";row.ProvisionalChoice;row.LowestRMSEModel],'stable');
E=table;G=table;ModelAudit=table;
for yr=2020:2022
 package="Fold_"+string(yr)+"_T20";
 z=find(string(I.Empirical.Packages.PackageID)==package);assert(isscalar(z),'Missing fold %s.',package);
 pr=I.Empirical.Packages(z,:);a=load(pr.Path,'Surface');surface=a.Surface;
 assert(pr.TrainingCutoffExclusive==datetime(yr,1,1),'Unexpected training cutoff.');
 assert(surface.Horizon==120,'Expected T20 horizon of 120.');
 q=M.CacheEligible&M.Format=="T20"&year(M.Date)==yr;
 ix=find(q(double(C.MetaRow))&C.W==10);assert(~isempty(ix),'No full-wicket assessment observations for %d.',yr);
 meta=double(C.MetaRow(ix));u=double(C.U(ix));y=double(C.Outcome(ix));
 assert(all(M.Date(meta)>=pr.TrainingCutoffExclusive&M.Date(meta)<datetime(yr+1,1,1)),'Chronology mismatch.');
 phase=repmat("Middle",numel(ix),1);phase(u>80)="Early";phase(u<=40)="Late";
 for id=modelIDs'
  if id=="B0_LinearBalls"
   pred=u/120*surface.FullStartMean;support=true(size(u));grid=(0:120)'/120;
  else
   parts=split(id,'::');assert(numel(parts)==2,'Unsupported model identifier %s.',id);
   switch parts(1)
    case "Compact",P=I.Compact;
    case "Bernstein",P=I.Flexible;
    case "Reference",P=I.Reference;
    otherwise,error('No resource-model adapter for %s.',id);
   end
   j=find(string(P.Index.PackageID)==package&string(P.Index.CandidateID)==parts(2));assert(isscalar(j),'Fold candidate missing: %s %s.',package,id);
   model=P.Models{j};assert(model.Horizon==120&&isequal(size(model.Resource),[121 11]),'Unexpected grid.');
   assert(all(isfinite(model.Resource),'all')&&isfinite(model.FullStartMean)&&model.FullStartMean>0,'Invalid model.');
   ind=sub2ind(size(model.Resource),u+1,11*ones(size(u)));pred=model.Resource(ind)*model.FullStartMean;
   support=logical(model.Supported(ind));grid=model.Resource(:,11);
  end
  err=pred-y;assert(all(isfinite(err)),'Nonfinite errors.');
  for ph=["All","Early","Middle","Late"]
   take=true(size(u));if ph~="All",take=phase==ph;end
   if ~any(take),continue;end
   [m,~,g]=unique(meta(take));n=accumarray(g,1);e=err(take);
   A=table(M.MatchID(m),repmat(yr,numel(m),1),repmat(id,numel(m),1),repmat(ph,numel(m),1), ...
    M.CompetitionClass(m),M.Gender(m),n,accumarray(g,e)./n,accumarray(g,e.^2)./n, ...
    accumarray(g,abs(e))./n,accumarray(g,double(support(take)))./n, ...
    'VariableNames',{'MatchID','Year','Model','Phase','CompetitionClass','Gender','States','Bias','MSE','MAE','SupportedFraction'});
   E=[E;A]; %#ok<AGROW>
  end
  ModelAudit=[ModelAudit;table(package,id,pr.TrainingCutoffExclusive,numel(unique(meta)),numel(meta), ...
   'VariableNames',{'PackageID','Model','TrainingCutoffExclusive','AssessmentMatches','FullWicketStates'})]; %#ok<AGROW>
  % Grid approximation is kept distinct from outcome errors.
  ref=find(string(I.Reference.Index.PackageID)==package&string(I.Reference.Index.CandidateID)=="mean_state_n30_count_l0");
  assert(isscalar(ref),'Reference candidate absent.');R=I.Reference.Models{ref};
  G=[G;table(repmat(yr,121,1),repmat(id,121,1),(0:120)',grid,R.Resource(:,11), ...
   grid-R.Resource(:,11),logical(R.Supported(:,11)), ...
   'VariableNames',{'Year','Model','BallsRemaining','FittedCapacity','MeanStateReferenceCapacity','CapacityDifference','ReferenceSupported'})]; %#ok<AGROW>
 end
end
S=U.Summary(E,c.BootstrapReplicates,c.Seed);
U.Write(E,fullfile(c.Report,'Pre20E_FullWicketMatchErrors.csv'));
U.Write(S,fullfile(c.Report,'Pre20E_FullWicketSubgroups.csv'));
U.Write(G,fullfile(c.Report,'Pre20E_FullWicketApproximation.csv'));
U.Write(ModelAudit,fullfile(c.Report,'Pre20E_ModelUse.csv'));
U.Write(Audit,fullfile(c.Report,'Pre20E_CanonicalObservationAudit.csv'));
U.Write(Sources,fullfile(c.Report,'Pre20E_StateSources.csv'));
end
