function Results=RevisedCodes_Pre20E_RunAll(settings)
% Reviewer diagnostics; no parameter fitting, case scoring or test-set use.
if nargin<1,settings=struct;end
assert(isstruct(settings)&&isscalar(settings),'settings must be a scalar struct.');
c=struct('ProjectRoot',"D:\VihaanProject1",'BootstrapReplicates',1000,'Seed',200019);
for name=fieldnames(settings)'
 assert(isfield(c,name{1}),'Unknown setting %s.',name{1});c.(name{1})=settings.(name{1});
end
assert(isfolder(c.ProjectRoot),'Project root does not exist.');
validateattributes(c.BootstrapReplicates,{'numeric'},{'scalar','integer','>=',500});
validateattributes(c.Seed,{'numeric'},{'scalar','integer','nonnegative'});
here=fileparts(mfilename('fullpath'));old=path;addpath(char(c.ProjectRoot));addpath(here,'-begin');cl=onCleanup(@()path(old)); %#ok<NASGU>
c.Input=fullfile(here,'input');c.EligibilityFile=fullfile(c.Input,'09_04_SensitivityEligibility.csv');
c.ClassificationFile=fullfile(c.Input,'Pre20C_ClassifiedInnings.csv');
U=RevisedCodes_Pre20E_Utils;
manifest=U.Read(fullfile(c.Input,'InputHashes.csv'));
for j=1:height(manifest)
 p=fullfile(c.Input,manifest.File(j));assert(U.Hash(p)==manifest.SHA256(j),'Packaged input changed: %s.',p);
end
Checks=RevisedCodes_Pre20E_SelfTests;before=U.Freeze(c.ProjectRoot);
parent=fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','pre20e_reviewer_diagnostics');if ~isfolder(parent),mkdir(parent);end
c.Root=string(tempname(char(parent)));mkdir(c.Root);c.Report=fullfile(c.Root,'reports');c.Figures=fullfile(c.Root,'figures');mkdir(c.Report);mkdir(c.Figures);
U.Write(Checks,fullfile(c.Report,'Pre20E_SelfTests.csv'));U.Write(before,fullfile(c.Report,'FrozenBefore.csv'));
[Length,Short,Existing]=RevisedCodes_Pre20E_LengthAudit(c);
[Errors,Summary,Grid,Audit,Sources]=RevisedCodes_Pre20E_FullWicket(c);
RevisedCodes_Pre20E_Figures(c,Length,Summary,Grid);
after=U.Freeze(c.ProjectRoot);assert(isequal(before,after),'Frozen Step19 files changed during diagnostics.');
U.Write(after,fullfile(c.Report,'FrozenAfter.csv'));
Gates=table(["Packaged input hashes matched";"Development-only assessment years";"Canonical observation audit completed";"Frozen Step19 unchanged"], ...
 [true;all(ismember(Errors.Year,[2020 2021 2022]));~isempty(Audit);isequal(before,after)],'VariableNames',{'Gate','Passed'});
assert(all(Gates.Passed));U.Write(Gates,fullfile(c.Report,'Pre20E_Gates.csv'));
files=dir(fullfile(here,'*.m'));Code=table;
for j=1:numel(files),p=string(fullfile(files(j).folder,files(j).name));Code=[Code;table(p,U.Hash(p),'VariableNames',{'Path','SHA256'})];end %#ok<AGROW>
U.Write(Code,fullfile(c.Report,'Pre20E_CodeHashes.csv'));copyfile(fullfile(c.Input,'InputHashes.csv'),fullfile(c.Report,'Pre20E_InputHashes.csv'));
copyfile(fullfile(here,'INTERPRETATION.md'),fullfile(c.Report,'INTERPRETATION.md'));
Results=struct('Status',"DIAGNOSTICS_COMPLETE_INTERPRETATION_PENDING",'Root',c.Root,'Gates',Gates, ...
 'Length',Length,'ShortInnings',Short,'ExistingLengthExperiments',Existing,'Summary',Summary,'Sources',Sources);
save(fullfile(c.Root,'RevisedCodes_Pre20E_Result.mat'),'Results','-v7.3');
zipPath=c.Root+"_Checks.zip";zip(char(zipPath),{'reports','figures'},char(c.Root));
Results.ChecksZip=zipPath;disp(Gates);fprintf('\nUpload this ZIP:\n%s\n',zipPath);
end
