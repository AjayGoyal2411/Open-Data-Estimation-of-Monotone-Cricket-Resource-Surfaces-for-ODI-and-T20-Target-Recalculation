function RevisedCodes_Pre20E_Figures(c,T,S,G)
f=figure('Visible','off','Color','w','Position',[100 100 1450 1000]);
t=tiledlayout(f,2,2,'TileSpacing','compact','Padding','compact');
nexttile;A=T(T.CumulativeAuditStage=="CandidateLedger",:);labels=A.Format+" <"+string(A.CutoffBalls);
bar(categorical(labels,labels),A.BelowCutoff);ylabel('Innings below cutoff');title('A. Short innings in available development ledger');xtickangle(35);grid on;
nexttile;hold on;
models=unique(S.Model,'stable');colors=lines(numel(models));
for k=1:numel(models)
 A=S(S.Model==models(k)&S.Scope=="All"&S.Phase=="All"&S.Year>0,:);
 errorbar(A.Year,A.Bias,A.Bias-A.BiasLower95,A.BiasUpper95-A.Bias,'o-', ...
  'Color',colors(k,:),'DisplayName',label(models(k)),'LineWidth',1.2);
end
yline(0,'k:');xticks(2020:2022);ylabel('Prediction minus observed runs');title('B. Ten wickets in hand: assessment-year bias');legend('Location','best','Interpreter','none');grid on;
nexttile;hold on;
compact=models(startsWith(models,"Compact::"));assert(isscalar(compact),'Expected one compact model.');
A=S(S.Model==compact&startsWith(S.Scope,"Class:")&S.Year==0&S.Phase=="All",:);
if isempty(A),text(.1,.5,'No classified subgroup results');axis off;
else
 x=(1:height(A))';errorbar(x,A.Bias,A.Bias-A.BiasLower95,A.BiasUpper95-A.Bias,'o','LineWidth',1.2);
 xticks(x);xticklabels(extractAfter(A.Scope,'Class:'));xtickangle(30);yline(0,'k:');grid on;
 ylabel('Prediction minus observed runs');title('C. Selected compact: competition classes (pooled years)');
end
nexttile;hold on;
for k=1:numel(models)
 A=G(G.Year==2022&G.Model==models(k),:);plot(A.BallsRemaining,A.CapacityDifference,'Color',colors(k,:),'DisplayName',label(models(k)),'LineWidth',1.2);
end
yline(0,'k:');xlabel('Balls remaining');ylabel('Normalized capacity difference');title('D. Fold 2022 versus mean-state reference grid');grid on;
title(t,{'Development diagnostics only: full-wicket T20 states', ...
 'Bias intervals: match bootstrap within year; pointwise and exploratory. Grid difference is not prediction error.'},'FontSize',12);
exportgraphics(f,fullfile(c.Figures,'Pre20E_ReviewerDiagnostics.pdf'),'ContentType','vector');
exportgraphics(f,fullfile(c.Figures,'Pre20E_ReviewerDiagnostics.png'),'Resolution',300);
savefig(f,fullfile(c.Figures,'Pre20E_ReviewerDiagnostics.fig'));close(f);
end
function s=label(id)
if startsWith(id,'Compact::'),s='Selected compact';elseif startsWith(id,'Bernstein::'),s='Development-best Bernstein';else,s='Linear balls baseline';end
end
