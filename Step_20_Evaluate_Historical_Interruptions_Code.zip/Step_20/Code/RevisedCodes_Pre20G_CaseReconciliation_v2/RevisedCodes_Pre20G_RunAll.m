function Results=RevisedCodes_Pre20G_RunAll(settings)
% Reconcile case inputs without fitting or changing the frozen model.
fprintf('Pre20G release v2: direct-digit overs parser.\n');
if nargin<1,settings=struct;end
assert(isstruct(settings)&&isscalar(settings),'Settings must be a scalar struct.');
allowed={'ProjectRoot','RawFolders'};assert(all(ismember(fieldnames(settings),allowed)),'Unknown setting.');
c.ProjectRoot="D:\VihaanProject1";
if isfield(settings,'ProjectRoot'),c.ProjectRoot=string(settings.ProjectRoot);end
assert(isscalar(c.ProjectRoot)&&isfolder(c.ProjectRoot),'Project root not found.');
c.Input=fullfile(fileparts(mfilename('fullpath')),'input');
c.RawFolders=fullfile(c.ProjectRoot,["JSONFiles","ALLYAML","clean_from_json","clean_from_yaml"]);
if isfield(settings,'RawFolders'),c.RawFolders=string(settings.RawFolders);end
U=RevisedCodes_Pre20G_Utils;
manifest=U.Read(fullfile(c.Input,'InputHashes.csv'));
for j=1:height(manifest)
 assert(U.Hash(fullfile(c.Input,manifest.File(j)))==manifest.SHA256(j),'Packaged input changed: %s',manifest.File(j));
end
base=fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','pre20g_case_reconciliation');
if ~isfolder(base),mkdir(base);end
c.Report=string(tempname(base));mkdir(c.Report);
logfile=fullfile(c.Report,'RunLog.txt');diary(logfile);cleanup=onCleanup(@()diary('off')); %#ok<NASGU>
try
 Checks=RevisedCodes_Pre20G_SelfTests;U.Write(Checks,fullfile(c.Report,'Pre20G_SelfTests.csv'));
 before=U.Freeze(c.ProjectRoot);
 C=U.Read(fullfile(c.Input,'CaseRegister.csv'));E=U.Read(fullfile(c.Input,'EventLedger.csv'));
 assert(height(C)==40&&numel(unique(C.MatchID))==40,'Expected 40 unique cases.');
 assert(nnz(C.Format=="ODI")==20&&nnz(C.Format=="T20")==20,'Unexpected format inventory.');
 assert(all(C.CaseID=="CASE_"+C.MatchID),'Case identifiers are inconsistent.');
 for j=1:height(C),assert(~isempty(regexp(char(C.MatchID(j)),'^\d+$','once')),'Invalid match ID.');end
 [Files,Raw]=RevisedCodes_Pre20G_RawAudit(c,C);
 E=RevisedCodes_Pre20G_LedgerAudit(c,C,E);
 A=RevisedCodes_Pre20G_IndependenceAudit(c,C);
 n=height(C);C.EventCount=zeros(n,1);C.RawReady=false(n,1);C.StatesConsistent=false(n,1);
 C.ArithmeticConsistent=false(n,1);C.SourceEvidenceReady=false(n,1);C.AllocationsReady=false(n,1);
 C.TimelineReady=false(n,1);C.IndependenceReady=false(n,1);C.EvaluationEligible=false(n,1);C.Blockers=strings(n,1);
 for j=1:n
  q=E.MatchID==C.MatchID(j);r=find(Raw.MatchID==C.MatchID(j));a=find(A.MatchID==C.MatchID(j));
  assert(isscalar(r)&&isscalar(a),'Nonunique audit join.');C.EventCount(j)=nnz(q);
  C.RawReady(j)=Raw.ReviewedHashFound(r)&&~Raw.UnreviewedVersionPresent(r);
  C.StatesConsistent(j)=any(q)&&all(E.SnapshotStateMatched(q));
  C.ArithmeticConsistent(j)=any(q)&&all(E.ArithmeticConsistent(q));
  C.SourceEvidenceReady(j)=any(q)&&all(U.Logical(E.EventSourceVerified(q)))&&U.Logical(C.TargetSourceVerified(j));
  C.AllocationsReady(j)=any(q)&&all(U.Logical(E.AllocationSourceVerified(q)))&&U.Logical(C.InitialAllocationsVerified(j));
  C.TimelineReady(j)=any(q)&&all(U.Logical(E.TimelineComplete(q)))&&U.Logical(C.TimelineSourceVerified(j));
  C.IndependenceReady(j)=A.CompleteIndependenceCertified(a)&&~A.InFrozenTrainingHistory(a)&&~A.InHistoricalCheckedTable(a);
  flags=[C.RawReady(j),C.StatesConsistent(j),C.ArithmeticConsistent(j),C.SourceEvidenceReady(j),C.AllocationsReady(j),C.TimelineReady(j),C.IndependenceReady(j)];
  labels=["LOCAL_RAW_HASH_OR_VERSION_PENDING","RAW_STATE_UNRESOLVED","EVENT_ARITHMETIC_CONFLICT","EVENT_OR_TARGET_SOURCE_PENDING","ALLOCATION_SOURCE_PENDING","COMPLETE_TIMELINE_PENDING","FULL_INDEPENDENCE_AUDIT_PENDING"];
  C.Blockers(j)=strjoin(labels(~flags),';');
  C.EvaluationEligible(j)=U.Ready(flags(1),flags(2),flags(3),flags(4),flags(5),flags(6),flags(7));
 end
 U.Write(C,fullfile(c.Report,'Pre20G_ReconciledCaseRegister.csv'));
 after=U.Freeze(c.ProjectRoot);assert(isequal(before,after),'Frozen files changed during reconciliation.');
 U.Write(after,fullfile(c.Report,'Pre20G_FrozenHashes.csv'));
 Gates=table(["Input hashes verified";"Forty cases retained";"Event ledger reconciled";"Frozen files unchanged"],true(4,1),'VariableNames',{'Check','Passed'});
 U.Write(Gates,fullfile(c.Report,'Pre20G_ExecutionGates.csv'));
 Summary=table(height(C),height(E),nnz(C.RawReady),nnz(C.StatesConsistent),nnz(C.ArithmeticConsistent),nnz(C.EvaluationEligible), ...
  'VariableNames',{'Cases','Events','LocalRawReady','AllEventStatesMatched','ArithmeticConsistentCases','EvaluationEligibleCases'});
 U.Write(Summary,fullfile(c.Report,'Pre20G_ReadinessSummary.csv'));
 copyfile(c.Input,fullfile(c.Report,'input_snapshot'));
 code=dir(fullfile(fileparts(mfilename('fullpath')),'*.m'));CodeHashes=table;
 for j=1:numel(code)
  p=string(fullfile(code(j).folder,code(j).name));CodeHashes=[CodeHashes;table(string(code(j).name),U.Hash(p),'VariableNames',{'File','SHA256'})]; %#ok<AGROW>
 end
 U.Write(CodeHashes,fullfile(c.Report,'Pre20G_CodeHashes.csv'));
 Results=struct('Status',"RECONCILIATION_COMPLETE_SOURCE_REVIEW_PENDING",'Settings',c,'Summary',Summary,'Cases',C,'Events',E,'Raw',Raw,'Files',Files,'Overlap',A,'Checks',Checks,'Gates',Gates);
 save(fullfile(c.Report,'RevisedCodes_Pre20G_Result.mat'),'Results');
 disp(Summary);fprintf('Reconciliation completed. Source review remains pending; this does not authorize independent evaluation.\n');
 diary off;zip(c.Report+"_Checks.zip",{'*'},c.Report);
 fprintf('Upload %s\n',c.Report+"_Checks.zip");
catch err
 diary off;zip(c.Report+"_FAILED_Checks.zip",{'*'},c.Report);
 fprintf('Upload failure report: %s\n',c.Report+"_FAILED_Checks.zip");rethrow(err);
end
end
