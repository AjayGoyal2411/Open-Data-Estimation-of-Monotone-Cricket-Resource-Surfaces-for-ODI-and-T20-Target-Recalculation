function [R,Audit] = RevisedCodes_20_Predict(T,C,U)
% Apply the exact immutable Step19 PrimaryResource interface and locked target policy.
% No fitting, tuning, model selection, or outcome information enters this function.
codeDir=fullfile(C.FrozenRoot,'code'); addpath(codeDir,'-end'); cleaner=onCleanup(@()rmpath(codeDir)); %#ok<NASGU>
assert(exist('RevisedCodes_19_PredictFrozen','file')==2,'Frozen predictor is unavailable.');
modelFile=fullfile(C.FrozenRoot,'RevisedCodes_19_FrozenModels.mat');
S=load(modelFile,'Frozen'); assert(isfield(S,'Frozen'),'Frozen model MAT lacks variable Frozen.'); Frozen=S.Frozen;
assert(Frozen.PolicyFrozen && ~Frozen.IndependentPerformanceEvaluated,'Unexpected frozen-model state.');
assert(all(ismember(["Format","Role"],string(Frozen.Index.Properties.VariableNames))));

n=height(T); firstRuns=str2double(T.FirstInningsRuns); firstWickets=str2double(T.FirstInningsWickets);
published=str2double(T.PublishedTargetRuns); wicketsLost=str2double(T.WicketsLost);
firstBalls=str2double(T.FirstInningsLegalBalls); eventBalls=U.OversToBalls(T.OversBowled);
allocationBalls=U.OversToBalls(T.PublishedTargetOvers); finalOrder=str2double(T.FinalEventOrder);
scheduledBalls=zeros(n,1); scheduledBalls(strcmpi(T.Format,'ODI'))=300; scheduledBalls(strcmpi(T.Format,'T20'))=120;
assert(all(scheduledBalls>0),'Unsupported format.'); assert(all(allocationBalls<=scheduledBalls));
assert(all(eventBalls<=allocationBalls),'Interruption state exceeds final allocation.');
assert(all(firstWickets>=0&firstWickets<=10&fix(firstWickets)==firstWickets));
assert(all(wicketsLost>=0&wicketsLost<=10&fix(wicketsLost)==wicketsLost));

% A completed full-quota or all-out first innings has full allocated resource.
% For a non-all-out shortened first innings, observed legal balls are used as the
% allocation proxy and the row is explicitly marked assumption-bound.
firstAllocatedBalls=firstBalls;
fullOrAllOut=(firstBalls==scheduledBalls)|(firstWickets==10);
firstAllocatedBalls(fullOrAllOut)=scheduledBalls(fullOrAllOut);
[A1,supportA1]=resourceAt(Frozen,T.Format,firstAllocatedBalls,10*ones(n,1));

beforeRemaining=scheduledBalls-eventBalls; afterRemaining=allocationBalls-eventBalls;
[startResource,supportStart]=resourceAt(Frozen,T.Format,scheduledBalls,10*ones(n,1));
[beforeR,supportBefore]=resourceAt(Frozen,T.Format,beforeRemaining,10-wicketsLost);
[afterR,supportAfter]=resourceAt(Frozen,T.Format,afterRemaining,10-wicketsLost);
A2=startResource-(beforeR-afterR);
prestart=eventBalls==0;
[prestartResource,supportPrestart]=resourceAt(Frozen,T.Format(prestart),allocationBalls(prestart),10*ones(nnz(prestart),1));
A2(prestart)=prestartResource;
assert(all(A1>0&A1<=1.0000001&A2>=0&A2<=1.0000001),'Invalid frozen-resource arithmetic.');

gain=gainScale(Frozen,T.Format); par=zeros(n,1); branch=strings(n,1);
fewer=A2<=A1+1e-12; par(fewer)=firstRuns(fewer).*A2(fewer)./A1(fewer); branch(fewer)="RATIO_FEWER_OR_EQUAL_RESOURCES";
greater=~fewer; par(greater)=firstRuns(greater)+gain(greater).*(A2(greater)-A1(greater)); branch(greater)="LOCKED_ADDITIVE_GREATER_RESOURCES";
modelTarget=floor(par)+1;
assert(all(isfinite(modelTarget)&modelTarget>=1&fix(modelTarget)==modelTarget),'Invalid model target.');

timelineComplete=finalOrder==1; allocationObserved=firstBalls==scheduledBalls;
tier=repmat("ASSUMPTION_BOUND_FINAL_STATE_SCENARIO",n,1);
tier(timelineComplete&allocationObserved)="STRICT_FINAL_STATE_RECONSTRUCTION";
firstMethod=repmat("OBSERVED_BALLS_AS_FIRST_ALLOCATION_PROXY",n,1);
firstMethod(firstWickets==10&~allocationObserved)="ALL_OUT_ASSUMED_FULL_SCHEDULE_RESOURCE";
firstMethod(allocationObserved)="OBSERVED_FULL_SCHEDULE_RESOURCE";
timelineMethod=repmat("FINAL_ALLOCATION_ONLY_INTERMEDIATE_UNVERIFIED",n,1);
timelineMethod(timelineComplete)="SINGLE_VERIFIED_FINAL_EVENT";

R=T; R.ScheduledBalls=scheduledBalls; R.FirstAllocatedBallsUsed=firstAllocatedBalls;
R.EventBalls=eventBalls; R.FinalAllocationBalls=allocationBalls; R.BeforeRemainingBalls=beforeRemaining; R.AfterRemainingBalls=afterRemaining;
R.InitialResource=A1; R.SecondInningsStartResource=startResource; R.BeforeEventResource=beforeR; R.AfterEventResource=afterR;
R.FinalResource=A2; R.ResourceLossAtFinalEvent=beforeR-afterR; R.GainRunsPerFullResource=gain;
R.FirstResourceEmpiricallySupported=supportA1; R.StartResourceEmpiricallySupported=supportStart;
R.BeforeResourceEmpiricallySupported=supportBefore; R.AfterResourceEmpiricallySupported=supportAfter;
R.FinalResourceEmpiricallySupported=supportAfter; R.FinalResourceEmpiricallySupported(prestart)=supportPrestart;
R.AllResourceStatesEmpiricallySupported=supportA1&supportStart&supportBefore&supportAfter;
R.AllResourceStatesEmpiricallySupported(prestart)=supportA1(prestart)&supportStart(prestart)&supportPrestart;
R.TargetPolicyBranch=branch; R.UnroundedPar=par; R.ModelParRuns=floor(par); R.ModelTargetRuns=modelTarget;
R.PublishedTargetRunsNumeric=published; R.SignedDifference=modelTarget-published; R.AbsoluteDifference=abs(R.SignedDifference);
R.ExactAgreement=R.SignedDifference==0; R.WithinFiveRuns=R.AbsoluteDifference<=5; R.WithinTenRuns=R.AbsoluteDifference<=10;
R.FirstInningsResourceMethod=firstMethod; R.EventTimelineMethod=timelineMethod; R.CalculationTier=tier;
R.AnalysisClaim=repmat("HISTORICAL_FINAL_STATE_TARGET_AGREEMENT_NOT_INDEPENDENT",n,1);

Audit=table(["Frozen MAT";"Predictor";"Role";"Target policy";"Rounding";"No fitting";"Independent claim"], ...
    [string(modelFile);string(which('RevisedCodes_19_PredictFrozen'));"PrimaryResource"; ...
    "ratio if A2<=A1; frozen additive gain if A2>A1";"floor(unrounded par)+1";"TRUE";"PROHIBITED"], ...
    'VariableNames',{'Item','Value'});
end

function [r,supported]=resourceAt(Frozen,format,balls,wicketsInHand)
format=string(format(:)); balls=double(balls(:)); wicketsInHand=double(wicketsInHand(:));
assert(numel(format)==numel(balls)&&numel(balls)==numel(wicketsInHand)); r=nan(size(balls)); supported=false(size(balls));
for fmt=unique(format,'stable')'
    q=format==fmt; F=table(balls(q),wicketsInHand(q),'VariableNames',{'BallsRemaining','WicketsInHand'});
    [~,Info]=RevisedCodes_19_PredictFrozen(Frozen,fmt,"PrimaryResource",F);
    assert(ismember('NormalizedCapacity',Info.Properties.VariableNames),'Frozen resource interface changed.');
    r(q)=double(Info.NormalizedCapacity);
    assert(ismember('EmpiricallySupported',Info.Properties.VariableNames),'Frozen support interface changed.');
    supported(q)=logical(Info.EmpiricallySupported);
end
assert(all(isfinite(r)&r>=0&r<=1.0000001),'Invalid normalized resource returned by frozen model.');
end

function g=gainScale(Frozen,format)
format=string(format(:)); g=nan(size(format));
for fmt=unique(format,'stable')'
    j=find(Frozen.Index.Format==fmt&Frozen.Index.Role=="PrimaryResource"); assert(isscalar(j));
    M=Frozen.Models{j}; assert(isfield(M,'FullStartMean')&&isscalar(M.FullStartMean)&&isfinite(M.FullStartMean)&&M.FullStartMean>0);
    g(format==fmt)=double(M.FullStartMean);
end
end
