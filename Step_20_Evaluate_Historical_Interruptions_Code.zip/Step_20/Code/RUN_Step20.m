clear; clc;
here = fileparts(mfilename('fullpath'));
addpath(here);
Results = RevisedCodes_20_RunAll(); %#ok<NASGU>
