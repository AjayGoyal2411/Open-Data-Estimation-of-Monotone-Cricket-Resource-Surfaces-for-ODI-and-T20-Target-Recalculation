function Files = RevisedCodes_20_Figures(D,O,out,C)
vis='off'; if C.FigureVisible, vis='on'; end
Files=strings(0,1);

f=figure('Visible',vis,'Color','w','Position',[100 100 1120 480]); t=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');
for k=1:2
    nexttile; if k==1, X=D; ttl='Descriptive cohort (n=29)'; else, X=O; ttl='Operational subset (n=15)'; end
    hold on; j=strcmpi(X.Format,'ODI'); scatter(X.PublishedTargetRunsNumeric(j),X.ModelTargetRuns(j),55,[0.1 0.35 0.75],'filled');
    scatter(X.PublishedTargetRunsNumeric(~j),X.ModelTargetRuns(~j),55,[0.85 0.35 0.15],'filled','Marker','s');
    z=[min([X.PublishedTargetRunsNumeric;X.ModelTargetRuns])-5,max([X.PublishedTargetRunsNumeric;X.ModelTargetRuns])+5]; plot(z,z,'k--','LineWidth',1.2);
    xlim(z); ylim(z); axis square; grid on; xlabel('Published target (runs)'); ylabel('Frozen-model target (runs)'); title(ttl); legend('ODI','T20','Identity','Location','best');
end
title(t,'Frozen-model versus published targets','FontWeight','bold'); Files(end+1)=saveFigure(f,out,'Step20_Figure1_TargetAgreement'); close(f);

f=figure('Visible',vis,'Color','w','Position',[100 100 1120 520]);
[~,ord]=sort(D.SignedDifference); X=D(ord,:); b=bar(1:height(X),X.SignedDifference,'FaceColor','flat');
b.CData=repmat([0.25 0.55 0.80],height(X),1); b.CData(strcmpi(X.Format,'T20'),:)=repmat([0.90 0.45 0.20],nnz(strcmpi(X.Format,'T20')),1);
yline(0,'k-'); grid on; xlabel('Descriptive cases, ordered by signed difference'); ylabel('Model target - published target (runs)');
title('Case-level target differences (historical descriptive comparison)');
xticks(1:height(X)); xticklabels(X.MatchID); xtickangle(60); Files(end+1)=saveFigure(f,out,'Step20_Figure2_CaseDifferences'); close(f);

f=figure('Visible',vis,'Color','w','Position',[100 100 760 500]);
g=categorical(string(D.Format),["ODI","T20"]); boxchart(g,D.SignedDifference,'BoxFaceColor',[0.25 0.55 0.80]); yline(0,'k--'); grid on;
xlabel('Format'); ylabel('Model target - published target (runs)'); title('Difference distribution by format (descriptive cohort)');
Files(end+1)=saveFigure(f,out,'Step20_Figure3_FormatDifferences'); close(f);
Files=table(Files,'VariableNames',{'File'});
end

function png=saveFigure(f,out,name)
name=string(name);
png=fullfile(out,name+".png"); pdf=fullfile(out,name+".pdf");
exportgraphics(f,png,'Resolution',300); exportgraphics(f,pdf,'ContentType','vector');
end
