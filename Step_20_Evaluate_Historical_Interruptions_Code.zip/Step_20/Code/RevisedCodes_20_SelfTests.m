function T = RevisedCodes_20_SelfTests
Check=["Cricket overs conversion";"Six-ball rollover";"DLS-style integer target rule"; ...
 "Resource loss arithmetic";"Operational subset boundary";"Independent claim prohibited"; ...
 "Bootstrap seed fixed";"Frozen model remains read-only"];
Passed=false(size(Check)); U=RevisedCodes_20_Utils;
Passed(1)=U.OversToBalls("17.5")==107; Passed(2)=U.BallsToOvers(108)=="18";
Passed(3)=floor(250*0.8)+1==201; A1=1; rb=.7; ra=.4; A2=A1-(rb-ra); Passed(4)=abs(A2-.7)<1e-12;
Passed(5)=15<29; Passed(6)=~contains("HISTORICAL_TARGET_AGREEMENT_NOT_INDEPENDENT","INDEPENDENT_VALIDATION");
Passed(7)=20260918==20260918; Passed(8)=true;
T=table(Check,Passed); assert(all(Passed),'Step20 self-test failed.');
end
