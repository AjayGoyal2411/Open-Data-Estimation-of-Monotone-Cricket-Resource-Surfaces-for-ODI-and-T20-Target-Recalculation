function T=RevisedCodes_Pre20M_BuildStep20Input(Evidence,Roles,caseIDs,U)
MatchID=strings(0,1);EventOrder=strings(0,1);Identity=strings(0,1);InitialAllocations=strings(0,1);CompleteTimeline=strings(0,1);PenaltyConvention=strings(0,1);FirstInningsScoreBasis=strings(0,1);PublishedWinningTarget=strings(0,1);
InningsIndex=strings(0,1);EventType=strings(0,1);OversBowled=strings(0,1);Score=strings(0,1);WicketsLost=strings(0,1);NewOversClaim=strings(0,1);TargetRunsClaim=strings(0,1);
DevelopmentTrain=false(0,1);DevelopmentValidation=false(0,1);SensitivityAssessment=false(0,1);DirectDevelopmentOverlap=false(0,1);IndependenceStatus=strings(0,1);
for c=1:numel(caseIDs)
 id=caseIDs(c);orders=unique(Evidence.EventOrder(Evidence.MatchID==id&str2double(Evidence.EventOrder)>0),'stable');role=Roles(Roles.MatchID==id,:);assert(height(role)==1);
 for o=reshape(orders,1,[])
  MatchID(end+1,1)=id;EventOrder(end+1,1)=o;Identity(end+1,1)=one(Evidence,id,"0","Identity");InitialAllocations(end+1,1)=one(Evidence,id,"0","InitialAllocations"); %#ok<AGROW>
  CompleteTimeline(end+1,1)=one(Evidence,id,"0","CompleteTimeline");PenaltyConvention(end+1,1)=one(Evidence,id,"0","PenaltyConvention");FirstInningsScoreBasis(end+1,1)=one(Evidence,id,"0","FirstInningsScoreBasis");PublishedWinningTarget(end+1,1)=one(Evidence,id,"0","PublishedWinningTarget"); %#ok<AGROW>
  InningsIndex(end+1,1)=one(Evidence,id,o,"InningsIndex");EventType(end+1,1)=one(Evidence,id,o,"EventType");OversBowled(end+1,1)=one(Evidence,id,o,"OversBowled");Score(end+1,1)=one(Evidence,id,o,"Score");WicketsLost(end+1,1)=one(Evidence,id,o,"WicketsLost");NewOversClaim(end+1,1)=one(Evidence,id,o,"NewOversClaim");TargetRunsClaim(end+1,1)=one(Evidence,id,o,"TargetRunsClaim"); %#ok<AGROW>
  DevelopmentTrain(end+1,1)=U.Bool(role.DevelopmentTrain);DevelopmentValidation(end+1,1)=U.Bool(role.DevelopmentValidation);SensitivityAssessment(end+1,1)=U.Bool(role.SensitivityAssessment);DirectDevelopmentOverlap(end+1,1)=U.Bool(role.DirectDevelopmentOverlap);IndependenceStatus(end+1,1)=role.IndependenceStatus; %#ok<AGROW>
 end
end
T=table(MatchID,EventOrder,Identity,InitialAllocations,CompleteTimeline,PenaltyConvention,FirstInningsScoreBasis,PublishedWinningTarget,InningsIndex,EventType,OversBowled,Score,WicketsLost,NewOversClaim,TargetRunsClaim,DevelopmentTrain,DevelopmentValidation,SensitivityAssessment,DirectDevelopmentOverlap,IndependenceStatus);
end

function v=one(E,id,order,field)
q=E.MatchID==id&E.EventOrder==order&E.Field==field;assert(nnz(q)==1,'Expected one evidence value for %s|%s|%s.',id,order,field);v=E.AdjudicatedValue(q);
end

