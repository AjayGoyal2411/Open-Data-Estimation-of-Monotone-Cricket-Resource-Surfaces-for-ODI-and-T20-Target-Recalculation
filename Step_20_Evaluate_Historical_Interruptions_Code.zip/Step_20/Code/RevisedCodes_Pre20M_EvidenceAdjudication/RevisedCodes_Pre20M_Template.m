function T=RevisedCodes_Pre20M_Template(C,U)
RowKey=C.MatchID+"|"+C.EventOrder+"|"+C.Field;
assert(numel(unique(RowKey))==height(C),'Carry-forward evidence keys are not unique.');
MatchID=C.MatchID;EventOrder=C.EventOrder;Field=C.Field;SubmittedValue=C.SubmittedValue;CurrentStatus=C.Status;Priority=upper(C.Priority);
if ismember("SourceURL",string(C.Properties.VariableNames)),CurrentSourceURL=C.SourceURL;else,CurrentSourceURL=strings(height(C),1);end
calculationFields=["EventType","InningsIndex","OversBowled","Score","WicketsLost","NewOversClaim","TargetRunsClaim","PublishedWinningTarget"];
RequiresSecondReview=ismember(Priority,["CRITICAL","HIGH"])|ismember(Field,calculationFields);
n=height(C);ReviewerDecision=repmat("PENDING",n,1);ReviewedValue=SubmittedValue;EvidenceType=strings(n,1);SourceURL=CurrentSourceURL;
SourceDocumentPath=strings(n,1);ExpectedSourceSHA256=strings(n,1);SourceLocation=strings(n,1);ReviewerName=strings(n,1);ReviewDateISO=strings(n,1);ReviewNote=strings(n,1);
SecondReviewerName=strings(n,1);SecondReviewDateISO=strings(n,1);SecondReviewDecision=repmat("PENDING",n,1);
T=table(RowKey,MatchID,EventOrder,Field,SubmittedValue,CurrentStatus,Priority,CurrentSourceURL,RequiresSecondReview, ...
 ReviewerDecision,ReviewedValue,EvidenceType,SourceURL,SourceDocumentPath,ExpectedSourceSHA256,SourceLocation,ReviewerName,ReviewDateISO,ReviewNote,SecondReviewerName,SecondReviewDateISO,SecondReviewDecision);
T=sortrows(T,{'MatchID','EventOrder','Field'});
end

