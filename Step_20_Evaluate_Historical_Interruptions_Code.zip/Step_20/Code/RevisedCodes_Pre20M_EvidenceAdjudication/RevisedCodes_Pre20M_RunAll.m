function Results=RevisedCodes_Pre20M_RunAll(settings)
% External-evidence adjudication and endpoint release only. No model fitting.
if nargin<1,settings=struct;end
assert(isstruct(settings)&&isscalar(settings),'Settings must be scalar struct.');
allowed={'ProjectRoot','ReviewFile','AttestationFile','VerifyFrozenFiles'};assert(all(ismember(fieldnames(settings),allowed)),'Unknown setting.');
c.ProjectRoot="D:\VihaanProject1";c.ReviewFile="";c.AttestationFile="";c.VerifyFrozenFiles=true;
for n=reshape(string(fieldnames(settings)),1,[]),c.(n)=settings.(n);end
c.ProjectRoot=string(c.ProjectRoot);assert(isfolder(c.ProjectRoot),'Project root missing.');assert(isscalar(c.VerifyFrozenFiles)&&islogical(c.VerifyFrozenFiles),'VerifyFrozenFiles must be logical.');
U=RevisedCodes_Pre20M_Utils;here=fileparts(mfilename('fullpath'));input=fullfile(here,'input');
if string(c.ReviewFile)=="",c.ReviewFile=string(fullfile(here,'review_input','Pre20M_EvidenceReview.csv'));else,c.ReviewFile=string(c.ReviewFile);end
if string(c.AttestationFile)=="",c.AttestationFile=string(fullfile(here,'review_input','Pre20M_Step18InfluenceAttestation.csv'));else,c.AttestationFile=string(c.AttestationFile);end
base=fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','pre20m_evidence_adjudication');if ~isfolder(base),mkdir(base);end
report=string(tempname(base));mkdir(report);work=string(tempname);mkdir(work);cleanupWork=onCleanup(@()safeRemove(work)); %#ok<NASGU>
diary(fullfile(report,'RunLog.txt'));cleanupDiary=onCleanup(@()diary('off')); %#ok<NASGU>
try
 Checks=RevisedCodes_Pre20M_SelfTests;U.Write(Checks,fullfile(report,'Pre20M_SelfTests.csv'));
 D=RevisedCodes_Pre20M_LoadInputs(input,work,U);Canonical=RevisedCodes_Pre20M_Template(D.CarryForward,U);
 U.Write(Canonical,fullfile(report,'Pre20M_CanonicalEvidenceReviewTemplate.csv'));
 [Review,Audit,SourceManifest]=RevisedCodes_Pre20M_ReviewAudit(Canonical,c.ReviewFile,here,U);
 U.Write(Review,fullfile(report,'Pre20M_SubmittedEvidenceReview.csv'));U.Write(Audit,fullfile(report,'Pre20M_EvidenceReviewAudit.csv'));U.Write(SourceManifest,fullfile(report,'Pre20M_SourceDocumentManifest.csv'));
 FrozenVerification=D.Frozen;FrozenVerification.Pre20MCurrentSHA256=strings(height(FrozenVerification),1);FrozenVerification.Pre20MHashMatched=false(height(FrozenVerification),1);
 if c.VerifyFrozenFiles
  for k=1:height(FrozenVerification)
   assert(isfile(FrozenVerification.Path(k)),'Frozen file missing: %s',FrozenVerification.Path(k));FrozenVerification.Pre20MCurrentSHA256(k)=U.Hash(FrozenVerification.Path(k));FrozenVerification.Pre20MHashMatched(k)=FrozenVerification.Pre20MCurrentSHA256(k)==lower(FrozenVerification.ExpectedSHA256(k));
  end
  assert(all(FrozenVerification.Pre20MHashMatched),'Frozen Step19 file changed.');
 else,FrozenVerification.Pre20MCurrentSHA256(:)="NOT_RECHECKED";FrozenVerification.Pre20MHashMatched=U.Bool(FrozenVerification.Pre20LHashMatched);end
 U.Write(FrozenVerification,fullfile(report,'Pre20M_FrozenVerification.csv'));
 Attestation=U.Read(c.AttestationFile);assert(isequal(string(Attestation.Properties.VariableNames),string(D.AttestationTemplate.Properties.VariableNames)),'Attestation schema changed.');
 assert(height(Attestation)==height(D.AttestationTemplate)&&all(Attestation.Question==D.AttestationTemplate.Question),'Attestation questions changed.');U.Write(Attestation,fullfile(report,'Pre20M_Step18InfluenceAttestation.csv'));
 [Evidence,Endpoint,descriptiveCases,operationalCases]=RevisedCodes_Pre20M_Adjudicate(D.Evidence,Review,Audit,D.Roles,U);
 U.Write(Evidence,fullfile(report,'Pre20M_AdjudicatedEvidence.csv'));U.Write(Endpoint,fullfile(report,'Pre20M_EndpointDisposition.csv'));
 DescriptiveInput=RevisedCodes_Pre20M_BuildStep20Input(Evidence,D.Roles,descriptiveCases,U);OperationalInput=RevisedCodes_Pre20M_BuildStep20Input(Evidence,D.Roles,operationalCases,U);
 U.Write(DescriptiveInput,fullfile(report,'Pre20M_Step20_DescriptiveInput_RELEASE_ONLY_IF_NONEMPTY.csv'));U.Write(OperationalInput,fullfile(report,'Pre20M_Step20_OperationalInput_RELEASE_ONLY_IF_NONEMPTY.csv'));
 IndependentInput=DescriptiveInput([],:);U.Write(IndependentInput,fullfile(report,'Pre20M_IndependentEvaluationInput_LOCKED.csv'));
 decisions=upper(Review.ReviewerDecision);Summary=table(40,597,height(Review),nnz(decisions=="PENDING"),nnz(decisions=="ACCEPT"),nnz(decisions=="REJECT"),nnz(decisions=="NOT_APPLICABLE"),nnz(Audit.Accepted), ...
  nnz(Endpoint.DescriptiveEligible),nnz(Endpoint.OperationalEligible),0,height(DescriptiveInput),height(OperationalInput), ...
  'VariableNames',{'Cases','EvidenceRows','ReviewRows','PendingDecisions','AcceptDecisions','RejectDecisions','NotApplicableDecisions','AcceptedReviewRows','DescriptiveCasesReleased','OperationalCasesReleased','IndependentCasesReleased','DescriptiveEventsReleased','OperationalEventsReleased'});
 U.Write(Summary,fullfile(report,'Pre20M_Summary.csv'));
 Gate=["Packaged inputs hash verified";"Review keys and protected columns unchanged";"Frozen 94-file boundary unchanged";"All nonpending accepted decisions passed validation";"All evidence rows resolved";"Step20 descriptive calculation authorized";"Operational comparison authorized";"Independent evaluation authorized"];
 nonpending=~ismember(decisions,["PENDING","REJECT"]);Passed=[true;true;all(FrozenVerification.Pre20MHashMatched);all(Audit.Accepted(nonpending));all(U.Resolved(Evidence.AdjudicationStatus));any(Endpoint.DescriptiveEligible);any(Endpoint.OperationalEligible);false];
 Gates=table(Gate,Passed);U.Write(Gates,fullfile(report,'Pre20M_ExecutionGates.csv'));
 code=dir(fullfile(here,'*.m'));CodeHashes=table;
 for k=1:numel(code),CodeHashes=[CodeHashes;table(string(code(k).name),U.Hash(fullfile(code(k).folder,code(k).name)),'VariableNames',{'File','SHA256'})];end %#ok<AGROW>
 U.Write(CodeHashes,fullfile(report,'Pre20M_CodeHashes.csv'));
 Results=struct('Status',"EVIDENCE_REVIEW_AUDITED_ENDPOINT_RELEASES_GATED",'Settings',c,'Summary',Summary,'Gates',Gates);
 save(fullfile(report,'RevisedCodes_Pre20M_Result.mat'),'Results');disp(Summary);disp(Gates);
 diary off;zip(report+"_Checks.zip",{'*'},report);fprintf('Upload %s\n',report+"_Checks.zip");
catch err
 diary off;zip(report+"_FAILED_Checks.zip",{'*'},report);fprintf('Upload %s\n',report+"_FAILED_Checks.zip");rethrow(err);
end
end

function safeRemove(path)
if isfolder(path),rmdir(path,'s');end
end

