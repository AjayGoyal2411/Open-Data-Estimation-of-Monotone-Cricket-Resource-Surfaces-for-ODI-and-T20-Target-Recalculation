function Checks=RevisedCodes_Pre20M_SelfTests
U=RevisedCodes_Pre20M_Utils;Check=["Exact composite key";"Pending is unresolved";"NOT_APPLICABLE is resolved not verified";"Published target domain";"Wickets domain";"Cricket over notation valid";"Invalid sixth ball rejected";"Initial allocation syntax";"Complete timeline token";"Penalty convention syntax";"Event type vocabulary";"ISO date valid";"Invalid calendar date rejected";"Primary and second reviewers must differ";"Independent release remains locked";"Hash deterministic"];
Passed=false(16,1);Passed(1)=("123|1|Score"~="1230|1|Score");Passed(2)=~U.Resolved("PENDING");Passed(3)=U.Resolved("NOT_APPLICABLE")&&~U.Verified("NOT_APPLICABLE");
[Passed(4),~]=U.ValidValue("PublishedWinningTarget","171");[Passed(5),~]=U.ValidValue("WicketsLost","10");Passed(6)=U.ValidOvers("19.5")&&U.ValidOvers("20");Passed(7)=~U.ValidOvers("19.6");
[Passed(8),~]=U.ValidValue("InitialAllocations","INN1=20;INN2=20");[Passed(9),~]=U.ValidValue("CompleteTimeline","COMPLETE_VERIFIED");[Passed(10),~]=U.ValidValue("PenaltyConvention","NONE");[Passed(11),~]=U.ValidValue("EventType","interruption");
Passed(12)=U.ValidDate("2026-09-18");Passed(13)=~U.ValidDate("2026-02-30");Passed(14)="Reviewer A"~="Reviewer B";independentEligible=false;Passed(15)=~independentEligible;
p=string(tempname);f=fopen(p,'wb');assert(f>=0);fwrite(f,uint8('pre20m'));fclose(f);c=onCleanup(@()deleteIfPresent(p));Passed(16)=U.Hash(p)==U.Hash(p);clear c;
Checks=table(Check,Passed);assert(all(Passed),'Pre20M self-test failed.');
end

function deleteIfPresent(p)
if isfile(p),delete(p);end
end
