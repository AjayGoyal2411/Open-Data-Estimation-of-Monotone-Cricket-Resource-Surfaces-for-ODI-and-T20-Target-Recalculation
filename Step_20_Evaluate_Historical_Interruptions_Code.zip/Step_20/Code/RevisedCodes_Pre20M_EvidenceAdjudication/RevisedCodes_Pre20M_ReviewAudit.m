function [Review,Audit,SourceManifest]=RevisedCodes_Pre20M_ReviewAudit(canonical,reviewPath,packageDir,U)
assert(isfile(reviewPath),'Review file missing: %s',reviewPath);Review=U.Read(reviewPath);
expected=string(canonical.Properties.VariableNames);assert(isequal(string(Review.Properties.VariableNames),expected),'Review schema changed. Use the supplied template without adding, removing or renaming columns.');
assert(height(Review)==height(canonical),'Review row count changed.');assert(numel(unique(Review.RowKey))==height(Review),'Duplicate review RowKey.');
[tf,loc]=ismember(canonical.RowKey,Review.RowKey);assert(all(tf)&&numel(unique(loc))==height(canonical),'Review keys do not exactly match the template.');Review=Review(loc,:);
assert(all(Review.RowKey==canonical.RowKey),'Review key alignment failed.');
assert(all(Review.MatchID==canonical.MatchID&Review.EventOrder==canonical.EventOrder&Review.Field==canonical.Field),'Protected key columns changed.');
assert(all(Review.SubmittedValue==canonical.SubmittedValue&Review.CurrentStatus==canonical.CurrentStatus&Review.Priority==canonical.Priority),'Protected evidence columns changed.');
assert(all(U.Bool(Review.RequiresSecondReview)==canonical.RequiresSecondReview),'RequiresSecondReview was modified.');
n=height(Review);Decision=upper(Review.ReviewerDecision);SchemaValid=true(n,1);DomainValid=false(n,1);SourceValid=false(n,1);SecondReviewValid=false(n,1);Accepted=false(n,1);
Issue=strings(n,1);ResolvedSourcePath=strings(n,1);ActualSourceSHA256=strings(n,1);
allowed=["PENDING","ACCEPT","REJECT","NOT_APPLICABLE"];
for i=1:n
 d=Decision(i);issues=strings(0,1);
 if ~ismember(d,allowed),issues(end+1)="INVALID_DECISION";SchemaValid(i)=false;end
 if d=="PENDING",Issue(i)="PENDING_REVIEW";continue;elseif d=="REJECT",Issue(i)="REJECTED_BY_REVIEWER";continue;end
 if d=="NOT_APPLICABLE"
  DomainValid(i)=Review.Field(i)=="TargetRunsClaim";if ~DomainValid(i),issues(end+1)="NOT_APPLICABLE_NOT_ALLOWED_FOR_FIELD";end
 else
  [DomainValid(i),why]=U.ValidValue(Review.Field(i),Review.ReviewedValue(i));if ~DomainValid(i),issues(end+1)=why;end
 end
 requiredText=Review.EvidenceType(i)~=""&&Review.SourceLocation(i)~=""&&Review.ReviewerName(i)~=""&&Review.ReviewNote(i)~=""&&U.ValidDate(Review.ReviewDateISO(i));
 if ~requiredText,issues(end+1)="INCOMPLETE_PRIMARY_REVIEW_METADATA";end
 hasURL=Review.SourceURL(i)~="";hasDocument=Review.SourceDocumentPath(i)~="";docOK=false;
 if hasDocument
  p=Review.SourceDocumentPath(i);if ~isfile(p),p=fullfile(packageDir,'source_documents',p);end
  if isfile(p)
   ResolvedSourcePath(i)=string(p);ActualSourceSHA256(i)=U.Hash(p);docOK=Review.ExpectedSourceSHA256(i)==""||lower(Review.ExpectedSourceSHA256(i))==ActualSourceSHA256(i);
   if ~docOK,issues(end+1)="SOURCE_DOCUMENT_HASH_MISMATCH";end
  else,issues(end+1)="SOURCE_DOCUMENT_NOT_FOUND";end
 end
 SourceValid(i)=requiredText&&(hasURL||(hasDocument&&docOK));if ~hasURL&&~hasDocument,issues(end+1)="NO_SOURCE_URL_OR_DOCUMENT";end
 if canonical.RequiresSecondReview(i)
  SecondReviewValid(i)=Review.SecondReviewerName(i)~=""&&Review.SecondReviewerName(i)~=Review.ReviewerName(i)&&U.ValidDate(Review.SecondReviewDateISO(i))&&upper(Review.SecondReviewDecision(i))=="CONCUR";
  if ~SecondReviewValid(i),issues(end+1)="SECOND_REVIEW_REQUIRED_OR_INVALID";end
 else,SecondReviewValid(i)=true;end
 Accepted(i)=SchemaValid(i)&&DomainValid(i)&&SourceValid(i)&&SecondReviewValid(i);
 if Accepted(i),Issue(i)="ACCEPTED";else,Issue(i)=U.Join(issues);end
end
Audit=table(Review.RowKey,Review.MatchID,Review.EventOrder,Review.Field,Decision,SchemaValid,DomainValid,SourceValid,SecondReviewValid,Accepted,Issue,ResolvedSourcePath,ActualSourceSHA256, ...
 'VariableNames',{'RowKey','MatchID','EventOrder','Field','ReviewerDecision','SchemaValid','DomainValid','SourceValid','SecondReviewValid','Accepted','Issue','ResolvedSourcePath','ActualSourceSHA256'});
q=ResolvedSourcePath~="";SourcePath=ResolvedSourcePath(q);SHA256=ActualSourceSHA256(q);SourceManifest=unique(table(SourcePath,SHA256),'rows','stable');
end

