function U=RevisedCodes_Pre20M_Utils
U.Read=@readCSV;U.Write=@writeCSV;U.Hash=@hashFile;U.Bool=@toLogical;
U.Num=@toNumber;U.Require=@requireColumns;U.Join=@joinNonempty;
U.Clean=@cleanStrings;U.Verified=@isVerified;U.Resolved=@isResolved;
U.ValidValue=@validFieldValue;U.ValidDate=@validDate;U.ValidOvers=@validOvers;
end

function T=readCSV(path)
assert(isfile(path),'Required file is missing: %s',path);
f=fopen(path,'rt','n','UTF-8');assert(f>=0,'Cannot read %s.',path);
c=onCleanup(@()fclose(f));header=fgetl(f);clear c;
assert(ischar(header),'Empty CSV: %s',path);header=strrep(header,char(65279),'');
names=strip(erase(split(string(header),','),'"'))';
assert(numel(unique(names))==numel(names)&&all(strlength(names)>0),'Invalid CSV header: %s',path);
o=delimitedTextImportOptions('NumVariables',numel(names));o.Delimiter=',';o.DataLines=[2 Inf];
o.VariableNames=cellstr(names);o.VariableTypes=repmat({'string'},1,numel(names));
o.ExtraColumnsRule='error';o.EmptyLineRule='skip';T=readtable(path,o);
assert(isequal(string(T.Properties.VariableNames),names),'Header changed while reading %s.',path);
for k=1:width(T),name=T.Properties.VariableNames{k};T.(name)=cleanStrings(T.(name));end
end

function writeCSV(T,path)
assert(istable(T),'Only tables may be written as CSV.');writetable(T,path);
end

function h=hashFile(path)
f=fopen(path,'rb');assert(f>=0,'Cannot hash %s.',path);c=onCleanup(@()fclose(f)); %#ok<NASGU>
md=java.security.MessageDigest.getInstance('SHA-256');
while ~feof(f),bytes=fread(f,1048576,'*uint8');md.update(typecast(bytes,'int8'));end
h=lower(string(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[])));
end

function x=toNumber(v)
if isnumeric(v),x=double(v);else,x=str2double(string(v));end
end

function x=toLogical(v)
if islogical(v),x=v;return;end
s=lower(cleanStrings(v));assert(all(ismember(s,["0","1","false","true","yes","no"])),'Invalid logical value.');
x=ismember(s,["1","true","yes"]);
end

function requireColumns(T,names)
missing=string(names);missing=missing(~ismember(missing,string(T.Properties.VariableNames)));
assert(isempty(missing),'Missing required columns: %s',strjoin(missing,', '));
end

function s=joinNonempty(v)
v=cleanStrings(v);v=v(strlength(v)>0);v=unique(v,'stable');
if isempty(v),s="";else,s=strjoin(v,';');end
end

function s=cleanStrings(v)
s=strtrim(string(v));s(ismissing(s))="";
end

function tf=isVerified(status)
tf=ismember(upper(cleanStrings(status)),["SOURCE_VERIFIED","VERIFIED","CONFIRMED","VERIFIED_EXTERNAL_SOURCE"]);
end

function tf=isResolved(status)
tf=isVerified(status)|upper(cleanStrings(status))=="NOT_APPLICABLE";
end

function tf=validDate(value)
s=cleanStrings(value);tf=isscalar(s)&&~isempty(regexp(char(s),'^\d{4}-\d{2}-\d{2}$','once'));
if tf
 try
  p=str2double(split(s,"-"));d=datetime(p(1),p(2),p(3));tf=~isnat(d)&&year(d)==p(1)&&month(d)==p(2)&&day(d)==p(3);
 catch,tf=false;
 end
end
end

function tf=validOvers(value)
s=cleanStrings(value);tf=false;if strlength(s)==0,return;end
t=regexp(char(s),'^(\d+)(?:\.([0-5]))?$','tokens','once');tf=~isempty(t);
end

function [tf,reason]=validFieldValue(field,value)
field=string(field);value=cleanStrings(value);tf=true;reason="";
if strlength(value)==0||upper(value)=="UNKNOWN",tf=false;reason="VALUE_MISSING_OR_UNKNOWN";return;end
switch field
 case "InningsIndex"
  x=str2double(value);tf=isfinite(x)&&fix(x)==x&&ismember(x,[1 2]);
 case "EventType"
  tf=ismember(lower(value),["interruption","terminal_abandonment","pre_start_reduction"]);
 case "InitialAllocations"
  t=regexp(char(upper(value)),'^INN1=([^;]+);INN2=([^;]+)$','tokens','once');tf=~isempty(t)&&validOvers(string(t{1}))&&validOvers(string(t{2}));
 case "CompleteTimeline"
  tf=upper(value)=="COMPLETE_VERIFIED";
 case "PenaltyConvention"
  tf=upper(value)=="NONE"||(startsWith(upper(value),"APPLIED:")&&strlength(value)>8);
 case "FirstInningsScoreBasis"
  x=str2double(value);tf=isfinite(x)&&fix(x)==x&&x>=0;
 case {"Score","WicketsLost","PublishedWinningTarget","TargetRunsClaim"}
  x=str2double(value);tf=isfinite(x)&&fix(x)==x&&x>=0;
  if field=="WicketsLost",tf=tf&&x<=10;elseif ismember(field,["PublishedWinningTarget","TargetRunsClaim"]),tf=tf&&x>=1;end
 case {"OversBowled","NewOversClaim"}
  tf=validOvers(value);
 otherwise
  tf=strlength(value)>0&&upper(value)~="UNKNOWN";
end
if ~tf,reason="INVALID_VALUE_FOR_"+upper(field);end
end
