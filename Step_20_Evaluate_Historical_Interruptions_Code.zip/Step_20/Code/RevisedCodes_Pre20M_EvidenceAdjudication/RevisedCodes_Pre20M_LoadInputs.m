function D=RevisedCodes_Pre20M_LoadInputs(inputDir,work,U)
M=U.Read(fullfile(inputDir,'InputHashes.csv'));U.Require(M,["File","SHA256"]);
for k=1:height(M)
 p=fullfile(inputDir,M.File(k));assert(isfile(p),'Packaged input missing: %s',p);
 assert(U.Hash(p)==lower(M.SHA256(k)),'Packaged input changed: %s',M.File(k));
end
kDir=fullfile(work,'pre20k');lDir=fullfile(work,'pre20l');mkdir(kDir);mkdir(lDir);
unzip(fullfile(inputDir,'Pre20K_Checked.zip'),kDir);unzip(fullfile(inputDir,'Pre20L_Checked.zip'),lDir);
requiredK=["Pre20K_ExternalEvidenceDraft.csv","Pre20K_ExecutionGates.csv"];
requiredL=["Pre20L_CaseRoleMatrix.csv","Pre20L_EndpointDisposition.csv","Pre20L_ExternalEvidenceCarryForward.csv", ...
 "Pre20L_FrozenVerification.csv","Pre20L_ExecutionGates.csv","Pre20L_Step18InfluenceAttestation_REQUIRED.csv"];
for f=requiredK,assert(isfile(fullfile(kDir,f)),'Pre20K input missing %s.',f);end
for f=requiredL,assert(isfile(fullfile(lDir,f)),'Pre20L input missing %s.',f);end
D=struct;
D.Evidence=U.Read(fullfile(kDir,'Pre20K_ExternalEvidenceDraft.csv'));
D.KGates=U.Read(fullfile(kDir,'Pre20K_ExecutionGates.csv'));
D.Roles=U.Read(fullfile(lDir,'Pre20L_CaseRoleMatrix.csv'));
D.LEndpoint=U.Read(fullfile(lDir,'Pre20L_EndpointDisposition.csv'));
D.CarryForward=U.Read(fullfile(lDir,'Pre20L_ExternalEvidenceCarryForward.csv'));
D.Frozen=U.Read(fullfile(lDir,'Pre20L_FrozenVerification.csv'));
D.LGates=U.Read(fullfile(lDir,'Pre20L_ExecutionGates.csv'));
D.AttestationTemplate=U.Read(fullfile(lDir,'Pre20L_Step18InfluenceAttestation_REQUIRED.csv'));
U.Require(D.Evidence,["MatchID","EventOrder","Field","SubmittedValue","Status"]);
U.Require(D.CarryForward,["MatchID","EventOrder","Field","SubmittedValue","Status","Priority"]);
U.Require(D.Roles,["MatchID","DevelopmentTrain","DevelopmentValidation","EmpiricalEstimation","Tuning","SensitivityAssessment"]);
U.Require(D.Frozen,["Path","ExpectedSHA256","Pre20LHashMatched"]);
assert(height(D.Evidence)==597,'Expected exactly 597 evidence rows.');
assert(height(D.CarryForward)==339,'Expected exactly 339 unresolved evidence rows.');
assert(height(D.Roles)==40,'Expected exactly 40 role-adjudicated cases.');
assert(height(D.Frozen)==94&&all(U.Bool(D.Frozen.Pre20LHashMatched)),'Pre20L frozen verification is incomplete.');
end

