function [Evidence,Endpoint,DescriptiveCases,OperationalCases]=RevisedCodes_Pre20M_Adjudicate(baseEvidence,Review,Audit,Roles,U)
Evidence=baseEvidence;Evidence.AdjudicatedValue=Evidence.SubmittedValue;Evidence.AdjudicationStatus=Evidence.Status;
Evidence.ReviewerDecision=strings(height(Evidence),1);Evidence.EvidenceReviewRowKey=strings(height(Evidence),1);Evidence.ReviewEvidenceType=strings(height(Evidence),1);
Evidence.ReviewSourceURL=strings(height(Evidence),1);Evidence.ReviewSourceDocumentPath=strings(height(Evidence),1);Evidence.ReviewSourceSHA256=strings(height(Evidence),1);
Evidence.ReviewSourceLocation=strings(height(Evidence),1);Evidence.ReviewerName=strings(height(Evidence),1);Evidence.ReviewDateISO=strings(height(Evidence),1);Evidence.ReviewNote=strings(height(Evidence),1);
keys=Evidence.MatchID+"|"+Evidence.EventOrder+"|"+Evidence.Field;assert(numel(unique(keys))==height(Evidence),'Base evidence keys are not unique.');
for i=1:height(Review)
 j=find(keys==Review.RowKey(i),1);assert(~isempty(j),'Review key absent from evidence.');Evidence.ReviewerDecision(j)=upper(Review.ReviewerDecision(i));Evidence.EvidenceReviewRowKey(j)=Review.RowKey(i);
 Evidence.ReviewEvidenceType(j)=Review.EvidenceType(i);Evidence.ReviewSourceURL(j)=Review.SourceURL(i);Evidence.ReviewSourceDocumentPath(j)=Audit.ResolvedSourcePath(i);Evidence.ReviewSourceSHA256(j)=Audit.ActualSourceSHA256(i);
 Evidence.ReviewSourceLocation(j)=Review.SourceLocation(i);Evidence.ReviewerName(j)=Review.ReviewerName(i);Evidence.ReviewDateISO(j)=Review.ReviewDateISO(i);Evidence.ReviewNote(j)=Review.ReviewNote(i);
 if Audit.Accepted(i)&&upper(Review.ReviewerDecision(i))=="ACCEPT",Evidence.AdjudicatedValue(j)=Review.ReviewedValue(i);Evidence.AdjudicationStatus(j)="VERIFIED_EXTERNAL_SOURCE";
 elseif Audit.Accepted(i)&&upper(Review.ReviewerDecision(i))=="NOT_APPLICABLE",Evidence.AdjudicatedValue(j)="NOT_APPLICABLE";Evidence.AdjudicationStatus(j)="NOT_APPLICABLE";
 elseif upper(Review.ReviewerDecision(i))=="REJECT",Evidence.AdjudicationStatus(j)="REJECTED_EXTERNAL_REVIEW";end
end
caseIDs=unique(Evidence.MatchID,'stable');n=numel(caseIDs);MatchID=caseIDs;IdentityVerified=false(n,1);PublishedTargetVerified=false(n,1);CompleteTimelineVerified=false(n,1);
InitialAllocationsVerified=false(n,1);PenaltyConventionVerified=false(n,1);FirstInningsScoreBasisVerified=false(n,1);EventStateVerified=false(n,1);AllRequiredEvidenceResolved=false(n,1);
DescriptiveEligible=false(n,1);OperationalEligible=false(n,1);IndependentEligible=false(n,1);Disposition=strings(n,1);BlockingReasons=strings(n,1);
for i=1:n
 id=MatchID(i);IdentityVerified(i)=fieldVerified(Evidence,id,"Identity",U);PublishedTargetVerified(i)=fieldVerified(Evidence,id,"PublishedWinningTarget",U);
 CompleteTimelineVerified(i)=fieldVerified(Evidence,id,"CompleteTimeline",U);InitialAllocationsVerified(i)=fieldVerified(Evidence,id,"InitialAllocations",U);
 PenaltyConventionVerified(i)=fieldVerified(Evidence,id,"PenaltyConvention",U);FirstInningsScoreBasisVerified(i)=fieldVerified(Evidence,id,"FirstInningsScoreBasis",U);
 EventStateVerified(i)=fieldVerified(Evidence,id,"InningsIndex",U)&&fieldVerified(Evidence,id,"OversBowled",U)&&fieldVerified(Evidence,id,"Score",U)&&fieldVerified(Evidence,id,"WicketsLost",U);
 q=Evidence.MatchID==id;AllRequiredEvidenceResolved(i)=all(U.Resolved(Evidence.AdjudicationStatus(q)));
 DescriptiveEligible(i)=IdentityVerified(i)&&PublishedTargetVerified(i)&&CompleteTimelineVerified(i)&&InitialAllocationsVerified(i)&&PenaltyConventionVerified(i)&&FirstInningsScoreBasisVerified(i)&&EventStateVerified(i)&&AllRequiredEvidenceResolved(i);
 role=Roles(Roles.MatchID==id,:);assert(height(role)==1,'Role row missing or duplicated.');
 OperationalEligible(i)=DescriptiveEligible(i)&&~U.Bool(role.DevelopmentTrain)&&~U.Bool(role.DevelopmentValidation)&&~U.Bool(role.EmpiricalEstimation)&&~U.Bool(role.Tuning);
 b=strings(0,1);if ~IdentityVerified(i),b(end+1)="IDENTITY_UNVERIFIED";end;if ~PublishedTargetVerified(i),b(end+1)="TARGET_UNVERIFIED";end
 if ~CompleteTimelineVerified(i),b(end+1)="TIMELINE_UNVERIFIED";end;if ~InitialAllocationsVerified(i),b(end+1)="ALLOCATIONS_UNVERIFIED";end
 if ~PenaltyConventionVerified(i),b(end+1)="PENALTY_CONVENTION_UNVERIFIED";end;if ~FirstInningsScoreBasisVerified(i),b(end+1)="SCORE_BASIS_UNVERIFIED";end
 if ~EventStateVerified(i),b(end+1)="EVENT_STATE_UNVERIFIED";end;if ~AllRequiredEvidenceResolved(i),b(end+1)="REQUIRED_EVIDENCE_ROWS_UNRESOLVED";end
 b(end+1)="INDEPENDENT_EVALUATION_REQUIRES_LOCKED_TEMPORAL_TEST";BlockingReasons(i)=U.Join(b);
 if OperationalEligible(i),Disposition(i)="OPERATIONAL_COMPARISON_RELEASED_NOT_INDEPENDENT";elseif DescriptiveEligible(i),Disposition(i)="DESCRIPTIVE_ONLY_RELEASED";else,Disposition(i)="WITHHELD_PENDING_EVIDENCE";end
end
Endpoint=table(MatchID,IdentityVerified,PublishedTargetVerified,CompleteTimelineVerified,InitialAllocationsVerified,PenaltyConventionVerified,FirstInningsScoreBasisVerified,EventStateVerified,AllRequiredEvidenceResolved,DescriptiveEligible,OperationalEligible,IndependentEligible,Disposition,BlockingReasons);
DescriptiveCases=MatchID(DescriptiveEligible);OperationalCases=MatchID(OperationalEligible);
end

function tf=fieldVerified(E,id,field,U)
q=E.MatchID==id&E.Field==field;tf=any(q)&&all(U.Verified(E.AdjudicationStatus(q)));
end

