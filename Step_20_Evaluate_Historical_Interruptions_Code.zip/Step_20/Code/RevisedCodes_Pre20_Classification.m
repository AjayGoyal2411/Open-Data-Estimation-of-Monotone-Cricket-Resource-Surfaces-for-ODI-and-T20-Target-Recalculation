function [I,Audit]=RevisedCodes_Pre20_Classification(c,J)
U=RevisedCodes_Pre20_Utils;V=RevisedCodes_17D_Utils;
E=U.Read(fullfile(c.Inputs,'17C_EligibleInnings.csv'));E.Date=V.Date(E.Date);
assert(height(E)==numel(unique(E.MatchID)),'Expected one first innings per match.');
assert(all(E.Date<datetime(2023,1,1)),'Classification scope must remain pre-2023.');
n=height(E);cls=repmat("unclassified",n,1);reason=cls;verified=false(n,1);paths=strings(n,1);hashes=paths;events=paths;
for k=1:n
 [d,p,why]=U.Raw(J,E.MatchID(k));paths(k)=p;
 if why==""
  [cls(k),verified(k),reason(k)]=U.Classify(d,E.Format(k),E.Gender(k),E.Date(k));hashes(k)=U.Hash(p);
  if isfield(d,'info')&&isfield(d.info,'event')&&isfield(d.info.event,'name'),events(k)=string(d.info.event.name);end
 else,reason(k)=why;end
 if mod(k,250)==0||k==n,fprintf('Competition source metadata %d/%d\n',k,n);end
end
I=E;I.InningsIndex=ones(n,1);I.Key=I.MatchID+"|1";I.CompetitionClass=cls;I.ClassVerified=verified;
I.EventClassificationStatus=repmat("pending",n,1);I.EventClassificationStatus(verified)="verified";
I.ClassificationSource=paths+"#info.team_type";I.EventName=events;
Audit=table(E.MatchID,E.Format,E.Gender,E.Date,cls,verified,reason,events,paths,hashes, ...
 'VariableNames',{'MatchID','Format','Gender','Date','CompetitionClass','Verified','Reason','EventName','SourcePath','SHA256'});
U.Write(I,fullfile(c.Report,'Pre20_ClassifiedInnings.csv'));U.Write(Audit,fullfile(c.Report,'Pre20_ClassificationEvidence.csv'));
U.Write(groupsummary(Audit,{'Format','Gender','CompetitionClass','Verified'}),fullfile(c.Report,'Pre20_ClassificationCoverage.csv'));
% Event map reflects only the classified development cohort, not all dates or formats.
keys=I.Format+"|"+I.Gender+"|"+I.EventName;[uk,~,g]=unique(keys);T=table;
for k=1:numel(uk)
 q=g==k;one=find(q,1);values=unique(cls(q&verified));ready=all(verified(q))&&numel(values)==1&&strlength(events(one))>0;
 value="unclassified";if ready,value=values(1);end
 t=table(I.EventName(one),I.Format(one),I.Gender(one),nnz(q),value,ready, ...
  'VariableNames',{'EventName','Format','Gender','DevelopmentMatches','CompetitionClass','UnanimousSourceMapping'});T=[T;t]; %#ok<AGROW>
end
U.Write(T,fullfile(c.Report,'Pre20_DevelopmentEventMapping.csv'));
end
