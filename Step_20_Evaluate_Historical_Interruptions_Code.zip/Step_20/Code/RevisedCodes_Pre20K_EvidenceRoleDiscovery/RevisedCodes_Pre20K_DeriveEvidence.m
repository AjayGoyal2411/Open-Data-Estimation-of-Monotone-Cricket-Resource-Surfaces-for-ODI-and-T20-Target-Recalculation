function [Draft,PromotionLog]=RevisedCodes_Pre20K_DeriveEvidence(J,Facts,U)
Draft=J.Evidence;
PromotionLog=table(strings(0,1),strings(0,1),strings(0,1),strings(0,1),strings(0,1), ...
 'VariableNames',{'MatchID','EventOrder','Field','Basis','Status'});
U.Require(Draft,["MatchID","EventOrder","Field","SubmittedValue","Status","EvidenceType","SourceURL","SourceLocation","ReviewNote"]);
% Promote only facts established by a hash-pinned Cricsheet record or an exact matched raw state.
for k=1:height(J.Cases)
 id=J.Cases.MatchID(k);f=find(Facts.MatchID==id,1);
 if U.Bool(J.Cases.IdentityVerified(k))&&~isempty(f)
  ix=Draft.MatchID==id&Draft.EventOrder=="0"&Draft.Field=="Identity";
  Draft=promote(Draft,ix,"CRICSHEET_RAW_RECORD",Facts,f,"Date, format and teams parsed from hash-pinned raw record.");
  PromotionLog=[PromotionLog;logRows(Draft,ix,"IDENTITY_RAW_RECORD")]; %#ok<AGROW>
 end
end
stateFields=["InningsIndex","OversBowled","Score","WicketsLost"];
for j=1:height(J.Events)
 if ~U.Bool(J.Events.RawStateUsable(j)),continue;end
 ix=J.Evidence.MatchID==J.Events.MatchID(j)&J.Evidence.EventOrder==J.Events.EventOrder(j)&ismember(J.Evidence.Field,stateFields);
 Draft.Status(ix)="SOURCE_VERIFIED";Draft.EvidenceType(ix)="CRICSHEET_DELIVERY_STATE";
 Draft.SourceURL(ix)="https://cricsheet.org/";
 Draft.SourceLocation(ix)="Hash-pinned raw state matched in Pre20J";
 Draft.ReviewNote(ix)="Exact innings, legal-ball state, score and wickets corroborated; this does not verify that an interruption occurred.";
 PromotionLog=[PromotionLog;logRows(Draft,ix,"EVENT_STATE_RAW_RECORD")]; %#ok<AGROW>
end
for k=1:height(Facts)
 if ~isfinite(Facts.TargetRuns(k)),continue;end
 id=Facts.MatchID(k);ix=Draft.MatchID==id&Draft.EventOrder=="0"&Draft.Field=="PublishedWinningTarget";
 if nnz(ix)==1&&U.Num(Draft.SubmittedValue(ix))==Facts.TargetRuns(k)
  Draft.Status(ix)="SOURCE_VERIFIED";Draft.EvidenceType(ix)="CRICSHEET_TARGET_FIELD";
  Draft.SourceURL(ix)="https://cricsheet.org/";Draft.SourceLocation(ix)="Raw second-innings target field; SHA256="+Facts.SHA256(k);
  Draft.ReviewNote(ix)="Winning target exactly matches the hash-pinned raw target field; operational method version remains separately unresolved.";
  PromotionLog=[PromotionLog;logRows(Draft,ix,"PUBLISHED_TARGET_RAW_RECORD")]; %#ok<AGROW>
 end
end
assert(height(Draft)==597,'Evidence row count changed.');
end

function T=promote(T,ix,type,Facts,f,note)
T.Status(ix)="SOURCE_VERIFIED";T.EvidenceType(ix)=type;T.SourceURL(ix)="https://cricsheet.org/";
T.SourceLocation(ix)="SHA256="+Facts.SHA256(f)+"; "+Facts.SourcePath(f);T.ReviewNote(ix)=note;
end
function L=logRows(T,ix,basis)
n=nnz(ix);L=table(T.MatchID(ix),T.EventOrder(ix),T.Field(ix),repmat(string(basis),n,1),T.Status(ix), ...
 'VariableNames',{'MatchID','EventOrder','Field','Basis','Status'});
end
