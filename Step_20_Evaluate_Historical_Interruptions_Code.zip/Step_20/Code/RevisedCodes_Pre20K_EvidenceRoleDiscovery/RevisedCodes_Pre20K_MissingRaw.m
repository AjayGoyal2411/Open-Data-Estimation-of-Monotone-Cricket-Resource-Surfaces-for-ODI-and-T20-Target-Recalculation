function Audit=RevisedCodes_Pre20K_MissingRaw(projectRoot,missingIDs,U)
roots=[fullfile(projectRoot,'JSONFiles'),fullfile(projectRoot,'ALLYAML'),fullfile(projectRoot,'clean_from_json'), ...
 fullfile(projectRoot,'clean_from_yaml'),fullfile(projectRoot,'final_retained_dataset')];
MatchID=strings(0,1);CandidatePath=strings(0,1);SHA256=strings(0,1);Extension=strings(0,1);Status=strings(0,1);
for i=1:numel(missingIDs)
 id=string(missingIDs(i));found=strings(0,1);
 for r=1:numel(roots)
  if ~isfolder(roots(r)),continue;end
  for ext=[".json",".yaml",".yml"]
   d=dir(fullfile(roots(r),'**',id+ext));for k=1:numel(d),found(end+1,1)=string(fullfile(d(k).folder,d(k).name));end %#ok<AGROW>
  end
 end
 found=unique(found,'stable');
 if isempty(found)
  MatchID(end+1,1)=id;CandidatePath(end+1,1)="";SHA256(end+1,1)="";Extension(end+1,1)="";Status(end+1,1)="NOT_FOUND_EXACT_ID"; %#ok<AGROW>
 else
  for k=1:numel(found)
   [~,~,ext]=fileparts(found(k));MatchID(end+1,1)=id;CandidatePath(end+1,1)=found(k);SHA256(end+1,1)=U.Hash(found(k));Extension(end+1,1)=string(ext);Status(end+1,1)="FOUND_REVIEW_REQUIRED"; %#ok<AGROW>
  end
 end
end
Audit=table(MatchID,CandidatePath,SHA256,Extension,Status);
end

