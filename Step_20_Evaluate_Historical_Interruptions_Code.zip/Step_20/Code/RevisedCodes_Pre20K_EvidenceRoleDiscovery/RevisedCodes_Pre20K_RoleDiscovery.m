function [Inventory,Draft]=RevisedCodes_Pre20K_RoleDiscovery(projectRoot,caseIDs,U)
base=fullfile(projectRoot,'paper_outputs_revisedcodes');assert(isfolder(base),'paper_outputs_revisedcodes missing.');
top=dir(base);top=top([top.isdir]);names=string({top.name});top=top(startsWith(lower(names),'step'));
Path=strings(0,1);SHA256=strings(0,1);SuggestedRole=strings(0,1);Rows=zeros(0,1);UniqueMatchIDs=zeros(0,1);CaseMatches=zeros(0,1);CaseHitIDs=strings(0,1);ReviewStatus=strings(0,1);
keywords=["membership","manifest","ledger","fold","history","influence","error","split","cohort","train","test","validation","sensitivity","bootstrap"];
for r=1:numel(top)
 root=fullfile(top(r).folder,top(r).name);files=dir(fullfile(root,'**','*.csv'));
 for k=1:numel(files)
  low=lower(string(files(k).name));if ~any(contains(low,keywords)),continue;end
  path=string(fullfile(files(k).folder,files(k).name));
  try
   f=fopen(path,'rt','n','UTF-8');if f<0,continue;end;c=onCleanup(@()fclose(f));h=string(fgetl(f));clear c;h=strrep(h,char(65279),'');
   cols=strip(erase(split(h,','),'"'));if ~any(cols=="MatchID"),continue;end
   ids=U.MatchIDs(path);hits=unique(ids(ismember(ids,caseIDs)),'stable');
   Path(end+1,1)=path;SHA256(end+1,1)=U.Hash(path);SuggestedRole(end+1,1)=roleFromPath(path);Rows(end+1,1)=numel(ids);UniqueMatchIDs(end+1,1)=numel(unique(ids));CaseMatches(end+1,1)=numel(hits);CaseHitIDs(end+1,1)=U.Join(hits);ReviewStatus(end+1,1)="CANDIDATE_REVIEW_REQUIRED"; %#ok<AGROW>
  catch err
   Path(end+1,1)=path;SHA256(end+1,1)="";SuggestedRole(end+1,1)=roleFromPath(path);Rows(end+1,1)=NaN;UniqueMatchIDs(end+1,1)=NaN;CaseMatches(end+1,1)=NaN;CaseHitIDs(end+1,1)="";ReviewStatus(end+1,1)="READ_FAILED: "+string(err.message); %#ok<AGROW>
  end
 end
end
Inventory=table(Path,SHA256,SuggestedRole,Rows,UniqueMatchIDs,CaseMatches,CaseHitIDs,ReviewStatus);
if ~isempty(Inventory),Inventory=sortrows(Inventory,{'SuggestedRole','Path'});end
allowed=["PREPROCESSING_SELECTION","EMPIRICAL_ESTIMATION","CONTEXT_HISTORY","TUNING","SENSITIVITY_ASSESSMENT","CONFIRMATION","FROZEN_REFIT","TEMPORAL_TEST"];
usable=Inventory.ReviewStatus=="CANDIDATE_REVIEW_REQUIRED"&ismember(Inventory.SuggestedRole,allowed);
Draft=table(Inventory.SuggestedRole(usable),Inventory.Path(usable),Inventory.SHA256(usable),repmat("PARTIAL",nnz(usable),1), ...
 'VariableNames',{'Role','Path','SHA256','CoverageStatus'});
end

function role=roleFromPath(path)
s=lower(string(path));role="UNCLASSIFIED";
if contains(s,'step08')||contains(s,'step8'),role="PREPROCESSING_SELECTION";
elseif contains(s,'step09'),role="CONTEXT_HISTORY";
elseif contains(s,'step10')||contains(s,'step11')||contains(s,'step12'),role="EMPIRICAL_ESTIMATION";
elseif contains(s,'step13')||contains(s,'step14'),role="TUNING";
elseif contains(s,'step15')||contains(s,'step16'),role="CONFIRMATION";
elseif contains(s,'step17')||contains(s,'step18'),role="SENSITIVITY_ASSESSMENT";
elseif contains(s,'step19'),role="FROZEN_REFIT";
end
end
