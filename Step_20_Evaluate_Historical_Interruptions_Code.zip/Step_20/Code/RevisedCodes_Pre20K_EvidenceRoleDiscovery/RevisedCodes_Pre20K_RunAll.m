function Results=RevisedCodes_Pre20K_RunAll(settings)
% Evidence derivation and targeted role discovery only. No fitting or target calculation.
if nargin<1,settings=struct;end
assert(isstruct(settings)&&isscalar(settings),'Settings must be scalar struct.');
assert(all(ismember(fieldnames(settings),{'ProjectRoot','VerifyFrozenFiles'})),'Unknown setting.');
c.ProjectRoot="D:\VihaanProject1";c.VerifyFrozenFiles=true;
for n=reshape(string(fieldnames(settings)),1,[]),c.(n)=settings.(n);end
c.ProjectRoot=string(c.ProjectRoot);assert(isfolder(c.ProjectRoot),'Project root missing.');
assert(isscalar(c.VerifyFrozenFiles)&&islogical(c.VerifyFrozenFiles),'VerifyFrozenFiles must be logical.');
U=RevisedCodes_Pre20K_Utils;here=fileparts(mfilename('fullpath'));input=fullfile(here,'input');
M=U.Read(fullfile(input,'InputHashes.csv'));for k=1:height(M),p=fullfile(input,M.File(k));assert(U.Hash(p)==M.SHA256(k),'Packaged input changed.');end
base=fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','pre20k_evidence_role_discovery');if ~isfolder(base),mkdir(base);end
report=string(tempname(base));mkdir(report);work=string(tempname);mkdir(work);cleanupWork=onCleanup(@()safeRemove(work)); %#ok<NASGU>
diary(fullfile(report,'RunLog.txt'));cleanupDiary=onCleanup(@()diary('off')); %#ok<NASGU>
try
 Checks=RevisedCodes_Pre20K_SelfTests;U.Write(Checks,fullfile(report,'Pre20K_SelfTests.csv'));
 J=RevisedCodes_Pre20K_LoadPre20J(fullfile(input,'Pre20J_v3_Checks.zip'),work,U);
 if c.VerifyFrozenFiles
  for k=1:height(J.Frozen)
   assert(isfile(J.Frozen.Path(k)),'Frozen file missing: %s',J.Frozen.Path(k));
   assert(U.Hash(J.Frozen.Path(k))==J.Frozen.ExpectedSHA256(k),'Frozen file changed: %s',J.Frozen.Path(k));
  end
 end
 Facts=RevisedCodes_Pre20K_ParseRaw(J.RawDir,U);U.Write(Facts,fullfile(report,'Pre20K_RawCaseFacts.csv'));
 [EvidenceDraft,PromotionLog]=RevisedCodes_Pre20K_DeriveEvidence(J,Facts,U);
 U.Write(EvidenceDraft,fullfile(report,'Pre20K_ExternalEvidenceDraft.csv'));U.Write(PromotionLog,fullfile(report,'Pre20K_EvidencePromotionLog.csv'));
 missing=J.Cases.MatchID(~U.Bool(J.Cases.IdentityVerified));assert(numel(missing)==5,'Expected five unresolved raw identities.');
 MissingRaw=RevisedCodes_Pre20K_MissingRaw(c.ProjectRoot,missing,U);U.Write(MissingRaw,fullfile(report,'Pre20K_MissingRawAudit.csv'));
 [RoleInventory,RoleDraft]=RevisedCodes_Pre20K_RoleDiscovery(c.ProjectRoot,J.Cases.MatchID,U);
 U.Write(RoleInventory,fullfile(report,'Pre20K_RoleCandidateInventory.csv'));U.Write(RoleDraft,fullfile(report,'Pre20K_ExternalRoleManifestDraft.csv'));
 Requests=buildRequests(J,EvidenceDraft);U.Write(Requests,fullfile(report,'Pre20K_ExternalSourceRequests.csv'));
 verified=upper(EvidenceDraft.Status)=="SOURCE_VERIFIED";
 Summary=table(40,51,height(EvidenceDraft),nnz(verified),nnz(EvidenceDraft.Field=="Identity"&verified), ...
  nnz(EvidenceDraft.Field=="PublishedWinningTarget"&verified),height(PromotionLog),height(RoleInventory),nnz(MissingRaw.Status=="FOUND_REVIEW_REQUIRED"), ...
  'VariableNames',{'Cases','Events','EvidenceRows','RawBackedVerifiedRows','IdentitiesVerified','TargetsVerified','Promotions','RoleCandidates','MissingRawCandidatesFound'});
 U.Write(Summary,fullfile(report,'Pre20K_Summary.csv'));
 Gates=table(["Pre20J hardened inputs passed";"Frozen files unchanged";"Evidence row keys retained";"Unsupported timelines remain pending";"Step20 calculation authorized"], ...
  [true;~c.VerifyFrozenFiles||height(J.Frozen)==94;height(EvidenceDraft)==597;~any(EvidenceDraft.Field=="CompleteTimeline"&verified);false], ...
  'VariableNames',{'Gate','Passed'});U.Write(Gates,fullfile(report,'Pre20K_ExecutionGates.csv'));
 code=dir(fullfile(here,'*.m'));CodeHashes=table;
 for k=1:numel(code),CodeHashes=[CodeHashes;table(string(code(k).name),U.Hash(fullfile(code(k).folder,code(k).name)),'VariableNames',{'File','SHA256'})];end %#ok<AGROW>
 U.Write(CodeHashes,fullfile(report,'Pre20K_CodeHashes.csv'));
 Results=struct('Status',"LOCAL_EVIDENCE_DERIVED_EXTERNAL_REVIEW_REQUIRED",'Settings',c,'Summary',Summary,'Gates',Gates);
 save(fullfile(report,'RevisedCodes_Pre20K_Result.mat'),'Results');disp(Summary);disp(Gates);
 diary off;zip(report+"_Checks.zip",{'*'},report);fprintf('Upload %s\n',report+"_Checks.zip");
catch err
 diary off;zip(report+"_FAILED_Checks.zip",{'*'},report);fprintf('Upload %s\n',report+"_FAILED_Checks.zip");rethrow(err);
end
end

function R=buildRequests(J,E)
pending=~ismember(upper(E.Status),["SOURCE_VERIFIED","VERIFIED","CONFIRMED","VERIFIED_EXTERNAL_SOURCE","NOT_APPLICABLE"]);
q=E(pending,:);R=q(:,{'MatchID','EventOrder','Field','SubmittedValue','SourceURL','Status','ReviewNote'});
R.Priority=repmat("STANDARD",height(R),1);
R.Priority(ismember(R.Field,["CompleteTimeline","InitialAllocations","PublishedWinningTarget"]))="HIGH";
R.Priority(ismember(R.MatchID,J.Cases.MatchID(~ismember(upper(J.Cases.RawParseStatus),["JSON_PARSED_HASH_VERIFIED","YAML_IDENTITY_PARSED_HASH_VERIFIED"]))))="CRITICAL";
end
function safeRemove(path)
if isfolder(path),rmdir(path,'s');end
end

