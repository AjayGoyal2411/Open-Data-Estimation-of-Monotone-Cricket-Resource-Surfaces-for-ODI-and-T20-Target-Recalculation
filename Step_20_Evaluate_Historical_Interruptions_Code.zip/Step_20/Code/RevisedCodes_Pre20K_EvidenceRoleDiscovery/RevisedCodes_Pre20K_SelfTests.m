function Checks=RevisedCodes_Pre20K_SelfTests
U=RevisedCodes_Pre20K_Utils;
Check=["Exact ID matching";"Pending evidence not promoted";"NOT_APPLICABLE not verified";"Pinned checks hash deterministic";"Target equality is exact";"Missing case set fixed"];
Passed=false(6,1);Passed(1)=ismember("123",["123","0123"])&&~ismember("123",["1230"]);
Passed(2)="PENDING"~="SOURCE_VERIFIED";Passed(3)="NOT_APPLICABLE"~="SOURCE_VERIFIED";
p=fullfile(fileparts(mfilename('fullpath')),'input','Pre20J_v3_Checks.zip');Passed(4)=U.Hash(p)==U.Hash(p);
Passed(5)=double(171)==str2double("171")&&double(171)~=str2double("170");
Passed(6)=numel(unique(["1415752","1377016","1307163","1377012","1532480"]))==5;
Checks=table(Check,Passed);assert(all(Passed),'Pre20K self-test failed.');
end

