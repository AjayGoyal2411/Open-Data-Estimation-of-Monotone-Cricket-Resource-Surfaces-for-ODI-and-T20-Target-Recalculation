function Facts=RevisedCodes_Pre20K_ParseRaw(rawDir,U)
files=[dir(fullfile(rawDir,'*.json'));dir(fullfile(rawDir,'*.yaml'));dir(fullfile(rawDir,'*.yml'))];
n=numel(files);MatchID=strings(n,1);Format=strings(n,1);RawDate=strings(n,1);Teams=strings(n,1);
Method=strings(n,1);FirstInningsRuns=NaN(n,1);FirstInningsWickets=NaN(n,1);FirstInningsLegalBalls=NaN(n,1);
TargetRuns=NaN(n,1);TargetOvers=NaN(n,1);SHA256=strings(n,1);ParseStatus=strings(n,1);SourcePath=strings(n,1);
for k=1:n
 path=string(fullfile(files(k).folder,files(k).name));SourcePath(k)=path;[~,stem,ext]=fileparts(path);MatchID(k)=string(stem);SHA256(k)=U.Hash(path);
 try
  if strcmpi(ext,'.json')
   J=jsondecode(fileread(path)); info=J.info;
   RawDate(k)=firstText(info.dates);Format(k)=upper(string(info.match_type));Teams(k)=strjoin(string(info.teams),' | ');
   if isfield(info,'outcome')&&isfield(info.outcome,'method'),Method(k)=string(info.outcome.method);end
   innings=asCell(J.innings);
   if ~isempty(innings)
    [FirstInningsRuns(k),FirstInningsWickets(k),FirstInningsLegalBalls(k)]=inningsTotals(innings{1});
   end
   for z=1:numel(innings)
    I=innings{z};if isfield(I,'target')
     if isfield(I.target,'runs'),TargetRuns(k)=double(I.target.runs);end
     if isfield(I.target,'overs'),TargetOvers(k)=double(I.target.overs);end
    end
   end
   ParseStatus(k)="JSON_PARSED_HASHED";
  else
   txt=string(fileread(path));RawDate(k)=stripQuotes(capture(txt,'(?m)^\s{2}dates:\s*\r?\n\s*-\s*([^\r\n]+)'));
   Format(k)=upper(stripQuotes(capture(txt,'(?m)^\s{2}match_type:\s*([^\r\n]+)')));
   Method(k)=stripQuotes(capture(txt,'(?m)^\s{4}method:\s*([^\r\n]+)'));ParseStatus(k)="YAML_IDENTITY_PARSED_HASHED";
  end
 catch err
  ParseStatus(k)="PARSE_FAILED: "+string(err.message);
 end
end
Facts=table(MatchID,Format,RawDate,Teams,Method,FirstInningsRuns,FirstInningsWickets,FirstInningsLegalBalls,TargetRuns,TargetOvers,SHA256,ParseStatus,SourcePath);
end

function c=asCell(v)
if iscell(v),c=v;else,c=num2cell(v);end
end
function s=firstText(v)
if iscell(v),v=v{1};elseif numel(v)>1,v=v(1);end;s=string(v);
end
function s=capture(txt,pattern)
t=regexp(char(txt),pattern,'tokens','once');if isempty(t),s="";else,s=strtrim(string(t{1}));end
end
function s=stripQuotes(s)
c=char(s);if numel(c)>=2&&((c(1)==''''&&c(end)=='''')||(c(1)=='"'&&c(end)=='"')),s=string(c(2:end-1));end
end
function [runs,wickets,legal]=inningsTotals(I)
runs=0;wickets=0;legal=0;if ~isfield(I,'overs'),runs=NaN;wickets=NaN;legal=NaN;return;end
overs=asCell(I.overs);
for a=1:numel(overs)
 O=overs{a};deliveries=asCell(O.deliveries);
 for b=1:numel(deliveries)
  D=deliveries{b};runs=runs+double(D.runs.total);illegal=false;
  if isfield(D,'extras'),illegal=isfield(D.extras,'wides')||isfield(D.extras,'noballs');end
  if ~illegal,legal=legal+1;end
  if isfield(D,'wickets')
   W=asCell(D.wickets);
   for q=1:numel(W)
    kind=lower(string(W{q}.kind));if kind~="retired hurt",wickets=wickets+1;end
   end
  end
 end
end
end

