function J=RevisedCodes_Pre20K_LoadPre20J(zipPath,workDir,U)
assert(isfile(zipPath),'Pinned Pre20J checks archive missing.'); unzip(zipPath,workDir);
J.Summary=U.Read(fullfile(workDir,'Pre20J_Summary.csv'));
J.Gates=U.Read(fullfile(workDir,'Pre20J_ExecutionGates.csv'));
J.Tests=U.Read(fullfile(workDir,'Pre20J_SelfTests.csv'));
J.Cases=U.Read(fullfile(workDir,'Pre20J_CaseDisposition.csv'));
J.Events=U.Read(fullfile(workDir,'Pre20J_EventDisposition.csv'));
J.Evidence=U.Read(fullfile(workDir,'Pre20J_ExternalEvidenceReviewTemplate.csv'));
J.RawFacts=U.Read(fullfile(workDir,'Pre20J_RawFacts.csv'));
J.Frozen=U.Read(fullfile(workDir,'Pre20J_FrozenVerification.csv'));
assert(height(J.Cases)==40&&numel(unique(J.Cases.MatchID))==40,'Pre20J case count changed.');
assert(height(J.Events)==51,'Pre20J event count changed.');
assert(height(J.Evidence)==597,'Expected the hardened 597-row Pre20J evidence schema.');
assert(height(J.Tests)==7&&all(U.Bool(J.Tests.Passed)),'Pre20J seven-test gate did not pass.');
assert(all(U.Bool(J.Gates.Passed(1:4))),'A required Pre20J execution gate failed.');
assert(height(J.Frozen)==94&&all(U.Bool(J.Frozen.HashMatched)),'Pre20J frozen verification is incomplete.');
J.RawDir=fullfile(workDir,'input_snapshot','raw'); assert(isfolder(J.RawDir),'Pre20J raw snapshot missing.');
end

