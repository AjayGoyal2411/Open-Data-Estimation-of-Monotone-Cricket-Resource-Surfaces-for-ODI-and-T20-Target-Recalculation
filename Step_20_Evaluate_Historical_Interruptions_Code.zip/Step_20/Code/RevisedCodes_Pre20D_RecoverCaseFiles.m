function Results = RevisedCodes_Pre20D_RecoverCaseFiles(settings)
% Collect missing case-source files only. Does not fit or modify any model.
% MATLAB R2024b. Run from any folder; default project D:\VihaanProject1.
% Results = RevisedCodes_Pre20D_RecoverCaseFiles;
% Optional settings.Root and settings.SourceFolders (absolute folder paths).
% Linked IDs are candidate identities, NOT verified cases or reserved IDs.
if nargin == 0, settings = struct; end
assert(isstruct(settings) && isscalar(settings), 'settings must be a scalar struct.');
if ~isfield(settings,'Root'), settings.Root = 'D:\VihaanProject1'; end
root = string(settings.Root);
assert(isscalar(root) && isfolder(root), 'Project folder does not exist: %s',root);
ids = ["1415752";"1377016";"1307163";"1377012";"1532480"; ...
       "352665";"412685";"65272";"682961";"829807"];
if ~isfield(settings,'SourceFolders')
    sources = [fullfile(root,'JSONFiles');fullfile(root,'ALLYAML'); ...
        fullfile(root,'clean_from_json');fullfile(root,'clean_from_yaml')];
else
    sources = string(settings.SourceFolders(:));
end
assert(~isempty(sources) && ~any(ismissing(sources)), 'SourceFolders must contain folder paths.');
sources = unique(sources,'stable');
runFolder = string(tempname(char(root)));
mkdir(runFolder); mkdir(fullfile(runFolder,'reports')); mkdir(fullfile(runFolder,'raw'));
rawFolder = fullfile(runFolder,'raw');
report = fullfile(runFolder,'reports');
folders = table(sources,isfolder(sources),zeros(numel(sources),1), ...
    'VariableNames',{'SourceFolder','Exists','ExactCandidateFiles'});
files = table('Size',[0 11], ...
    'VariableTypes',repmat({'string'},1,11), ...
    'VariableNames',{'MatchID','SourcePath','CopiedRelativePath','Extension', ...
    'SHA256','CopySHA256','ContentStatus','RawDates','RawTeams','RawFormat','RawChaseTarget'});
seen = strings(0,1);
for s = 1:numel(sources)
    if ~folders.Exists(s), continue; end
    fprintf('Searching filenames in %s\n',sources(s));
    listing = dir(fullfile(sources(s),'**','*'));
    for j = 1:numel(listing)
        if listing(j).isdir, continue; end
        [~,stem,ext] = fileparts(listing(j).name);
        if ~ismember(lower(string(ext)),[".json",".yaml",".yml"]) || ~ismember(string(stem),ids)
            continue;
        end
        source = string(fullfile(listing(j).folder,listing(j).name));
        if ispc, key=lower(source); else, key=source; end
        if ismember(key,seen), continue; end
        seen(end+1,1)=key; %#ok<AGROW>
        folders.ExactCandidateFiles(s)=folders.ExactCandidateFiles(s)+1;
        destinationName = string(stem)+"__"+string(height(files)+1)+lower(string(ext));
        destination = fullfile(rawFolder,destinationName);
        sourceHash = hashFile(source);
        [ok,msg] = copyfile(char(source),char(destination));
        assert(ok,'Cannot copy %s: %s',source,msg);
        copiedHash = hashFile(destination);
        assert(sourceHash==copiedHash,'Copy hash differs for %s. No model was modified.',source);
        status="YAML_REQUIRES_PROJECT_PARSER";
        dates=""; teams=""; format=""; target="";
        if lower(string(ext))==".json"
            try
                obj=jsondecode(fileread(char(destination)));
                if ~isstruct(obj) || ~isfield(obj,'info') || ~isfield(obj,'innings')
                    status="JSON_SCHEMA_NOT_CRICSHEET";
                else
                    status="JSON_PARSED_ID_NOT_INDEPENDENTLY_VERIFIED";
                    if isfield(obj.info,'dates'), dates=join(string(obj.info.dates(:)),";"); end
                    if isfield(obj.info,'teams'), teams=join(string(obj.info.teams(:)),";"); end
                    if isfield(obj.info,'match_type'), format=string(obj.info.match_type); end
                    innings=obj.innings;
                    if numel(innings)>=2
                        if iscell(innings), chase=innings{2}; else, chase=innings(2); end
                        if isfield(chase,'target'), target=string(jsonencode(chase.target)); end
                    end
                end
            catch err
                status="JSON_PARSE_OR_METADATA_ERROR: "+string(err.message);
            end
        end
        files(end+1,:)={string(stem),source,"raw/"+destinationName,string(ext), ...
            sourceHash,copiedHash,status,dates,teams,format,target}; %#ok<AGROW>
    end
end
n=zeros(numel(ids),1); hashes=n; jsonFiles=n; yamlFiles=n;
for k=1:numel(ids)
    mask=files.MatchID==ids(k);
    n(k)=nnz(mask); hashes(k)=numel(unique(files.SHA256(mask)));
    jsonFiles(k)=nnz(mask & lower(files.Extension)==".json");
    yamlFiles(k)=nnz(mask & ismember(lower(files.Extension),[".yaml",".yml"]));
end
status=repmat("FILES_RECOVERED_REVIEW_PENDING",numel(ids),1);
status(n==0)="NOT_FOUND_IN_SEARCHED_FOLDERS";
status(n>1)="MULTIPLE_FILES_REVIEW_REQUIRED";
readiness=table(ids,n,jsonFiles,yamlFiles,hashes,status,false(numel(ids),1), ...
    false(numel(ids),1),'VariableNames',{'MatchID','FilesFound','JSONFiles','YAMLFiles', ...
    'DistinctContentHashes','RecoveryStatus','SourceReviewComplete','EvaluationEligible'});
writetable(folders,char(fullfile(report,'Pre20D_SearchFolders.csv')));
writetable(files,char(fullfile(report,'Pre20D_RecoveredFiles.csv')));
writetable(readiness,char(fullfile(report,'Pre20D_CaseRecovery.csv')));
notes=["Collection only: no source-review or evaluation eligibility is granted."; ...
    "Exact numeric filename stems are matched. Suffixes and partial matches are excluded."; ...
    "All matching versions are retained. Different JSON/YAML hashes do not alone mean disagreement."; ...
    "No existing pipeline inputs, models, allocations or reservation files were changed."; ...
    "The five formerly unmatched IDs require a split/confirmation/freeze overlap audit."; ...
    "Missing files are not evidence that a match is fictitious or unusable."; ...
    "Raw metadata may store only the final target, not every interruption." ];
fid=fopen(char(fullfile(report,'READ_ME.txt')),'w');
assert(fid>=0,'Cannot write recovery notes.');
closer=onCleanup(@()fclose(fid));
fprintf(fid,'%s\n',notes); clear closer;
zipPath=runFolder+"_Checks.zip";
zip(char(zipPath),{'reports','raw'},char(runFolder));
Results=struct('ReportFolder',report,'ChecksZip',zipPath,'Cases',readiness);
disp(readiness);
fprintf('Pre20D source recovery completed. Upload this file:\n%s\n',zipPath);
end

function value=hashFile(path)
fid=fopen(char(path),'rb');
assert(fid>=0,'Cannot read source file %s.',path);
closer=onCleanup(@()fclose(fid));
bytes=fread(fid,Inf,'*uint8'); clear closer;
md=java.security.MessageDigest.getInstance('SHA-256');
md.update(typecast(bytes(:),'int8'));
digest=typecast(md.digest(),'uint8');
value=string(lower(reshape(dec2hex(digest,2).',1,[])));
end
