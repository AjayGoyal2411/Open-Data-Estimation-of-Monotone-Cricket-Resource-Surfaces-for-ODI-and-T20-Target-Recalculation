function U=RevisedCodes_Pre20_Utils
U.Read=@readCSV;U.Write=@writeCSV;U.Index=@indexJSON;U.Raw=@readRaw;U.Classify=@classify;
U.Overs=@overs;U.Hash=@hashFile;U.Freeze=@freezeHashes;
end
function T=readCSV(p)
opts=detectImportOptions(p,'TextType','string','VariableNamingRule','preserve');
for n=["MatchID","ResolvedMatchID","CaseID","Key"]
 if ismember(n,string(opts.VariableNames)),opts=setvartype(opts,char(n),'string');end
end
T=readtable(p,opts);
end
function writeCSV(T,p)
assert(istable(T),'Expected table.');folder=fileparts(p);if ~isfolder(folder),mkdir(folder);end;writetable(T,p);
end
function J=indexJSON(root)
d=dir(fullfile(root,'**','*.json'));id=strings(numel(d),1);p=id;
for k=1:numel(d),[~,id(k)]=fileparts(d(k).name);p(k)=string(fullfile(d(k).folder,d(k).name));end
J=table(id,p,'VariableNames',{'MatchID','Path'});
end
function [d,p,reason]=readRaw(J,id)
p="";d=[];reason="";ix=find(J.MatchID==id);
if isempty(ix),reason="raw_json_missing";return;end
if numel(ix)>1
 hs=strings(numel(ix),1);for k=1:numel(ix),hs(k)=hashFile(J.Path(ix(k)));end
 if numel(unique(hs))>1,reason="conflicting_raw_json_copies";return;end
end
p=J.Path(ix(1));
try,d=jsondecode(fileread(p));catch,reason="invalid_json";end
end
function [cls,verified,reason]=classify(d,fmt,gender,date)
cls="unclassified";verified=false;reason="missing_info";
if ~isstruct(d)||~isfield(d,'info'),return;end;i=d.info;
required={'match_type','gender','dates','team_type'};
if ~all(isfield(i,required)),reason="required_metadata_missing";return;end
if upper(string(i.match_type))~=fmt,reason="format_conflict";return;end
U=RevisedCodes_17D_Utils;if U.Gender(i.gender)~=gender,reason="gender_conflict";return;end
try,dates=datetime(string(i.dates),'InputFormat','yyyy-MM-dd');catch,reason="invalid_raw_date";return;end
if ~any(dates==date),reason="date_conflict";return;end
kind=lower(strtrim(string(i.team_type)));
if ~isscalar(kind)||~ismember(kind,["international","club"]),reason="unsupported_team_type";return;end
cls=kind;verified=true;reason="explicit_source_team_type_identity_reconciled";
end
function n=overs(x)
% Split literal components; do not rely on optional regexp capture tokens.
% Preserve the shape of string/numeric inputs. Six-ball cricket only.
s=string(x);n=nan(size(s));
for k=1:numel(s)
 assert(~ismissing(s(k)),'Pre20:Overs','Missing cricket notation.');
 t=strtrim(s(k));
 assert(~isempty(regexp(char(t),'^[0-9]+([.][0-5])?$','once')), ...
  'Pre20:Overs','Invalid six-ball cricket notation: %s',t);
 pieces=split(t,".");whole=str2double(pieces(1));balls=0;
 if numel(pieces)==2,balls=str2double(pieces(2));end
 value=6*whole+balls;
 assert(isfinite(value)&&value<=flintmax,'Pre20:Overs','Cricket notation exceeds exact integer range.');
 n(k)=value;
end
end
function h=hashFile(p)
U=RevisedCodes_17D_Utils;h=U.Hash(p);
end
function T=freezeHashes(project)
d=dir(fullfile(project,'paper_outputs_revisedcodes','step19_final','frozen','**','*'));d=d(~[d.isdir]);
assert(~isempty(d),'Step19 frozen folder is missing.');T=table(strings(0,1),strings(0,1),'VariableNames',{'Path','SHA256'});
for k=1:numel(d),p=string(fullfile(d(k).folder,d(k).name));T=[T;table(p,hashFile(p),'VariableNames',T.Properties.VariableNames)];end %#ok<AGROW>
T=sortrows(T,'Path');
end
