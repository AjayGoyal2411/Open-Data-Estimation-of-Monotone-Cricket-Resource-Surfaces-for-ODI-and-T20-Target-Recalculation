function Results = RevisedCodes_20_RunAll(settings)
if nargin<1, settings=struct; end
C=RevisedCodes_20_Config(settings); U=RevisedCodes_20_Utils; here=fileparts(mfilename('fullpath'));
base=fullfile(C.ProjectRoot,'paper_outputs_revisedcodes','step20_complete'); if ~isfolder(base), mkdir(base); end
report=string(tempname(base)); mkdir(report); work=string(tempname); mkdir(work); cw=onCleanup(@()safeRemove(work)); %#ok<NASGU>
diary(fullfile(report,'RunLog.txt')); cdia=onCleanup(@()diary('off')); %#ok<NASGU>
try
    Tests=RevisedCodes_20_SelfTests; U.Write(Tests,fullfile(report,'Step20_SelfTests.csv'));
    D=RevisedCodes_20_Load(here,C,U,work); U.Write(D.Frozen,fullfile(report,'Step20_FrozenVerification.csv'));
    FrozenTests=RevisedCodes_20_FrozenSelfTests(C); U.Write(FrozenTests,fullfile(report,'Step20_FrozenSelfTests.csv'));
    [Descriptive,AuditD]=RevisedCodes_20_Predict(D.Descriptive,C,U);
    [Operational,AuditO]=RevisedCodes_20_Predict(D.Operational,C,U);
    assert(isequal(Operational.MatchID,D.Operational.MatchID));
    [Metrics,CI]=RevisedCodes_20_Analyse(Descriptive,Operational,C,U);
    U.Write(Descriptive,fullfile(report,'Step20_Descriptive_CaseResults.csv'));
    U.Write(Operational,fullfile(report,'Step20_Operational_CaseResults.csv'));
    U.Write(Metrics,fullfile(report,'Step20_PerformanceSummary.csv')); U.Write(CI,fullfile(report,'Step20_Bootstrap95CI.csv'));
    Audit=[addvars(AuditD,repmat("DESCRIPTIVE",height(AuditD),1),'Before',1,'NewVariableNames','Cohort'); ...
        addvars(AuditO,repmat("OPERATIONAL",height(AuditO),1),'Before',1,'NewVariableNames','Cohort')];
    U.Write(Audit,fullfile(report,'Step20_PredictionInterfaceAudit.csv'));
    FigureFiles=RevisedCodes_20_Figures(Descriptive,Operational,report,C); U.Write(FigureFiles,fullfile(report,'Step20_FigureManifest.csv'));
    Gate=["Accepted Pre20 package hash verified";"Pre20 descriptive gate passed";"Pre20 operational gate passed"; ...
        "Frozen 94-file boundary unchanged";"Twenty-nine descriptive cases analysed";"Fifteen operational cases analysed"; ...
        "No fitting or tuning in Step20";"Independent validation claim authorized"];
    Passed=[true;true;true;all(D.Frozen.Step20HashMatched);height(Descriptive)==29;height(Operational)==15;true;false];
    Gates=table(Gate,Passed); U.Write(Gates,fullfile(report,'Step20_ExecutionGates.csv'));
    Summary=table(29,15,nnz(strcmpi(Descriptive.Format,'ODI')),nnz(strcmpi(Descriptive.Format,'T20')), ...
        nnz(strcmpi(Operational.Format,'ODI')),nnz(strcmpi(Operational.Format,'T20')), ...
        nnz(Descriptive.CalculationTier=="STRICT_FINAL_STATE_RECONSTRUCTION"), ...
        nnz(Operational.CalculationTier=="STRICT_FINAL_STATE_RECONSTRUCTION"),0, ...
        'VariableNames',{'DescriptiveCases','OperationalCases','DescriptiveODI','DescriptiveT20','OperationalODI','OperationalT20', ...
        'DescriptiveStrictCases','OperationalStrictCases','IndependentCases'});
    U.Write(Summary,fullfile(report,'Step20_CohortSummary.csv'));
    writeNarrative(fullfile(report,'Step20_README_RESULTS.md'),Metrics,Summary);
    code=dir(fullfile(here,'*.m')); H=table; for k=1:numel(code), H=[H;table(string(code(k).name),U.Hash(fullfile(code(k).folder,code(k).name)),'VariableNames',{'File','SHA256'})]; end %#ok<AGROW>
    U.Write(H,fullfile(report,'Step20_CodeHashes.csv'));
    Results=struct('Status',"STEP20_COMPLETE_HISTORICAL_TARGET_COMPARISON",'Settings',C,'Summary',Summary, ...
        'Metrics',Metrics,'Gates',Gates,'ClaimBoundary',"NOT_INDEPENDENT_VALIDATION");
    save(fullfile(report,'RevisedCodes_Step20_Result.mat'),'Results'); disp(Summary); disp(Metrics); disp(Gates);
    diary off; zip(report+"_Checks.zip",{'*'},report); fprintf('Upload %s\n',report+"_Checks.zip");
catch err
    diary off; writeFailure(fullfile(report,'Step20_FAILURE.txt'),err,C);
    zip(report+"_FAILED_Checks.zip",{'*'},report); fprintf('Upload %s\n',report+"_FAILED_Checks.zip"); rethrow(err);
end
end

function writeNarrative(path,M,S)
f=fopen(path,'wt'); assert(f>=0); c=onCleanup(@()fclose(f)); a=M(M.Cohort=="DESCRIPTIVE"&M.Format=="ALL",:); o=M(M.Cohort=="OPERATIONAL"&M.Format=="ALL",:);
fprintf(f,'# Step 20 results\n\n'); fprintf(f,'The frozen Step19 model was applied without fitting or tuning.\n\n');
fprintf(f,'- Descriptive cohort: n=%d; MAE %.3f; RMSE %.3f; bias %.3f runs.\n',S.DescriptiveCases,a.MAE,a.RMSE,a.Bias);
fprintf(f,'- Operational subset: n=%d; MAE %.3f; RMSE %.3f; bias %.3f runs.\n',S.OperationalCases,o.MAE,o.RMSE,o.Bias);
fprintf(f,'- Strict final-state reconstruction subsets: descriptive n=%d; operational n=%d.\n',S.DescriptiveStrictCases,S.OperationalStrictCases);
fprintf(f,'- These are historical target-agreement results. Neither cohort is an independent validation sample.\n');
fprintf(f,'- Target agreement, arithmetic consistency, documented outcome agreement, and counterfactual fairness are distinct questions. Step20 addresses target agreement only.\n');
fprintf(f,'- Observed match winners do not establish an optimal counterfactual target.\n'); clear c
end

function writeFailure(path,err,C)
f=fopen(path,'wt'); if f<0, return; end; c=onCleanup(@()fclose(f));
fprintf(f,'Message: %s\nIdentifier: %s\nFrozenRoot: %s\n\nStack:\n',err.message,err.identifier,C.FrozenRoot);
for k=1:numel(err.stack), fprintf(f,'%s line %d\n',err.stack(k).name,err.stack(k).line); end; clear c
end

function safeRemove(p), if isfolder(p), rmdir(p,'s'); end, end
