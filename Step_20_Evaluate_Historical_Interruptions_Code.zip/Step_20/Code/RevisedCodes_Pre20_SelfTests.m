function Checks=RevisedCodes_Pre20_SelfTests
U=RevisedCodes_Pre20_Utils;
d=struct('info',struct('match_type','T20','gender','female','dates',{{'2020-01-02'}},'team_type','club'));
[cls,ok]=U.Classify(d,"T20","women",datetime(2020,1,2));assert(ok&&cls=="club");
[~,ok]=U.Classify(d,"T20","women",datetime(2020,1,3));assert(~ok);
d.info.team_type='international';[cls,ok]=U.Classify(d,"T20","women",datetime(2020,1,2));assert(ok&&cls=="international");
d.info=rmfield(d.info,'team_type');[~,ok]=U.Classify(d,"T20","women",datetime(2020,1,2));assert(~ok);
assert(isequal(U.Overs(["21.3","19.5","0.0"]),[129 119 0]),'Row conversion failed.');
assert(isequal(U.Overs(["21.3";"19.5";"0.0"]),[129;119;0]),'Column conversion failed.');
assert(isequal(U.Overs([21.3 19.5 0 20]),[129 119 0 120]),'Numeric JSON conversion failed.');
assert(isequal(U.Overs([" 21.3 ","20","00.0"]),[129 120 0]),'Literal component conversion failed.');
for bad=["-1","1.7","1.23","NaN","Inf","","1e2"]
 failed=false;try,U.Overs(bad);catch,failed=true;end;assert(failed,'Invalid notation was accepted.');
end
failed=false;try,U.Overs("21.6");catch,failed=true;end;assert(failed);
% Team-type classification never infers franchise ownership or event identity.
d.info.team_type='franchise';[~,ok]=U.Classify(d,"T20","women",datetime(2020,1,2));assert(~ok);
Checks=table(["Explicit club field";"Date conflict rejected";"Explicit international field"; ...
 "Missing field not guessed";"Cricket notation";"Invalid notation rejected";"Unsupported type not guessed";"Column shape preserved";"Numeric JSON notation";"Integer and whitespace notation";"Malformed notation rejected"], ...
 true(11,1),'VariableNames',{'Check','Passed'});disp(Checks);
end
