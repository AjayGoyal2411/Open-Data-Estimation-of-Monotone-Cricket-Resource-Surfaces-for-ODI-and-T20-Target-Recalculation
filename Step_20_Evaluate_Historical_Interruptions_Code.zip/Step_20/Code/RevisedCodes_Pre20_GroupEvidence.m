function RevisedCodes_Pre20_GroupEvidence(D,c)
% One row per innings. Descriptive variance and common-stratum mean contrasts.
U=RevisedCodes_Pre20_Utils;V=RevisedCodes_17D_Utils;
D.Date=V.Date(D.Date);D.Year=year(D.Date);D.DeliveryRuns=V.Number(D.DeliveryRuns);
D.RunsPerSixRetainedLegalStates=6*D.DeliveryRuns./D.CanonicalStates;
assert(all(isfinite(D.DeliveryRuns)&D.CanonicalStates>0)&&all(D.Date<datetime(2023,1,1)));
Summary=table;Variance=table;Adjusted=table;Cells=table;
for fmt=["ODI","T20"]
 for metric=["DeliveryRuns","RunsPerSixRetainedLegalStates"]
  T=D(D.Format==fmt,:);y=T.(metric);g=string(T.Gender);overall=mean(y);total=sum((y-overall).^2);between=0;within=0;
  for gender=["men","women"]
   a=y(g==gender);if isempty(a),continue;end
   between=between+numel(a)*(mean(a)-overall)^2;within=within+sum((a-mean(a)).^2);
   r=table(fmt,metric,gender,numel(a),mean(a),std(a),median(a),prctile(a,25),prctile(a,75), ...
    'VariableNames',{'Format','Metric','Gender','Innings','Mean','SD','Median','Q25','Q75'});Summary=[Summary;r]; %#ok<AGROW>
  end
  assert(abs(total-between-within)<1e-7*max(1,total),'Variance decomposition mismatch.');
  fraction=NaN;ratio=NaN;if total>0,fraction=between/total;end;if within>0,ratio=between/within;end
  r=table(fmt,metric,height(T),between,within,total,fraction,ratio, ...
   'VariableNames',{'Format','Metric','Innings','BetweenGenderSS','WithinGenderSS','TotalSS','BetweenFraction','BetweenToWithinRatio'});Variance=[Variance;r]; %#ok<AGROW>
  % Same calendar year and source-defined competition class, min two per gender.
  good=V.Logical(T.ClassVerified);keys=string(T.Year)+"|"+T.CompetitionClass;uk=unique(keys(good));
  men={};women={};weight=[];
  for k=1:numel(uk)
   q=good&keys==uk(k);a=y(q&g=="men");b=y(q&g=="women");use=numel(a)>=2&&numel(b)>=2;
   r=table(fmt,metric,uk(k),numel(a),numel(b),use, ...
    'VariableNames',{'Format','Metric','YearClass','MenInnings','WomenInnings','CommonSupport'});Cells=[Cells;r]; %#ok<AGROW>
   if use,men{end+1}=a;women{end+1}=b;weight(end+1)=numel(a)+numel(b);end %#ok<AGROW>
  end
  estimate=NaN;lo=NaN;hi=NaN;nm=0;nw=0;
  if ~isempty(weight)
   weight=weight/sum(weight);delta=cellfun(@mean,women)-cellfun(@mean,men);estimate=sum(weight.*delta);
   rs=RandStream('mt19937ar','Seed',c.Seed+21);v=zeros(c.BootstrapReplicates,1);
   for k=1:numel(men),nm=nm+numel(men{k});nw=nw+numel(women{k});end
   for b=1:numel(v)
    for k=1:numel(men)
     a=men{k};w=women{k};v(b)=v(b)+weight(k)*(mean(w(randi(rs,numel(w),numel(w),1)))-mean(a(randi(rs,numel(a),numel(a),1))));
    end
   end
   z=prctile(v,[2.5 97.5]);lo=z(1);hi=z(2);
  end
  r=table(fmt,metric,numel(weight),nm,nw,estimate,lo,hi, ...
   'VariableNames',{'Format','Metric','CommonYearClassStrata','MenInnings','WomenInnings', ...
   'WomenMinusMenStandardizedMean','CI95Low','CI95High'});Adjusted=[Adjusted;r]; %#ok<AGROW>
 end
end
U.Write(Summary,fullfile(c.Report,'Pre20_ScoringDistributions.csv'));
U.Write(Variance,fullfile(c.Report,'Pre20_BetweenWithinGender.csv'));
U.Write(Adjusted,fullfile(c.Report,'Pre20_CommonYearClassContrasts.csv'));
if isempty(Cells),Cells=table("No verified strata",'VariableNames',{'Status'});end
U.Write(Cells,fullfile(c.Report,'Pre20_CommonSupportCells.csv'));
end
