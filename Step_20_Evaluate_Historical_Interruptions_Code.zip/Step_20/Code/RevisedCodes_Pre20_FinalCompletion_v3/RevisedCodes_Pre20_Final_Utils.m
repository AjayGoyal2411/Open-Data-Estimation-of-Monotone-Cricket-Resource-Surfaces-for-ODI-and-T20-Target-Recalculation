function U=RevisedCodes_Pre20_Final_Utils
U.Read=@readCSV;U.Write=@writeCSV;U.Hash=@hashFile;U.Bool=@toLogical;
U.Verified=@isVerified;U.Require=@requireColumns;U.BallsToOvers=@ballsToOvers;
U.OversEqual=@oversEqual;U.ValidOvers=@validOvers;U.Join=@joinNonempty;
end

function T=readCSV(path)
assert(isfile(path),'Required file missing: %s',path);f=fopen(path,'rt','n','UTF-8');assert(f>=0);c=onCleanup(@()fclose(f));h=fgetl(f);clear c;
assert(ischar(h),'Empty CSV: %s',path);h=strrep(h,char(65279),'');names=strip(erase(split(string(h),','),'"'))';
o=delimitedTextImportOptions('NumVariables',numel(names));o.Delimiter=',';o.DataLines=[2 Inf];o.VariableNames=cellstr(names);o.VariableTypes=repmat({'string'},1,numel(names));o.ExtraColumnsRule='error';o.EmptyLineRule='skip';T=readtable(path,o);
assert(isequal(string(T.Properties.VariableNames),names),'Header changed: %s',path);for k=1:width(T),n=T.Properties.VariableNames{k};T.(n)=strtrim(string(T.(n)));T.(n)(ismissing(T.(n)))="";end
end

function writeCSV(T,path),assert(istable(T));writetable(T,path);end

function h=hashFile(path)
f=fopen(path,'rb');assert(f>=0,'Cannot hash %s',path);c=onCleanup(@()fclose(f));md=java.security.MessageDigest.getInstance('SHA-256');
while ~feof(f),b=fread(f,1048576,'*uint8');md.update(typecast(b,'int8'));end;h=lower(string(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[])));clear c
end

function x=toLogical(v)
if islogical(v),x=v;return;end;s=lower(strtrim(string(v)));assert(all(ismember(s,["0","1","false","true","yes","no"])));x=ismember(s,["1","true","yes"]);
end

function tf=isVerified(s),tf=ismember(upper(strtrim(string(s))),["SOURCE_VERIFIED","VERIFIED","CONFIRMED","VERIFIED_EXTERNAL_SOURCE"]);end

function requireColumns(T,names)
m=string(names);m=m(~ismember(m,string(T.Properties.VariableNames)));assert(isempty(m),'Missing columns: %s',strjoin(m,', '));
end

function s=ballsToOvers(b)
b=str2double(string(b));assert(isfinite(b)&&b>=0&&fix(b)==b);q=floor(b/6);r=mod(b,6);if r==0,s=string(q);else,s=string(q)+"."+string(r);end
end

function tf=oversEqual(a,b)
tf=oversToBalls(a)==oversToBalls(b);
end

function tf=validOvers(v)
try,oversToBalls(v);tf=true;catch,tf=false;end
end

function b=oversToBalls(v)
s=strtrim(string(v));parts=split(s,".");assert(numel(parts)>=1&&numel(parts)<=2&&parts(1)~="",'Invalid cricket overs: %s',s);
q=str2double(parts(1));assert(isfinite(q)&&q>=0&&fix(q)==q,'Invalid cricket overs: %s',s);
if numel(parts)==1,r=0;else,r=str2double(parts(2));assert(strlength(parts(2))==1&&isfinite(r)&&r>=0&&r<=5&&fix(r)==r,'Invalid cricket ball digit: %s',s);end
b=6*q+r;
end

function s=joinNonempty(v)
v=strtrim(string(v));v=v(~ismissing(v)&v~="");v=unique(v,'stable');if isempty(v),s="";else,s=strjoin(v,';');end
end
