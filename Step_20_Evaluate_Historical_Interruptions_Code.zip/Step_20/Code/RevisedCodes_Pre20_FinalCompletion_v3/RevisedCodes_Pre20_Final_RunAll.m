function Results=RevisedCodes_Pre20_Final_RunAll(settings)
if nargin<1,settings=struct;end;assert(isstruct(settings)&&isscalar(settings));assert(all(ismember(fieldnames(settings),{'ProjectRoot','VerifyFrozenFiles'})));
c.ProjectRoot="D:\VihaanProject1";c.VerifyFrozenFiles=true;for n=reshape(string(fieldnames(settings)),1,[]),c.(n)=settings.(n);end;c.ProjectRoot=string(c.ProjectRoot);assert(isfolder(c.ProjectRoot));
U=RevisedCodes_Pre20_Final_Utils;here=fileparts(mfilename('fullpath'));input=fullfile(here,'input');base=fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','pre20_final_completion');if ~isfolder(base),mkdir(base);end
report=string(tempname(base));mkdir(report);work=string(tempname);mkdir(work);cw=onCleanup(@()safeRemove(work));diary(fullfile(report,'RunLog.txt'));cdia=onCleanup(@()diary('off')); %#ok<NASGU>
try
 Tests=RevisedCodes_Pre20_Final_SelfTests;U.Write(Tests,fullfile(report,'Pre20_Final_SelfTests.csv'));D=RevisedCodes_Pre20_Final_Load(input,work,U);
 Frozen=D.Frozen;Frozen.FinalCurrentSHA256=strings(height(Frozen),1);Frozen.FinalHashMatched=false(height(Frozen),1);
 if c.VerifyFrozenFiles,for k=1:height(Frozen),assert(isfile(Frozen.Path(k)),'Frozen file missing: %s',Frozen.Path(k));Frozen.FinalCurrentSHA256(k)=U.Hash(Frozen.Path(k));Frozen.FinalHashMatched(k)=Frozen.FinalCurrentSHA256(k)==lower(Frozen.ExpectedSHA256(k));end;assert(all(Frozen.FinalHashMatched),'Frozen model changed.');else,Frozen.FinalCurrentSHA256(:)="NOT_RECHECKED";Frozen.FinalHashMatched=U.Bool(Frozen.Pre20MHashMatched);end
 U.Write(Frozen,fullfile(report,'Pre20_Final_FrozenVerification.csv'));
 [Cases,Events,Descriptive,Operational]=RevisedCodes_Pre20_Final_Release(D,U);U.Write(Cases,fullfile(report,'Pre20_Final_CaseDisposition.csv'));U.Write(Events,fullfile(report,'Pre20_Final_EventDisposition.csv'));U.Write(Descriptive,fullfile(report,'Pre20_Final_Step20_DescriptiveInput.csv'));U.Write(Operational,fullfile(report,'Pre20_Final_Step20_OperationalInput.csv'));
 assert(height(Descriptive)==29,'Expected 29 descriptive cases, obtained %d.',height(Descriptive));
 assert(height(Operational)==15,'Expected 15 operational cases, obtained %d.',height(Operational));
 assert(nnz(Events.Disposition=="EXCLUDED_INTERMEDIATE_EVENT")==8,'Expected eight excluded intermediate events.');
 assert(nnz(~Cases.DescriptiveEligible)==11,'Expected eleven excluded cases.');
 Independent=Descriptive([],:);U.Write(Independent,fullfile(report,'Pre20_Final_IndependentInput_LOCKED.csv'));
 Summary=table(40,51,nnz(Cases.DescriptiveEligible),height(Descriptive),nnz(Cases.OperationalEligible),height(Operational),nnz(Events.Disposition=="EXCLUDED_INTERMEDIATE_EVENT"),nnz(~Cases.DescriptiveEligible),0,'VariableNames',{'RegisteredCases','RegisteredEvents','DescriptiveCasesReleased','DescriptiveFinalEventsReleased','OperationalCasesReleased','OperationalFinalEventsReleased','IntermediateEventsExcluded','CasesExcluded','IndependentCasesReleased'});U.Write(Summary,fullfile(report,'Pre20_Final_Summary.csv'));
 Gate=["Pinned predecessor inputs verified";"Frozen 94-file boundary unchanged";"Raw target and final allocation matched";"Pre20 completed";"Step20 descriptive comparison authorized";"Step20 operational comparison authorized";"Independent validation authorized"];
 Passed=[true;all(Frozen.FinalHashMatched);all(Cases.RawTargetMatched(Cases.DescriptiveEligible)&Cases.FinalAllocationMatched(Cases.DescriptiveEligible));height(Descriptive)==29;height(Descriptive)==29;height(Operational)==15;false];Gates=table(Gate,Passed);U.Write(Gates,fullfile(report,'Pre20_Final_ExecutionGates.csv'));
 code=dir(fullfile(here,'*.m'));Hashes=table;for k=1:numel(code),Hashes=[Hashes;table(string(code(k).name),U.Hash(fullfile(code(k).folder,code(k).name)),'VariableNames',{'File','SHA256'})];end;U.Write(Hashes,fullfile(report,'Pre20_Final_CodeHashes.csv')); %#ok<AGROW>
 Results=struct('Status',"PRE20_COMPLETE_RAW_BACKED_FINAL_STATE_RELEASE",'Settings',c,'Summary',Summary,'Gates',Gates);save(fullfile(report,'RevisedCodes_Pre20_Final_Result.mat'),'Results');disp(Summary);disp(Gates);diary off;zip(report+"_Checks.zip",{'*'},report);fprintf('Upload %s\n',report+"_Checks.zip");
catch err,diary off;zip(report+"_FAILED_Checks.zip",{'*'},report);fprintf('Upload %s\n',report+"_FAILED_Checks.zip");rethrow(err);end
end
function safeRemove(p),if isfolder(p),rmdir(p,'s');end,end
