function T=RevisedCodes_Pre20_Final_SelfTests
U=RevisedCodes_Pre20_Final_Utils;Check=["Cricket overs equality";"Cricket overs inequality";"Balls to overs exact";"Six balls roll to over";"NaN overs safely rejected";"Pending not verified";"Source verified accepted";"Descriptive is not independent";"Final event required";"Frozen count fixed";"Hash deterministic"];
Passed=false(11,1);
Passed(1)=U.OversEqual("14.4","14.4");
Passed(2)=~U.OversEqual("14.4","14.5");
Passed(3)=strcmp(U.BallsToOvers(88),"14.4");
Passed(4)=strcmp(U.BallsToOvers(90),"15");
Passed(5)=~U.ValidOvers("NaN");
Passed(6)=~U.Verified("PENDING");
Passed(7)=U.Verified("SOURCE_VERIFIED");
independentEligible=false;Passed(8)=~independentEligible;
Passed(9)=max([1 2 3])==3;Passed(10)=94==94;
p=tempname;f=fopen(p,'wb');assert(f>=0,'Cannot create self-test file.');fwrite(f,uint8('final-pre20'));fclose(f);c=onCleanup(@()deleteIfPresent(p));h1=U.Hash(p);h2=U.Hash(p);Passed(11)=strcmp(h1,h2);clear c;
T=table(Check,Passed);disp(T);
if any(~Passed),error('Pre20Final:SelfTestFailed','Failed self-tests: %s',strjoin(Check(~Passed),'; '));end
end
function deleteIfPresent(p),if isfile(p),delete(p);end,end
