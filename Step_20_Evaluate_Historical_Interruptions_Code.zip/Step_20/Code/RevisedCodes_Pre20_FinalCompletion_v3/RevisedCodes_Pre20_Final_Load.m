function D=RevisedCodes_Pre20_Final_Load(inputDir,work,U)
M=U.Read(fullfile(inputDir,'InputHashes.csv'));for k=1:height(M),p=fullfile(inputDir,M.File(k));assert(U.Hash(p)==lower(M.SHA256(k)),'Packaged input changed: %s',M.File(k));end
names=["Pre20K_Checked.zip","Pre20L_Checked.zip","Pre20M_Checked.zip"];
for n=names,d=fullfile(work,erase(n,"_Checked.zip"));mkdir(d);unzip(fullfile(inputDir,n),d);end
k=fullfile(work,'Pre20K');l=fullfile(work,'Pre20L');m=fullfile(work,'Pre20M');
D.Evidence=U.Read(fullfile(k,'Pre20K_ExternalEvidenceDraft.csv'));D.Facts=U.Read(fullfile(k,'Pre20K_RawCaseFacts.csv'));
D.Roles=U.Read(fullfile(l,'Pre20L_CaseRoleMatrix.csv'));D.Frozen=U.Read(fullfile(m,'Pre20M_FrozenVerification.csv'));D.MGates=U.Read(fullfile(m,'Pre20M_ExecutionGates.csv'));
assert(height(D.Evidence)==597&&height(D.Facts)==35&&height(D.Roles)==40&&height(D.Frozen)==94,'Pinned input dimensions changed.');
assert(all(U.Bool(D.Frozen.Pre20MHashMatched)),'Pre20M frozen verification failed.');
end

