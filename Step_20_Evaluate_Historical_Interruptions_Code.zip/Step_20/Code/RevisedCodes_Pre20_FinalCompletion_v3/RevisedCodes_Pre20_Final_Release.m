function [CaseDisposition,EventDisposition,DescriptiveInput,OperationalInput]=RevisedCodes_Pre20_Final_Release(D,U)
E=D.Evidence;F=D.Facts;R=D.Roles;caseIDs=unique(E.MatchID,'stable');n=numel(caseIDs);
MatchID=caseIDs;RawAvailable=false(n,1);RawFinalTargetAvailable=false(n,1);IdentityVerified=false(n,1);PublishedTargetVerified=false(n,1);FinalEventStateVerified=false(n,1);RawTargetMatched=false(n,1);FinalAllocationMatched=false(n,1);DescriptiveEligible=false(n,1);OperationalEligible=false(n,1);ExclusionReason=strings(n,1);
for i=1:n
 id=MatchID(i);f=F(F.MatchID==id,:);RawAvailable(i)=height(f)==1&&contains(f.ParseStatus,"PARSED");IdentityVerified(i)=fieldVerified(E,id,"0","Identity",U);PublishedTargetVerified(i)=fieldVerified(E,id,"0","PublishedWinningTarget",U);
 orders=str2double(E.EventOrder(E.MatchID==id));finalOrder=max(orders);FinalEventStateVerified(i)=fieldVerified(E,id,string(finalOrder),"InningsIndex",U)&&fieldVerified(E,id,string(finalOrder),"OversBowled",U)&&fieldVerified(E,id,string(finalOrder),"Score",U)&&fieldVerified(E,id,string(finalOrder),"WicketsLost",U);
 if RawAvailable(i),RawFinalTargetAvailable(i)=isfinite(str2double(f.TargetRuns))&&U.ValidOvers(f.TargetOvers);end
 if RawAvailable(i)&&RawFinalTargetAvailable(i)
  FinalAllocationMatched(i)=U.OversEqual(value(E,id,string(finalOrder),"NewOversClaim"),f.TargetOvers);
  if PublishedTargetVerified(i),RawTargetMatched(i)=str2double(value(E,id,"0","PublishedWinningTarget"))==str2double(f.TargetRuns);end
 end
 DescriptiveEligible(i)=RawAvailable(i)&&RawFinalTargetAvailable(i)&&IdentityVerified(i)&&PublishedTargetVerified(i)&&FinalEventStateVerified(i)&&RawTargetMatched(i)&&FinalAllocationMatched(i);
 role=R(R.MatchID==id,:);assert(height(role)==1);OperationalEligible(i)=DescriptiveEligible(i)&&~U.Bool(role.DirectDevelopmentOverlap);
 b=strings(0,1);if ~RawAvailable(i),b(end+1)="RAW_RECORD_UNAVAILABLE";end;if RawAvailable(i)&&~RawFinalTargetAvailable(i),b(end+1)="RAW_FINAL_TARGET_UNAVAILABLE";end;if ~IdentityVerified(i),b(end+1)="IDENTITY_UNVERIFIED";end;if ~PublishedTargetVerified(i),b(end+1)="PUBLISHED_TARGET_UNVERIFIED";end;if ~FinalEventStateVerified(i),b(end+1)="FINAL_EVENT_STATE_UNVERIFIED";end;if RawFinalTargetAvailable(i)&&PublishedTargetVerified(i)&&~RawTargetMatched(i),b(end+1)="RAW_TARGET_MISMATCH";end;if RawFinalTargetAvailable(i)&&~FinalAllocationMatched(i),b(end+1)="FINAL_ALLOCATION_MISMATCH";end
 if DescriptiveEligible(i)&&~OperationalEligible(i),b(end+1)="DIRECT_DEVELOPMENT_OVERLAP_DESCRIPTIVE_ONLY";end;ExclusionReason(i)=U.Join(b);
end
CaseDisposition=table(MatchID,RawAvailable,RawFinalTargetAvailable,IdentityVerified,PublishedTargetVerified,FinalEventStateVerified,RawTargetMatched,FinalAllocationMatched,DescriptiveEligible,OperationalEligible,ExclusionReason);
DescriptiveInput=buildInput(MatchID(DescriptiveEligible),D,U);OperationalInput=buildInput(MatchID(OperationalEligible),D,U);
EventMatchID=strings(0,1);EventOrder=strings(0,1);IsFinalEvent=false(0,1);Disposition=strings(0,1);Reason=strings(0,1);
for i=1:n
 id=MatchID(i);orders=unique(E.EventOrder(E.MatchID==id&str2double(E.EventOrder)>0),'stable');last=max(str2double(orders));
 for o=reshape(orders,1,[])
  EventMatchID(end+1,1)=id;EventOrder(end+1,1)=o;IsFinalEvent(end+1,1)=str2double(o)==last; %#ok<AGROW>
  if DescriptiveEligible(i)&&IsFinalEvent(end),Disposition(end+1,1)="RELEASED_RAW_BACKED_FINAL_STATE";Reason(end+1,1)="";
  elseif DescriptiveEligible(i),Disposition(end+1,1)="EXCLUDED_INTERMEDIATE_EVENT";Reason(end+1,1)="INTERMEDIATE_ALLOCATION_NOT_VERIFIED_BY_RAW_FINAL_TARGET";
  else,Disposition(end+1,1)="EXCLUDED_CASE_EVIDENCE_GAP";Reason(end+1,1)=ExclusionReason(i);end %#ok<AGROW>
 end
end
EventDisposition=table(EventMatchID,EventOrder,IsFinalEvent,Disposition,Reason,'VariableNames',{'MatchID','EventOrder','IsFinalEvent','Disposition','Reason'});
end

function T=buildInput(ids,D,U)
E=D.Evidence;F=D.Facts;R=D.Roles;
MatchID=strings(0,1);Format=strings(0,1);RawDate=strings(0,1);Teams=strings(0,1);Method=strings(0,1);FirstInningsRuns=strings(0,1);FirstInningsWickets=strings(0,1);FirstInningsLegalBalls=strings(0,1);FirstInningsOvers=strings(0,1);PublishedTargetRuns=strings(0,1);PublishedTargetOvers=strings(0,1);FinalEventOrder=strings(0,1);InningsIndex=strings(0,1);OversBowled=strings(0,1);Score=strings(0,1);WicketsLost=strings(0,1);EventTypeSubmitted=strings(0,1);NewOversClaimSubmitted=strings(0,1);TargetRunsClaimSubmitted=strings(0,1);RawSHA256=strings(0,1);EvidenceTier=strings(0,1);DirectDevelopmentOverlap=false(0,1);SensitivityAssessment=false(0,1);IndependenceStatus=strings(0,1);AllowedUse=strings(0,1);
for i=1:numel(ids)
 id=ids(i);f=F(F.MatchID==id,:);r=R(R.MatchID==id,:);o=string(max(str2double(E.EventOrder(E.MatchID==id))));MatchID(end+1,1)=id;Format(end+1,1)=f.Format;RawDate(end+1,1)=f.RawDate;Teams(end+1,1)=f.Teams;Method(end+1,1)=f.Method;FirstInningsRuns(end+1,1)=f.FirstInningsRuns;FirstInningsWickets(end+1,1)=f.FirstInningsWickets;FirstInningsLegalBalls(end+1,1)=f.FirstInningsLegalBalls;FirstInningsOvers(end+1,1)=U.BallsToOvers(f.FirstInningsLegalBalls);PublishedTargetRuns(end+1,1)=f.TargetRuns;PublishedTargetOvers(end+1,1)=f.TargetOvers;FinalEventOrder(end+1,1)=o;InningsIndex(end+1,1)=value(E,id,o,"InningsIndex");OversBowled(end+1,1)=value(E,id,o,"OversBowled");Score(end+1,1)=value(E,id,o,"Score");WicketsLost(end+1,1)=value(E,id,o,"WicketsLost");EventTypeSubmitted(end+1,1)=value(E,id,o,"EventType");NewOversClaimSubmitted(end+1,1)=value(E,id,o,"NewOversClaim");TargetRunsClaimSubmitted(end+1,1)=value(E,id,o,"TargetRunsClaim");RawSHA256(end+1,1)=f.SHA256;EvidenceTier(end+1,1)="RAW_BACKED_FINAL_STATE";DirectDevelopmentOverlap(end+1,1)=U.Bool(r.DirectDevelopmentOverlap);SensitivityAssessment(end+1,1)=U.Bool(r.SensitivityAssessment);IndependenceStatus(end+1,1)=r.IndependenceStatus;AllowedUse(end+1,1)="DESCRIPTIVE_FINAL_STATE_TARGET_COMPARISON_NOT_INDEPENDENT"; %#ok<AGROW>
end
T=table(MatchID,Format,RawDate,Teams,Method,FirstInningsRuns,FirstInningsWickets,FirstInningsLegalBalls,FirstInningsOvers,PublishedTargetRuns,PublishedTargetOvers,FinalEventOrder,InningsIndex,OversBowled,Score,WicketsLost,EventTypeSubmitted,NewOversClaimSubmitted,TargetRunsClaimSubmitted,RawSHA256,EvidenceTier,DirectDevelopmentOverlap,SensitivityAssessment,IndependenceStatus,AllowedUse);
end

function tf=fieldVerified(E,id,o,f,U),q=E.MatchID==id&E.EventOrder==o&E.Field==f;tf=nnz(q)==1&&U.Verified(E.Status(q));end
function v=value(E,id,o,f),q=E.MatchID==id&E.EventOrder==o&E.Field==f;assert(nnz(q)==1,'Evidence key missing/duplicate: %s|%s|%s',id,o,f);v=E.SubmittedValue(q);end
