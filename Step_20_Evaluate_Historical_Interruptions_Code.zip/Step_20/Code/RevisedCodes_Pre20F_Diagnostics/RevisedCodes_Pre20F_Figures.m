function RevisedCodes_Pre20F_Figures(c,R)
% Diagnostics are exploratory; retain saved source tables for every plotted point.
f=figure('Visible','off','Color','w','Position',[80 80 1500 1000]);cl=onCleanup(@()close(f)); %#ok<NASGU>
t=tiledlayout(f,2,2,'TileSpacing','loose','Padding','loose');colors=[0 .45 .74;.85 .33 .10];
for panel=1:4
 ax=nexttile(t);hold(ax,'on');
 if panel==1,scope="PrimaryMen";mask="AllEligible";ttl='A. Primary men: all eligible full-wicket states';end
 if panel==2,scope="WomenTransfer";mask="AllEligible";ttl='B. Women: transfer of men''s models and scale';end
 if panel==3,scope="PrimaryMen";mask="CommonSupported";ttl='C. Primary men: common supported states';end
 if panel==4,scope="WomenTransfer";mask="CommonSupported";ttl='D. Women: common supported transfer states';end
 for k=1:2
  names=["Compact","Bernstein"];phases=["All","Early","Middle","Late"];
  A=R(R.Scope==scope&R.Mask==mask&R.Model==names(k)&R.Year==0,:);
  [ok,j]=ismember(phases,A.Phase);assert(all(ok));A=A(j,:);
  x=(1:4)'+(k-1.5)*.16;
  errorbar(ax,x,A.DeltaRMSE,A.DeltaRMSE-A.DeltaRMSELower95,A.DeltaRMSEUpper95-A.DeltaRMSE, ...
   'o','Color',colors(k,:),'LineWidth',1.3,'DisplayName',char(names(k)));
 end
 yline(ax,0,'k:','HandleVisibility','off');xlim(ax,[.5 4.5]);xticks(ax,1:4);xticklabels(ax,phases);
 ylabel(ax,'RMSE difference in runs (model minus baseline)');title(ax,ttl);grid(ax,'on');
 legend(ax,'Location','best','Interpreter','none');
end
title(t,{'Paired development comparisons at ten wickets in hand', ...
 'Negative differences favour the fitted model. Intervals are exploratory, not independent confirmation.'},'FontSize',12);
exportgraphics(f,fullfile(c.Figures,'Pre20F_PairedDiagnostics.pdf'),'ContentType','vector');
exportgraphics(f,fullfile(c.Figures,'Pre20F_PairedDiagnostics.png'),'Resolution',300);
savefig(f,fullfile(c.Figures,'Pre20F_PairedDiagnostics.fig'));
end
