function [R,Matches,Reproduction]=RevisedCodes_Pre20F_02_PairedValidation(c,D)
U=RevisedCodes_Pre20F_Utils;[scopes,masks]=U.Scopes(D);R=table;Matches=table;counter=0;
for maskName=["AllEligible","CommonSupported"]
 for model=["Compact","Bernstein"]
  for si=1:numel(scopes)
   for yr=[0 2020 2021 2022]
    for phase=["All","Early","Middle","Late"]
     q=masks{si};if yr>0,q=q&D.Year==yr;end
     if phase~="All",q=q&D.Phase==phase;end
     eligibleStates=nnz(q);eligibleMatches=numel(unique(D.MatchID(q)));
     if maskName=="CommonSupported",q=q&D.CommonSupported;end
     A=U.Aggregate(D(q,:),model);counter=counter+1;
     [dif,lo,hi,status]=U.Paired(A,c.BootstrapReplicates,c.Seed+counter);
     base=NaN(1,3);fit=base;
     if ~isempty(A)
      base=[sqrt(mean(A.BaselineMSE)),mean(A.BaselineMAE),mean(A.BaselineBias)];
      fit=[sqrt(mean(A.ModelMSE)),mean(A.ModelMAE),mean(A.ModelBias)];
     end
     direction="UNCERTAIN_OR_NO_INTERVAL";
     if isfinite(hi(1))&&hi(1)<0,direction="LOWER_RMSE_EXPLORATORY";end
     if isfinite(lo(1))&&lo(1)>0,direction="HIGHER_RMSE_EXPLORATORY";end
     role="EXPLORATORY_SUBGROUP_OR_MIXED_SCOPE";
     if scopes(si)=="PrimaryMen",role="PRIMARY_POPULATION_DEVELOPMENT_DIAGNOSTIC";end
     if scopes(si)=="WomenTransfer",role="TRANSFER_OF_MENS_MODEL_AND_SCALE";end
     row=table(model,maskName,scopes(si),yr,phase,eligibleMatches,eligibleStates,height(A),sum(A.States), ...
      eligibleMatches-height(A),eligibleStates-sum(A.States),base(1),fit(1),dif(1),lo(1),hi(1), ...
      base(2),fit(2),dif(2),lo(2),hi(2),base(3),fit(3),dif(3),lo(3),hi(3),status,direction,role, ...
      'VariableNames',{'Model','Mask','Scope','Year','Phase','EligibleMatches','EligibleStates','RetainedMatches','RetainedStates', ...
      'RemovedMatches','RemovedStates','BaselineRMSE','ModelRMSE','DeltaRMSE','DeltaRMSELower95','DeltaRMSEUpper95', ...
      'BaselineMAE','ModelMAE','DeltaMAE','DeltaMAELower95','DeltaMAEUpper95','BaselineBias','ModelBias', ...
      'DeltaBias','DeltaBiasLower95','DeltaBiasUpper95','IntervalStatus','RMSEDirection','AnalysisRole'});
     R=[R;row]; %#ok<AGROW>
     % Nonoverlapping year rows are enough to recreate every pooled estimate.
     if scopes(si)=="PooledAll"&&yr>0
      A.Model=repmat(model,height(A),1);A.Mask=repmat(maskName,height(A),1);A.Phase=repmat(phase,height(A),1);
      Matches=[Matches;A]; %#ok<AGROW>
     end
    end
   end
  end
  fprintf('Pre20F paired bootstrap complete: %s / %s\n',model,maskName);
 end
end
% Reproduce prior errors without relying on CSV row order.
E=U.Read(fullfile(c.Input,'Pre20E_FullWicketMatchErrors.csv'));Reproduction=table;
for model=["Compact","Bernstein"]
 old=E(startsWith(E.Model,model+"::"),:);
 new=Matches(Matches.Model==model&Matches.Mask=="AllEligible",:);
 oldKey=old.MatchID+"|"+old.Year+"|"+old.Phase;
 newKey=new.MatchID+"|"+string(new.Year)+"|"+new.Phase;
 assert(numel(unique(oldKey))==height(old)&&numel(unique(newKey))==height(new));
 [found,j]=ismember(newKey,oldKey);assert(all(found)&&height(new)==height(old),'Pre20E population changed.');
 delta=max(abs(new{:,{'States','ModelMSE','ModelMAE','ModelBias'}}- ...
  [U.Number(old.States(j)),U.Number(old.MSE(j)),U.Number(old.MAE(j)),U.Number(old.Bias(j))]),[],1);
 assert(all(delta<[0.5 1e-6 1e-7 1e-7]),'Pre20E model errors not reproduced.');
 old=E(E.Model=="B0_LinearBalls",:);oldKey=old.MatchID+"|"+old.Year+"|"+old.Phase;
 [found,j]=ismember(newKey,oldKey);assert(all(found)&&height(new)==height(old));
 db=max(abs(new{:,{'BaselineMSE','BaselineMAE','BaselineBias'}}- ...
  [U.Number(old.MSE(j)),U.Number(old.MAE(j)),U.Number(old.Bias(j))]),[],1);
 assert(all(db<[1e-6 1e-7 1e-7]),'Pre20E baseline errors not reproduced.');
 Reproduction=[Reproduction;table(model,height(new),delta(1),delta(2),delta(3),delta(4),max(db),true, ...
 'VariableNames',{'Model','MatchPhaseRows','MaxStateCountDifference','MaxMSEDifference','MaxMAEDifference', ...
 'MaxBiasDifference','MaxBaselineMetricDifference','Passed'})]; %#ok<AGROW>
end
U.Write(R,fullfile(c.Report,'Pre20F_PairedComparisons.csv'));
U.Write(Matches,fullfile(c.SourceData,'Pre20F_PairedMatchErrors.csv'));
U.Write(Reproduction,fullfile(c.Report,'Pre20F_Pre20E_Reproduction.csv'));
end
