function [Coverage,Composition]=RevisedCodes_Pre20F_03_SupportAndSubgroups(c,D)
U=RevisedCodes_Pre20F_Utils;[names,masks]=U.Scopes(D);Coverage=table;Composition=table;
for si=1:numel(names)
 for yr=[0 2020 2021 2022]
  for ph=["All","Early","Middle","Late"]
   q=masks{si};if yr>0,q=q&D.Year==yr;end
   if ph~="All",q=q&D.Phase==ph;end
   T=D(q,:);
   for field=["CompactSupported","BernsteinSupported","CommonSupported"]
    n=height(T);nm=numel(unique(T.MatchID));kept=nnz(T.(field));km=numel(unique(T.MatchID(T.(field))));
    frac=NaN;equal=NaN;
    if n>0
     frac=kept/n;[~,~,g]=unique(T.MatchID);equal=mean(accumarray(g,double(T.(field)))./accumarray(g,1));
    end
    Coverage=[Coverage;table(names(si),yr,ph,field,nm,n,km,kept,nm-km,n-kept,frac,equal, ...
    'VariableNames',{'Scope','Year','Phase','SupportDefinition','EligibleMatches','EligibleStates', ...
    'RetainedMatches','RetainedStates','RemovedMatches','RemovedStates','StateWeightedSupportedFraction', ...
    'EqualMatchSupportedFraction'})]; %#ok<AGROW>
   end
  end
 end
end
for yr=[0 2020 2021 2022]
 for gender=["men","women"]
  for cls=reshape(unique(D.CompetitionClass),1,[])
   q=D.Gender==gender&D.CompetitionClass==cls;if yr>0,q=q&D.Year==yr;end
   Composition=[Composition;table(yr,gender,cls,numel(unique(D.MatchID(q))),nnz(q), ...
    numel(unique(D.MatchID(q&D.PrimaryEligible))),all(D.ClassVerified(q))&&any(q), ...
    'VariableNames',{'Year','Gender','CompetitionClass','Matches','States','PrimaryEligibleMatches','ClassVerified'})]; %#ok<AGROW>
  end
 end
end
U.Write(Coverage,fullfile(c.Report,'Pre20F_SupportCoverage.csv'));
U.Write(Composition,fullfile(c.Report,'Pre20F_PopulationComposition.csv'));
end
