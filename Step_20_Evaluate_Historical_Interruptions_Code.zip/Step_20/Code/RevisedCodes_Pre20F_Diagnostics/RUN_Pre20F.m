% Run this script from the extracted RevisedCodes_Pre20F_Diagnostics folder.
ResultsPre20F=RevisedCodes_Pre20F_RunAll;
