function U=RevisedCodes_Pre20F_Utils
U.Read=@readCSV;U.Hash=@hashFile;U.Number=@number;U.Logical=@bool;
U.Date=@toDate;U.Gender=@gender;U.Canonical=@canonical;U.Freeze=@freeze;
U.Aggregate=@aggregate;U.Paired=@paired;U.Scopes=@scopes;U.Mask=@scopeMask;U.MatchKey=@matchKey;
U.Require=@require;U.Write=@write;
end
function T=readCSV(p)
f=fopen(p,'rt','n','UTF-8');assert(f>=0,'Cannot read %s.',p);
c=onCleanup(@()fclose(f));h=fgetl(f);clear c;
assert(ischar(h),'Empty CSV %s.',p);h=strrep(h,char(65279),'');
names=strip(erase(split(string(h),','),'"'))';
assert(numel(unique(names))==numel(names)&&all(strlength(names)>0),'Invalid header: %s',p);
o=delimitedTextImportOptions('NumVariables',numel(names));o.Delimiter=',';o.DataLines=[2 Inf];
o.VariableNames=cellstr(names);o.VariableTypes=repmat({'string'},1,numel(names));
o.ExtraColumnsRule='error';o.EmptyLineRule='skip';T=readtable(p,o);
assert(isequal(string(T.Properties.VariableNames),names),'Header changed in %s.',p);
end
function y=number(x)
if isnumeric(x),y=double(x);else,y=str2double(string(x));end
end
function v=bool(x)
if islogical(x),v=x;return;end
s=lower(strtrim(string(x)));assert(all(ismember(s,["0","1","false","true","yes","no"])), 'Unrecognized boolean CSV value.');
v=ismember(s,["1","true","yes"]);
end
function d=toDate(x)
if isdatetime(x),d=x;return;end
s=string(x);d=NaT(size(s));
for f=["dd-MMM-yyyy","yyyy-MM-dd","MM/dd/yyyy"]
 for j=find(isnat(d)&~ismissing(s)&s~="")'
  try,d(j)=datetime(s(j),'InputFormat',f);catch,end
 end
end
end
function g=gender(x)
g=lower(strtrim(string(x)));g(ismember(g,["male","m","mens","men's"]))="men";
g(ismember(g,["female","f","womens","women's"]))="women";g(ismissing(g)|g=="")="unknown";
end
function require(T,n)
m=string(n);m=m(~ismember(m,string(T.Properties.VariableNames)));assert(isempty(m),'Missing columns: %s',strjoin(m,', '));
end
function q=canonical(S)
require(S,["StateType","CorrectedIsLegalBall","BallsRemaining","WicketsInHand","DeliveryScoreBefore","FinalDeliveryRuns"]);
u=number(S.BallsRemaining);w=number(S.WicketsInHand);y=number(S.FinalDeliveryRuns)-number(S.DeliveryScoreBefore);
q=string(S.StateType)=="delivery"&number(S.CorrectedIsLegalBall)==1&isfinite(u)&u>0&u==floor(u)& ...
 isfinite(w)&w>0&w<=10&w==floor(w)&isfinite(y)&y>=0;
end
function h=hashFile(p)
f=fopen(p,'rb');assert(f>=0,'Cannot hash %s.',p);c=onCleanup(@()fclose(f)); %#ok<NASGU>
md=java.security.MessageDigest.getInstance('SHA-256');
while ~feof(f),b=fread(f,1048576,'*uint8');md.update(typecast(b,'int8'));end
h=lower(string(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[])));
end
function T=freeze(root)
d=dir(fullfile(root,'paper_outputs_revisedcodes','step19_final','frozen','**','*'));d=d(~[d.isdir]);
assert(~isempty(d),'Step19 frozen folder missing.');T=table(strings(0,1),strings(0,1),'VariableNames',{'Path','SHA256'});
for j=1:numel(d),p=string(fullfile(d(j).folder,d(j).name));T(end+1,:)={p,hashFile(p)};end
T=sortrows(T,'Path');
end
function write(T,p)
assert(istable(T),'Report must be a table.');writetable(T,p);
end
function key=matchKey(T)
key=string(T.MatchID)+"|"+string(T.Year);
end
function [names,masks]=scopes(D)
names=["PooledAll";"PrimaryMen";"WomenTransfer"];
masks={true(height(D),1);D.Gender=="men"&D.PrimaryEligible;D.Gender=="women"};
if any(D.Gender=="men"&~D.PrimaryEligible)
 names(end+1,1)="MenNonprimary";masks{end+1,1}=D.Gender=="men"&~D.PrimaryEligible;
end
for cls=reshape(unique(D.CompetitionClass),1,[])
 names(end+1,1)="Class:"+cls;masks{end+1,1}=D.CompetitionClass==cls;
 for gender=["men","women"]
  names(end+1,1)=gender+"/"+cls;masks{end+1,1}=D.Gender==gender&D.CompetitionClass==cls;
 end
end
end
function q=scopeMask(D,name)
[n,m]=scopes(D);j=find(n==name);assert(isscalar(j),'Unknown scope.');q=m{j};
end
function A=aggregate(T,model)
% One row per match; both errors use exactly the same states.
assert(ismember(model,["Compact","Bernstein"]),'Unexpected model.');
if isempty(T)
 A=table(strings(0,1),zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1),zeros(0,1), ...
 'VariableNames',{'MatchID','Year','States','BaselineMSE','ModelMSE','BaselineMAE','ModelMAE','BaselineBias','ModelBias'});return;
end
assert(all(isfinite(T.ObservedRemainingRuns)&isfinite(T.BaselinePrediction)&isfinite(T.(model+"Prediction"))));
key=T.MatchID+"|"+string(T.InningsIndex)+"|"+string(T.DeliverySeq);
assert(numel(unique(key))==height(T),'Duplicate state in paired analysis.');
[key,first,g]=unique(matchKey(T)); %#ok<ASGLU>
e0=T.BaselinePrediction-T.ObservedRemainingRuns;e1=T.(model+"Prediction")-T.ObservedRemainingRuns;
n=accumarray(g,1);ym=T.Year(first);assert(all(T.Year==ym(g)));
A=table(T.MatchID(first),ym,n,accumarray(g,e0.^2)./n,accumarray(g,e1.^2)./n, ...
 accumarray(g,abs(e0))./n,accumarray(g,abs(e1))./n,accumarray(g,e0)./n,accumarray(g,e1)./n, ...
 'VariableNames',{'MatchID','Year','States','BaselineMSE','ModelMSE','BaselineMAE','ModelMAE','BaselineBias','ModelBias'});
assert(numel(unique(A.MatchID))==height(A),'Match assigned to multiple years.');
end
function [point,lo,hi,status]=paired(A,B,seed)
% Columns: RMSE difference, MAE difference, signed bias difference.
point=NaN(1,3);lo=point;hi=point;status="NO_OBSERVATIONS";
if isempty(A),return;end
assert(numel(unique(matchKey(A)))==height(A),'Duplicate paired match keys.');
x=A{:,{'BaselineMSE','ModelMSE','BaselineMAE','ModelMAE','BaselineBias','ModelBias'}};
assert(all(isfinite(x),'all')&&all(x(:,1:4)>=0,'all'),'Invalid paired errors.');
point=delta(x);status="DESCRIPTIVE_NO_INTERVAL";
ys=unique(A.Year);groups=cell(numel(ys),1);
for j=1:numel(ys),groups{j}=find(A.Year==ys(j));end
% Singleton year strata have no within-year resampling information.
if height(A)<2||any(cellfun(@numel,groups)<2),return;end
stream=RandStream('mt19937ar','Seed',seed);v=zeros(B,3);
for b=1:B
 ix=zeros(height(A),1);pos=0;
 for j=1:numel(groups)
  a=groups{j};n=numel(a);ix(pos+(1:n))=a(randi(stream,n,n,1));pos=pos+n;
 end
 v(b,:)=delta(x(ix,:));
end
ci=quantile(v,[.025 .975],1);lo=ci(1,:);hi=ci(2,:);
status="EXPLORATORY_PAIRED_POINTWISE_CI";
if height(A)<20,status="SMALL_GROUP_EXPLORATORY_CI";end
end
function v=delta(x)
m=mean(x,1);v=[sqrt(m(2))-sqrt(m(1)),m(4)-m(3),m(6)-m(5)];
end
