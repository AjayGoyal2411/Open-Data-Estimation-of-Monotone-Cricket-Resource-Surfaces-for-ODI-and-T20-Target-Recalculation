function Checks=RevisedCodes_Pre20F_SelfTests
U=RevisedCodes_Pre20F_Utils;
T=table(["001";"001";"002";"002"],ones(4,1),[1;2;1;2],2020*ones(4,1), ...
 [10;10;10;10],[12;12;14;14],[11;11;12;12],[11;11;12;12], ...
 'VariableNames',{'MatchID','InningsIndex','DeliverySeq','Year','ObservedRemainingRuns', ...
 'BaselinePrediction','CompactPrediction','BernsteinPrediction'});
A=U.Aggregate(T,"Compact");[p,lo,hi]=U.Paired(A,500,1);
assert(abs(p(1)-(sqrt(2.5)-sqrt(10)))<1e-12&&p(1)<0&&all(isfinite([lo hi])));
assert(isequal(A,U.Aggregate(T([4 1 3 2],:),"Compact")),'Row order changed pairs.');
T.CompactPrediction=T.BaselinePrediction;A=U.Aggregate(T,"Compact");[p,lo,hi]=U.Paired(A,500,1);
assert(isequal(p,[0 0 0])&&isequal(lo,[0 0 0])&&isequal(hi,[0 0 0]));
Z=U.Aggregate(T([],:),"Compact");[p,lo,hi,status]=U.Paired(Z,500,1);
assert(all(isnan([p lo hi]))&&status=="NO_OBSERVATIONS");
[~,lo,hi]=U.Paired(A(1,:),500,1);assert(all(isnan([lo hi])));
B=A;B.Year=[2020;2021];[~,lo,hi]=U.Paired(B,500,1);assert(all(isnan([lo hi])));
B=T;B.BaselinePrediction(1)=NaN;mustFail(@()U.Aggregate(B,"Compact"));
B=[T;T(1,:)];mustFail(@()U.Aggregate(B,"Compact"));
% Unequal states: each innings retains equal weight.
B=T([1 2 3],:);B.CompactPrediction=[11;11;13];A=U.Aggregate(B,"Compact");
assert(abs(sqrt(mean(A.ModelMSE))-sqrt(5))<1e-12);
% Explicit text import must preserve numeric-looking IDs and comma paths.
pth=string(tempname)+".csv";cl=onCleanup(@()delete(pth)); %#ok<NASGU>
f=fopen(pth,'wt');fprintf(f,'MatchID,Path\n001,"D:\\folder,one\\x.mat"\n');fclose(f);
Q=U.Read(pth);assert(Q.MatchID=="001"&&Q.Path=="D:\folder,one\x.mat");
% Common support is intersection, never model-specific paired masks.
a=[true;false;true];b=[true;true;false];assert(isequal(a&b,[true;false;false]));
Check=["Exact paired RMSE difference and sign";"Row-order invariance";"Identical-model zero intervals"; ...
 "Empty and singleton groups";"Singleton year strata disclosed";"Nonfinite errors rejected"; ...
 "Duplicate states rejected";"Equal-innings weighting";"CSV IDs and comma paths";"Common-support intersection"];
Checks=table(Check,true(numel(Check),1),'VariableNames',{'Check','Passed'});disp(Checks);
end
function mustFail(f)
failed=false;try,f();catch,failed=true;end
assert(failed,'Expected invalid input rejection.');
end
