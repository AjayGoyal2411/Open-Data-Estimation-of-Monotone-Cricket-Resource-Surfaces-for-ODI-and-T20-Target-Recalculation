function [D,Scale,Training,Audit,Sources]=RevisedCodes_Pre20F_01_ScopeAndScaleAudit(c)
% Read existing fold models. No fitting or scale recalibration.
U=RevisedCodes_Pre20F_Utils;
V=RevisedCodes_15_16_Utils;I=V.Inputs();
assert(string(I.cfg.ProjectRoot)==string(c.ProjectRoot),'Model project root differs.');
c.StateManifest=string(fullfile(I.cfg.OutputRoot,'RevisedCodes_09_Result.mat'));c.Step19AuditFile="";
[C,M,Audit,Sources]=RevisedCodes_Pre20F_Data(c);
U.Require(M,["PrimaryModelEligible","CachedPrimaryStates"]);
M.PrimaryModelEligible=U.Logical(M.PrimaryModelEligible);
P=U.Read(fullfile(c.Input,'19_00_DevelopmentSelection.csv'));
r=P(P.Format=="T20"&P.Track=="Resource",:);assert(height(r)==1,'Ambiguous T20 selection.');
ids=["B0_LinearBalls";r.ProvisionalChoice;r.LowestRMSEModel];
assert(numel(unique(ids))==3&&startsWith(ids(2),"Compact::")&&startsWith(ids(3),"Bernstein::"), ...
 'This audit expects the documented baseline, compact and Bernstein specifications.');
Scale=table;Training=table;D=table;
for yr=2020:2022
 pkg="Fold_"+string(yr)+"_T20";j=find(string(I.Empirical.Packages.PackageID)==pkg);assert(isscalar(j),'Missing empirical fold.');
 pr=I.Empirical.Packages(j,:);z=load(pr.Path,'Surface');S=z.Surface;L=S.TrainingLedger;
 U.Require(L,["MatchID","InningsIndex","DeliveryRuns","Date"]);
 key=string(L.MatchID)+"|"+string(U.Number(L.InningsIndex));
 assert(numel(unique(key))==height(L),'Duplicate training innings.');
 [ok,k]=ismember(key,M.Key);assert(all(ok),'Training ledger missing from eligibility snapshot.');
 cutoff=datetime(yr,1,1);
 assert(pr.TrainingCutoffExclusive==cutoff&&S.TrainingCutoffExclusive==cutoff,'Fold cutoff mismatch.');
 assert(all(U.Date(L.Date)<cutoff)&all(M.Date(k)==U.Date(L.Date)),'Training dates invalid.');
 assert(all(M.Format(k)=="T20"&M.PrimaryModelEligible(k)&~U.Logical(M.CaseStudyReserved(k))), ...
 'Training scope differs from documented primary nonreserved T20 cohort.');
 assert(all(M.Gender(k)=="men"),'Primary training population is not exclusively men; investigate before interpreting transfer.');
 totals=U.Number(L.DeliveryRuns);assert(all(isfinite(totals)&totals>=0));
 assert(all(totals==U.Number(M.DeliveryRuns(k))),'Training totals disagree across ledgers.');
 mu=mean(totals);assert(isfinite(mu)&&mu>0);
 assert(abs(mu-S.FullStartMean)<=1e-9*max(1,mu),'Empirical scale is not its training-innings mean.');
 Training=[Training;table(repmat(pkg,height(L),1),key,M.MatchID(k),M.Gender(k),M.Date(k),totals, ...
 'VariableNames',{'PackageID','InningsKey','MatchID','Gender','Date','DeliveryRuns'})]; %#ok<AGROW>
 sel=find(M.CacheEligible(double(C.MetaRow))&M.Format(double(C.MetaRow))=="T20"& ...
 year(M.Date(double(C.MetaRow)))==yr&C.W==10);
 assert(~isempty(sel),'No assessment states.');mi=double(C.MetaRow(sel));u=double(C.U(sel));y=C.Outcome(sel);
 assert(all(M.Date(mi)>=cutoff&M.Date(mi)<datetime(yr+1,1,1)));
 assert(~any(ismember(M.Key(mi),key)),'Training-assessment overlap.');
 pred=zeros(numel(sel),3);supported=false(numel(sel),3);
 for a=1:3
  if a==1
   grid=(0:120)'/120;mask=true(121,1);scale=S.FullStartMean;
  else
   parts=split(ids(a),'::');if a==2,Q=I.Compact;else,Q=I.Flexible;end
   n=find(string(Q.Index.PackageID)==pkg&string(Q.Index.CandidateID)==parts(2));assert(isscalar(n),'Missing fitted candidate.');
   model=Q.Models{n};assert(model.Horizon==120&&isequal(size(model.Resource),[121 11]),'Invalid model grid.');
   grid=model.Resource(:,11);mask=logical(model.Supported(:,11));scale=model.FullStartMean;
   assert(all(isfinite(grid))&&abs(grid(1))<1e-8&&abs(grid(end)-1)<1e-8&&all(diff(grid)>=-1e-8), ...
    'Full-wicket boundary/order check failed.');
  end
  assert(isfinite(scale)&&scale>0&&abs(scale-mu)<=1e-9*max(1,mu),'Model scale differs from originating training mean.');
  pred(:,a)=grid(u+1)*scale;supported(:,a)=mask(u+1);
  for gender=["men","women"]
   available=M.CacheEligible&M.Format=="T20"&M.Gender==gender&M.Date<cutoff;
   nTrain=nnz(available);otherMu=NaN;if nTrain>0,otherMu=mean(U.Number(M.DeliveryRuns(available)));end
   aq=M.Gender(mi)==gender;role="PRIMARY_POPULATION_CHECK";if gender=="women",role="TRANSFER_OF_MENS_MODEL_AND_SCALE";end
   row=table(pkg,ids(a),cutoff,"men",height(L),mu,scale,gender,numel(unique(mi(aq))),nnz(aq), ...
    nTrain,otherMu,scale-otherMu,role,"DESCRIPTIVE_TRAINING_MEAN_NOT_A_REFITTED_MODEL", ...
    'VariableNames',{'PackageID','Model','TrainingCutoffExclusive','TrainingGender','FitInnings','RecomputedFitMean', ...
    'AppliedScale','AssessmentGender','AssessmentMatches','AssessmentStates','AvailableTrainingGenderInnings', ...
    'AvailableTrainingGenderMean','ScaleMinusAvailableGenderMean','AssessmentRole','GenderMeanInterpretation'});
   Scale=[Scale;row]; %#ok<AGROW>
  end
 end
 phase=repmat("Middle",numel(sel),1);phase(u>80)="Early";phase(u<=40)="Late";
 T=table(M.MatchID(mi),ones(numel(sel),1),C.DeliverySeq(sel),repmat(yr,numel(sel),1),M.Gender(mi), ...
  M.CompetitionClass(mi),M.ClassVerified(mi),M.PrimaryModelEligible(mi),u,y,phase,pred(:,1),pred(:,2),pred(:,3), ...
  supported(:,2),supported(:,3),supported(:,2)&supported(:,3), ...
  'VariableNames',{'MatchID','InningsIndex','DeliverySeq','Year','Gender','CompetitionClass','ClassVerified','PrimaryEligible', ...
  'BallsRemaining','ObservedRemainingRuns','Phase','BaselinePrediction','CompactPrediction','BernsteinPrediction', ...
  'CompactSupported','BernsteinSupported','CommonSupported'});
 D=[D;T]; %#ok<AGROW>
 fprintf('Pre20F %s: %d full-wicket states; verified training scale %.6f\n',pkg,height(T),mu);
 Sources=[Sources;table(string(pr.Path),U.Hash(pr.Path),'VariableNames',{'Path','SHA256'})]; %#ok<AGROW>
end
assert(all(isfinite(D{:,{'BaselinePrediction','CompactPrediction','BernsteinPrediction','ObservedRemainingRuns'}}),'all'));
keys=D.MatchID+"|"+string(D.InningsIndex)+"|"+string(D.DeliverySeq);
assert(numel(unique(keys))==height(D),'Duplicate assessment state keys.');
for p=reshape(string(I.Paths),1,[]),Sources=[Sources;table(p,U.Hash(p),'VariableNames',{'Path','SHA256'})];end %#ok<AGROW>
Sources=unique(Sources,'rows','stable');
U.Write(Scale,fullfile(c.Report,'Pre20F_ScaleAudit.csv'));
U.Write(Training,fullfile(c.Report,'Pre20F_TrainingMembership.csv'));
U.Write(Audit,fullfile(c.Report,'Pre20F_CanonicalObservationAudit.csv'));
U.Write(D,fullfile(c.SourceData,'Pre20F_StatePredictions.csv'));
U.Write(Sources,fullfile(c.Report,'Pre20F_SourceHashes.csv'));
end
