function Results=RevisedCodes_Pre20F_RunAll(settings)
% Read-only diagnostic extension to Pre20E. No fitting or case evaluation.
if nargin<1,settings=struct;end
assert(isstruct(settings)&&isscalar(settings),'Settings must be a scalar struct.');
c=struct('ProjectRoot',"D:\VihaanProject1",'BootstrapReplicates',2000,'Seed',200061,'MakeFigures',true);
for name=fieldnames(settings)'
 assert(isfield(c,name{1}),'Unknown setting %s.',name{1});c.(name{1})=settings.(name{1});
end
c.ProjectRoot=string(c.ProjectRoot);assert(isscalar(c.ProjectRoot)&&isfolder(c.ProjectRoot),'Missing project folder.');
validateattributes(c.BootstrapReplicates,{'numeric'},{'scalar','integer','>=',500});
validateattributes(c.Seed,{'numeric'},{'scalar','integer','>=',0,'<=',2^32-100000});
assert(islogical(c.MakeFigures)&&isscalar(c.MakeFigures),'MakeFigures must be logical.');
here=fileparts(mfilename('fullpath'));old=path;addpath(char(c.ProjectRoot));addpath(here,'-begin');cleanup=onCleanup(@()path(old)); %#ok<NASGU>
assert(exist('RevisedCodes_15_16_Utils','file')==2,'Existing Step15/16 utilities must be in the project root/on path.');
c.Input=fullfile(here,'input');c.EligibilityFile=fullfile(c.Input,'09_04_SensitivityEligibility.csv');
c.ClassificationFile=fullfile(c.Input,'Pre20C_ClassifiedInnings.csv');U=RevisedCodes_Pre20F_Utils;
H=U.Read(fullfile(c.Input,'InputHashes.csv'));
for j=1:height(H),assert(U.Hash(fullfile(c.Input,H.File(j)))==H.SHA256(j),'Packaged input changed: %s.',H.File(j));end
checks=RevisedCodes_Pre20F_SelfTests;before=U.Freeze(c.ProjectRoot);
parent=fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','pre20f_diagnostics');if ~isfolder(parent),mkdir(parent);end
c.Root=string(tempname(char(parent)));mkdir(c.Root);
c.Report=fullfile(c.Root,'reports');c.SourceData=fullfile(c.Root,'source_data');c.Figures=fullfile(c.Root,'figures');
mkdir(c.Report);mkdir(c.SourceData);mkdir(c.Figures);
U.Write(checks,fullfile(c.Report,'Pre20F_SelfTests.csv'));U.Write(before,fullfile(c.Report,'FrozenBefore.csv'));
fid=fopen(fullfile(c.Report,'Settings.json'),'wt');assert(fid>=0);fprintf(fid,'%s',jsonencode(c));fclose(fid);
diary(char(fullfile(c.Report,'ExecutionLog.txt')));diaryCleanup=onCleanup(@()diary('off')); %#ok<NASGU>
try
 [D,Scale,Training,Audit,Sources]=RevisedCodes_Pre20F_01_ScopeAndScaleAudit(c); %#ok<ASGLU>
 [Comparisons,Matches,Reproduction]=RevisedCodes_Pre20F_02_PairedValidation(c,D); %#ok<ASGLU>
 [Coverage,Composition]=RevisedCodes_Pre20F_03_SupportAndSubgroups(c,D);
 if c.MakeFigures,RevisedCodes_Pre20F_Figures(c,Comparisons);end
 after=U.Freeze(c.ProjectRoot);U.Write(after,fullfile(c.Report,'FrozenAfter.csv'));
 assert(isequal(before,after),'Frozen Step19 files changed.');
 Gate=["Packaged input hashes matched";"Self-tests passed";"Training population and scale traced"; ...
 "Development assessment years only";"Pre20E errors reproduced";"Frozen Step19 unchanged"];
 Passed=[true;all(checks.Passed);all(Scale.TrainingGender=="men");all(ismember(D.Year,[2020 2021 2022])); ...
 all(Reproduction.Passed);isequal(before,after)];Gates=table(Gate,Passed);assert(all(Passed));
 U.Write(Gates,fullfile(c.Report,'Pre20F_Gates.csv'));
 Code=table;files=dir(fullfile(here,'*.m'));
 for j=1:numel(files)
  p=string(fullfile(files(j).folder,files(j).name));Code=[Code;table(p,U.Hash(p),'VariableNames',{'Path','SHA256'})]; %#ok<AGROW>
 end
 U.Write(Code,fullfile(c.Report,'Pre20F_CodeHashes.csv'));
 copyfile(fullfile(c.Input,'InputHashes.csv'),fullfile(c.Report,'Pre20F_InputHashes.csv'));
 copyfile(fullfile(here,'INTERPRETATION.md'),fullfile(c.Report,'INTERPRETATION.md'));
 Results=struct('Status',"DIAGNOSTICS_COMPLETE_REVIEW_REQUIRED",'Root',c.Root,'Gates',Gates, ...
 'Comparisons',Comparisons,'ScaleAudit',Scale,'Coverage',Coverage,'Composition',Composition);
 Results.ChecksZip=c.Root+"_Checks.zip";
 save(fullfile(c.Root,'RevisedCodes_Pre20F_Result.mat'),'Results','-v7.3');
 disp(Gates);diary off;
 zip(char(Results.ChecksZip),{'reports','source_data','figures'},char(c.Root));
 fprintf('\nPre20F completed. Upload this ZIP:\n%s\n',Results.ChecksZip);
catch err
 fid=fopen(fullfile(c.Report,'FAILURE.txt'),'wt');
 if fid>=0,fprintf(fid,'%s',getReport(err,'extended','hyperlinks','off'));fclose(fid);end
 diary off;failure=c.Root+"_FAILED_Checks.zip";
 zip(char(failure),{'reports','source_data','figures'},char(c.Root));
 fprintf('\nRun failed. Upload diagnostics ZIP:\n%s\n',failure);rethrow(err);
end
end
