function Results=RevisedCodes_Pre20_RunAll(settings)
% One prerequisite run. Does not evaluate proposed case targets or open Step22.
if nargin<1,settings=struct;end
b=RevisedCodes_09_00_Config;
c=struct('ProjectRoot',string(b.ProjectRoot),'RawJSONRoot',string(fullfile(b.ProjectRoot,'JSONFiles')), ...
 'StateManifest',string(fullfile(b.OutputRoot,'RevisedCodes_09_Result.mat')), ...
 'EligibilityFile',"",'Step19AuditFile',"",'BootstrapReplicates',2000,'Seed',170019);
for f=fieldnames(settings)',assert(isfield(c,f{1}),'Unknown setting %s',f{1});c.(f{1})=settings.(f{1});end
assert(c.ProjectRoot==string(b.ProjectRoot),'Keep the configured project root.');
assert(isfolder(c.RawJSONRoot),'Raw JSON folder missing; set settings.RawJSONRoot.');
c.Inputs=string(fullfile(fileparts(mfilename('fullpath')),'pre20_inputs'));
assert(isfolder(c.Inputs),'Extract the whole ZIP, including pre20_inputs.');
c.Root=string(fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','pre20_preparation', ...
 ['run_' char(datetime('now','Format','yyyyMMdd_HHmmss_SSS'))]));
c.Report=fullfile(c.Root,'reports');mkdir(c.Report);mkdir(fullfile(c.Root,'case_raw'));mkdir(fullfile(c.Root,'case_states'));
U=RevisedCodes_Pre20_Utils;
checks=RevisedCodes_Pre20_SelfTests;U.Write(checks,fullfile(c.Report,'Pre20_SelfTests.csv'));
Before=U.Freeze(c.ProjectRoot);U.Write(Before,fullfile(c.Report,'Pre20_FrozenBefore.csv'));
% Verify committed freeze and runtime dependencies, before extracting reserved cases.
Frozen=RevisedCodes_19_LoadFrozen;assert(Frozen.PolicyFrozen,'Committed freeze required.');clear Frozen;
% Hash the executable package and immutable supplied claims before analysis.
files=[dir(fullfile(fileparts(mfilename('fullpath')),'RevisedCodes_Pre20_*.m')); ...
 dir(fullfile(fileparts(mfilename('fullpath')),'RevisedCodes_17D_*.m'));dir(fullfile(c.Inputs,'*.csv'))];
Dependencies=table;
for k=1:numel(files),p=string(fullfile(files(k).folder,files(k).name));Dependencies=[Dependencies;table(p,U.Hash(p),'VariableNames',{'Path','SHA256'})];end %#ok<AGROW>
U.Write(Dependencies,fullfile(c.Report,'Pre20_CodeAndInputHashes.csv'));
save(fullfile(c.Root,'Pre20_Protocol.mat'),'c','Dependencies','Before');
J=U.Index(c.RawJSONRoot);
[I,Classification]=RevisedCodes_Pre20_Classification(c,J);
CaseAudit=RevisedCodes_Pre20_Cases(c,J);
s=struct('ClassificationFile',fullfile(c.Report,'Pre20_ClassifiedInnings.csv'), ...
 'BootstrapReplicates',c.BootstrapReplicates,'Seed',c.Seed,'StateManifest',c.StateManifest);
if strlength(c.EligibilityFile)>0,s.EligibilityFile=c.EligibilityFile;end
if strlength(c.Step19AuditFile)>0,s.Step19AuditFile=c.Step19AuditFile;end
% New names keep the already-tested Step17C code and all frozen code intact.
Results=struct;Results.Gender=RevisedCodes_17D_RunAll(s);
D=U.Read(fullfile(Results.Gender.Config.Report,'17D_EligibleInnings.csv'));
assert(height(D)==height(I)&&all(ismember(D.MatchID,I.MatchID)),'Gender analysis cohort changed from audited Step17C.');
RevisedCodes_Pre20_GroupEvidence(D,c);
After=U.Freeze(c.ProjectRoot);assert(isequal(Before,After),'Step19 frozen bytes changed.');
U.Write(After,fullfile(c.Report,'Pre20_FrozenAfter.csv'));
Gates=table(["Competition metadata classified for every eligible innings";"Step19 frozen bytes unchanged"; ...
 "Reserved raw records extracted where available";"All supplied case timelines externally verified"; ...
 "DLS/VJD/modified-DL implementations certified";"2024+ general temporal test evaluated"], ...
 [all(Classification.Verified);true;any(CaseAudit.RawCopied);false;false;false], ...
 'VariableNames',{'Requirement','Passed'});U.Write(Gates,fullfile(c.Report,'Pre20_Readiness.csv'));
Results.Status="PREREQUISITES_RUN_CASE_AND_COMPARATOR_REVIEW_REQUIRED";Results.Classification=Classification;
Results.CaseAudit=CaseAudit;Results.Gates=Gates;Results.Root=c.Root;
U.Write(table(Results.Status,'VariableNames',{'Status'}),fullfile(c.Report,'Pre20_Status.csv'));
copyfile(c.Inputs,fullfile(c.Root,'supplied_inputs'));
copyfile(fullfile(c.ProjectRoot,'RevisedCodes_17D_Checks.zip'),fullfile(c.Root,'RevisedCodes_17D_Checks.zip'));
save(fullfile(c.Root,'RevisedCodes_Pre20_Result.mat'),'Results','c','-v7.3');
out=fullfile(c.ProjectRoot,'RevisedCodes_Pre20_Checks.zip');
zip(out,{'reports','case_raw','case_states','supplied_inputs','RevisedCodes_17D_Checks.zip'},c.Root);
fprintf('\nUpload %s\nThis is the evidence preparation run. Steps20 and21 will run together after source review.\n',out);
disp(Gates);
end
