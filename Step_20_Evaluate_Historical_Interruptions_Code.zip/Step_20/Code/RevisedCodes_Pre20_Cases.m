function Audit=RevisedCodes_Pre20_Cases(c,J)
U=RevisedCodes_Pre20_Utils;V=RevisedCodes_17D_Utils;identifierSelfTest;
L=U.Read(fullfile(c.Inputs,'09_03B_CaseLedger.csv'));
Q=U.Read(fullfile(c.Inputs,'Pre20_DocumentTimelineClaims.csv'));
C=U.Read(fullfile(c.Inputs,'Pre20_DocumentCaseClaims.csv'));
assert(numel(unique(L.CaseID))==40&&height(L)==40,'Expected registered forty-case ledger.');
assert(all(ismember(Q.CaseID,L.CaseID))&&isequal(C.CaseID,L.CaseID),'Claim/registration mismatch.');
n=height(L);paths=strings(n,1);hashes=paths;status=repmat("unresolved_identity",n,1);copied=false(n,1);
Metadata=table;
for j=1:n
 [id,idStatus]=caseIdentifier(L.ResolvedMatchID(j));
 if idStatus~="resolved",status(j)=idStatus;continue;end
 [d,p,why]=U.Raw(J,id);if why~="",status(j)=why;continue;end
 if ~isfield(d,'info'),status(j)="missing_raw_info";continue;end
 i=d.info;
 try
  dt=datetime(string(i.dates),'InputFormat','yyyy-MM-dd');expected=V.Date(L.SuppliedDate(j));
  teams=sort(string(i.teams(:)));want=sort([string(L.SuppliedTeam1(j));string(L.SuppliedTeam2(j))]);
  if ~any(dt==expected)||~isequal(teams,want)||upper(string(i.match_type))~=L.SuppliedFormat(j)
   status(j)="raw_identity_conflict";continue;
  end
 catch,status(j)="raw_identity_unreadable";continue;end
 paths(j)=p;hashes(j)=U.Hash(p);copyfile(p,fullfile(c.Root,'case_raw',id+".json"));copied(j)=true;status(j)="raw_identity_matched_timeline_review_pending";
 if isfield(d,'innings')
  for k=1:numel(d.innings)
   if iscell(d.innings),inn=d.innings{k};else,inn=d.innings(k);end
   target=NaN;allocation=NaN;penPre=0;penPost=0;method="";
   if isfield(inn,'target')
    if isfield(inn.target,'runs'),target=double(inn.target.runs);end
    if isfield(inn.target,'overs'),allocation=U.Overs(inn.target.overs);end
   end
   if isfield(inn,'penalty_runs')
    if isfield(inn.penalty_runs,'pre'),penPre=double(inn.penalty_runs.pre);end
    if isfield(inn.penalty_runs,'post'),penPost=double(inn.penalty_runs.post);end
   end
   if isfield(i,'outcome')&&isfield(i.outcome,'method'),method=string(i.outcome.method);end
   t=table(L.CaseID(j),id,k,target,allocation,penPre,penPost,method, ...
    'VariableNames',{'CaseID','MatchID','InningsIndex','RawTargetRuns','RawTargetBalls', ...
    'RawPenaltyPre','RawPenaltyPost','RawOutcomeMethod'});Metadata=[Metadata;t]; %#ok<AGROW>
  end
 end
end
% Cache point checks are consistency evidence, not independent timeline verification.
Q.CachePointMatched=false(height(Q),1);Q.CacheRowsAtBall=zeros(height(Q),1);
Q.CacheScoreCandidates=repmat("",height(Q),1);Q.CacheWicketsCandidates=repmat("",height(Q),1);
Q.InternalAllocationConflict=false(height(Q),1);Q.CacheFirstScoreMatchesDocument=false(height(Q),1);
for cid=unique(Q.CaseID)'
 a=find(Q.CaseID==cid);
 for k=2:numel(a)
  prev=a(1:k-1);prev=prev(Q.InningsIndex(prev)==Q.InningsIndex(a(k)));
  if ~isempty(prev),Q.InternalAllocationConflict(a(k))=Q.LegalBallsBowled(a(k))>Q.DocumentNewAllocationBalls(prev(end));end
 end
end
z=load(c.StateManifest,'Result');P=z.Result.Partitions;counts=zeros(n,1);parts=cell(n,1);
cols=["MatchID","InningsIndex","DeliverySeq","StateType","MatchDate","Format","Gender", ...
 "Team1","Team2","CaseReserved","LegalBallsBowled","BallsRemaining","WicketsInHand", ...
 "DeliveryScoreBefore","FinalDeliveryRuns","CorrectedIsLegalBall","GenuineDismissalsOnDelivery", ...
 "RetiredNotOutEvents","RecordIntegrityPassed"];
for k=1:height(P)
 z=load(P.Path(k),'States');S=z.States;[ok,j]=ismember(string(S.MatchID),string(L.ResolvedMatchID));
 for ix=unique(j(ok))'
  T=S(j==ix,:);assert(all(V.Logical(T.CaseReserved)),'Registered case unexpectedly not reserved. Stop for leakage review.');
  out=fullfile(c.Root,'case_states',L.CaseID(ix)+"_States.csv");
  names=cols(ismember(cols,string(T.Properties.VariableNames)));A=T(:,cellstr(names));
  if counts(ix)>0,A=[parts{ix};A];end
  parts{ix}=A;counts(ix)=counts(ix)+height(T);
  for row=find(Q.CaseID==L.CaseID(ix))'
   q=V.Number(T.InningsIndex)==Q.InningsIndex(row)&V.Number(T.LegalBallsBowled)==Q.LegalBallsBowled(row);
   Q.CacheRowsAtBall(row)=Q.CacheRowsAtBall(row)+nnz(q);
   score=V.Number(T.DeliveryScoreBefore(q));wickets=10-V.Number(T.WicketsInHand(q));
   Q.CachePointMatched(row)=Q.CachePointMatched(row)||any(score==Q.DocumentScore(row)&wickets==Q.DocumentWicketsLost(row));
   Q.CacheScoreCandidates(row)=strjoin(unique([Q.CacheScoreCandidates(row);string(score)]),";");
   Q.CacheWicketsCandidates(row)=strjoin(unique([Q.CacheWicketsCandidates(row);string(wickets)]),";");
   one=V.Number(T.InningsIndex)==1;
   if any(one),Q.CacheFirstScoreMatchesDocument(row)=all(V.Number(T.FinalDeliveryRuns(one))==C.DocumentFirstScore(ix));end
  end
 end
 if mod(k,24)==0,fprintf('Reserved case state extraction %d/%d\n',k,height(P));end
end
for ix=find(counts>0)'
 U.Write(parts{ix},fullfile(c.Root,'case_states',L.CaseID(ix)+"_States.csv"));
end
Audit=table(L.CaseID,L.ResolvedMatchID,copied,counts,status,paths,hashes,false(n,1), ...
 'VariableNames',{'CaseID','MatchID','RawCopied','CachedStateRows','Status','RawPath','SHA256','EvaluationEligible'});
U.Write(Audit,fullfile(c.Report,'Pre20_CaseExtractionAudit.csv'));
if isempty(Metadata)
 Metadata=table("No raw case metadata extracted",'VariableNames',{'Status'});
end
U.Write(Metadata,fullfile(c.Report,'Pre20_RawCaseMetadata.csv'));
U.Write(Q,fullfile(c.Report,'Pre20_CasePointReconciliation.csv'));
U.Write(L,fullfile(c.Report,'Pre20_RegisteredCases.csv'));
end

function [id,status]=caseIdentifier(value)
% Preserve literal IDs, including leading zeros. Never round or invent an ID.
id=string(value);assert(isscalar(id),'Expected one case identifier.');
status="unresolved_identity";
if ismissing(id),id="";return;end
id=strtrim(id);
if strlength(id)==0||any(strcmpi(id,["NaN","NaT","missing","<missing>","null","none","N/A","NA"]))
 id="";return;
end
if isempty(regexp(char(id),'^[0-9]+$','once'))
 status="invalid_identifier_review_required";id="";return;
end
status="resolved";
end
function identifierSelfTest
for value=["NaN","nan"," NaN ","","<missing>","NaT","N/A"]
 [id,status]=caseIdentifier(value);assert(id==""&&status=="unresolved_identity");
end
value=strings(1,1);value(1)=missing;
[id,status]=caseIdentifier(value);assert(id==""&&status=="unresolved_identity");
[id,status]=caseIdentifier("001072322");assert(id=="001072322"&&status=="resolved");
[id,status]=caseIdentifier("1072322");assert(id=="1072322"&&status=="resolved");
for value=["1072322.0","1.072322e6","../1072322","-1"]
 [id,status]=caseIdentifier(value);assert(id==""&&status=="invalid_identifier_review_required");
end
end
