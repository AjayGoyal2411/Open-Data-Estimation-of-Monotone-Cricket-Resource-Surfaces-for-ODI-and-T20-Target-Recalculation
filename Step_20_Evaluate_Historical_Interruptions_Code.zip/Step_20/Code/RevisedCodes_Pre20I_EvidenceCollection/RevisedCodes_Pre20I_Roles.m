function [Groups,Hits]=RevisedCodes_Pre20I_Roles(T,caseIDs)
% Group actual row roles without guessing that a filename certifies coverage.
U=RevisedCodes_Pre20I_Utils;U.Require(T,"MatchID");
ids=strtrim(string(T.MatchID));assert(all(~ismissing(ids)&strlength(ids)>0),'Missing membership IDs.');
assert(all(~cellfun(@isempty,regexp(cellstr(ids),'^\d+$','once'))),'Noncanonical membership IDs.');
role=repmat("UNSPECIFIED",height(T),1);fold=role;
if ismember('Role',T.Properties.VariableNames),role=string(T.Role);end
if ismember('FoldID',T.Properties.VariableNames),fold=string(T.FoldID);end
role(ismissing(role))="MISSING";fold(ismissing(fold))="MISSING";
keys=unique(table(fold,role,'VariableNames',{'FoldID','Role'}),'rows');Groups=table;
for j=1:height(keys)
 q=fold==keys.FoldID(j)&role==keys.Role(j);
 Groups=[Groups;table(keys.FoldID(j),keys.Role(j),nnz(q),numel(unique(ids(q))),nnz(ismember(unique(ids(q)),caseIDs)), ...
 'VariableNames',{'FoldID','Role','Rows','UniqueMatchIDs','CaseMatches'})]; %#ok<AGROW>
end
Hits=T(ismember(ids,caseIDs),:);
end
