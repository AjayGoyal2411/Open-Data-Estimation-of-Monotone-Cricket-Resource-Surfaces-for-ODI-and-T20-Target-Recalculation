function U=RevisedCodes_Pre20I_Utils
U.Read=@readCSV;U.Hash=@hashFile;U.Number=@number;U.Logical=@bool;
U.Date=@toDate;U.Gender=@gender;U.Canonical=@canonical;U.Freeze=@freeze;
U.Overs=@overs;U.Ready=@ready;
U.Require=@require;U.Write=@write;
end
function T=readCSV(p)
f=fopen(p,'rt','n','UTF-8');assert(f>=0,'Cannot read %s.',p);
c=onCleanup(@()fclose(f));h=fgetl(f);clear c;
assert(ischar(h),'Empty CSV %s.',p);h=strrep(h,char(65279),'');
names=strip(erase(split(string(h),','),'"'))';
assert(numel(unique(names))==numel(names)&&all(strlength(names)>0),'Invalid header: %s',p);
o=delimitedTextImportOptions('NumVariables',numel(names));o.Delimiter=',';o.DataLines=[2 Inf];
o.VariableNames=cellstr(names);o.VariableTypes=repmat({'string'},1,numel(names));
o.ExtraColumnsRule='error';o.EmptyLineRule='skip';T=readtable(p,o);
assert(isequal(string(T.Properties.VariableNames),names),'Header changed in %s.',p);
end
function y=number(x)
if isnumeric(x),y=double(x);else,y=str2double(string(x));end
end
function v=bool(x)
if islogical(x),v=x;return;end
s=lower(strtrim(string(x)));assert(all(ismember(s,["0","1","false","true","yes","no"])), 'Unrecognized boolean CSV value.');
v=ismember(s,["1","true","yes"]);
end
function d=toDate(x)
if isdatetime(x),d=x;return;end
s=string(x);d=NaT(size(s));
for f=["dd-MMM-yyyy","yyyy-MM-dd","MM/dd/yyyy"]
 for j=find(isnat(d)&~ismissing(s)&s~="")'
  try,d(j)=datetime(s(j),'InputFormat',f);catch,end
 end
end
end
function g=gender(x)
g=lower(strtrim(string(x)));g(ismember(g,["male","m","mens","men's"]))="men";
g(ismember(g,["female","f","womens","women's"]))="women";g(ismissing(g)|g=="")="unknown";
end
function require(T,n)
m=string(n);m=m(~ismember(m,string(T.Properties.VariableNames)));assert(isempty(m),'Missing columns: %s',strjoin(m,', '));
end
function q=canonical(S)
require(S,["StateType","CorrectedIsLegalBall","BallsRemaining","WicketsInHand","DeliveryScoreBefore","FinalDeliveryRuns"]);
u=number(S.BallsRemaining);w=number(S.WicketsInHand);y=number(S.FinalDeliveryRuns)-number(S.DeliveryScoreBefore);
q=string(S.StateType)=="delivery"&number(S.CorrectedIsLegalBall)==1&isfinite(u)&u>0&u==floor(u)& ...
 isfinite(w)&w>0&w<=10&w==floor(w)&isfinite(y)&y>=0;
end
function h=hashFile(p)
f=fopen(p,'rb');assert(f>=0,'Cannot hash %s.',p);c=onCleanup(@()fclose(f)); %#ok<NASGU>
md=java.security.MessageDigest.getInstance('SHA-256');
while ~feof(f),b=fread(f,1048576,'*uint8');md.update(typecast(b,'int8'));end
h=lower(string(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[])));
end
function T=freeze(root)
d=dir(fullfile(root,'paper_outputs_revisedcodes','step19_final','frozen','**','*'));d=d(~[d.isdir]);
assert(~isempty(d),'Step19 frozen folder missing.');T=table(strings(0,1),strings(0,1),'VariableNames',{'Path','SHA256'});
for j=1:numel(d),p=string(fullfile(d(j).folder,d(j).name));T(end+1,:)={p,hashFile(p)};end
T=sortrows(T,'Path');
end
function write(T,p)
assert(istable(T),'Report must be a table.');writetable(T,p);
end
function b=overs(x)
% Parse digits directly: no optional regexp capture groups or decimal rounding.
% Preserve row, column and matrix dimensions of the string input.
s=strtrim(string(x));b=NaN(size(s));
for j=1:numel(s)
 assert(~ismissing(s(j)),'Missing overs notation.');
 token=char(s(j));assert(~isempty(token),'Empty overs notation.');
 dots=find(token=='.');
 assert(numel(dots)<=1,'Invalid six-ball overs notation: %s.',s(j));
 balls=0;
 if isempty(dots)
  whole=token;
 else
  k=dots(1);
  assert(k>1&&k==numel(token)-1,'Expected whole overs and one ball digit: %s.',s(j));
  whole=token(1:k-1);digit=token(k+1);
  assert(digit>='0'&&digit<='5','Ball digit must be between 0 and 5: %s.',s(j));
  balls=double(digit)-double('0');
 end
 assert(all(whole>='0'&whole<='9'),'Invalid whole overs: %s.',s(j));
 wholeOvers=str2double(whole);value=6*wholeOvers+balls;
 assert(isfinite(value)&&value<=flintmax,'Overs exceed exact integer range.');
 b(j)=value;
end
end
function y=ready(rawOK,stateOK,arithmeticOK,sourceOK,allocationOK,timelineOK,independentOK)
y=rawOK&stateOK&arithmeticOK&sourceOK&allocationOK&timelineOK&independentOK;
end
