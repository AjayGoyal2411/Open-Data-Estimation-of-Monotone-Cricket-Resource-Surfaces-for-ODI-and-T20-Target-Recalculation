function Checks=RevisedCodes_Pre20I_SelfTests
U=RevisedCodes_Pre20I_Utils;assert(isequal(U.Overs(["21.3","19.5","0.0"]),[129 119 0]));
T=table(["00123";"456";"00123"],["A";"A";"B"],["fit";"assessment";"assessment"], ...
 'VariableNames',{'MatchID','FoldID','Role'});
[G,H]=RevisedCodes_Pre20I_Roles(T,"00123");assert(height(G)==3&&height(H)==2&&all(H.MatchID=="00123"));
[~,H]=RevisedCodes_Pre20I_Roles(T,"123");assert(isempty(H),'IDs coerced numerically.');
T.MatchID(1)="1.23e2";bad=false;try,RevisedCodes_Pre20I_Roles(T,"123");catch,bad=true;end;assert(bad);
Checks=table(["Cricket notation";"Actual fold and role grouping";"Exact string IDs";"Malformed membership ID rejected"],true(4,1),'VariableNames',{'Check','Passed'});disp(Checks);
end
