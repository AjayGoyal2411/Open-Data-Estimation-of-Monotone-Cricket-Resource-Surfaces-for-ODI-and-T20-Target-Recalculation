function Results=RevisedCodes_Pre20I_RunAll(settings)
% Collect evidence bytes and explicit row roles for subsequent adjudication.
if nargin<1,settings=struct;end
assert(isstruct(settings)&&isscalar(settings),'Settings must be scalar struct.');
assert(all(ismember(fieldnames(settings),{'ProjectRoot','FetchPages','TimeoutSeconds'})),'Unknown setting.');
c.ProjectRoot="D:\VihaanProject1";c.FetchPages=true;c.TimeoutSeconds=12;
for n=reshape(string(fieldnames(settings)),1,[]),c.(n)=settings.(n);end
c.ProjectRoot=string(c.ProjectRoot);
assert(isscalar(c.FetchPages)&&islogical(c.FetchPages),'FetchPages must be logical.');
assert(isscalar(c.TimeoutSeconds)&&isfinite(c.TimeoutSeconds)&&c.TimeoutSeconds>0,'Invalid timeout.');
assert(isscalar(c.ProjectRoot)&&isfolder(c.ProjectRoot),'Project root missing.');
U=RevisedCodes_Pre20I_Utils;input=fullfile(fileparts(mfilename('fullpath')),'input');
manifest=U.Read(fullfile(input,'InputHashes.csv'));
for j=1:height(manifest),assert(U.Hash(fullfile(input,manifest.File(j)))==manifest.SHA256(j),'Packaged input changed.');end
base=fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','pre20i_evidence_collection');if ~isfolder(base),mkdir(base);end
report=string(tempname(base));mkdir(report);mkdir(fullfile(report,'raw'));mkdir(fullfile(report,'membership'));mkdir(fullfile(report,'pages'));
diary(fullfile(report,'RunLog.txt'));clean=onCleanup(@()diary('off')); %#ok<NASGU>
try
 Checks=RevisedCodes_Pre20I_SelfTests;U.Write(Checks,fullfile(report,'Pre20I_SelfTests.csv'));
 before=U.Freeze(c.ProjectRoot);
 C=U.Read(fullfile(input,'Pre20H_EndpointEligibility.csv'));
 S=U.Read(fullfile(input,'Pre20H_CanonicalRawSources.csv'));
 I=U.Read(fullfile(input,'Pre20H_MembershipInventory.csv'));
 assert(height(C)==40&&numel(unique(C.MatchID))==40,'Expected 40 unique cases.');
 % Original audited paths are intentionally used; relocated projects need a new path audit.
 Raw=table;
 for j=1:height(S)
  status="NO_REVIEWED_RAW";dest="";
  if U.Logical(S.RawSelected(j))
   source=S.SelectedPath(j);assert(isfile(source),'Reviewed raw file missing: %s',source);
   assert(U.Hash(source)==S.SelectedSHA256(j),'Reviewed raw changed: %s',source);
   [~,~,ext]=fileparts(source);dest="raw/"+S.MatchID(j)+ext;
   copyfile(source,fullfile(report,dest));assert(U.Hash(fullfile(report,dest))==S.SelectedSHA256(j),'Raw copy differs.');status="COPIED_HASH_VERIFIED";
  end
  Raw=[Raw;table(S.MatchID(j),S.SelectedPath(j),S.SelectedSHA256(j),dest,status,'VariableNames',{'MatchID','SourcePath','SHA256','BundlePath','Status'})]; %#ok<AGROW>
 end
 U.Write(Raw,fullfile(report,'Pre20I_RawCollection.csv'));
 Tables=table;seen=strings(0,1);
 for j=1:height(I)
  source=I.Path(j);expected=I.SHA256(j);
  assert(isfile(source),'Audited membership file missing: %s',source);
  assert(U.Hash(source)==expected,'Membership file changed since Pre20H: %s',source);
  [~,stem,ext]=fileparts(source);dest="membership/"+string(j)+"_"+stem+ext;
  status="DUPLICATE_HASH_ALREADY_COLLECTED";
  if ~ismember(expected,seen)
   copyfile(source,fullfile(report,dest));assert(U.Hash(fullfile(report,dest))==expected,'Membership copy differs.');
   T=U.Read(source);[G,H]=RevisedCodes_Pre20I_Roles(T,C.MatchID);
   U.Write(G,fullfile(report,'membership',string(j)+"_RoleSummary.csv"));
   U.Write(H,fullfile(report,'membership',string(j)+"_CaseHits.csv"));
   seen(end+1,1)=expected;status="COPIED_AND_ROLE_AUDITED";
  else
   prior=find(Tables.SHA256==expected,1);dest=Tables.BundlePath(prior);
  end
  Tables=[Tables;table(source,expected,dest,status,'VariableNames',{'SourcePath','SHA256','BundlePath','Status'})]; %#ok<AGROW>
 end
 U.Write(Tables,fullfile(report,'Pre20I_MembershipCollection.csv'));
 % Collect context fold dates beside the reviewed membership file, if present.
 ix=find(endsWith(I.Path,'09_02A_InningsMembership.csv'),1);Context=table;
 if ~isempty(ix)
  path=fullfile(fileparts(I.Path(ix)),'09_02A_FoldLedger.csv');status="MISSING";hash="";
  if isfile(path),hash=U.Hash(path);copyfile(path,fullfile(report,'membership','09_02A_FoldLedger.csv'));status="COLLECTED_CURRENT_NOT_PRE20H_PINNED";end
  Context=table(string(path),hash,status,'VariableNames',{'SourcePath','SHA256','Status'});
  U.Write(Context,fullfile(report,'Pre20I_ContextFoldSource.csv'));
 end
 Pages=table;
 for j=1:height(C)
  fprintf('Case evidence page %d/%d: %s\n',j,height(C),C.MatchID(j));
  url=C.SourceURL(j);status="NOT_REQUESTED";errText="";dest="";hash="";
  if c.FetchPages
   assert(startsWith(url,"https://")||startsWith(url,"http://"),'Invalid source URL.');
   target=fullfile(report,'pages',C.MatchID(j)+".html");
   try
    websave(char(target),char(url),weboptions('Timeout',c.TimeoutSeconds,'ContentType','text'));
    hash=U.Hash(target);dest="pages/"+C.MatchID(j)+".html";status="CAPTURED_CONTENT_REVIEW_REQUIRED";
   catch err
    status="FETCH_FAILED";errText=string(err.message);
    if isfile(target),delete(target);end
   end
  end
  Pages=[Pages;table(C.MatchID(j),url,string(datetime('now','TimeZone','UTC','Format','yyyy-MM-dd HH:mm:ss')),dest,hash,status,errText, ...
   'VariableNames',{'MatchID','RequestedURL','RetrievedUTC','BundlePath','SHA256','Status','Error'})]; %#ok<AGROW>
  U.Write(Pages,fullfile(report,'Pre20I_PageCollection.csv'));
 end
 after=U.Freeze(c.ProjectRoot);assert(isequal(before,after),'Frozen files changed during collection.');
 U.Write(after,fullfile(report,'Pre20I_FrozenHashes.csv'));copyfile(input,fullfile(report,'input_snapshot'));
 Summary=table(height(C),nnz(Raw.Status=="COPIED_HASH_VERIFIED"),numel(seen),nnz(Pages.Status=="CAPTURED_CONTENT_REVIEW_REQUIRED"),nnz(Pages.Status=="FETCH_FAILED"), ...
  'VariableNames',{'Cases','ReviewedRawFilesCopied','DistinctMembershipTables','PagesCaptured','PageFetchFailures'});
 U.Write(Summary,fullfile(report,'Pre20I_Summary.csv'));
 code=dir(fullfile(fileparts(mfilename('fullpath')),'*.m'));CodeHashes=table;
 for k=1:numel(code)
  CodeHashes=[CodeHashes;table(string(code(k).name),U.Hash(fullfile(code(k).folder,code(k).name)),'VariableNames',{'File','SHA256'})]; %#ok<AGROW>
 end
 U.Write(CodeHashes,fullfile(report,'Pre20I_CodeHashes.csv'));
 Results=struct('Status',"EVIDENCE_COLLECTED_ADJUDICATION_REQUIRED",'Summary',Summary,'Settings',c,'Raw',Raw,'Membership',Tables,'Pages',Pages);
 save(fullfile(report,'RevisedCodes_Pre20I_Result.mat'),'Results');disp(Summary);
 diary off;zip(report+"_Evidence.zip",{'*'},report);fprintf('Upload %s\n',report+"_Evidence.zip");
catch err
 diary off;zip(report+"_FAILED_Evidence.zip",{'*'},report);fprintf('Upload %s\n',report+"_FAILED_Evidence.zip");rethrow(err);
end
end
