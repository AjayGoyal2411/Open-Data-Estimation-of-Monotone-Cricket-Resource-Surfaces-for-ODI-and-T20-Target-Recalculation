function C = RevisedCodes_20_Config(settings)
% Configuration for the locked Step 20 case-study analysis.
if nargin < 1, settings = struct; end
assert(isstruct(settings) && isscalar(settings),'settings must be a scalar struct.');
allowed = ["ProjectRoot","FrozenRoot","VerifyFrozenFiles","BootstrapReplicates", ...
    "RandomSeed","FigureVisible"];
assert(all(ismember(string(fieldnames(settings)),allowed)), ...
    'Unknown setting: %s',strjoin(setdiff(string(fieldnames(settings)),allowed),', '));

C.ProjectRoot = "D:\VihaanProject1";
C.FrozenRoot = fullfile(C.ProjectRoot,'paper_outputs_revisedcodes','step19_final', ...
    'frozen','build_20260917_194500_402');
C.VerifyFrozenFiles = true;
C.BootstrapReplicates = 10000;
C.RandomSeed = 20260918;
C.FigureVisible = false;
for n = reshape(string(fieldnames(settings)),1,[]), C.(n) = settings.(n); end
C.ProjectRoot = string(C.ProjectRoot);
C.FrozenRoot = string(C.FrozenRoot);
assert(isfolder(C.ProjectRoot),'ProjectRoot not found: %s',C.ProjectRoot);
assert(isfolder(C.FrozenRoot),'FrozenRoot not found: %s',C.FrozenRoot);
assert(islogical(C.VerifyFrozenFiles) && isscalar(C.VerifyFrozenFiles));
assert(isnumeric(C.BootstrapReplicates) && isscalar(C.BootstrapReplicates) && ...
    C.BootstrapReplicates >= 1000 && fix(C.BootstrapReplicates)==C.BootstrapReplicates);
assert(isnumeric(C.RandomSeed) && isscalar(C.RandomSeed) && isfinite(C.RandomSeed));
assert(islogical(C.FigureVisible) && isscalar(C.FigureVisible));
end
