function D = RevisedCodes_20_Load(here,C,U,work)
inputDir=fullfile(here,'input'); zipPath=fullfile(inputDir,'Pre20_Final_Checked.zip');
assert(isfile(zipPath),'Packaged Pre20 input missing.');
manifest=U.Read(fullfile(inputDir,'InputHashes.csv')); U.Require(manifest,["File","SHA256"]);
assert(height(manifest)==1 && manifest.File(1)=="Pre20_Final_Checked.zip");
assert(U.Hash(zipPath)==lower(manifest.SHA256(1)),'Packaged Pre20 checks hash mismatch.');
preDir=fullfile(work,'pre20'); mkdir(preDir); unzip(zipPath,preDir);

g=U.Read(fullfile(preDir,'Pre20_Final_ExecutionGates.csv')); U.Require(g,["Gate","Passed"]);
required=["Pinned predecessor inputs verified";"Frozen 94-file boundary unchanged"; ...
    "Raw target and final allocation matched";"Pre20 completed"; ...
    "Step20 descriptive comparison authorized";"Step20 operational comparison authorized"];
for k=1:numel(required)
    j=find(g.Gate==required(k),1); assert(~isempty(j)&&U.Bool(g.Passed(j)),'Required Pre20 gate failed: %s',required(k));
end
j=find(g.Gate=="Independent validation authorized",1); assert(~isempty(j)&&~U.Bool(g.Passed(j)), ...
    'Independent-input lock unexpectedly changed.');

D.Descriptive=U.Read(fullfile(preDir,'Pre20_Final_Step20_DescriptiveInput.csv'));
D.Operational=U.Read(fullfile(preDir,'Pre20_Final_Step20_OperationalInput.csv'));
D.Cases=U.Read(fullfile(preDir,'Pre20_Final_CaseDisposition.csv'));
D.Events=U.Read(fullfile(preDir,'Pre20_Final_EventDisposition.csv'));
D.Frozen=U.Read(fullfile(preDir,'Pre20_Final_FrozenVerification.csv'));
assert(height(D.Descriptive)==29 && numel(unique(D.Descriptive.MatchID))==29,'Expected 29 unique descriptive cases.');
assert(height(D.Operational)==15 && numel(unique(D.Operational.MatchID))==15,'Expected 15 unique operational cases.');
assert(all(ismember(D.Operational.MatchID,D.Descriptive.MatchID)),'Operational cohort is not a subset.');
assert(height(D.Frozen)==94,'Frozen boundary must contain exactly 94 files.');

needed=["MatchID","Format","FirstInningsRuns","FirstInningsWickets", ...
    "FirstInningsLegalBalls","FirstInningsOvers","PublishedTargetRuns", ...
    "PublishedTargetOvers","OversBowled","Score","WicketsLost", ...
    "DirectDevelopmentOverlap","SensitivityAssessment","IndependenceStatus","AllowedUse"];
U.Require(D.Descriptive,needed); U.Require(D.Operational,needed);
assert(all(D.Descriptive.EvidenceTier=="RAW_BACKED_FINAL_STATE"));
assert(all(D.Operational.EvidenceTier=="RAW_BACKED_FINAL_STATE"));
assert(all(D.Operational.DirectDevelopmentOverlap=="0"));
assert(all(contains(D.Descriptive.AllowedUse,"NOT_INDEPENDENT")));
assert(all(contains(D.Operational.AllowedUse,"NOT_INDEPENDENT")));

% Rebase the pinned Windows paths to the selected frozen root, then hash all 94 files.
F=D.Frozen; F.Step20Path=strings(height(F),1); F.Step20SHA256=strings(height(F),1); F.Step20HashMatched=false(height(F),1);
for k=1:height(F)
    original=replace(F.Path(k),'\','/'); marker='/build_20260917_194500_402/'; q=strfind(lower(original),lower(marker));
    assert(~isempty(q),'Unexpected frozen path: %s',F.Path(k)); rel=extractAfter(original,q(1)+strlength(marker)-1);
    F.Step20Path(k)=fullfile(C.FrozenRoot,replace(rel,'/',filesep));
    assert(isfile(F.Step20Path(k)),'Frozen file missing: %s',F.Step20Path(k));
    if C.VerifyFrozenFiles
        F.Step20SHA256(k)=U.Hash(F.Step20Path(k)); F.Step20HashMatched(k)=F.Step20SHA256(k)==lower(F.ExpectedSHA256(k));
    else
        F.Step20SHA256(k)="NOT_RECHECKED"; F.Step20HashMatched(k)=true;
    end
end
assert(all(F.Step20HashMatched),'At least one frozen Step19 file changed.'); D.Frozen=F;
end
