function [Metrics,CI] = RevisedCodes_20_Analyse(D,O,C,U)
Ds=D(D.CalculationTier=="STRICT_FINAL_STATE_RECONSTRUCTION",:);
Os=O(O.CalculationTier=="STRICT_FINAL_STATE_RECONSTRUCTION",:);
cohorts={D,"DESCRIPTIVE";O,"OPERATIONAL";Ds,"DESCRIPTIVE_STRICT";Os,"OPERATIONAL_STRICT"};
metricRows=cell(0,1);
for c=1:size(cohorts,1)
    X=cohorts{c,1}; label=cohorts{c,2};
    for f=["ALL","ODI","T20"]
        if f=="ALL", Y=X; else, Y=X(strcmpi(X.Format,f),:); end
        if ~isempty(Y), metricRows{end+1,1}=summarise(Y,label,f); end %#ok<AGROW>
    end
end
Metrics=vertcat(metricRows{:});
rows=cell(0,1);
for c=1:size(cohorts,1)
    X=cohorts{c,1}; label=cohorts{c,2};
    for f=["ALL","ODI","T20"]
        if f=="ALL", Y=X; else, Y=X(strcmpi(X.Format,f),:); end
        if ~isempty(Y), rows{end+1,1}=boot(Y,label,f,C,U); end %#ok<AGROW>
    end
end
CI=vertcat(rows{:});
end

function T=summarise(X,cohort,format)
e=double(X.SignedDifference); a=abs(e); n=numel(e); assert(n>0);
T=table(string(cohort),string(format),n,mean(e),mean(a),sqrt(mean(e.^2)),median(a), ...
    100*mean(a==0),100*mean(a<=5),100*mean(a<=10),min(e),max(e), ...
    'VariableNames',{'Cohort','Format','N','Bias','MAE','RMSE','MedianAbsoluteError', ...
    'ExactAgreementPercent','WithinFivePercent','WithinTenPercent','MinimumDifference','MaximumDifference'});
end

function T=boot(X,cohort,format,C,U)
e=double(X.SignedDifference); n=numel(e); B=C.BootstrapReplicates;
stream=RandStream('mt19937ar','Seed',C.RandomSeed+sum(double(char(cohort+format))));
out=zeros(B,4); chunk=1000;
for lo=1:chunk:B
    hi=min(B,lo+chunk-1); idx=randi(stream,n,n,hi-lo+1); z=e(idx);
    out(lo:hi,1)=reshape(mean(z,1),[],1); out(lo:hi,2)=reshape(mean(abs(z),1),[],1);
    out(lo:hi,3)=reshape(sqrt(mean(z.^2,1)),[],1); out(lo:hi,4)=reshape(median(abs(z),1),[],1);
end
metric=["Bias";"MAE";"RMSE";"MedianAbsoluteError"]; estimate=[mean(e);mean(abs(e));sqrt(mean(e.^2));median(abs(e))];
low=zeros(4,1); high=zeros(4,1); for k=1:4, low(k)=U.Percentile(out(:,k),2.5); high(k)=U.Percentile(out(:,k),97.5); end
T=table(repmat(string(cohort),4,1),repmat(string(format),4,1),metric,repmat(n,4,1),estimate,low,high,repmat(B,4,1), ...
    'VariableNames',{'Cohort','Format','Metric','N','Estimate','Lower95','Upper95','BootstrapReplicates'});
end
