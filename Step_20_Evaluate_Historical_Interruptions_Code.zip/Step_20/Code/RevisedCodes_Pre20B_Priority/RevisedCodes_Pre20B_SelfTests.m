function T=RevisedCodes_Pre20B_SelfTests
U=RevisedCodes_Pre20B_Utils;
t=tempname;mkdir(t);g=onCleanup(@()rmdir(t,'s')); %#ok<NASGU>
p=fullfile(t,'ids.csv');f=fopen(p,'w');fprintf(f,'MatchID,CaseID\n000123,CASE_000123\n');fclose(f);
a=U.Read(p);assert(a.MatchID(1)=="000123");
p=fullfile(t,'abc.txt');f=fopen(p,'w');fprintf(f,'abc');fclose(f);
assert(U.Hash(p)=="ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
d=jsondecode('{"info":{"match_type":"IT20","overs":20,"gender":"female","team_type":"international","dates":["2018-01-01"]}}');
m=U.Metadata(d);assert(m.MatchType=="IT20"&&m.Dates=="2018-01-01"&&m.Overs=="20");
assert(U.Decision("T20",m)=="possible_IT20_alias_REVIEW_REQUIRED");
assert(U.Decision("ODI",m)=="format_conflict_REVIEW_REQUIRED");
m=U.Metadata(struct);assert(m.Status=="missing_info");
f=fopen(fullfile(t,'000123.json'),'w');fprintf(f,'{}');fclose(f);
mkdir(fullfile(t,'duplicate'));f=fopen(fullfile(t,'duplicate','000123.json'),'w');fprintf(f,'{}');fclose(f);
j=U.Index(t);assert(height(j)==2&&all(j.MatchID=="000123"));
txt=strjoin(["---";"info:";"  players:";"    Test:";"    - J Hazlewood";"  team_type: international";"  venue: Final field";"innings:";"- deliveries: []"],newline);
block=U.YAMLInfo(txt);
assert(contains(block,"J Hazlewood")&&contains(block,"venue: Final field")&&~contains(block,"innings:"));
assert(U.YAMLInfo(strrep(txt,newline,sprintf('\r\n')))==block);
assert(contains(U.YAMLInfo(strjoin(["info:";"  team_type: club"],newline)),"team_type: club"));
assert(U.YAMLInfo("no_info: true")=="");
T=table(["Text IDs preserved";"SHA256 reference vector";"JSON metadata fields";"Alias never auto-promoted";"Conflict retained";"Missing info retained";"Duplicate paths retained";"Whole YAML lines preserved";"CRLF YAML supported";"EOF YAML supported";"Missing YAML info explicit"],true(11,1),'VariableNames',{'Check','Passed'});
disp(T);
end
