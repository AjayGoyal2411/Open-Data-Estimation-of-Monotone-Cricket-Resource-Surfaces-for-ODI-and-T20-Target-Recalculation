function Results=RevisedCodes_Pre20B_RunAll(settings)
% Read-only targeted audit. Copies metadata, not models or full training data.
if nargin<1,settings=struct;end
assert(isstruct(settings)&&isscalar(settings),'settings must be a scalar struct.');
allowed={'Root','JSONRoot','YAMLRoot'};assert(all(ismember(fieldnames(settings),allowed)),'Unknown setting.');
c.Root='D:\VihaanProject1';if isfield(settings,'Root'),c.Root=char(settings.Root);end
c.JSONRoot=fullfile(c.Root,'JSONFiles');c.YAMLRoot=fullfile(c.Root,'ALLYAML');
if isfield(settings,'JSONRoot'),c.JSONRoot=char(settings.JSONRoot);end
if isfield(settings,'YAMLRoot'),c.YAMLRoot=char(settings.YAMLRoot);end
here=fileparts(mfilename('fullpath'));U=RevisedCodes_Pre20B_Utils;
Checks=RevisedCodes_Pre20B_SelfTests;
assert(isfolder(c.JSONRoot)||isfolder(c.YAMLRoot),'Neither source folder exists. Check JSONRoot/YAMLRoot settings.');
parent=fullfile(c.Root,'paper_outputs_revisedcodes','pre20b_priority');if ~isfolder(parent),mkdir(parent);end
out=tempname(parent);mkdir(out);mkdir(fullfile(out,'metadata'));mkdir(fullfile(out,'reports'));
B=U.Snapshot(c.Root);writetable(B,fullfile(out,'reports','FrozenBefore.csv'));
J=[U.Index(c.JSONRoot);U.Index(c.YAMLRoot)];J=unique(J,'rows');
Q=U.Read(fullfile(here,'input','FormatConflictQueue.csv'));
H=U.Read(fullfile(here,'input','HistoricalRecoveryQueue.csv'));
Q.Queue=repmat("format_conflict",height(Q),1);H.Queue=repmat("historical_missing",height(H),1);Q=[Q;H];
assert(height(Q)==numel(unique(Q.MatchID)),'Repeated queue IDs.');
names={'MatchID','Queue','ExpectedFormat','ExpectedGender','ExpectedDate','SourcePath','Extension','SHA256','RawMatchType','RawOvers','RawGender','RawDates','RawTeamType','RawBallsPerOver','MetadataFile','Disposition','Error','CandidateCount','DistinctHashes'};
rows=cell(0,numel(names));
for k=1:height(Q)
 ix=find(J.MatchID==Q.MatchID(k));
 if isempty(ix)
  row=repmat({""},1,numel(names));row(1:5)={Q.MatchID(k),Q.Queue(k),Q.Format(k),Q.Gender(k),Q.Date(k)};row{16}="source_missing";row{18}="0";row{19}="0";rows(end+1,:)=row; %#ok<AGROW>
  continue;
 end
 hs=strings(numel(ix),1);start=size(rows,1)+1;
 for a=1:numel(ix)
  j=ix(a);row=repmat({""},1,numel(names));row(1:7)={Q.MatchID(k),Q.Queue(k),Q.Format(k),Q.Gender(k),Q.Date(k),J.Path(j),J.Extension(j)};row{18}=string(numel(ix));
  try
   hs(a)=U.Hash(J.Path(j));row{8}=hs(a);txt=fileread(J.Path(j));
   if J.Extension(j)=="json"
    d=jsondecode(txt);m=U.Metadata(d);row(9:14)={m.MatchType,m.Overs,m.Gender,m.Dates,m.TeamType,m.BallsPerOver};row{16}=U.Decision(Q.Format(k),m);
    if strlength(m.InfoJSON)>0
     rel="metadata/"+Q.MatchID(k)+"_"+string(a)+"_info.json";writeText(fullfile(out,rel),m.InfoJSON);row{15}=rel;
    end
   else
    % Preserve the complete top-level info block for manual review. No YAML parser or guessed classification.
    block=U.YAMLInfo(txt);
    if strlength(block)==0,row{16}="yaml_info_not_extracted_review_required";
    else
     rel="metadata/"+Q.MatchID(k)+"_"+string(a)+"_info.yaml";writeText(fullfile(out,rel),block);row{15}=rel;row{16}="yaml_info_extracted_manual_review_required";
    end
   end
  catch ME
   row{16}="source_read_or_parse_error";row{17}=string(ME.message);
  end
  rows(end+1,:)=row; %#ok<AGROW>
 end
 validHashes=hs(strlength(hs)>0);distinct=numel(unique(validHashes));
 for r=start:size(rows,1),rows{r,19}=string(distinct);end
 if numel(ix)>1
  % Different JSON/YAML serialization is not necessarily a semantic conflict.
  for r=start:size(rows,1),rows{r,16}=string(rows{r,16})+";multiple_sources_review_required";end
 end
 if mod(k,100)==0||k==height(Q),fprintf('Pre20B metadata %d/%d\n',k,height(Q));end
end
Audit=cell2table(rows,'VariableNames',names);for k=1:width(Audit),Audit.(names{k})=string(Audit.(names{k}));end
writetable(Audit,fullfile(out,'reports','MetadataEvidence.csv'));
S=groupsummary(Audit,{'Queue','RawMatchType','Disposition'});writetable(S,fullfile(out,'reports','MetadataSourceSummary.csv'));
% Cases and source corrections are review records, never automatic eligibility inputs.
copyfile(fullfile(here,'input'),fullfile(out,'submitted_registers'));
copyfile(fullfile(here,'evidence_raw'),fullfile(out,'evidence_raw'));
writetable(Checks,fullfile(out,'reports','SelfTests.csv'));
A=U.Snapshot(c.Root);writetable(A,fullfile(out,'reports','FrozenAfter.csv'));assert(isequal(A,B),'Frozen files changed during audit.');
Status=table("AUDIT_EXPORTED_REVIEW_REQUIRED",height(Q),nnz(Q.Queue=="format_conflict"),false,true, ...
 'VariableNames',{'Status','QueuedMatches','FormatConflictMatches','AnyAutomaticPromotion','FrozenUnchanged'});
writetable(Status,fullfile(out,'reports','Status.csv'));
writeText(fullfile(out,'SETTINGS.json'),jsonencode(c));
zipPath=[out '_Checks.zip'];zip(zipPath,{'reports','metadata','submitted_registers','evidence_raw','SETTINGS.json'},out);
Results=struct('ReportFolder',out,'ChecksZip',zipPath,'Status',Status);
disp(Status);fprintf('Upload this file: %s\n',zipPath);
end
function writeText(p,s)
f=fopen(p,'w','n','UTF-8');assert(f>=0,'Cannot write %s',p);g=onCleanup(@()fclose(f)); %#ok<NASGU>
fprintf(f,'%s',char(s));
end
