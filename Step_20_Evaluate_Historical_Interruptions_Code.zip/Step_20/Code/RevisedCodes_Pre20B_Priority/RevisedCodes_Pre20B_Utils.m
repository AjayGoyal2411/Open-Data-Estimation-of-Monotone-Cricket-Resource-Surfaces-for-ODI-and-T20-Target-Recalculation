function U=RevisedCodes_Pre20B_Utils
% Standalone read-only evidence helpers. No dependency on earlier utility versions.
U.Read=@readTextTable; U.Hash=@hashFile; U.Index=@indexFiles;
U.YAMLInfo=@yamlInfo; U.Metadata=@metadata; U.Snapshot=@snapshot; U.Decision=@decision;
end
function T=readTextTable(p)
o=detectImportOptions(p,'TextType','string','VariableNamingRule','preserve');
o=setvartype(o,o.VariableNames,'string');T=readtable(p,o);
end
function h=hashFile(p)
f=fopen(p,'rb');assert(f>=0,'Cannot read %s',p);guard=onCleanup(@()fclose(f)); %#ok<NASGU>
m=java.security.MessageDigest.getInstance('SHA-256');
while true
 b=fread(f,1048576,'*uint8');if isempty(b),break;end
 m.update(typecast(b(:),'int8'));
end
b=typecast(m.digest(),'uint8');h=string(lower(reshape(dec2hex(b,2).',1,[])));
end
function J=indexFiles(root)
J=table(strings(0,1),strings(0,1),strings(0,1),'VariableNames',{'MatchID','Path','Extension'});
if ~isfolder(root),return;end
for ext=["json","yaml","yml"]
 d=dir(fullfile(root,'**','*.'+ext));
 for k=1:numel(d)
  [~,id]=fileparts(d(k).name);
  if isempty(regexp(id,'^\d+$','once')),continue;end
  J(end+1,:)={string(id),string(fullfile(d(k).folder,d(k).name)),ext}; %#ok<AGROW>
 end
end
J=unique(J,'rows');J=sortrows(J,{'MatchID','Path'});
end
function m=metadata(d)
m=struct('MatchType',"",'Overs',"",'Gender',"",'Dates',"",'TeamType',"",'BallsPerOver',"",'InfoJSON',"",'Status',"missing_info");
if ~isstruct(d)||~isscalar(d)||~isfield(d,'info')||~isstruct(d.info)||~isscalar(d.info),return;end
i=d.info;m.InfoJSON=string(jsonencode(i));m.Status="metadata_extracted";
pairs={'match_type','MatchType';'overs','Overs';'gender','Gender';'dates','Dates';'team_type','TeamType';'balls_per_over','BallsPerOver'};
for k=1:size(pairs,1)
 if isfield(i,pairs{k,1})
  v=i.(pairs{k,1});
  if ischar(v)
   m.(pairs{k,2})=string(v);
  elseif isstring(v)||isnumeric(v)||iscellstr(v)
   m.(pairs{k,2})=join(string(v(:)),';');
  else
   m.(pairs{k,2})=string(jsonencode(v));
  end
 end
end
end
function s=decision(expected,m)
s="metadata_review_required";
if m.Status~="metadata_extracted",s=m.Status;return;end
if strcmpi(strtrim(expected),strtrim(m.MatchType)),s="format_matches_now_identity_review_pending";return;end
if strcmpi(expected,"T20")&&strcmpi(m.MatchType,"IT20")
 s="possible_IT20_alias_REVIEW_REQUIRED";
else
 s="format_conflict_REVIEW_REQUIRED";
end
end
function T=snapshot(root)
T=table(strings(0,1),strings(0,1),'VariableNames',{'Path','SHA256'});
d=dir(fullfile(root,'paper_outputs_revisedcodes','step19_final','frozen','**','*'));d=d(~[d.isdir]);
assert(~isempty(d),'Pre20B:MissingFreeze','Step19 frozen files not found under %s',root);
for k=1:numel(d)
 p=string(fullfile(d(k).folder,d(k).name));T(end+1,:)={p,hashFile(p)}; %#ok<AGROW>
end
T=sortrows(T,'Path');
end

function block=yamlInfo(txt)
% Preserve whole lines: no multiline regexp or end-of-input escape dependency.
lines=splitlines(string(txt));first=0;last=numel(lines);
for k=1:numel(lines)
 line=char(lines(k));
 if ~isempty(regexp(line,'^info:[ \t]*(#.*)?$','once'))
  assert(first==0,'Pre20B:DuplicateInfo','Multiple top-level info blocks.');
  first=k;
 end
end
block="";if first==0,return;end
for k=first+1:numel(lines)
 line=char(lines(k));
 if isempty(strtrim(line))||startsWith(strtrim(string(line)),"#"),continue;end
 if ~isspace(line(1))
  last=k-1;break;
 end
end
assert(last>first,'Pre20B:EmptyInfo','Empty YAML info block.');
block=join(lines(first:last),newline);
end
