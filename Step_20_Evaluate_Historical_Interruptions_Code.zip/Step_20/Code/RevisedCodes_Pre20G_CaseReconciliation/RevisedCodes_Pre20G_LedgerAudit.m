function E=RevisedCodes_Pre20G_LedgerAudit(c,C,E)
U=RevisedCodes_Pre20G_Utils;S=U.Read(fullfile(c.Input,'ReviewedRawStates.csv'));
for n=["InningsIndex","DeliverySequence","LegalBalls","Score","WicketsLost"],S.(n)=U.Number(S.(n));end
for n=["EventOrder","InningsIndex","Score","WicketsLost","TargetRunsClaim"],E.(n)=U.Number(E.(n));end
E.LegalBallsBowled=U.Overs(E.OversBowled);E.NewAllocationClaimBalls=U.Overs(E.NewOversClaim);
n=height(E);E.PreviousAllocationClaimBalls=NaN(n,1);E.RemainingBallsAfterEvent=NaN(n,1);
E.ArithmeticConsistent=true(n,1);E.SnapshotStateMatched=false(n,1);E.SnapshotMatchingRows=zeros(n,1);
E.RawStatesAtBall=zeros(n,1);E.StateMeaning=repmat("NO_REVIEWED_RAW_SNAPSHOT",n,1);E.ArithmeticIssue=strings(n,1);
assert(numel(unique(E.CaseID+"|"+string(E.EventOrder)))==n,'Duplicate event keys.');
assert(all(ismember(E.MatchID,C.MatchID)),'Event references an unknown case.');
assert(all(E.CaseID=="CASE_"+E.MatchID),'Event case/match ID mismatch.');
assert(all(ismember(E.EventType,["interruption","pre_start_reduction","terminal_abandonment"])));
for ci=1:height(C)
 ix=find(E.MatchID==C.MatchID(ci));[~,o]=sort(E.EventOrder(ix));ix=ix(o);
 assert(isequal(E.EventOrder(ix),(1:numel(ix))'),'Event orders must be consecutive within case.');
 lastInnings=0;lastBalls=[-1 -1];lastWickets=[-1 -1];lastScore=[-1 -1];alloc=[NaN NaN];terminal=[false false];
 horizon=120;if C.Format(ci)=="ODI",horizon=300;end
 for z=reshape(ix,1,[])
  ii=E.InningsIndex(z);assert(ismember(ii,[1 2]),'Invalid innings index.');
  b=E.LegalBallsBowled(z);new=E.NewAllocationClaimBalls(z);sc=E.Score(z);w=E.WicketsLost(z);typ=E.EventType(z);issues=strings(0,1);
  if ~isfinite(sc)||sc<0||sc~=floor(sc)||~isfinite(w)||w<0||w>10||w~=floor(w),issues(end+1)="INVALID_SCORE_OR_WICKETS";end
  if ii<lastInnings||b<lastBalls(ii)||w<lastWickets(ii)||sc<lastScore(ii)||terminal(ii),issues(end+1)="EVENT_SEQUENCE_CONFLICT";end
  if b>horizon||new>horizon||new<b,issues(end+1)="ALLOCATION_OUTSIDE_BOUNDS";end
  if typ=="pre_start_reduction"&&(b~=0||sc~=0||w~=0),issues(end+1)="PRESTART_STATE_NOT_ZERO";end
  E.PreviousAllocationClaimBalls(z)=alloc(ii);
  if isfinite(alloc(ii))&&(b>alloc(ii)||new>alloc(ii)),issues(end+1)="CONFLICT_WITH_PRIOR_ALLOCATION_CLAIM";end
  if typ=="terminal_abandonment"
   E.RemainingBallsAfterEvent(z)=0;terminal(ii)=true;
   if new~=b,issues(end+1)="TERMINAL_LABEL_CONFLICT";end
  else
   E.RemainingBallsAfterEvent(z)=new-b;
   if new<=b,issues(end+1)="NO_BALLS_LEFT_FOR_RESTART";end
   alloc(ii)=new;
  end
  E.ArithmeticConsistent(z)=isempty(issues);E.ArithmeticIssue(z)=strjoin(issues,';');
  q=S.MatchID==E.MatchID(z)&S.InningsIndex==ii&S.LegalBalls==b;
  hit=q&S.Score==sc&S.WicketsLost==w;E.RawStatesAtBall(z)=nnz(q);E.SnapshotMatchingRows(z)=nnz(hit);E.SnapshotStateMatched(z)=any(hit);
  if any(S.MatchID==E.MatchID(z))
   E.StateMeaning(z)="STATE_NOT_FOUND_IN_REVIEWED_SNAPSHOT";
   if any(hit),E.StateMeaning(z)="STATE_EXISTS_NOT_PROOF_OF_INTERRUPTION";end
   if any(hit)&&b==0,E.StateMeaning(z)="TRIVIAL_ZERO_STATE_NOT_INTERRUPTION_EVIDENCE";end
  end
  lastInnings=ii;lastBalls(ii)=b;lastWickets(ii)=w;lastScore(ii)=sc;
 end
end
% Source verification fields stay separate from numeric consistency.
U.Write(E,fullfile(c.Report,'Pre20G_RevisedEventLedger.csv'));
end
