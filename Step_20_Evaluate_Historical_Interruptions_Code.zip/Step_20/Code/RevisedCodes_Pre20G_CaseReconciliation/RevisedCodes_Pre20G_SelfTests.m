function Checks=RevisedCodes_Pre20G_SelfTests
U=RevisedCodes_Pre20G_Utils;
assert(isequal(U.Overs(["21.3","19.5","0.0"]),[129 119 0]));
assert(isequal(U.Overs(["21.3";"19.5";"0.0"]),[129;119;0]));
for s=["21.6","21.30","-1","NaN",""]
 rejected=false;try,U.Overs(s);catch,rejected=true;end;assert(rejected,'Invalid notation accepted.');
end
assert(U.Ready(true,true,true,true,true,true,true));
for j=1:7
 flags=true(1,7);flags(j)=false;
 assert(~U.Ready(flags(1),flags(2),flags(3),flags(4),flags(5),flags(6),flags(7)));
end
p=[tempname '.csv'];cleanup=onCleanup(@()delete(p)); %#ok<NASGU>
T=table(["00123";"1298154"],["a,b";"c"],'VariableNames',{'MatchID','Note'});U.Write(T,p);V=U.Read(p);
assert(isequal(V.MatchID,T.MatchID)&&isequal(V.Note,T.Note));
assert(~U.Ready(true,true,true,false,false,false,false),'State existence promoted to source verification.');
% Exercise the actual ledger routine on terminal and invalid restart fixtures.
d=tempname;mkdir(d);cleanDir=onCleanup(@()rmdir(d,'s')); %#ok<NASGU>
c=struct('Input',d,'Report',d);
S=table("900001",2,1,87,105,5,"test",'VariableNames', ...
 {'MatchID','InningsIndex','DeliverySequence','LegalBalls','Score','WicketsLost','RawSHA256'});
U.Write(S,fullfile(d,'ReviewedRawStates.csv'));
C=table("CASE_900001","900001","T20",'VariableNames',{'CaseID','MatchID','Format'});
E=table("CASE_900001","900001",1,2,"terminal_abandonment","14.3",105,5,"14.3",111, ...
 'VariableNames',{'CaseID','MatchID','EventOrder','InningsIndex','EventType','OversBowled','Score','WicketsLost','NewOversClaim','TargetRunsClaim'});
F=RevisedCodes_Pre20G_LedgerAudit(c,C,E);
assert(F.ArithmeticConsistent&&F.SnapshotStateMatched&&F.RemainingBallsAfterEvent==0);
assert(isnan(F.PreviousAllocationClaimBalls),'Unknown initial allocation invented.');
E.EventType="interruption";F=RevisedCodes_Pre20G_LedgerAudit(c,C,E);
assert(~F.ArithmeticConsistent,'Restart with no balls left accepted.');
Checks=table(["Cricket notation row shape";"Cricket notation column shape";"Invalid notation rejected";"Every readiness gate required";"CSV exact IDs and quoted fields";"State match cannot verify source";"Terminal event and unknown allocation";"Invalid restart rejected"],true(8,1),'VariableNames',{'Check','Passed'});
disp(Checks);
end
