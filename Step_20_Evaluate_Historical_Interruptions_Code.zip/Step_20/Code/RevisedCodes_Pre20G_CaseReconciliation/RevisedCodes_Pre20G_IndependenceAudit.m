function A=RevisedCodes_Pre20G_IndependenceAudit(c,C)
U=RevisedCodes_Pre20G_Utils;
p=fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','step19_final','RevisedCodes_19_02_Result.mat');
assert(isfile(p),'Step19 final result missing.');z=load(p,'Result');R=z.Result;
assert(isfield(R,'Hashes')&&isfield(R,'FrozenModelPath'),'Step19 result schema differs.');
for j=1:height(R.Hashes),assert(U.Hash(R.Hashes.Path(j))==string(R.Hashes.SHA256(j)),'Frozen artifact differs from recorded hash.');end
hp=string(fullfile(fileparts(R.FrozenModelPath),'Frozen_TrainingHistory.csv'));
assert(any(string(R.Hashes.Path)==hp),'Frozen history is not in the verified artifact manifest.');
H=U.Read(hp);U.Require(H,["MatchID","Date","Format"]);
old=U.Read(fullfile(c.Input,'HistoricalOverlapChecks.csv'));old.Present=U.Logical(old.Present);A=table;
for j=1:height(C)
 id=C.MatchID(j);q=old.MatchID==id;hit=any(H.MatchID==id);historical=any(old.Present(q));
 A=[A;table(id,hit,historical,nnz(q),false,"FROZEN_REFIT_HISTORY_AND_LISTED_HISTORICAL_TABLES_ONLY", ...
 'VariableNames',{'MatchID','InFrozenTrainingHistory','InHistoricalCheckedTable','HistoricalTablesChecked', ...
 'CompleteIndependenceCertified','AuditScope'})]; %#ok<AGROW>
end
U.Write(H(:,{'MatchID','Date','Format'}),fullfile(c.Report,'Pre20G_FrozenMembershipChecked.csv'));
U.Write(table(hp,U.Hash(hp),'VariableNames',{'Path','SHA256'}),fullfile(c.Report,'Pre20G_FrozenHistorySource.csv'));
U.Write(A,fullfile(c.Report,'Pre20G_OverlapAudit.csv'));
end
