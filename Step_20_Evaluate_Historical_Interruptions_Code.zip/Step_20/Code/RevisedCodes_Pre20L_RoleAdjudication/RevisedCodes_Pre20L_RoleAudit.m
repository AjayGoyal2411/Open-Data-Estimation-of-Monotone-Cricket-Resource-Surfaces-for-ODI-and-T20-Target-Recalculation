function [FileAudit,Hits,Coverage]=RevisedCodes_Pre20L_RoleAudit(projectRoot,KInventory,caseIDs,U)
% Comprehensive discovery: every CSV with a MatchID column in step01..step19.
base=fullfile(projectRoot,'paper_outputs_revisedcodes');assert(isfolder(base),'paper_outputs_revisedcodes missing.');
top=dir(base);top=top([top.isdir]);names=string({top.name});top=top(startsWith(lower(names),'step'));
paths=strings(0,1);
for i=1:numel(top)
 n=stepNumber(string(top(i).name));if isnan(n)||n>=20,continue;end
 files=dir(fullfile(top(i).folder,top(i).name,'**','*.csv'));
 for j=1:numel(files)
  p=string(fullfile(files(j).folder,files(j).name));
  if hasMatchIDHeader(p),paths(end+1,1)=p;end %#ok<AGROW>
 end
end
paths=unique([paths;string(KInventory.Path)],'stable');
Path=strings(0,1);SHA256=strings(0,1);ExpectedSHA256=strings(0,1);Role=strings(0,1);Subrole=strings(0,1);
Rows=zeros(0,1);NonmissingMatchIDs=zeros(0,1);UniqueMatchIDs=zeros(0,1);MissingMatchIDRows=zeros(0,1);InvalidMatchIDRows=zeros(0,1);
CaseMatches=zeros(0,1);CaseHitIDs=strings(0,1);HashStatus=strings(0,1);ReadStatus=strings(0,1);PriorPre20KCandidate=false(0,1);
HitPath=strings(0,1);HitMatchID=strings(0,1);HitRole=strings(0,1);HitSubrole=strings(0,1);
for k=1:numel(paths)
 p=paths(k);prior=find(string(KInventory.Path)==p,1);expected="";if ~isempty(prior),expected=lower(KInventory.SHA256(prior));if ismissing(expected),expected="";end,end
 Path(end+1,1)=p;ExpectedSHA256(end+1,1)=expected;PriorPre20KCandidate(end+1,1)=~isempty(prior); %#ok<AGROW>
 [role,subrole]=classify(p);Role(end+1,1)=role;Subrole(end+1,1)=subrole; %#ok<AGROW>
 if ~isfile(p)
  SHA256(end+1,1)="";Rows(end+1,1)=NaN;NonmissingMatchIDs(end+1,1)=NaN;UniqueMatchIDs(end+1,1)=NaN;
  MissingMatchIDRows(end+1,1)=NaN;InvalidMatchIDRows(end+1,1)=NaN;CaseMatches(end+1,1)=NaN;CaseHitIDs(end+1,1)="";
  HashStatus(end+1,1)="NOT_AVAILABLE";ReadStatus(end+1,1)="FILE_NOT_AVAILABLE";continue
 end
 actual=U.Hash(p);SHA256(end+1,1)=actual;
 if expected=="",HashStatus(end+1,1)="NEWLY_HASHED";elseif actual==expected,HashStatus(end+1,1)="MATCHED_PRE20K";else,HashStatus(end+1,1)="HASH_MISMATCH";end
 try
  [ids,nRows,nMissing,nInvalid]=U.MatchIDsForgiving(p);hits=unique(ids(ismember(ids,caseIDs)),'stable');
  Rows(end+1,1)=nRows;NonmissingMatchIDs(end+1,1)=numel(ids);UniqueMatchIDs(end+1,1)=numel(unique(ids));
  MissingMatchIDRows(end+1,1)=nMissing;InvalidMatchIDRows(end+1,1)=nInvalid;CaseMatches(end+1,1)=numel(hits);CaseHitIDs(end+1,1)=U.Join(hits);
  if nInvalid>0,ReadStatus(end+1,1)="READ_OK_INVALID_MATCHIDS_EXCLUDED";elseif nMissing>0,ReadStatus(end+1,1)="READ_OK_BLANK_MATCHIDS_EXCLUDED";else,ReadStatus(end+1,1)="READ_OK";end
  for h=1:numel(hits)
   HitPath(end+1,1)=p;HitMatchID(end+1,1)=hits(h);HitRole(end+1,1)=role;HitSubrole(end+1,1)=subrole; %#ok<AGROW>
  end
 catch err
  Rows(end+1,1)=NaN;NonmissingMatchIDs(end+1,1)=NaN;UniqueMatchIDs(end+1,1)=NaN;MissingMatchIDRows(end+1,1)=NaN;
  InvalidMatchIDRows(end+1,1)=NaN;CaseMatches(end+1,1)=NaN;CaseHitIDs(end+1,1)="";ReadStatus(end+1,1)="READ_FAILED: "+string(err.message);
 end
end
FileAudit=table(Path,SHA256,ExpectedSHA256,Role,Subrole,Rows,NonmissingMatchIDs,UniqueMatchIDs,MissingMatchIDRows,InvalidMatchIDRows,CaseMatches,CaseHitIDs,HashStatus,ReadStatus,PriorPre20KCandidate);
FileAudit=sortrows(FileAudit,{'Role','Subrole','Path'});
Hits=table(HitMatchID,HitRole,HitSubrole,HitPath,'VariableNames',{'MatchID','Role','Subrole','Path'});
if ~isempty(Hits),Hits=unique(sortrows(Hits,{'MatchID','Role','Subrole','Path'}),'rows','stable');end
roles=["PREPROCESSING_SELECTION","CONTEXT_HISTORY","EMPIRICAL_ESTIMATION","TUNING","CONFIRMATION","SENSITIVITY_ASSESSMENT","FROZEN_REFIT"]';
CandidateFiles=zeros(numel(roles),1);ReadableFiles=zeros(numel(roles),1);FilesWithCaseHits=zeros(numel(roles),1);UniqueCaseHits=zeros(numel(roles),1);
for i=1:numel(roles)
 q=FileAudit.Role==roles(i);CandidateFiles(i)=nnz(q);ReadableFiles(i)=nnz(q&startsWith(FileAudit.ReadStatus,"READ_OK"));FilesWithCaseHits(i)=nnz(q&FileAudit.CaseMatches>0);
 UniqueCaseHits(i)=numel(unique(Hits.MatchID(Hits.Role==roles(i))));
end
Coverage=table(roles,CandidateFiles,ReadableFiles,FilesWithCaseHits,UniqueCaseHits,'VariableNames',{'Role','CandidateFiles','ReadableFiles','FilesWithCaseHits','UniqueCaseHits'});
assert(~any(FileAudit.HashStatus=="HASH_MISMATCH"),'A Pre20K role-candidate file changed after discovery.');
end

function tf=hasMatchIDHeader(path)
tf=false;f=fopen(path,'rt','n','UTF-8');if f<0,return;end;c=onCleanup(@()fclose(f));h=fgetl(f);if ~ischar(h),return;end
h=strrep(h,char(65279),'');names=strip(erase(split(string(h),','),'"'));tf=any(names=="MatchID");
end

function n=stepNumber(name)
t=regexp(lower(char(name)),'^step0*([0-9]+)','tokens','once');if isempty(t),n=NaN;else,n=str2double(t{1});end
end

function [role,subrole]=classify(path)
s=lower(string(path));parts=split(replace(s,'\','/'),'/');step="";
for i=1:numel(parts),if startsWith(parts(i),'step'),step=parts(i);break;end,end
n=stepNumber(step);role="UNCLASSIFIED";
if n==8,role="PREPROCESSING_SELECTION";elseif n==9,role="CONTEXT_HISTORY";elseif ismember(n,10:12),role="EMPIRICAL_ESTIMATION";
elseif ismember(n,13:14),role="TUNING";elseif ismember(n,15:16),role="CONFIRMATION";elseif ismember(n,17:18),role="SENSITIVITY_ASSESSMENT";elseif n==19,role="FROZEN_REFIT";end
[~,stem,ext]=fileparts(char(path));name=lower(string([stem ext]));subrole=role;
if role=="PREPROCESSING_SELECTION"
 if contains(name,'validation'),subrole="DEVELOPMENT_VALIDATION";elseif contains(name,'test'),subrole="DEVELOPMENT_TEST";
 elseif contains(name,'train'),subrole="DEVELOPMENT_TRAIN";elseif contains(name,'candidate')||contains(name,'manifest'),subrole="CANDIDATE_MANIFEST";
 else,subrole="PREPROCESSING_OTHER";end
elseif role=="CONTEXT_HISTORY",subrole="CONTEXT_HISTORY";
elseif role=="EMPIRICAL_ESTIMATION",subrole="EMPIRICAL_ESTIMATION";
elseif role=="TUNING",subrole="TUNING";
elseif role=="CONFIRMATION",subrole="CONFIRMATION";
elseif role=="SENSITIVITY_ASSESSMENT",subrole="SENSITIVITY_ASSESSMENT";
elseif role=="FROZEN_REFIT",subrole="FROZEN_REFIT";
end
end
