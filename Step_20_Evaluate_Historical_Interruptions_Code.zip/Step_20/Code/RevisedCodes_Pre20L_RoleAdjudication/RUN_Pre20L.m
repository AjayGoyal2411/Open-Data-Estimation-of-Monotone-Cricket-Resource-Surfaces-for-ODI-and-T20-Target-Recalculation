%% RUN_Pre20L
% Single entry point. Pre20L audits roles and releases inputs; it never fits a model.
clear; clc;
Results = RevisedCodes_Pre20L_RunAll(); %#ok<NASGU>

