function [CaseMatrix,Endpoint,CarryForward,Descriptive,Operational,Independent,Guardrails,Attestation]=RevisedCodes_Pre20L_Adjudicate(Evidence,Hits,FileAudit,U)
caseIDs=unique(Evidence.MatchID,'stable');n=numel(caseIDs);
MatchID=caseIDs;DevelopmentTrain=false(n,1);DevelopmentValidation=false(n,1);DevelopmentTest=false(n,1);CandidateManifest=false(n,1);
ContextHistory=false(n,1);EmpiricalEstimation=false(n,1);Tuning=false(n,1);Confirmation=false(n,1);SensitivityAssessment=false(n,1);FrozenRefit=false(n,1);
IdentityVerified=false(n,1);PublishedTargetVerified=false(n,1);CompleteTimelineVerified=false(n,1);InitialAllocationsVerified=false(n,1);PenaltyConventionVerified=false(n,1);FirstInningsScoreBasisVerified=false(n,1);
EventStateVerified=false(n,1);AllRequiredEvidenceResolved=false(n,1);
for i=1:n
 q=Hits.MatchID==MatchID(i);sr=Hits.Subrole(q);r=Hits.Role(q);
 DevelopmentTrain(i)=any(sr=="DEVELOPMENT_TRAIN");DevelopmentValidation(i)=any(sr=="DEVELOPMENT_VALIDATION");DevelopmentTest(i)=any(sr=="DEVELOPMENT_TEST");CandidateManifest(i)=any(sr=="CANDIDATE_MANIFEST");
 ContextHistory(i)=any(r=="CONTEXT_HISTORY");EmpiricalEstimation(i)=any(r=="EMPIRICAL_ESTIMATION");Tuning(i)=any(r=="TUNING");Confirmation(i)=any(r=="CONFIRMATION");
 SensitivityAssessment(i)=any(r=="SENSITIVITY_ASSESSMENT");FrozenRefit(i)=any(r=="FROZEN_REFIT");
 IdentityVerified(i)=fieldAllVerified(Evidence,MatchID(i),"Identity",U);PublishedTargetVerified(i)=fieldAllVerified(Evidence,MatchID(i),"PublishedWinningTarget",U);
 CompleteTimelineVerified(i)=fieldAllVerified(Evidence,MatchID(i),"CompleteTimeline",U);InitialAllocationsVerified(i)=fieldAllVerified(Evidence,MatchID(i),"InitialAllocations",U);
 PenaltyConventionVerified(i)=fieldAllVerified(Evidence,MatchID(i),"PenaltyConvention",U);FirstInningsScoreBasisVerified(i)=fieldAllVerified(Evidence,MatchID(i),"FirstInningsScoreBasis",U);
 EventStateVerified(i)=fieldAllVerified(Evidence,MatchID(i),"InningsIndex",U)&&fieldAllVerified(Evidence,MatchID(i),"OversBowled",U)&& ...
  fieldAllVerified(Evidence,MatchID(i),"Score",U)&&fieldAllVerified(Evidence,MatchID(i),"WicketsLost",U);
 qCase=Evidence.MatchID==MatchID(i);resolved=U.Verified(Evidence.Status(qCase))|upper(Evidence.Status(qCase))=="NOT_APPLICABLE";AllRequiredEvidenceResolved(i)=all(resolved);
end
DirectDevelopmentOverlap=DevelopmentTrain|DevelopmentValidation;AnyPriorAnalyticUse=DirectDevelopmentOverlap|DevelopmentTest|ContextHistory|EmpiricalEstimation|Tuning|Confirmation|SensitivityAssessment|FrozenRefit;
roleAuditComplete=all(startsWith(FileAudit.ReadStatus,"READ_OK"));IndependenceStatus=strings(n,1);
for i=1:n
 if DevelopmentTrain(i),IndependenceStatus(i)="NOT_INDEPENDENT_DEVELOPMENT_TRAIN";
 elseif DevelopmentValidation(i),IndependenceStatus(i)="NOT_INDEPENDENT_DEVELOPMENT_VALIDATION";
 elseif Tuning(i),IndependenceStatus(i)="NOT_INDEPENDENT_TUNING";
 elseif EmpiricalEstimation(i),IndependenceStatus(i)="NOT_INDEPENDENT_EMPIRICAL_ESTIMATION";
 elseif Confirmation(i),IndependenceStatus(i)="NOT_UNTOUCHED_CONFIRMATION_USE";
 elseif SensitivityAssessment(i),IndependenceStatus(i)="NOT_UNTOUCHED_SENSITIVITY_USE";
 elseif ContextHistory(i),IndependenceStatus(i)="NOT_UNTOUCHED_CONTEXT_USE";
 elseif DevelopmentTest(i),IndependenceStatus(i)="RESERVED_TEST_OVERLAP";
 elseif FrozenRefit(i),IndependenceStatus(i)="NOT_INDEPENDENT_FROZEN_REFIT";
 elseif ~roleAuditComplete,IndependenceStatus(i)="UNRESOLVED_ROLE_AUDIT_INCOMPLETE";
 else,IndependenceStatus(i)="NO_DISCOVERED_OVERLAP_SCOPE_LIMITED";end
end
CaseMatrix=table(MatchID,DevelopmentTrain,DevelopmentValidation,DevelopmentTest,CandidateManifest,ContextHistory,EmpiricalEstimation,Tuning,Confirmation,SensitivityAssessment,FrozenRefit,DirectDevelopmentOverlap,AnyPriorAnalyticUse,IndependenceStatus);
EvidenceComplete=IdentityVerified&PublishedTargetVerified&CompleteTimelineVerified&InitialAllocationsVerified&PenaltyConventionVerified&FirstInningsScoreBasisVerified&EventStateVerified&AllRequiredEvidenceResolved;
DescriptiveEligible=EvidenceComplete;
OperationalEligible=EvidenceComplete&~DevelopmentTrain&~DevelopmentValidation&~Tuning&~EmpiricalEstimation;
% Independence is intentionally not releasable in Pre20L. It requires a separately
% locked temporal-test protocol (planned Step22), not merely absence from discovered files.
IndependentEligible=false(n,1);
Disposition=strings(n,1);BlockingReasons=strings(n,1);
for i=1:n
 b=strings(0,1);if ~IdentityVerified(i),b(end+1)="IDENTITY_UNVERIFIED";end;if ~PublishedTargetVerified(i),b(end+1)="TARGET_UNVERIFIED";end
 if ~CompleteTimelineVerified(i),b(end+1)="TIMELINE_UNVERIFIED";end;if ~InitialAllocationsVerified(i),b(end+1)="ALLOCATIONS_UNVERIFIED";end
 if ~PenaltyConventionVerified(i),b(end+1)="PENALTY_CONVENTION_UNVERIFIED";end;if ~FirstInningsScoreBasisVerified(i),b(end+1)="SCORE_BASIS_UNVERIFIED";end
 if ~EventStateVerified(i),b(end+1)="EVENT_STATE_UNVERIFIED";end;if ~AllRequiredEvidenceResolved(i),b(end+1)="REQUIRED_EVIDENCE_ROWS_UNRESOLVED";end
 if AnyPriorAnalyticUse(i),b(end+1)="PRIOR_ANALYTIC_USE";end;if ~roleAuditComplete,b(end+1)="ROLE_AUDIT_INCOMPLETE";end
 b(end+1)="INDEPENDENT_EVALUATION_REQUIRES_LOCKED_TEMPORAL_TEST";
 BlockingReasons(i)=U.Join(b);
 if IndependentEligible(i),Disposition(i)="INDEPENDENT_EVALUATION_RELEASED";elseif OperationalEligible(i),Disposition(i)="OPERATIONAL_COMPARISON_RELEASED_NOT_INDEPENDENT";
 elseif DescriptiveEligible(i),Disposition(i)="DESCRIPTIVE_ONLY_RELEASED";else,Disposition(i)="WITHHELD_PENDING_EVIDENCE_OR_ROLE_REVIEW";end
end
Endpoint=table(MatchID,IdentityVerified,PublishedTargetVerified,CompleteTimelineVerified,InitialAllocationsVerified,PenaltyConventionVerified,FirstInningsScoreBasisVerified,EventStateVerified,AllRequiredEvidenceResolved,EvidenceComplete,DescriptiveEligible,OperationalEligible,IndependentEligible,Disposition,BlockingReasons);
Descriptive=joinRelease(Evidence,CaseMatrix,Endpoint,DescriptiveEligible);Operational=joinRelease(Evidence,CaseMatrix,Endpoint,OperationalEligible);Independent=joinRelease(Evidence,CaseMatrix,Endpoint,IndependentEligible);
pending=~U.Verified(Evidence.Status)&upper(Evidence.Status)~="NOT_APPLICABLE";CarryForward=Evidence(pending,{'MatchID','EventOrder','Field','SubmittedValue','Status','SourceURL','ReviewNote'});
CarryForward=outerjoin(CarryForward,CaseMatrix(:,{'MatchID','DirectDevelopmentOverlap','SensitivityAssessment','IndependenceStatus'}),'Keys','MatchID','MergeKeys',true,'Type','left');
CarryForward.Priority=repmat("STANDARD",height(CarryForward),1);CarryForward.Priority(ismember(CarryForward.Field,["CompleteTimeline","InitialAllocations","PublishedWinningTarget"]))="HIGH";
CarryForward.Priority(ismember(CarryForward.MatchID,MatchID(~IdentityVerified)))="CRITICAL";CarryForward=sortrows(CarryForward,{'Priority','MatchID','EventOrder','Field'},["ascend","ascend","ascend","ascend"]);
Claim=["Descriptive recalculation";"Operational comparison";"Independent validation";"Frozen model performance";"Sensitivity independence"];
Rule=["Allowed only for rows in the descriptive release file; disclose prior-use roles.";"Allowed only for rows in the operational release file; do not label independent.";"Allowed only for rows in the independent release file and only after a locked temporal-test protocol.";"Do not refit, retune, or reinterpret Step19 from case outcomes.";"Step18 overlap means independence cannot be asserted without a documented pre-analysis firewall."];
CurrentStatus=[availability(height(Descriptive));availability(height(Operational));availability(height(Independent));"FROZEN_NO_CHANGE";"CANNOT_EXCLUDE_INFLUENCE"];
Guardrails=table(Claim,Rule,CurrentStatus);
Question=["Were the 40 cases or their outcomes inspected before Step19 specification selection was irrevocably locked?";"Did Step18 case evidence change any model, predictor, interaction, endpoint, subgroup, or reporting choice?";"Was an independent dated protocol or commit created before Step18 case review?";"Identify the documentary evidence supporting each answer."];
RequiredResponse=repmat("AUTHOR_RESPONSE_REQUIRED",4,1);Response=strings(4,1);EvidenceReference=strings(4,1);Attestation=table(Question,RequiredResponse,Response,EvidenceReference);
end

function tf=fieldAllVerified(E,id,field,U)
q=E.MatchID==id&E.Field==field;if ~any(q),tf=false;else,tf=all(U.Verified(E.Status(q)));end
end

function R=joinRelease(E,C,A,keep)
ids=A.MatchID(keep);R=E(ismember(E.MatchID,ids),:);if isempty(R),R=E([],:);end
R=outerjoin(R,C,'Keys','MatchID','MergeKeys',true,'Type','left');
R=outerjoin(R,A(:,{'MatchID','Disposition','BlockingReasons'}),'Keys','MatchID','MergeKeys',true,'Type','left');
end

function s=availability(n)
if n>0,s="AVAILABLE";else,s="NOT_AVAILABLE_N_ZERO";end
end
