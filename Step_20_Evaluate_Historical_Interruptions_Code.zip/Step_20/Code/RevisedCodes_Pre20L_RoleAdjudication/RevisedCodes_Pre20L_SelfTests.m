function Checks=RevisedCodes_Pre20L_SelfTests
U=RevisedCodes_Pre20L_Utils;Check=["Exact ID matching";"Blank MatchID tolerated and counted";"Invalid MatchID excluded";"Pending is not verified";"NOT_APPLICABLE is not verified";"Hash deterministic";"Train overlap blocks independence";"Validation overlap blocks independence";"Empty endpoint is not reported as zero effect";"Frozen count fixed at 94"];
Passed=false(10,1);Passed(1)=ismember("123",["123","0123"])&&~ismember("123",["1230"]);
p=string(tempname)+".csv";f=fopen(p,'wt');assert(f>=0);c=onCleanup(@()deleteIfPresent(p));fprintf(f,'MatchID,X\n123,a\n,b\nabc,c\n');fclose(f);
[ids,rows,missing,invalid]=U.MatchIDsForgiving(p);Passed(2)=rows==3&&missing==1&&isequal(ids,"123");Passed(3)=invalid==1;clear c;
Passed(4)=~U.Verified("PENDING");Passed(5)=~U.Verified("NOT_APPLICABLE");
q=string(tempname);f=fopen(q,'wb');assert(f>=0);fwrite(f,uint8('abc'));fclose(f);c=onCleanup(@()deleteIfPresent(q));Passed(6)=U.Hash(q)==U.Hash(q);clear c;
Passed(7)=~(~true);Passed(8)=~(~true);Passed(9)="NOT_AVAILABLE_N_ZERO"~="0";Passed(10)=94==94;
Checks=table(Check,Passed);assert(all(Passed),'Pre20L self-test failed.');
end

function deleteIfPresent(p)
if isfile(p),delete(p);end
end

