function D=RevisedCodes_Pre20L_LoadInputs(inputDir,work,U)
M=U.Read(fullfile(inputDir,'InputHashes.csv'));U.Require(M,["File","SHA256"]);
for k=1:height(M)
 p=fullfile(inputDir,M.File(k));assert(isfile(p),'Packaged input missing: %s',p);
 assert(U.Hash(p)==lower(M.SHA256(k)),'Packaged input changed: %s',M.File(k));
end
kDir=fullfile(work,'pre20k');jDir=fullfile(work,'pre20j');mkdir(kDir);mkdir(jDir);
unzip(fullfile(inputDir,'Pre20K_Checked.zip'),kDir);unzip(fullfile(inputDir,'Pre20J_Checked.zip'),jDir);
requiredK=["Pre20K_ExternalEvidenceDraft.csv","Pre20K_ExternalSourceRequests.csv", ...
 "Pre20K_RoleCandidateInventory.csv","Pre20K_MissingRawAudit.csv","Pre20K_ExecutionGates.csv","Pre20K_Summary.csv"];
for f=requiredK,assert(isfile(fullfile(kDir,f)),'Pre20K input missing %s.',f);end
requiredJ=["Pre20J_FrozenVerification.csv","Pre20J_ExecutionGates.csv"];
for f=requiredJ,assert(isfile(fullfile(jDir,f)),'Pre20J input missing %s.',f);end
D=struct;
D.Evidence=U.Read(fullfile(kDir,'Pre20K_ExternalEvidenceDraft.csv'));
D.Requests=U.Read(fullfile(kDir,'Pre20K_ExternalSourceRequests.csv'));
D.KInventory=U.Read(fullfile(kDir,'Pre20K_RoleCandidateInventory.csv'));
D.MissingRaw=U.Read(fullfile(kDir,'Pre20K_MissingRawAudit.csv'));
D.KGates=U.Read(fullfile(kDir,'Pre20K_ExecutionGates.csv'));
D.KSummary=U.Read(fullfile(kDir,'Pre20K_Summary.csv'));
D.Frozen=U.Read(fullfile(jDir,'Pre20J_FrozenVerification.csv'));
D.JGates=U.Read(fullfile(jDir,'Pre20J_ExecutionGates.csv'));
U.Require(D.Evidence,["MatchID","EventOrder","Field","SubmittedValue","Status","SourceURL","ReviewNote"]);
U.Require(D.KInventory,["Path","SHA256","SuggestedRole","ReviewStatus"]);
U.Require(D.Frozen,["Path","ExpectedSHA256"]);
assert(height(D.Frozen)==94,'Expected exactly 94 frozen files.');
assert(height(D.Evidence)==597,'Expected exactly 597 evidence rows.');
assert(all(U.Bool(D.KGates.Passed(D.KGates.Gate~="Step20 calculation authorized"))),'Required Pre20K gate failed.');
assert(all(U.Bool(D.JGates.Passed(D.JGates.Gate~="Step20 release available"))),'Required Pre20J gate failed.');
end

