function Results=RevisedCodes_Pre20L_RunAll(settings)
% PRE20L role adjudication and endpoint-specific release. No model fitting.
if nargin<1,settings=struct;end
assert(isstruct(settings)&&isscalar(settings),'Settings must be scalar struct.');
assert(all(ismember(fieldnames(settings),{'ProjectRoot','VerifyFrozenFiles'})),'Unknown setting.');
c.ProjectRoot="D:\VihaanProject1";c.VerifyFrozenFiles=true;
for n=reshape(string(fieldnames(settings)),1,[]),c.(n)=settings.(n);end
c.ProjectRoot=string(c.ProjectRoot);assert(isfolder(c.ProjectRoot),'Project root missing.');assert(isscalar(c.VerifyFrozenFiles)&&islogical(c.VerifyFrozenFiles),'VerifyFrozenFiles must be logical.');
U=RevisedCodes_Pre20L_Utils;here=fileparts(mfilename('fullpath'));input=fullfile(here,'input');
base=fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','pre20l_role_adjudication');if ~isfolder(base),mkdir(base);end
report=string(tempname(base));mkdir(report);work=string(tempname);mkdir(work);cleanupWork=onCleanup(@()safeRemove(work)); %#ok<NASGU>
diary(fullfile(report,'RunLog.txt'));cleanupDiary=onCleanup(@()diary('off')); %#ok<NASGU>
try
 Checks=RevisedCodes_Pre20L_SelfTests;U.Write(Checks,fullfile(report,'Pre20L_SelfTests.csv'));
 D=RevisedCodes_Pre20L_LoadInputs(input,work,U);caseIDs=unique(D.Evidence.MatchID,'stable');assert(numel(caseIDs)==40,'Expected 40 cases.');
 FrozenVerification=D.Frozen;FrozenVerification.CurrentSHA256=strings(height(FrozenVerification),1);FrozenVerification.Pre20LHashMatched=false(height(FrozenVerification),1);
 if c.VerifyFrozenFiles
  for k=1:height(FrozenVerification)
   assert(isfile(FrozenVerification.Path(k)),'Frozen file missing: %s',FrozenVerification.Path(k));
   FrozenVerification.CurrentSHA256(k)=U.Hash(FrozenVerification.Path(k));FrozenVerification.Pre20LHashMatched(k)=FrozenVerification.CurrentSHA256(k)==lower(FrozenVerification.ExpectedSHA256(k));
  end
  assert(all(FrozenVerification.Pre20LHashMatched),'Frozen Step19 file changed.');
 else
  FrozenVerification.CurrentSHA256(:)="NOT_RECHECKED";FrozenVerification.Pre20LHashMatched=U.Bool(FrozenVerification.HashMatched);
 end
 U.Write(FrozenVerification,fullfile(report,'Pre20L_FrozenVerification.csv'));
 [FileAudit,Hits,Coverage]=RevisedCodes_Pre20L_RoleAudit(c.ProjectRoot,D.KInventory,caseIDs,U);
 U.Write(FileAudit,fullfile(report,'Pre20L_RoleFileAudit.csv'));U.Write(Hits,fullfile(report,'Pre20L_CaseRoleHits.csv'));U.Write(Coverage,fullfile(report,'Pre20L_RoleCoverage.csv'));
 [CaseMatrix,Endpoint,CarryForward,Descriptive,Operational,Independent,Guardrails,Attestation]=RevisedCodes_Pre20L_Adjudicate(D.Evidence,Hits,FileAudit,U);
 U.Write(CaseMatrix,fullfile(report,'Pre20L_CaseRoleMatrix.csv'));U.Write(Endpoint,fullfile(report,'Pre20L_EndpointDisposition.csv'));
 U.Write(CarryForward,fullfile(report,'Pre20L_ExternalEvidenceCarryForward.csv'));U.Write(Guardrails,fullfile(report,'Pre20L_ManuscriptClaimGuardrails.csv'));
 U.Write(Attestation,fullfile(report,'Pre20L_Step18InfluenceAttestation_REQUIRED.csv'));
 U.Write(Descriptive,fullfile(report,'Pre20L_Step20_DescriptiveInput_RELEASE_ONLY_IF_NONEMPTY.csv'));
 U.Write(Operational,fullfile(report,'Pre20L_Step20_OperationalInput_RELEASE_ONLY_IF_NONEMPTY.csv'));
 U.Write(Independent,fullfile(report,'Pre20L_IndependentEvaluationInput_RELEASE_ONLY_IF_NONEMPTY.csv'));
 Summary=table(numel(caseIDs),height(FileAudit),nnz(startsWith(FileAudit.ReadStatus,"READ_OK")),sum(FileAudit.MissingMatchIDRows,'omitnan'), ...
  nnz(CaseMatrix.DevelopmentTrain),nnz(CaseMatrix.DevelopmentValidation),nnz(CaseMatrix.DevelopmentTest),nnz(CaseMatrix.SensitivityAssessment),nnz(CaseMatrix.FrozenRefit), ...
  nnz(Endpoint.DescriptiveEligible),nnz(Endpoint.OperationalEligible),nnz(Endpoint.IndependentEligible),height(CarryForward), ...
  'VariableNames',{'Cases','RoleFiles','ReadableRoleFiles','BlankMatchIDRows','TrainingOverlap','ValidationOverlap','TestOverlap','SensitivityOverlap','FrozenRefitOverlap','DescriptiveCasesReleased','OperationalCasesReleased','IndependentCasesReleased','PendingEvidenceRows'});
 U.Write(Summary,fullfile(report,'Pre20L_Summary.csv'));
 roleAuditComplete=all(startsWith(FileAudit.ReadStatus,"READ_OK"));
 Gate=["Packaged inputs hash verified";"Forty cases retained";"Frozen 94-file boundary unchanged";"All discovered role files readable";"No changed Pre20K role file";"Step20 descriptive calculation authorized";"Operational comparison authorized";"Independent evaluation authorized"];
 Passed=[true;numel(caseIDs)==40;all(FrozenVerification.Pre20LHashMatched);roleAuditComplete;~any(FileAudit.HashStatus=="HASH_MISMATCH");any(Endpoint.DescriptiveEligible);any(Endpoint.OperationalEligible);any(Endpoint.IndependentEligible)];
 Gates=table(Gate,Passed);U.Write(Gates,fullfile(report,'Pre20L_ExecutionGates.csv'));
 code=dir(fullfile(here,'*.m'));CodeHashes=table;
 for k=1:numel(code),CodeHashes=[CodeHashes;table(string(code(k).name),U.Hash(fullfile(code(k).folder,code(k).name)),'VariableNames',{'File','SHA256'})];end %#ok<AGROW>
 U.Write(CodeHashes,fullfile(report,'Pre20L_CodeHashes.csv'));
 Results=struct('Status',"ROLE_ADJUDICATED_ENDPOINT_RELEASES_GATED",'Settings',c,'Summary',Summary,'Gates',Gates);
 save(fullfile(report,'RevisedCodes_Pre20L_Result.mat'),'Results');disp(Summary);disp(Gates);
 diary off;zip(report+"_Checks.zip",{'*'},report);fprintf('Upload %s\n',report+"_Checks.zip");
catch err
 diary off;zip(report+"_FAILED_Checks.zip",{'*'},report);fprintf('Upload %s\n',report+"_FAILED_Checks.zip");rethrow(err);
end
end

function safeRemove(path)
if isfolder(path),rmdir(path,'s');end
end
