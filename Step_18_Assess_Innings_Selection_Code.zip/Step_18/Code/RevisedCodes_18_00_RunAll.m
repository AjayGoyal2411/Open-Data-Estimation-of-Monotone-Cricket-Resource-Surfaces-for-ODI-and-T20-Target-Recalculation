function Results=RevisedCodes_18_00_RunAll(settings)
% Single entry point: tests -> evidence reconstruction -> Step18 (never Step19).
if nargin<1,settings=struct;end
Results=struct;
Results.Reconstruction=RevisedCodes_18_00_ChaseReconstruction(settings);
Results.SelfTests=Results.Reconstruction.SelfTests;
if startsWith(string(Results.Reconstruction.Status),"BLOCKED")
 fprintf('Step18 remains blocked. Upload RevisedCodes_18_00_Checks.zip; do not run Step19.\n');return;
end
if isfield(settings,'RawJSONRoot'),settings=rmfield(settings,'RawJSONRoot');end
Results.Selection=RevisedCodes_18_01_InningsSelection(settings);
fprintf('Step18 finished. Upload BOTH RevisedCodes_18_00_Checks.zip and RevisedCodes_18_Checks.zip for review before Step19.\n');
end
