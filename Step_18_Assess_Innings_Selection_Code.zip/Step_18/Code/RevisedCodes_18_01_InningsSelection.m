function Result = RevisedCodes_18_01_InningsSelection(settings)
% Development-only first/second-innings selection and chase-censoring audit.
if nargin<1,settings=struct;end
U=RevisedCodes_17_19_Utils;c=U.Config(settings);[C,M,cacheInfo]=RevisedCodes_18_00_LoadCache(c);
root=fullfile(c.WorkRoot,'step18');report=fullfile(root,'reports',"run_"+cacheInfo.RunID);U.Ensure(report);selfTest;
M.CompletionClass=lower(string(M.CompletionClass));
first=number(M.InningsIndex)==1&U.Logical(M.ResponseEligible)&M.Gender=="men"&M.CacheEligible;
second=number(M.InningsIndex)==2&M.Gender=="men"&M.CacheEligible;
completed=second&(contains(M.CompletionClass,"chase_full_length")|contains(M.CompletionClass,"chase_all_out"));
censored=second&M.CompletionClass=="chase_success_verified_censored";
% Ledger eligibility does not imply that an allocation-aware state exists.
% Step09 deliberately stores NaN BallsRemaining for second innings. Do not
% fill it using nominal/initial allocation: interruptions can change it.
stateCounts=accumarray(double(C.MetaRow),1,[height(M) 1],@sum,0);
Coverage=M(:,{'MatchID','InningsIndex','Format','Gender','Date','CompletionClass','CacheEligible'});
Coverage.UsableCachedStates=stateCounts;
Coverage.CompletedChaseCandidate=completed;
Coverage.CensoredOrInterruptedCandidate=censored;
Coverage.AllocationSource=M.EvidenceLevel;
U.Write(Coverage,fullfile(report,'18_01_StateCoverage.csv'));
% A target inferred as S1+1 is not a verified chase target. A separately
% audited target/allocation join is required even if cached rows exist.
required=["ChaseAllocationVerified","ChaseTargetVerified"];
hasContract=all(ismember(required,string(M.Properties.VariableNames)));
verified=false(height(M),1);
if hasContract
 verified=U.Logical(M.ChaseAllocationVerified)&U.Logical(M.ChaseTargetVerified);
end
ready=verified&stateCounts>0;
if ~any(completed&ready)
 Reason="Second-innings allocation-aware states and verified targets are unavailable. Step09 leaves auxiliary BallsRemaining undefined; nominal allocation and S1+1 must not substitute for verified chase histories.";
 Pending=table("Verified chase state/target join",Reason,'VariableNames',{'Requirement','Reason'});
 Gates=table(["Coverage audit completed";"Verified completed-chase states available";"Target adjustment fitted";"Bootstrap evaluation performed"], ...
  [true;false;false;false],'VariableNames',{'Check','Passed'});
 Summary=table("BLOCKED_CHASE_ALLOCATION_TARGET_EVIDENCE",nnz(completed),nnz(completed&stateCounts>0),nnz(completed&ready), ...
  'VariableNames',{'Status','LedgerCompletedChases','CompletedChasesWithStates','VerifiedCompletedChases'});
 U.Write(Pending,fullfile(report,'18_01_PendingRequirements.csv'));
 U.Write(Gates,fullfile(report,'18_01_GateChecks.csv'));
 U.Write(Summary,fullfile(report,'18_01_QC_Summary.csv'));
 zipPath=fullfile(c.ProjectRoot,'RevisedCodes_18_Checks.zip');
 zip(zipPath,{'18_01_StateCoverage.csv','18_01_PendingRequirements.csv','18_01_GateChecks.csv','18_01_QC_Summary.csv'},report);
 Result=struct('Status',Summary.Status(1),'Gates',Gates,'ReportZIP',string(zipPath),'Reason',Reason,'Cache',cacheInfo);
 save(fullfile(root,'RevisedCodes_18_Result.mat'),'Result','-v7.3');
 fprintf('Step18 BLOCKED: verified chase allocation/target evidence required. Upload %s\n',zipPath);
 return;
end
completed=completed&ready;censored=censored&ready;
scores=table;populations=table;coefficients=table;curveDistance=table;
for fmt=["ODI","T20"]
 horizon=120;if fmt=="ODI",horizon=300;end
 standard=number(M.InitialAllocatedBalls)==horizon&M.Format==fmt&~isnat(M.Date)&M.Date<datetime(2023,1,1);
 for yr=2020:2022
  fitFirst=first&standard&M.Date<datetime(yr,1,1);fitSecond=completed&standard&M.Date<datetime(yr,1,1)&M.TargetAvailable;
  assessComplete=completed&standard&M.Date>=datetime(yr,1,1)&M.Date<datetime(yr+1,1,1)&M.TargetAvailable;
  assessCensored=censored&standard&M.Date>=datetime(yr,1,1)&M.Date<datetime(yr+1,1,1)&M.TargetAvailable;
  base=U.FitSingle(C,M,fitFirst,fmt,c);adj=fitAdjustment(C,M,fitSecond,base,horizon);
  coefficients=[coefficients;table("Fold_"+string(yr),fmt,adj.Beta(1),adj.Beta(2),adj.Beta(3),adj.Beta(4),adj.Beta(5), ...
   adj.TrainingStates,adj.TrainingInnings,'VariableNames',{'Fold','Format','Intercept','RequiredRate', ...
   'WicketsInHand','RemainingFraction','CurrentRunRate','TrainingStates','TrainingInnings'})]; %#ok<AGROW>
  scores=[scores;scoreCohort(C,M,assessComplete,base,adj,horizon,"Fold_"+string(yr),fmt,"completed_comparable",true,c)]; %#ok<AGROW>
  scores=[scores;scoreCohort(C,M,assessCensored,base,adj,horizon,"Fold_"+string(yr),fmt,"successful_censored_descriptive",false,c)]; %#ok<AGROW>
  populations=[populations;populationRows(M,fmt,yr,first,completed,censored,standard)]; %#ok<AGROW>
 end
 fullFirst=first&standard;fullSecond=completed&standard&M.TargetAvailable;
 A=U.FitSingle(C,M,fullFirst,fmt,c);B=U.FitSingle(C,M,fullSecond,fmt,c);
 for w=[10 7 5 3]
  d=B.Surface(:,w+1)-A.Surface(:,w+1);
  curveDistance=[curveDistance;table(fmt,w,mean(abs(d)),sqrt(mean(d.^2)),max(abs(d)), ...
   'VariableNames',{'Format','WicketsInHand','MeanAbsoluteResourceDifference','RMSEDifference','MaximumDifference'})]; %#ok<AGROW>
 end
end

SelectionBias=selectionSummary(M,first,completed,censored);
Gates=table(["Only 2020-2022 assessment years used";"2023 validation unopened";"2024+ temporal test unopened"; ...
 "Reserved cases excluded";"Successful chases labelled informatively censored"; ...
 "Censored outcomes excluded from comparable model ranking";"Target-aware adjustment trained inside each fold"], ...
 true(7,1),'VariableNames',{'Check','Passed'});
Assumptions=table(["First innings";"Completed unsuccessful/all-out chase";"Successful chase";"Target-aware adjustment"], ...
 ["Primary capacity sensitivity; still tactically influenced"; ...
  "Comparable only as a selected completed-second-innings cohort"; ...
  "Observed remaining runs end at target attainment and are not unrestricted capacity"; ...
  "Forecast sensitivity only; not admitted to resource target policy"], ...
 'VariableNames',{'CohortOrMethod','Interpretation'});
U.Write(populations,fullfile(report,'18_01_Populations.csv'));U.Write(scores,fullfile(report,'18_01_FoldScores.csv'));
U.Write(coefficients,fullfile(report,'18_01_TargetAdjustmentCoefficients.csv'));U.Write(curveDistance,fullfile(report,'18_01_CurveDistances.csv'));
U.Write(SelectionBias,fullfile(report,'18_01_SelectionSummary.csv'));U.Write(Gates,fullfile(report,'18_01_GateChecks.csv'));
U.Write(Assumptions,fullfile(report,'18_01_Assumptions.csv'));
fig=figure('Visible','off','Color','w','Position',[100 100 1300 700]);tiledlayout(2,2,'Padding','compact','TileSpacing','compact');
nexttile;plotPopulation(populations);title('Innings-selection populations');
nexttile;plotComparable(scores);title('Completed-chase prediction RMSE');
nexttile;plotBias(scores);title('Prediction bias by outcome status');
nexttile;plotDistance(curveDistance);title('First versus completed-second resource shape');
figPath=fullfile(report,'F_M18_01_InningsSelection_Preview.png');exportgraphics(fig,figPath,'Resolution',600);
pdfPath=fullfile(report,'F_M18_01_InningsSelection.pdf');exportgraphics(fig,pdfPath,'ContentType','vector');
editablePath=fullfile(report,'F_M18_01_InningsSelection.fig');savefig(fig,editablePath);close(fig);
tables=string(fullfile(report,{dir(fullfile(report,'*.csv')).name}));pub=U.Publish(c,'Step18_InningsSelection',tables,string({figPath,pdfPath,editablePath}));
zipPath=fullfile(c.ProjectRoot,'RevisedCodes_18_Checks.zip');files=dir(fullfile(report,'*'));zip(zipPath,{files(~[files.isdir]).name},report);
Result=struct('Status','INNINGS_SELECTION_COMPLETE_CENSORING_LIMITATION_RETAINED','Scores',scores, ...
 'Populations',populations,'Gates',Gates,'Cache',cacheInfo,'PublicationPaths',pub,'ReportZIP',string(zipPath));
save(fullfile(root,'RevisedCodes_18_Result.mat'),'Result','-v7.3');
fprintf('Step18 COMPLETE. Successful-chase outcomes remain descriptive only. Upload %s\n',zipPath);
end

function A=fitAdjustment(C,M,metaMask,base,horizon)
ids=find(metaMask);flag=false(height(M),1);flag(ids)=true;rows=flag(double(C.MetaRow));
[p,X,y,mid]=design(C,M,rows,base,horizon);delta=y-p;
assert(~isempty(y)&&numel(unique(mid))>=2,'Step18:EmptyTraining', ...
 'At least two verified training innings with usable states are required.');
assert(all(isfinite(X),'all')&&all(isfinite(delta)),'Step18:NonfiniteTraining','Nonfinite training design or response.');
mu=mean(X(:,2:end),1);sd=std(X(:,2:end),0,1);sd(sd<1e-10)=1;Z=[ones(size(X,1),1),(X(:,2:end)-mu)./sd];
ridge=1e-3;P=eye(size(Z,2));P(1,1)=0;
% Augmented least squares avoids squaring the design condition number.
beta=[Z;sqrt(ridge)*P]\[delta;zeros(size(Z,2),1)];
assert(all(isfinite(beta)),'Step18:NonfiniteFit','Adjustment coefficients are nonfinite.');
A=struct('Beta',beta,'Mean',mu,'SD',sd,'TrainingStates',numel(y),'TrainingInnings',numel(unique(mid)));
end
function [p,X,y,mid]=design(C,M,rows,base,horizon)
u=double(C.U(rows));w=double(C.W(rows));idx=u+1+(horizon+1)*w;p=base.Surface(idx)*base.Scale;
mr=double(C.MetaRow(rows));target=M.Target(mr);required=max(target-double(C.Score(rows)),0);
rr=6*required./max(u,1);cr=6*double(C.Score(rows))./max(double(C.BallsBowled(rows)),1);
X=[ones(numel(u),1),rr,w,u/horizon,cr];y=double(C.Outcome(rows));mid=mr;
end
function T=scoreCohort(C,M,metaMask,base,A,horizon,fold,fmt,cohort,comparable,c)
ids=find(metaMask);if isempty(ids),T=table;return;end
flag=false(height(M),1);flag(ids)=true;rows=flag(double(C.MetaRow));[p,X,y,mid]=design(C,M,rows,base,horizon);
assert(~isempty(y),'Step18:EmptyAssessment', ...
 'Assessment ledger has innings but no usable cached states. Review 18_01_StateCoverage.csv.');
assert(all(isfinite(X),'all')&&all(isfinite(y))&&all(isfinite(p)), ...
 'Step18:NonfiniteAssessment','Nonfinite assessment design, label or prediction.');
Z=[ones(size(X,1),1),(X(:,2:end)-A.Mean)./A.SD];pa=p+Z*A.Beta;
T=table;
for method=["resource_only";"target_aware_forecast"]'
 if method=="resource_only",pred=p;else,pred=pa;end
 e=pred-y;[u,~,g]=unique(mid);sse=accumarray(g,e.^2);sae=accumarray(g,abs(e));sb=accumarray(g,e);n=accumarray(g,1);
 [lo,hi]=bootstrap(sse,n,c.BootstrapReplicates,c.RandomSeed+numel(u));
 row=table(string(fold),string(fmt),string(cohort),method,logical(comparable),numel(u),numel(e), ...
  sqrt(mean(sse./n)),mean(sae./n),mean(sb./n),sqrt(mean(e.^2)),lo,hi, ...
  'VariableNames',{'Fold','Format','Cohort','Model','ComparableOutcome','Innings','States', ...
  'EqualInningsRMSE','EqualInningsMAE','EqualInningsBias','StateRMSE','RMSE_CI_Low','RMSE_CI_High'});
 T=[T;row]; %#ok<AGROW>
end
end
function T=populationRows(M,fmt,yr,first,completed,censored,standard)
inYear=M.Date>=datetime(yr,1,1)&M.Date<datetime(yr+1,1,1)&M.Format==fmt&standard;
T=table(repmat("Fold_"+string(yr),3,1),repmat(fmt,3,1),["first_innings";"completed_second";"successful_censored"], ...
 [nnz(inYear&first);nnz(inYear&completed);nnz(inYear&censored)], ...
 'VariableNames',{'Fold','Format','Cohort','Innings'});
end
function T=selectionSummary(M,first,completed,censored)
T=table;for fmt=["ODI","T20"],for name=["first";"completed_second";"successful_censored"]'
 if name=="first",q=first;elseif name=="completed_second",q=completed;else,q=censored;end
 q=q&M.Format==fmt&M.Date<datetime(2023,1,1);runs=number(M.DeliveryRuns(q));balls=number(M.InitialAllocatedBalls(q));
 T=[T;table(fmt,name,nnz(q),mean(runs,'omitnan'),median(runs,'omitnan'),mean(balls,'omitnan'), ...
  'VariableNames',{'Format','Cohort','Innings','MeanObservedRuns','MedianObservedRuns','MeanInitialAllocation'})]; %#ok<AGROW>
end,end
end
function [lo,hi]=bootstrap(sse,n,B,seed)
assert(~isempty(sse)&&numel(sse)==numel(n),'Step18:EmptyBootstrap','No usable innings for bootstrap.');
assert(all(isfinite(sse)&sse>=0)&all(isfinite(n)&n>0),'Step18:InvalidBootstrap','Invalid match statistics.');
if numel(sse)<2,lo=NaN;hi=NaN;return;end
validateattributes(B,{'numeric'},{'scalar','integer','positive'});
old=rng;restore=onCleanup(@()rng(old));rng(seed,'twister');m=numel(sse);v=zeros(B,1);
for b=1:B,q=randi(m,m,1);v(b)=sqrt(mean(sse(q)./n(q)));end
z=prctile(v,[2.5 97.5]);lo=z(1);hi=z(2);
end
function plotPopulation(T),g=groupsummary(T,{'Format','Cohort'},'sum','Innings');bar(g.sum_Innings);set(gca,'XTickLabel',g.Format+" "+g.Cohort);xtickangle(35);ylabel('Innings');grid on;end
function plotComparable(T),q=T.ComparableOutcome;g=groupsummary(T(q,:),{'Format','Model'},'mean','EqualInningsRMSE');bar(g.mean_EqualInningsRMSE);set(gca,'XTickLabel',g.Format+" "+g.Model);xtickangle(30);ylabel('RMSE');grid on;end
function plotBias(T),g=groupsummary(T,{'Format','Cohort','Model'},'mean','EqualInningsBias');bar(g.mean_EqualInningsBias);ylabel('Bias (runs)');grid on;end
function plotDistance(T),g=groupsummary(T,{'Format'},'mean','MeanAbsoluteResourceDifference');bar(g.mean_MeanAbsoluteResourceDifference);set(gca,'XTickLabel',g.Format);ylabel('Mean absolute resource difference');grid on;end
function y=number(x),if isnumeric(x),y=double(x);else,y=str2double(string(x));end,end
function selfTest
thrown=false;try,bootstrap([],[],10,1);catch ex,thrown=strcmp(ex.identifier,'Step18:EmptyBootstrap');end
assert(thrown,'Empty bootstrap must be rejected before randi.');
[lo,hi]=bootstrap(4,1,10,1);assert(isnan(lo)&&isnan(hi),'One innings cannot provide a match-bootstrap interval.');
[lo,hi]=bootstrap([4;4],[1;1],20,1);assert(lo==2&&hi==2);
end
