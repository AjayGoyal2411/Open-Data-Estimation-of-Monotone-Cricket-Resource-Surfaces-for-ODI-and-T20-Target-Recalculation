function [C,M,info]=RevisedCodes_18_00_LoadCache(c)
% Refuse the legacy cache or a stale/blocked reconstruction.
p=fullfile(c.WorkRoot,'step18_00','RevisedCodes_18_00_Current.mat');
assert(isfile(p),'Step1800:Missing','Run RevisedCodes_18_00_RunAll first.');
z=load(p,'Result');assert(string(z.Result.Status)=="READY_FOR_STEP18_SELECTION_AUDIT", ...
 'Step1800:Blocked','Step18_00 is blocked. Inspect its evidence and fold-readiness reports.');
q=load(z.Result.CachePath,'C','M','info');V=RevisedCodes_18_00_Utils;
assert(strcmp(q.info.Version,'18.00.1'),'Step1800:Version','Incompatible reconstruction version.');
V.CheckDependencies(q.info);C=q.C;M=q.M;info=q.info;
assert(all(M.CacheEligible(double(C.MetaRow))),'Cache contains excluded innings.');
assert(all(M.Date(double(C.MetaRow))<datetime(2023,1,1)),'Holdout state in development cache.');
end
