function Result=RevisedCodes_18_00_ChaseReconstruction(settings)
% Rebuild a separate development-only cache. Never modifies Step09 or Step17.
if nargin<1,settings=struct;end
Checks=RevisedCodes_18_00_SelfTests;
rawRoot="";if isfield(settings,'RawJSONRoot'),rawRoot=string(settings.RawJSONRoot);settings=rmfield(settings,'RawJSONRoot');end
U=RevisedCodes_17_19_Utils;V=RevisedCodes_18_00_Utils;c=U.Config(settings);
if rawRoot=="",rawRoot=string(fullfile(c.ProjectRoot,'JSONFiles'));end
assert(isfolder(rawRoot),'Step1800:RawRoot','Raw JSON folder missing: %s. Set settings.RawJSONRoot.',rawRoot);
root=fullfile(c.WorkRoot,'step18_00');U.Ensure(root);
% Unique runs preserve old evidence; Current points only to a completed run.
run=string(datetime('now','Format','yyyyMMdd_HHmmss_SSS'));folder=fullfile(root,"run_"+run);U.Ensure(folder);
report=fullfile(folder,'reports');U.Ensure(report);
elig=U.ResolveCSV(c,'09_04_SensitivityEligibility.csv','RevisedCodes_09_04_Checks.zip',folder);
opts=detectImportOptions(elig,'TextType','string','VariableNamingRule','preserve');
opts=setvartype(opts,'MatchID','string');M=readtable(elig,opts);
U.Require(M,["MatchID","InningsIndex","Format","Gender","Date","Split","BattingTeam", ...
 "RecordIntegrityOK","CachedStateAvailable","CachedReconstructionPassed","CaseStudyReserved", ...
 "ResponseEligible","InitialAllocatedBalls","BallsPerOver","DeliveryRuns","LegalBalls", ...
 "GenuineDismissals","CompletionClass"]);
M.MatchID=string(M.MatchID);M.Format=upper(strtrim(string(M.Format)));M.Gender=lower(strtrim(string(M.Gender)));
M.Gender(M.Gender=="male")="men";M.Gender(M.Gender=="female")="women";M.Date=U.Date(M.Date);
M.InningsIndex=U.Number(M.InningsIndex);M.Key=M.MatchID+"|"+string(M.InningsIndex);
assert(numel(unique(M.Key))==height(M),'Step1800:DuplicateLedger','Duplicate innings keys in ledger.');
scope=~U.Logical(M.CaseStudyReserved)&~isnat(M.Date)&M.Date<datetime(2023,1,1)& ...
 lower(string(M.Split))=="train"&M.Gender=="men"&ismember(M.Format,["ODI","T20"]);
integrity=U.Logical(M.RecordIntegrityOK)&U.Logical(M.CachedStateAvailable)& ...
 U.Logical(M.CachedReconstructionPassed)&U.Number(M.BallsPerOver)==6;
horizon=120*ones(height(M),1);horizon(M.Format=="ODI")=300;
first=scope&integrity&M.InningsIndex==1&U.Logical(M.ResponseEligible)&U.Number(M.InitialAllocatedBalls)==horizon;
second=scope&integrity&M.InningsIndex==2;
M.CacheEligible=false(height(M),1);M.Target=nan(height(M),1);M.TargetAvailable=false(height(M),1);
M.ChaseAllocationVerified=false(height(M),1);M.ChaseTargetVerified=false(height(M),1);
M.CompletionClass=string(M.CompletionClass);M.InitialAllocatedBalls=U.Number(M.InitialAllocatedBalls);
M.EvidenceLevel=repmat("Not admitted",height(M),1);
Audit=M(M.InningsIndex==2,{'MatchID','Format','Gender','Date','Split','CompletionClass'});
idx=find(M.InningsIndex==2);Audit.MetaRow=idx;Audit.InScope=scope(idx);Audit.RawPath=strings(height(Audit),1);
Audit.RawSHA256=strings(height(Audit),1);Audit.Target=nan(height(Audit),1);Audit.AllocatedBalls=nan(height(Audit),1);
Audit.FirstReconciled=false(height(Audit),1);Audit.ChaseReconciled=false(height(Audit),1);
Audit.Accepted=false(height(Audit),1);Audit.Reason=repmat("OUTSIDE_DEVELOPMENT_SCOPE",height(Audit),1);
Audit.Reason(scope(idx)&~integrity(idx))="LEDGER_INTEGRITY_OR_CACHE_GATE";
Audit.Reason(second(idx))="NOT_PROCESSED";
auditRow=zeros(height(M),1);auditRow(idx)=(1:numel(idx))';
files=dir(fullfile(rawRoot,'**','*.json'));names=string({files.name})';ids=erase(names,".json");
rawPaths=string(fullfile({files.folder},{files.name}))';
dependencies=V.Stamp(elig);dependencies(end+1)=V.Stamp(c.StateManifest);
codeNames=["RevisedCodes_18_00_ChaseReconstruction","RevisedCodes_18_00_Utils", ...
 "RevisedCodes_18_00_LoadCache","RevisedCodes_18_01_InningsSelection","RevisedCodes_17_19_Utils"];
for name=codeNames,dependencies(end+1)=V.Stamp(which(char(name)));end %#ok<AGROW>
% Evidence objects hold only filenames here; delivery arrays are parsed one match at a time.
firstPartner=zeros(height(M),1);partnerChase=zeros(height(M),1);
for j=find(second)'
 a=auditRow(j);one=find(M.MatchID==M.MatchID(j)&M.InningsIndex==1);
 if numel(one)~=1||~first(one),Audit.Reason(a)="NO_ELIGIBLE_COMPLETED_FIRST_INNINGS";continue;end
 firstPartner(j)=one;partnerChase(one)=j;
 hits=find(ids==M.MatchID(j));
 if isempty(hits),Audit.Reason(a)="RAW_JSON_NOT_FOUND_YAML_NOT_IMPLEMENTED";continue;end
 if numel(hits)~=1,Audit.Reason(a)="AMBIGUOUS_RAW_JSON_ID";continue;end
 p=rawPaths(hits);Audit.RawPath(a)=p;dependencies(end+1)=V.Stamp(p); %#ok<AGROW>
 Audit.RawSHA256(a)=V.Hash(p);
 try,d=jsondecode(fileread(p));catch,Audit.Reason(a)="INVALID_JSON";continue;end
 try
  E=V.Inspect(d,horizon(j));verifyLedger(E,M,one,j,U);
  Audit.Target(a)=E.Target;Audit.AllocatedBalls(a)=E.AllocatedBalls;Audit.CompletionClass(a)=E.Cohort;
  Audit.Reason(a)="AWAITING_DELIVERY_RECONCILIATION";
 catch ex
  if strcmp(ex.identifier,'Step1800:Evidence'),Audit.Reason(a)=string(ex.message);else,rethrow(ex);end
 end
 if mod(a,250)==0,fprintf('Step18_00 raw evidence %d/%d\n',a,height(Audit));end
end
z=load(c.StateManifest,'Result');P=z.Result.Partitions;U.Require(P,"Path");
parts=cell(height(M),1);seen=false(height(M),1);
for k=1:height(P)
 p=string(P.Path(k));dependencies(end+1)=V.Stamp(p);q=load(p,'States');S=q.States; %#ok<AGROW>
 U.Require(S,["MatchID","InningsIndex","StateType","DeliverySeq","CorrectedIsLegalBall", ...
  "BallsRemaining","WicketsInHand","DeliveryScoreBefore","FinalDeliveryRuns","LegalBallsBowled", ...
  "RecordIntegrityPassed","MatchDate","CaseReserved","Split","Format"]);
 keys=string(S.MatchID)+"|"+string(U.Number(S.InningsIndex));[found,loc]=ismember(keys,M.Key);
 use=found;use(found)=first(loc(found))|second(loc(found));
 for j=unique(loc(use))'
  assert(~seen(j),'Step1800:SplitInnings','Innings appears in more than one partition: %s',M.Key(j));seen(j)=true;
  T=S(loc==j,:);T=T(string(T.StateType)=="delivery",:);T=sortrows(T,'DeliverySeq');
  if isempty(T),continue;end
  % Runtime assertions protect the development-only boundary, not just report labels.
  assert(all(U.Date(T.MatchDate)==M.Date(j))&&all(~U.Logical(T.CaseReserved))&& ...
   all(lower(string(T.Split))=="train")&&all(string(T.Format)==M.Format(j)), ...
   'Step1800:ScopeMismatch','State/ledger scope disagreement: %s',M.Key(j));
  assert(all(U.Logical(T.RecordIntegrityPassed)),'Step1800:Integrity','State integrity mismatch.');
  if first(j)
   u=U.Number(T.BallsRemaining);
   assert(all(u==horizon(j)-U.Number(T.LegalBallsBowled)),'First-innings allocation mismatch.');
   parts{j}=pack(T,u,j,U);parts{j}(:,8)=k;M.CacheEligible(j)=~isempty(parts{j});
   M.EvidenceLevel(j)="Step09 verified primary first innings; legal delivery pre-states";
   chase=partnerChase(j);if chase==0,continue;end;a=auditRow(chase);
   if Audit.Reason(a)~="AWAITING_DELIVERY_RECONCILIATION",continue;end
   try
    E=V.Inspect(jsondecode(fileread(Audit.RawPath(a))),horizon(j));V.Reconcile(T,E.First,horizon(j),true);
    Audit.FirstReconciled(a)=true;
   catch ex
    if strcmp(ex.identifier,'Step1800:Evidence'),Audit.Reason(a)="FIRST_"+string(ex.message);else,rethrow(ex);end
   end
  else
   a=auditRow(j);if Audit.Reason(a)~="AWAITING_DELIVERY_RECONCILIATION",continue;end
   try
    E=V.Inspect(jsondecode(fileread(Audit.RawPath(a))),horizon(j));V.Reconcile(T,E.Second,horizon(j),false);
    u=E.AllocatedBalls-U.Number(T.LegalBallsBowled);parts{j}=pack(T,u,j,U);parts{j}(:,8)=k;
    Audit.ChaseReconciled(a)=~isempty(parts{j});
   catch ex
    if strcmp(ex.identifier,'Step1800:Evidence'),Audit.Reason(a)="CHASE_"+string(ex.message);else,rethrow(ex);end
   end
  end
 end
 fprintf('Step18_00 corrected-state reconciliation %d/%d\n',k,height(P));
end
for a=1:height(Audit)
 j=Audit.MetaRow(a);ok=Audit.FirstReconciled(a)&&Audit.ChaseReconciled(a)&& ...
  Audit.Reason(a)=="AWAITING_DELIVERY_RECONCILIATION";
 Audit.Accepted(a)=ok;
 if ok
  Audit.Reason(a)="ACCEPTED_STANDARD_NO_RECORDED_REVISION";
  M.CacheEligible(j)=true;M.Target(j)=Audit.Target(a);M.TargetAvailable(j)=true;
  M.InitialAllocatedBalls(j)=Audit.AllocatedBalls(a);M.CompletionClass(j)=Audit.CompletionClass(a);
  M.ChaseAllocationVerified(j)=true;M.ChaseTargetVerified(j)=true;
  M.EvidenceLevel(j)="Explicit raw target/allocation; both innings reconciled; no recorded revision (not independent history verification)";
 else
  parts{j}=[];
  if Audit.Reason(a)=="AWAITING_DELIVERY_RECONCILIATION",Audit.Reason(a)="MISSING_FIRST_OR_CHASE_DELIVERY_STATES";end
 end
end
V.CheckDependencies(struct('Dependencies',dependencies));
allRows=vertcat(parts{:});if isempty(allRows),allRows=zeros(0,8);end
C=struct('MetaRow',uint32(allRows(:,1)),'U',uint16(allRows(:,2)), ...
 'W',uint8(allRows(:,3)),'Score',single(allRows(:,4)),'Outcome',single(allRows(:,5)), ...
 'BallsBowled',uint16(allRows(:,6)),'DeliverySeq',uint32(allRows(:,7)),'StatePartition',uint32(allRows(:,8)));
FoldReadiness=readiness(C,M,U);
ready=all(FoldReadiness.Ready)&&height(FoldReadiness)==6;
status="BLOCKED_INSUFFICIENT_VERIFIED_CHASE_COHORTS";if ready,status="READY_FOR_STEP18_SELECTION_AUDIT";end
Exclusions=groupsummary(Audit,{'InScope','Accepted','Reason'});
Summary=table(status,nnz(Audit.InScope),nnz(Audit.Accepted),nnz(M.CacheEligible&M.InningsIndex==1), ...
 nnz(Audit.Accepted&contains(Audit.CompletionClass,'success_verified')),numel(C.U), ...
 'VariableNames',{'Status','InScopeChases','AcceptedChases','FirstInningsWithStates','SuccessfulCensoredChases','States'});
Gates=table(["Only pre-2023 nonreserved training states";"Only legal delivery pre-states"; ...
 "Explicit target and standard allocation required";"Both innings delivery reconciliation required"; ...
 "All six development fold cohorts supported";"Interrupted/revised histories independently verified"], ...
 [true;true;true;true;ready;false],'VariableNames',{'Check','Passed'});
info=struct('Version','18.00.1','RunID',run,'Status',status,'Dependencies',dependencies, ...
 'Partitions',P,'Path',string(fullfile(folder,'18_00_StateCache.mat')), ...
 'EvidenceLimitation','Standard records only. Absence of a recorded revision is not independent proof of no interruption.', ...
 'FoldReadiness',FoldReadiness);
save(info.Path,'C','M','info','-v7.3');
U.Write(Audit,fullfile(report,'18_00_ChaseEvidenceLedger.csv'));
U.Write(Exclusions,fullfile(report,'18_00_ExclusionCounts.csv'));
U.Write(FoldReadiness,fullfile(report,'18_00_FoldReadiness.csv'));
U.Write(Summary,fullfile(report,'18_00_QC_Summary.csv'));U.Write(Gates,fullfile(report,'18_00_GateChecks.csv'));
U.Write(Checks,fullfile(report,'18_00_SelfTests.csv'));
plotCoverage(Audit,FoldReadiness,report);
zipPath=fullfile(c.ProjectRoot,'RevisedCodes_18_00_Checks.zip');list=dir(fullfile(report,'*'));
zip(zipPath,{list(~[list.isdir]).name},report);
Result=struct('Status',status,'CachePath',info.Path,'ReportZIP',string(zipPath),'Summary',Summary,'Gates',Gates,'SelfTests',Checks);
save(fullfile(folder,'RevisedCodes_18_00_Result.mat'),'Result','-v7.3');
save(fullfile(root,'RevisedCodes_18_00_Current.mat'),'Result');
disp(Summary);fprintf('Upload %s\n',zipPath);
end

function verifyLedger(E,M,one,two,U)
if E.Date~=M.Date(two)||E.Date~=M.Date(one)||M.Format(one)~=M.Format(two)
 error('Step1800:Evidence','RAW_LEDGER_DATE_OR_FORMAT');
end
for pair=[one two;1 2]
 j=pair(1);if pair(2)==1,A=E.First;else,A=E.Second;end
 if string(M.BattingTeam(j))~=A.Team||U.Number(M.DeliveryRuns(j))~=A.Runs|| ...
  U.Number(M.LegalBalls(j))~=A.LegalBalls||U.Number(M.GenuineDismissals(j))~=A.Wickets
  error('Step1800:Evidence','RAW_LEDGER_TOTALS_OR_TEAM');
 end
end
end
function x=pack(T,u,j,U)
w=U.Number(T.WicketsInHand);score=U.Number(T.DeliveryScoreBefore);y=U.Number(T.FinalDeliveryRuns)-score;
keep=U.Number(T.CorrectedIsLegalBall)==1&w>0&u>0;
x=[repmat(j,nnz(keep),1),u(keep),w(keep),score(keep),y(keep), ...
 U.Number(T.LegalBallsBowled(keep)),U.Number(T.DeliverySeq(keep)),zeros(nnz(keep),1)];
assert(all(isfinite(x),'all')&&all(x>=0,'all')&&all(x==floor(x),'all'),'Step1800:InvalidState','Nonfinite, negative or fractional state.');
assert(all(w(keep)<=10),'Wickets outside 0..10.');
end
function F=readiness(C,M,U)
counts=accumarray(double(C.MetaRow),1,[height(M) 1],@sum,0);has=counts>0;
first=M.CacheEligible&M.InningsIndex==1&U.Logical(M.ResponseEligible)&has;
second=M.CacheEligible&M.ChaseAllocationVerified&M.ChaseTargetVerified&has& ...
 (contains(M.CompletionClass,'chase_full_length')|contains(M.CompletionClass,'chase_all_out'));
F=table;
for fmt=["ODI","T20"],for yr=2020:2022
 train=M.Format==fmt&M.Date<datetime(yr,1,1);assess=M.Format==fmt&year(M.Date)==yr;
 n1=nnz(first&train);n2=nnz(second&train);n3=nnz(second&assess);
 F=[F;table(fmt,yr,n1,n2,n3,n1>=2&&n2>=2&&n3>=2, ...
  'VariableNames',{'Format','AssessmentYear','FirstTrainingInnings','ChaseTrainingInnings','ChaseAssessmentInnings','Ready'})]; %#ok<AGROW>
end,end
end
function plotCoverage(A,F,p)
f=figure('Visible','off','Color','w','Position',[100 100 1100 440]);clean=onCleanup(@()close(f));
tiledlayout(1,2,'Padding','compact');nexttile;
bar([nnz(A.InScope&~A.Accepted),nnz(A.Accepted)]);xticklabels({'Excluded/pending','Accepted standard'});
ylabel('Development chases');title('Evidence coverage (not model performance)');grid on;
nexttile;bar([F.ChaseTrainingInnings,F.ChaseAssessmentInnings]);
xticks(1:height(F));xticklabels(F.Format+" "+string(F.AssessmentYear));xtickangle(35);
legend('Training','Assessment','Location','best');ylabel('Completed chases');title('Fold support');grid on;
exportgraphics(f,fullfile(p,'F_18_00_Coverage.png'),'Resolution',300);
exportgraphics(f,fullfile(p,'F_18_00_Coverage.pdf'),'ContentType','vector');savefig(f,fullfile(p,'F_18_00_Coverage.fig'));
end
