function Checks=RevisedCodes_18_00_SelfTests
% Executable regression tests using synthetic data, not project outcomes.
V=RevisedCodes_18_00_Utils;names=strings(0,1);
d=fixture("full");E=V.Inspect(d,120);
assert(E.Target==121&&E.AllocatedBalls==120&&E.Cohort=="chase_full_length_selected");add("Completed unsuccessful chase");
d=fixture("success");E=V.Inspect(d,120);
assert(E.Successful&&E.Cohort=="chase_success_verified_censored");add("Successful chase stays censored");
d=fixture("tie");E=V.Inspect(d,120);assert(~E.Successful);add("Tie is completed, not successful");
d=fixture("allout");E=V.Inspect(d,120);assert(E.Second.Wickets==10&&contains(E.Cohort,"all_out"));add("Early all-out completed chase");
d=fixture("full");d.innings{2}=rmfield(d.innings{2},'target');reject(d,"EXPLICIT_TARGET_MISSING");add("Missing target rejected");
d=fixture("full");d.info.outcome.method='D/L';reject(d,"ADJUSTED_TARGET_METHOD");add("Adjusted method rejected");
d=fixture("full");d.innings{2}.target.overs=19;reject(d,"REVISED_OR_NONSTANDARD_CHASE_ALLOCATION");add("Reduced allocation rejected");
d=fixture("full");d.innings{2}.target.overs=19.6;reject(d,"INVALID_OVER_NOTATION");add("Invalid cricket notation rejected");
d=fixture("full");d.innings{2}.target.runs=100;reject(d,"REVISED_OR_INCONSISTENT_TARGET");add("Revised or inconsistent target rejected");
d=fixture("success");d.info.outcome.winner='A';reject(d,"OUTCOME_TARGET_CONTRADICTION");add("Winner contradiction rejected");
d=fixture("success");d.innings{2}.overs{end}.deliveries{end}.runs=struct('total',0,'batter',0,'extras',0);
reject(d,"UNRESOLVED_CHASE_TERMINATION");add("Unresolved stopped chase rejected");
d=fixture("full");d.innings{2}.penalty_runs=struct('pre',5);reject(d,"PENALTY_RUNS_REQUIRE_REVIEW");add("Penalty cases require review");
d=fixture("full");d.innings{2}.miscounted_overs=struct('x1',5);reject(d,"ABSENCE_MISCOUNT_OR_NONSTANDARD_ENDING");add("Miscounted overs rejected");
d=fixture("full");d.innings{2}.overs{1}.deliveries{1}.wickets=struct('kind','retired hurt');
reject(d,"RETIREMENT_OR_UNKNOWN_DISMISSAL");add("Retirement reconstruction deferred");
d=fixture("full");d.innings{2}.overs{1}.over=1;reject(d,"OVER_SEQUENCE");add("Over sequence checked");
d=fixture("full");v=struct('runs',struct('total',1,'batter',0,'extras',1),'extras',struct('wides',1));
d.innings{2}.overs{1}.deliveries=[{v};d.innings{2}.overs{1}.deliveries(:)];
E=V.Inspect(d,120);assert(E.Second.LegalBalls==120&&height(E.Second.Delivery)==121);
assert(E.Second.Delivery.BallsBefore(2)==0&&E.Second.Delivery.ScoreBefore(2)==1);add("Wide does not consume allocation");
S=cacheTable(E.Second,120);V.Reconcile(S,E.Second,120,false);add("Delivery-by-delivery cache reconciliation");
S.DeliveryScoreBefore(5)=999;thrown=false;
try,V.Reconcile(S,E.Second,120,false);catch ex,thrown=strcmp(ex.identifier,'Step1800:Evidence');end
assert(thrown);add("Cache mismatch rejected");
d=fixture("full");E=V.Inspect(d,120);S=cacheTable(E.First,120);V.Reconcile(S,E.First,120,true);
S.BallsRemaining(5)=NaN;thrown=false;
try,V.Reconcile(S,E.First,120,true);catch ex,thrown=strcmp(ex.identifier,'Step1800:Evidence');end
assert(thrown);add("First-innings allocation independently reconciled");
d=fixture("success");d.innings{2}.overs{end}.deliveries{end+1}=d.innings{2}.overs{end}.deliveries{end};
reject(d,"DELIVERY_AFTER_TARGET_REACHED");add("Post-target delivery rejected");
Checks=table(names,true(numel(names),1),'VariableNames',{'Check','Passed'});disp(Checks);
fprintf('Step18_00 synthetic evidence tests passed. Project-level evidence checks run next.\n');
 function add(s),names(end+1,1)=s;end
 function reject(x,reason)
  thrown=false;try,V.Inspect(x,120);catch ex
   thrown=strcmp(ex.identifier,'Step1800:Evidence')&&string(ex.message)==reason;
   if ~thrown,rethrow(ex);end
  end
  assert(thrown,'Expected evidence rejection: %s',reason);
 end
end
function d=fixture(kind)
d=struct;d.info=struct('overs',20,'balls_per_over',6,'gender','male','match_type','T20', ...
 'dates',{{'2021-02-03'}},'teams',{{'A','B'}},'outcome',struct('winner','A'));
a=struct('team','A','overs',{overs(120,1,false)});
b=struct('team','B','overs',{overs(120,0,false)},'target',struct('runs',121,'overs',20));
if kind=="success",b.overs=overs(61,2,false);d.info.outcome.winner='B';end
if kind=="tie",b.overs=overs(120,1,false);d.info.outcome=struct('result','tie');end
if kind=="allout",b.overs=overs(10,0,true);end
d.innings={a;b};
end
function oo=overs(n,r,wickets)
oo=cell(ceil(n/6),1);
for k=1:numel(oo)
 dd=cell(min(6,n-6*(k-1)),1);
 for j=1:numel(dd)
  v=struct('runs',struct('total',r,'batter',r,'extras',0));
  if wickets,v.wickets=struct('kind','bowled');end
  dd{j}=v;
 end
 oo{k}=struct('over',k-1,'deliveries',{dd});
end
end
function S=cacheTable(A,h)
D=A.Delivery;S=D;
S.Properties.VariableNames={'DeliverySeq','CorrectedIsLegalBall','DeliveryRuns','RunsOffBat','ExtrasRuns', ...
 'GenuineDismissalsOnDelivery','LegalBallsBowled','GenuineWicketsLost','DeliveryScoreBefore'};
n=height(S);S.StateType=repmat("delivery",n,1);S.RecordedBattingTeam=repmat(A.Team,n,1);
S.FinalDeliveryRuns=repmat(A.Runs,n,1);S.WicketsInHand=10-D.WicketsBefore;
S.ScoreboardBefore=D.ScoreBefore;S.RetiredNotOutEvents=zeros(n,1);S.BallsRemaining=h-D.BallsBefore;
end
