function U=RevisedCodes_18_00_Utils
% Pure, fail-closed JSON evidence checks; no inferred chase targets.
U.Inspect=@inspect; U.Reconcile=@reconcile; U.Stamp=@stamp; U.Hash=@hashFile;
U.Items=@items; U.CheckDependencies=@checkDependencies;
end

function E=inspect(d,horizon)
validateattributes(horizon,{'numeric'},{'scalar','integer','positive'});
need(isstruct(d)&&isfield(d,'info')&&isfield(d,'innings'),'RAW_SCHEMA');
info=d.info; need(isfield(info,'overs')&&isfield(info,'balls_per_over'),'ALLOCATION_MISSING');
need(num(info.overs)*6==horizon&&num(info.balls_per_over)==6,'NONSTANDARD_ALLOCATION');
need(isfield(info,'gender')&&lower(string(info.gender))=="male",'RAW_GENDER_MISMATCH');
need(isfield(info,'match_type'),'FORMAT_MISSING');
fmt=upper(string(info.match_type));
need((horizon==300&&fmt=="ODI")||(horizon==120&&ismember(fmt,["T20","IT20"])),'RAW_FORMAT_MISMATCH');
need(isfield(info,'outcome'),'OUTCOME_MISSING'); o=info.outcome;
need(~isfield(o,'method')||strlength(string(o.method))==0,'ADJUSTED_TARGET_METHOD');
need(~isfield(o,'eliminator')&&~isfield(o,'bowl_out'),'TIEBREAKER_REQUIRES_REVIEW');
need(~isfield(o,'result')||ismember(lower(string(o.result)),["tie",""]),'NO_RESULT_OR_OTHER_OUTCOME');
need(isfield(info,'dates')&&~isempty(info.dates),'RAW_DATE_MISSING');
dates=string(info.dates);
try,date=datetime(dates(1),'InputFormat','yyyy-MM-dd');catch,error('Step1800:Evidence','INVALID_RAW_DATE');end
need(~isnat(date),'INVALID_RAW_DATE');
ii=items(d.innings); need(numel(ii)==2,'NOT_TWO_REGULATION_INNINGS');
A=innings(ii{1},horizon); B=innings(ii{2},horizon);
need(A.Team~=B.Team,'BATTING_TEAM_CONFLICT');
need(isfield(info,'teams')&&isequal(sort(string(info.teams(:))),sort([A.Team;B.Team])),'RAW_TEAMS_MISMATCH');
need(A.LegalBalls==horizon||A.Wickets==10,'FIRST_INNINGS_NOT_COMPLETED');
need(isfield(ii{2},'target')&&isstruct(ii{2}.target),'EXPLICIT_TARGET_MISSING');
t=ii{2}.target; need(isfield(t,'runs')&&isfield(t,'overs'),'TARGET_OR_ALLOCATION_MISSING');
target=num(t.runs); allocated=oversBalls(t.overs);
need(isfinite(target)&&target>0&&target==floor(target),'INVALID_TARGET');
need(allocated==horizon,'REVISED_OR_NONSTANDARD_CHASE_ALLOCATION');
need(target==A.Runs+1,'REVISED_OR_INCONSISTENT_TARGET');
need(all(B.Delivery.ScoreBefore<target),'DELIVERY_AFTER_TARGET_REACHED');
success=B.Runs>=target; exhausted=B.LegalBalls==horizon||B.Wickets==10;
if success
 need(isfield(o,'winner')&&string(o.winner)==B.Team,'OUTCOME_TARGET_CONTRADICTION');
 need(~isfield(o,'result')||strlength(string(o.result))==0,'OUTCOME_TARGET_CONTRADICTION');
 cohort="chase_success_verified_censored";
else
 need(exhausted,'UNRESOLVED_CHASE_TERMINATION');
 if B.Runs==A.Runs
  need(isfield(o,'result')&&lower(string(o.result))=="tie"&&~isfield(o,'winner'),'TIE_OUTCOME_CONTRADICTION');
 else
  need(isfield(o,'winner')&&string(o.winner)==A.Team,'OUTCOME_TARGET_CONTRADICTION');
  need(~isfield(o,'result')||strlength(string(o.result))==0,'OUTCOME_TARGET_CONTRADICTION');
 end
 if B.Wickets==10,cohort="chase_all_out_selected";else,cohort="chase_full_length_selected";end
end
E=struct('First',A,'Second',B,'Target',target,'AllocatedBalls',allocated, ...
 'Date',date,'Cohort',cohort,'Successful',success, ...
 'EvidenceLevel',"Explicit JSON target; standard allocation; no recorded revision; raw/cache reconciliation required");
end

function A=innings(e,horizon)
need(isstruct(e)&&isfield(e,'team')&&isfield(e,'overs'),'INNINGS_SCHEMA');
need(~isfield(e,'super_over')||~logical(e.super_over),'SUPER_OVER');
for f=["absent_hurt","miscounted_overs","declared","forfeited"]
 need(~isfield(e,f)||isempty(e.(f)),'ABSENCE_MISCOUNT_OR_NONSTANDARD_ENDING');
end
if isfield(e,'penalty_runs')
 p=e.penalty_runs;
 for f=["pre","post"],need(~isfield(p,f)||num(p.(f))==0,'PENALTY_RUNS_REQUIRE_REVIEW');end
end
oo=items(e.overs); need(~isempty(oo),'EMPTY_INNINGS');
runs=zeros(0,1);legal=runs;wk=runs;bat=runs;extras=runs;
kinds=["bowled","caught","caught and bowled","lbw","stumped","run out","hit wicket", ...
 "obstructing the field","hit the ball twice","handled the ball","timed out","retired out"];
for k=1:numel(oo)
 ov=oo{k};need(isfield(ov,'over')&&num(ov.over)==k-1&&isfield(ov,'deliveries'),'OVER_SEQUENCE');
 dd=items(ov.deliveries);need(~isempty(dd),'EMPTY_OVER');start=numel(legal);
 for j=1:numel(dd)
  v=dd{j};need(isfield(v,'runs')&&all(isfield(v.runs,{'total','batter','extras'})),'RUNS_SCHEMA');
  rr=[num(v.runs.total),num(v.runs.batter),num(v.runs.extras)];
  need(all(isfinite(rr)&rr>=0&rr==floor(rr))&&rr(1)==rr(2)+rr(3),'INVALID_RUNS');
  ex=struct;if isfield(v,'extras'),ex=v.extras;end
  need(~isfield(ex,'penalty')||num(ex.penalty)==0,'PENALTY_RUNS_REQUIRE_REVIEW');
  wide=0;nb=0;if isfield(ex,'wides'),wide=num(ex.wides);end;if isfield(ex,'noballs'),nb=num(ex.noballs);end
  need(all(isfinite([wide nb])&[wide nb]>=0&[wide nb]==floor([wide nb])),'INVALID_EXTRAS');
  extraNames=fieldnames(ex);extraTotal=0;
  for ef=extraNames'
   need(ismember(string(ef{1}),["wides","noballs","byes","legbyes","penalty"]),'UNKNOWN_EXTRAS_KIND');
   val=num(ex.(ef{1}));need(isfinite(val)&&val>=0&&val==floor(val),'INVALID_EXTRAS');extraTotal=extraTotal+val;
  end
  need(extraTotal==rr(3),'EXTRAS_TOTAL_MISMATCH');
  count=0;if isfield(v,'wickets')
   ww=items(v.wickets);
   for z=1:numel(ww)
    need(isfield(ww{z},'kind'),'WICKET_SCHEMA');kind=lower(string(ww{z}.kind));
    need(ismember(kind,kinds),'RETIREMENT_OR_UNKNOWN_DISMISSAL');count=count+1;
   end
  end
  runs(end+1,1)=rr(1);bat(end+1,1)=rr(2);extras(end+1,1)=rr(3); %#ok<AGROW>
  legal(end+1,1)=double(wide==0&&nb==0);wk(end+1,1)=count; %#ok<AGROW>
 end
 nLegal=sum(legal(start+1:end));need(nLegal<=6&&(k==numel(oo)||nLegal==6),'OVER_LEGAL_BALL_MISMATCH');
end
lb=[0;cumsum(legal(1:end-1))];wl=[0;cumsum(wk(1:end-1))];sb=[0;cumsum(runs(1:end-1))];
need(sum(legal)<=horizon&&sum(wk)<=10&&all(wl<10)&&all(lb<horizon),'DELIVERY_AFTER_INNINGS_END');
D=table((1:numel(runs))',legal,runs,bat,extras,wk,lb,wl,sb, ...
 'VariableNames',{'DeliverySeq','Legal','Runs','Bat','Extras','Wickets','BallsBefore','WicketsBefore','ScoreBefore'});
A=struct('Team',string(e.team),'Runs',sum(runs),'LegalBalls',sum(legal),'Wickets',sum(wk),'Delivery',D);
end

function reconcile(S,A,horizon,isFirst)
S=S(string(S.StateType)=="delivery",:);S=sortrows(S,'DeliverySeq');D=A.Delivery;
need(height(S)==height(D),'CACHE_DELIVERY_COUNT');
names=["DeliverySeq","CorrectedIsLegalBall","DeliveryRuns","RunsOffBat","ExtrasRuns", ...
 "GenuineDismissalsOnDelivery","LegalBallsBowled","GenuineWicketsLost","DeliveryScoreBefore"];
raw=["DeliverySeq","Legal","Runs","Bat","Extras","Wickets","BallsBefore","WicketsBefore","ScoreBefore"];
for k=1:numel(names)
 need(ismember(names(k),string(S.Properties.VariableNames)),'CACHE_SCHEMA');
 need(isequal(double(S.(names(k))),double(D.(raw(k)))),'CACHE_DELIVERY_MISMATCH');
end
need(all(string(S.RecordedBattingTeam)==A.Team),'CACHE_TEAM_MISMATCH');
need(all(double(S.FinalDeliveryRuns)==A.Runs)&&all(double(S.WicketsInHand)==10-D.WicketsBefore),'CACHE_FINAL_MISMATCH');
need(all(double(S.ScoreboardBefore)==D.ScoreBefore)&&all(double(S.RetiredNotOutEvents)==0),'CACHE_PENALTY_OR_RETIREMENT');
if isFirst,need(all(double(S.BallsRemaining)==horizon-D.BallsBefore),'FIRST_ALLOCATION_MISMATCH');end
end

function c=items(v)
if isempty(v),c={};elseif iscell(v),c=v(:);elseif isstruct(v),c=num2cell(v(:));else,error('Step1800:Evidence','UNSUPPORTED_ARRAY_SCHEMA');end
end
function x=num(v)
if isnumeric(v)&&isscalar(v),x=double(v);else,x=str2double(string(v));end
if ~isscalar(x),x=NaN;end
end
function b=oversBalls(v)
s=string(v);need(isscalar(s)&&~ismissing(s),'INVALID_OVER_NOTATION');
t=regexp(char(s),'^(\d+)(?:\.([0-5]))?$','tokens','once');need(~isempty(t),'INVALID_OVER_NOTATION');
b=6*str2double(t{1});if numel(t)>1&&~isempty(t{2}),b=b+str2double(t{2});end
end
function need(q,reason)
if ~isscalar(q)||ismissing(q)||~q,error('Step1800:Evidence','%s',reason);end
end
function s=stamp(p)
f=dir(p);assert(numel(f)==1&&~f.isdir,'Step1800:Dependency','Missing/ambiguous dependency: %s',p);
s=struct('Path',string(p),'Bytes',f.bytes,'Datenum',f.datenum);
end
function h=hashFile(p)
fid=fopen(p,'rb');assert(fid>=0,'Cannot read %s',p);closer=onCleanup(@()fclose(fid));
md=java.security.MessageDigest.getInstance('SHA-256');
while true,b=fread(fid,1048576,'*uint8');if isempty(b),break;end;md.update(typecast(b,'int8'));end
h=string(lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[])));
end
function checkDependencies(info)
for k=1:numel(info.Dependencies)
 s=info.Dependencies(k);assert(isequaln(stamp(s.Path),s),'Step1800:StaleCache', ...
 'Dependency changed: %s. Rerun RevisedCodes_18_00_RunAll.',s.Path);
end
end
