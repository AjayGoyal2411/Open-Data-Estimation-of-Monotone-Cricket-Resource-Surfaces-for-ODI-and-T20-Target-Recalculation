%% Generate Fig9, Fig11, Fig12, Fig13 (Empirical Resource Surfaces/Curves) — ROBUST CSV (multiline-safe) — REVISED v2 (Fix collapse + sparsity + monotonic)
% Key fixes based on your figures:
% 1) Remove invalid late-innings states (truncate by observed Umax; stop at all-out)
% 2) Apply minimum support (counts) => set to NaN (not 0)
% 3) Enforce monotonicity in u (R must be non-decreasing with u) using isotonic regression (PAV)
% 4) Apply the same support+monotonic rules for competition & era curves (w=10)
%
% Outputs remain same:
%   ...\figures\Fig9*.png, Fig11*.png, Fig12*.png, Fig13*.png
%   ...\tables\Table_Fig9*_Ruw.csv etc.

clc; clear;

%% ---------------- USER SETTINGS ----------------
inFolder  = 'D:\VihaanProject1\final_retained_dataset';
outRoot   = 'D:\VihaanProject1\paper_outputs';

f_match   = fullfile(inFolder,'match_info_all_noCompetition.csv');
f_ball    = fullfile(inFolder,'ball_by_ball_all.csv');
f_evM     = fullfile(inFolder,'JSON_EventMaster_FromMatchIDs.csv');
f_evC     = fullfile(inFolder,'JSON_EventCounts_FromMatchIDs.csv');

assert(isfile(f_match), 'Missing: %s', f_match);
assert(isfile(f_ball),  'Missing: %s', f_ball);
assert(isfile(f_evM),   'Missing: %s', f_evM);
assert(isfile(f_evC),   'Missing: %s', f_evC);

outFig = fullfile(outRoot,'figures');
outTab = fullfile(outRoot,'tables');
outLog = fullfile(outRoot,'runlog');
if ~exist(outFig,'dir'), mkdir(outFig); end
if ~exist(outTab,'dir'), mkdir(outTab); end
if ~exist(outLog,'dir'), mkdir(outLog); end

logFile = fullfile(outLog, sprintf('RunLog_Fig9_11_12_13_REVISED_%s.txt', datestr(now,'yyyymmdd_HHMMSS')));
diary(logFile); diary on;

fprintf('Logging to: %s\n', logFile);
fprintf('Input folder: %s\n', inFolder);
fprintf('Output root : %s\n\n', outRoot);

%% ---------------- CONTROLS (NEW) ----------------
NMIN_GLOBAL = 30;   % for Fig9 & Fig11 surfaces/slices
NMIN_SUB    = 15;   % for Fig12 competition and Fig13 era (smaller subsets)
APPLY_MONO  = true; % enforce monotonicity in u for each w curve

%% ---------------- READ METADATA ----------------
fprintf('Reading match_info...\n');
Tm  = readtable(f_match, 'TextType','string');

fprintf('Reading JSON_EventMaster...\n');
Tev = readtable(f_evM, 'TextType','string');

fprintf('Reading JSON_EventCounts...\n');
TevC = readtable(f_evC, 'TextType','string');

Tm.MatchID  = normalizeID(Tm.MatchID);
Tev.MatchID = normalizeID(Tev.MatchID);

% Build canonical fields
fmtVar    = pickVar(Tm,  ["Format","MatchType"]);
genderVar = pickVar(Tm,  ["Gender"]);
startVar  = pickVar(Tm,  ["StartDate"]);

if fmtVar == "",    Tm.FormatCanon  = repmat("unknown", height(Tm), 1);
else,              Tm.FormatCanon  = lower(strtrim(string(Tm.(fmtVar))));
end
Tm.FormatCanon(ismissing(Tm.FormatCanon) | strlength(strtrim(Tm.FormatCanon))==0) = "unknown";

if genderVar == "", Tm.GenderCanon  = repmat("unknown", height(Tm), 1);
else,              Tm.GenderCanon  = lower(strtrim(string(Tm.(genderVar))));
end
Tm.GenderCanon(ismissing(Tm.GenderCanon) | strlength(strtrim(Tm.GenderCanon))==0) = "unknown";

if startVar == ""
    Tm.Year = nan(height(Tm),1);
else
    Tm.Year = extractYearSmart(Tm.(startVar));
end

% EventName from Tev
if ~ismember("EventName", string(Tev.Properties.VariableNames))
    Tev.EventName = repmat("UNKNOWN", height(Tev), 1);
else
    Tev.EventName = string(Tev.EventName);
    Tev.EventName(ismissing(Tev.EventName) | strlength(strtrim(Tev.EventName))==0) = "UNKNOWN";
end

Tev2 = Tev(:, intersect(["MatchID","EventName","MatchType","Gender","Season","StartDateRaw"], string(Tev.Properties.VariableNames), 'stable'));

% Join match->event
fprintf('Joining match_info + event master...\n');
Tmeta = outerjoin(Tm, Tev2, 'Keys','MatchID', 'MergeKeys',true, 'Type','left');

% Prefer match_info format; fallback to Tev MatchType
fmtMeta = pickVar(Tmeta, ["FormatCanon","MatchType"]);
if fmtMeta == "FormatCanon"
    formatCanon = lower(strtrim(string(Tmeta.FormatCanon)));
else
    formatCanon = lower(strtrim(string(Tmeta.(fmtMeta))));
end
formatCanon(ismissing(formatCanon) | strlength(strtrim(formatCanon))==0) = "unknown";
Tmeta.FormatCanon = formatCanon;

% Year fallback from event fields if missing
if ~ismember("Year", string(Tmeta.Properties.VariableNames))
    Tmeta.Year = nan(height(Tmeta),1);
end
y2 = nan(height(Tmeta),1);
sdrVar = pickVar(Tmeta, ["StartDateRaw","Season"]);
if sdrVar ~= ""
    y2 = extractYearSmart(Tmeta.(sdrVar));
end
idxFill = isnan(Tmeta.Year);
Tmeta.Year(idxFill) = y2(idxFill);

% EventName fallback
if ~ismember("EventName", string(Tmeta.Properties.VariableNames))
    Tmeta.EventName = repmat("UNKNOWN", height(Tmeta), 1);
else
    Tmeta.EventName = string(Tmeta.EventName);
    Tmeta.EventName(ismissing(Tmeta.EventName) | strlength(strtrim(Tmeta.EventName))==0) = "UNKNOWN";
end

% Limited-overs subset (strict: ODI + T20 + variants)
isT20 = contains(Tmeta.FormatCanon, "t20");
isODI = contains(Tmeta.FormatCanon, "odi");
isLO  = isT20 | isODI;

Tlo = Tmeta(isLO, :);
fprintf('Limited-overs matches: %d\n\n', height(Tlo));

% Map: MatchID -> (formatBalls, EventName, Year)
loIDs = unique(Tlo.MatchID);
loIDs = loIDs(~ismissing(loIDs) & strlength(strtrim(loIDs))>0);

mapBalls = containers.Map('KeyType','char','ValueType','double');
mapEvent = containers.Map('KeyType','char','ValueType','char');
mapYear  = containers.Map('KeyType','char','ValueType','double');
mapFmt   = containers.Map('KeyType','char','ValueType','char'); % "t20" or "odi"

for i = 1:numel(loIDs)
    id = char(loIDs(i));
    r  = Tlo(Tlo.MatchID==loIDs(i), :);
    if isempty(r), continue; end
    fc = lower(strtrim(string(r.FormatCanon(1))));
    if contains(fc,"t20")
        mapBalls(id) = 120;
        mapFmt(id)   = 't20';
    else
        mapBalls(id) = 300;  % ODI assumption
        mapFmt(id)   = 'odi';
    end
    ev = string(r.EventName(1));
    if ismissing(ev) || strlength(strtrim(ev))==0, ev="UNKNOWN"; end
    mapEvent(id) = char(ev);

    yy = r.Year(1);
    if isempty(yy) || isnan(yy), yy = NaN; end
    mapYear(id) = double(yy);
end

% Top competitions for Fig12
TevC.EventName = string(TevC.EventName);

%% ---------------- ACCUMULATORS (Fig9 overall) ----------------
maxW = 10;

sumR_t20 = zeros(121, maxW+1);  cntR_t20 = zeros(121, maxW+1);
sumR_odi = zeros(301, maxW+1);  cntR_odi = zeros(301, maxW+1);

compSum_t20 = containers.Map('KeyType','char','ValueType','any');
compSum_odi = containers.Map('KeyType','char','ValueType','any');

eraEdges = [1900 2005 2013 2018 2100];
eraNames = {'<=2004','2005–2012','2013–2017','2018+'};

eraSum_t20 = zeros(121, numel(eraNames)); eraCnt_t20 = zeros(121, numel(eraNames));
eraSum_odi = zeros(301, numel(eraNames)); eraCnt_odi = zeros(301, numel(eraNames));

%% ---------------- STREAM ball_by_ball_all.csv (ROBUST) ----------------
fprintf('Streaming ball_by_ball_all.csv with multiline-safe reader...\n');

fid = fopen(f_ball, 'r');
assert(fid>0, 'Cannot open: %s', f_ball);

hdr = readCSVRecord(fid);
if isempty(hdr), error('Empty ball_by_ball file.'); end
headerCols = splitCSVLine(hdr, 1000);
headerCols = string(headerCols);

idxMatchID   = find(headerCols=="MatchID", 1);
idxInn       = find(headerCols=="InningsIndex", 1);
idxIsLegal   = find(headerCols=="IsLegalBall", 1);
idxRuns      = find(headerCols=="TotalRuns", 1);
idxIsWicket  = find(headerCols=="IsWicket", 1);
idxWlost     = find(headerCols=="WicketsLost", 1);

need = [idxMatchID,idxInn,idxIsLegal,idxRuns,idxIsWicket,idxWlost];
if any(isempty(need))
    error('Required columns missing in ball_by_ball header. Found: %s', strjoin(headerCols, ','));
end

currKey = '';
currMatch = '';
currFmt = '';
totalBalls = NaN;

cumRuns = 0;
wLost   = 0;
legalBowled = 0;

U = []; W = []; Sb = [];

inningsCount = 0;
keptInnings  = 0;

tStart = tic;
nRec = 0;

while true
    rec = readCSVRecord(fid);
    if isempty(rec), break; end
    nRec = nRec + 1;

    cols = splitCSVLine(rec, idxWlost);
    if numel(cols) < idxWlost
        continue;
    end

    mid = normalizeID(cols{idxMatchID});
    if ismissing(string(mid)) || strlength(strtrim(string(mid)))==0
        continue;
    end
    midc = char(string(mid));

    if ~isKey(mapBalls, midc)
        continue;
    end

    inn = str2double(stripQuotes(cols{idxInn}));
    if ~isfinite(inn), continue; end

    key = sprintf('%s|%d', midc, inn);

    % If new innings, finalize previous (capture returned accumulators)
    if ~strcmp(currKey, key)
        if ~isempty(currKey)
            inningsCount = inningsCount + 1;

            [kept, ...
             sumR_t20, cntR_t20, ...
             sumR_odi, cntR_odi, ...
             compSum_t20, compSum_odi, ...
             eraSum_t20, eraCnt_t20, ...
             eraSum_odi, eraCnt_odi] = finalizeInningsAndAccumulate( ...
                currMatch, currFmt, totalBalls, cumRuns, U, W, Sb, ...
                sumR_t20, cntR_t20, sumR_odi, cntR_odi, ...
                compSum_t20, compSum_odi, ...
                eraSum_t20, eraCnt_t20, eraSum_odi, eraCnt_odi, ...
                mapEvent, mapYear, eraEdges);

            keptInnings = keptInnings + kept;
        end

        currKey   = key;
        currMatch = midc;
        currFmt   = mapFmt(midc);
        totalBalls = mapBalls(midc);

        cumRuns = 0;
        wLost = 0;
        legalBowled = 0;

        U = zeros(0,1); W = zeros(0,1); Sb = zeros(0,1);
    end

    isLegal = str2double(stripQuotes(cols{idxIsLegal})) ~= 0;
    truns   = str2double(stripQuotes(cols{idxRuns}));
    if ~isfinite(truns), truns = 0; end

    isWk = str2double(stripQuotes(cols{idxIsWicket})) ~= 0;
    wl   = str2double(stripQuotes(cols{idxWlost}));
    if ~isfinite(wl)
        wl = wLost + double(isWk);
    end

    % Record state at START of legal ball
    % NEW: stop recording once all-out is reached (wLost >= 10)
    if isLegal && (wLost < 10)
        u = totalBalls - legalBowled;
        w = 10 - wLost;
        u = max(0, min(u, totalBalls));
        w = max(0, min(w, 10));

        U(end+1,1)  = u; %#ok<AGROW>
        W(end+1,1)  = w; %#ok<AGROW>
        Sb(end+1,1) = cumRuns; %#ok<AGROW>
    end

    % Update totals AFTER delivery
    cumRuns = cumRuns + truns;
    if isLegal
        legalBowled = legalBowled + 1;
    end
    wLost = max(wLost, wl);

    if mod(nRec, 500000) == 0
        fprintf('Records scanned: %d | kept innings so far: %d | elapsed: %.1fs\n', ...
            nRec, keptInnings, toc(tStart));
    end
end

% finalize last innings (capture returned accumulators)
if ~isempty(currKey)
    inningsCount = inningsCount + 1;

    [kept, ...
     sumR_t20, cntR_t20, ...
     sumR_odi, cntR_odi, ...
     compSum_t20, compSum_odi, ...
     eraSum_t20, eraCnt_t20, ...
     eraSum_odi, eraCnt_odi] = finalizeInningsAndAccumulate( ...
        currMatch, currFmt, totalBalls, cumRuns, U, W, Sb, ...
        sumR_t20, cntR_t20, sumR_odi, cntR_odi, ...
        compSum_t20, compSum_odi, ...
        eraSum_t20, eraCnt_t20, eraSum_odi, eraCnt_odi, ...
        mapEvent, mapYear, eraEdges);

    keptInnings = keptInnings + kept;
end

fclose(fid);

fprintf('\nStreaming done.\n');
fprintf('Innings processed (limited-overs matches only): %d\n', inningsCount);
fprintf('Innings kept (non-empty states & Sfinal>0):     %d\n\n', keptInnings);

%% ---------------- FIG9: Empirical R(u,w) heatmaps ----------------
fprintf('Fig9...\n');

R_t20 = sumR_t20 ./ max(cntR_t20, 1);
R_odi = sumR_odi ./ max(cntR_odi, 1);

% NEW: mask sparse bins (NaN, not 0)
R_t20(cntR_t20 < NMIN_GLOBAL) = NaN;
R_odi(cntR_odi < NMIN_GLOBAL) = NaN;

% NEW: enforce monotonicity in u for each w
if APPLY_MONO
    R_t20 = enforceMonotoneInU(R_t20);
    R_odi = enforceMonotoneInU(R_odi);
end

writetable(ruwTable(R_t20, cntR_t20, 120), fullfile(outTab,'Table_Fig9A_Ruw_T20.csv'));
writetable(ruwTable(R_odi, cntR_odi, 300), fullfile(outTab,'Table_Fig9B_Ruw_ODI.csv'));

plotRuwHeatmap(R_t20, 'T20', outFig, 'Fig9A_RuwHeat_T20.png', 120);
plotRuwHeatmap(R_odi, 'ODI', outFig, 'Fig9B_RuwHeat_ODI.png', 300);

%% ---------------- FIG11: Slice curves for w = 10,8,6,4,2 ----------------
fprintf('Fig11...\n');

wList = [10 8 6 4 2];

plotSlices(R_t20, wList, 120, 'T20', outFig, 'Fig11A_Slices_T20.png');
plotSlices(R_odi, wList, 300, 'ODI', outFig, 'Fig11B_Slices_ODI.png');

writetable(sliceTable(R_t20, wList, 120), fullfile(outTab,'Table_Fig11A_Slices_T20.csv'));
writetable(sliceTable(R_odi, wList, 300), fullfile(outTab,'Table_Fig11B_Slices_ODI.csv'));

%% ---------------- FIG12: Competition-aware (w=10 curves) ----------------
fprintf('Fig12...\n');

topCandidates = TevC.EventName;
topCandidates = topCandidates(~ismissing(topCandidates));
topCandidates = topCandidates(1:min(30,numel(topCandidates)));

[t20Names, odiNames] = pickTopCompetitions(compSum_t20, compSum_odi, topCandidates, 6);

% NEW: build curves with support masking + monotonic
plotCompetitionCurves(compSum_t20, t20Names, 120, 'T20', outFig, 'Fig12A_CompetitionCurves_T20.png', NMIN_SUB, APPLY_MONO);
plotCompetitionCurves(compSum_odi, odiNames, 300, 'ODI', outFig, 'Fig12B_CompetitionCurves_ODI.png', NMIN_SUB, APPLY_MONO);

writetable(compCurveTable(compSum_t20, t20Names, 120, NMIN_SUB, APPLY_MONO), fullfile(outTab,'Table_Fig12A_CompetitionCurves_T20.csv'));
writetable(compCurveTable(compSum_odi, odiNames, 300, NMIN_SUB, APPLY_MONO), fullfile(outTab,'Table_Fig12B_CompetitionCurves_ODI.csv'));

%% ---------------- FIG13: Era shift (w=10 curves) ----------------
fprintf('Fig13...\n');

plotEraCurves(eraSum_t20, eraCnt_t20, 120, eraNames, 'T20', outFig, 'Fig13A_EraShift_T20.png', NMIN_SUB, APPLY_MONO);
plotEraCurves(eraSum_odi, eraCnt_odi, 300, eraNames, 'ODI', outFig, 'Fig13B_EraShift_ODI.png', NMIN_SUB, APPLY_MONO);

writetable(eraCurveTable(eraSum_t20, eraCnt_t20, 120, eraNames, NMIN_SUB, APPLY_MONO), fullfile(outTab,'Table_Fig13A_EraShift_T20.csv'));
writetable(eraCurveTable(eraSum_odi, eraCnt_odi, 300, eraNames, NMIN_SUB, APPLY_MONO), fullfile(outTab,'Table_Fig13B_EraShift_ODI.csv'));

%% ---------------- DONE ----------------
fprintf('\nAll figures written to: %s\n', outFig);
fprintf('All tables  written to: %s\n', outTab);
fprintf('DONE.\n');

diary off;

%% ======================= LOCAL HELPERS =======================

function name = pickVar(T, candidates)
vars = string(T.Properties.VariableNames);
name = "";
for c = candidates
    if any(vars == c)
        name = c;
        return;
    end
end
end

function id = normalizeID(x)
if iscell(x), x = string(x); end
if isnumeric(x)
    id = string(round(x));
else
    id = string(x);
    id = strtrim(id);
    id(ismissing(id)) = "";
    id = regexprep(id, '\.0$', '');
end
end

function y = extractYearSmart(s)
if isdatetime(s)
    y = double(year(s));
    return;
end
if iscell(s), s = string(s); else, s = string(s); end
y = nan(size(s));
miss = ismissing(s) | strlength(strtrim(s))==0;
idx = find(~miss);
for k = 1:numel(idx)
    i = idx(k);
    txt = char(s(i));
    m = regexp(txt, '(\d{4})', 'match');
    if ~isempty(m)
        yy = str2double(m{end});
        if ~isnan(yy) && yy >= 1800 && yy <= 2100
            y(i) = yy;
        end
    end
end
end

function s = stripQuotes(s)
s = string(s);
s = strtrim(s);
if startsWith(s,'"') && endsWith(s,'"') && strlength(s)>=2
    s = extractBetween(s,2,strlength(s)-1);
end
s = char(s);
end

function rec = readCSVRecord(fid)
rec = '';
if feof(fid), return; end
line = fgetl(fid);
if ~ischar(line), return; end
rec = line;
inQuotes = csvLineInQuotes(rec);
while inQuotes && ~feof(fid)
    nxt = fgetl(fid);
    if ~ischar(nxt), break; end
    rec = rec + newline + nxt;
    inQuotes = csvLineInQuotes(rec);
end
end

function tf = csvLineInQuotes(s)
inQ = false;
i = 1;
n = length(s);
while i <= n
    if s(i) == '"'
        if i < n && s(i+1) == '"'
            i = i + 2;
            continue;
        else
            inQ = ~inQ;
            i = i + 1;
            continue;
        end
    end
    i = i + 1;
end
tf = inQ;
end

function cols = splitCSVLine(line, stopAtCol)
cols = {};
buf = '';
inQ = false;
i = 1;
n = length(line);
colCount = 0;

while i <= n
    ch = line(i);
    if ch == '"'
        if inQ && i < n && line(i+1) == '"'
            buf(end+1) = '"'; %#ok<AGROW>
            i = i + 2;
            continue;
        else
            inQ = ~inQ;
            i = i + 1;
            continue;
        end
    elseif ch == ',' && ~inQ
        colCount = colCount + 1;
        cols{colCount,1} = buf; %#ok<AGROW>
        buf = '';
        if nargin>=2 && colCount >= stopAtCol
            return;
        end
        i = i + 1;
        continue;
    else
        buf(end+1) = ch; %#ok<AGROW>
        i = i + 1;
    end
end

colCount = colCount + 1;
cols{colCount,1} = buf;
end

function [ ...
    kept, ...
    sumR_t20, cntR_t20, ...
    sumR_odi, cntR_odi, ...
    compSum_t20, compSum_odi, ...
    eraSum_t20, eraCnt_t20, ...
    eraSum_odi, eraCnt_odi ] = finalizeInningsAndAccumulate( ...
    matchID, fmt, totalBalls, Sfinal, U, W, Sb, ...
    sumR_t20, cntR_t20, sumR_odi, cntR_odi, ...
    compSum_t20, compSum_odi, ...
    eraSum_t20, eraCnt_t20, eraSum_odi, eraCnt_odi, ...
    mapEvent, mapYear, eraEdges)

kept = 0;
if isempty(U) || isempty(W) || isempty(Sb) || ~isfinite(Sfinal) || Sfinal <= 0
    return;
end

% NEW: truncate states to observed legal-ball range to prevent late-u collapse
Umax = max(U);
mask = (U >= 0) & (U <= Umax) & (W >= 0) & (W <= 10);
U = U(mask); W = W(mask); Sb = Sb(mask);
if isempty(U), return; end

% NEW: remove any states where all-out already happened (W==0 means wickets in hand 0)
mask2 = (W > 0); % keep only states with at least 1 wicket in hand
U = U(mask2); W = W(mask2); Sb = Sb(mask2);
if isempty(U), return; end

rem = (Sfinal - Sb) ./ max(Sfinal,1);
rem = max(0, min(rem, 1));

if strcmpi(fmt,'t20')
    for i = 1:numel(rem)
        u = U(i); w = W(i);
        sumR_t20(u+1, w+1) = sumR_t20(u+1, w+1) + rem(i);
        cntR_t20(u+1, w+1) = cntR_t20(u+1, w+1) + 1;
    end
else
    for i = 1:numel(rem)
        u = U(i); w = W(i);
        sumR_odi(u+1, w+1) = sumR_odi(u+1, w+1) + rem(i);
        cntR_odi(u+1, w+1) = cntR_odi(u+1, w+1) + 1;
    end
end

ev = 'UNKNOWN';
if isKey(mapEvent, matchID), ev = mapEvent(matchID); end

if strcmpi(fmt,'t20')
    compSum_t20 = addCompCurve(compSum_t20, ev, U, W, rem, totalBalls);
else
    compSum_odi = addCompCurve(compSum_odi, ev, U, W, rem, totalBalls);
end

yy = NaN;
if isKey(mapYear, matchID), yy = mapYear(matchID); end
if isfinite(yy)
    eraIdx = find(yy >= eraEdges(1:end-1) & yy < eraEdges(2:end), 1);
    if ~isempty(eraIdx)
        if strcmpi(fmt,'t20')
            [eraSum_t20, eraCnt_t20] = addEraCurve(eraSum_t20, eraCnt_t20, eraIdx, U, W, rem);
        else
            [eraSum_odi, eraCnt_odi] = addEraCurve(eraSum_odi, eraCnt_odi, eraIdx, U, W, rem);
        end
    end
end

kept = 1;
end

function mapObj = addCompCurve(mapObj, evName, U, W, rem, totalBalls)
key = char(string(evName));
if ~isKey(mapObj, key)
    if totalBalls==120
        s.sum = zeros(121,1); s.cnt = zeros(121,1);
    else
        s.sum = zeros(301,1); s.cnt = zeros(301,1);
    end
else
    s = mapObj(key);
end
for i = 1:numel(rem)
    if W(i) == 10
        u = U(i);
        s.sum(u+1) = s.sum(u+1) + rem(i);
        s.cnt(u+1) = s.cnt(u+1) + 1;
    end
end
mapObj(key) = s;
end

function [Ssum, Scnt] = addEraCurve(Ssum, Scnt, eraIdx, U, W, rem)
for i = 1:numel(rem)
    if W(i) == 10
        u = U(i);
        Ssum(u+1, eraIdx) = Ssum(u+1, eraIdx) + rem(i);
        Scnt(u+1, eraIdx) = Scnt(u+1, eraIdx) + 1;
    end
end
end

function T = ruwTable(R, C, totalBalls)
[uGrid, wGrid] = ndgrid(0:totalBalls, 0:10);
T = table(uGrid(:), wGrid(:), R(:), C(:), ...
    'VariableNames', {'BallsRemaining_u','WicketsInHand_w','R_RemainingRatio','SampleCount'});
end

function plotRuwHeatmap(R, tag, outFig, fname, totalBalls)
fig = figure('Visible','off');
imagesc(0:10, 0:totalBalls, R);
set(gca,'YDir','normal');
colorbar; grid on;
xlabel('Wickets in hand (w)'); ylabel('Balls remaining (u)');
title(sprintf('Empirical Resource Surface R(u,w) — %s', tag));
set(gcf,'Color','w');
exportgraphics(fig, fullfile(outFig, fname), 'Resolution',300);
close(fig);
end

function plotSlices(R, wList, totalBalls, tag, outFig, fname)
fig = figure('Visible','off'); hold on; grid on;
u = (0:totalBalls)';
for w = wList
    plot(u, R(:, w+1), 'LineWidth', 1.8);
end
xlabel('Balls remaining (u)');
ylabel('R(u,w) = E[(Sfinal - Sb)/Sfinal | u,w]');
title(sprintf('Empirical Resource Curves (Slice of Fig9) — %s', tag));
legend(arrayfun(@(w)sprintf('w=%d',w), wList, 'UniformOutput',false), 'Location','best');
set(gcf,'Color','w');
exportgraphics(fig, fullfile(outFig, fname), 'Resolution',300);
close(fig);
end

function T = sliceTable(R, wList, totalBalls)
u = (0:totalBalls)';
T = table(u, 'VariableNames', {'BallsRemaining_u'});
for w = wList
    T.(sprintf('R_w%d',w)) = R(:, w+1);
end
end

function [t20Names, odiNames] = pickTopCompetitions(compSum_t20, compSum_odi, candidates, k)
t20Names = strings(0,1);
odiNames = strings(0,1);

for i = 1:numel(candidates)
    nm = char(candidates(i));
    if isKey(compSum_t20, nm) && numel(t20Names) < k
        t20Names(end+1,1) = string(nm); %#ok<AGROW>
    end
    if isKey(compSum_odi, nm) && numel(odiNames) < k
        odiNames(end+1,1) = string(nm); %#ok<AGROW>
    end
    if numel(t20Names) >= k && numel(odiNames) >= k
        break;
    end
end

if numel(t20Names) < k
    keys = compSum_t20.keys;
    [~, order] = sort(cellfun(@(kk)sum(compSum_t20(kk).cnt), keys), 'descend');
    for j = 1:numel(order)
        if numel(t20Names) >= k, break; end
        nm = string(keys{order(j)});
        if ~any(t20Names==nm), t20Names(end+1,1)=nm; end %#ok<AGROW>
    end
end

if numel(odiNames) < k
    keys = compSum_odi.keys;
    [~, order] = sort(cellfun(@(kk)sum(compSum_odi(kk).cnt), keys), 'descend');
    for j = 1:numel(order)
        if numel(odiNames) >= k, break; end
        nm = string(keys{order(j)});
        if ~any(odiNames==nm), odiNames(end+1,1)=nm; end %#ok<AGROW>
    end
end
end

function plotCompetitionCurves(compMap, names, totalBalls, tag, outFig, fname, Nmin, doMono)
fig = figure('Visible','off'); hold on; grid on;
u = (0:totalBalls)';

for i = 1:numel(names)
    nm = char(names(i));
    s = compMap(nm);
    r = s.sum ./ max(s.cnt,1);
    r(s.cnt < Nmin) = NaN;              % NEW: sparse mask
    if doMono, r = isotonicFill(r); end % NEW: monotone
    plot(u, r, 'LineWidth', 1.8);
end

xlabel('Balls remaining (u)');
ylabel('R(u,10) (remaining ratio)');
title(sprintf('Competition-aware Empirical Curves (w=10) — %s', tag));
legend(cellstr(names), 'Location','best');
set(gcf,'Color','w');
exportgraphics(fig, fullfile(outFig, fname), 'Resolution',300);
close(fig);
end

function T = compCurveTable(compMap, names, totalBalls, Nmin, doMono)
u = (0:totalBalls)';
T = table(u, 'VariableNames', {'BallsRemaining_u'});
for i = 1:numel(names)
    nm = char(names(i));
    s = compMap(nm);
    r = s.sum ./ max(s.cnt,1);
    r(s.cnt < Nmin) = NaN;
    if doMono, r = isotonicFill(r); end
    vname = matlab.lang.makeValidName("R_"+string(names(i)));
    T.(vname) = r;
end
end

function plotEraCurves(eraSum, eraCnt, totalBalls, eraNames, tag, outFig, fname, Nmin, doMono)
fig = figure('Visible','off'); hold on; grid on;
u = (0:totalBalls)';

for e = 1:numel(eraNames)
    r = eraSum(:,e) ./ max(eraCnt(:,e),1);
    r(eraCnt(:,e) < Nmin) = NaN;        % NEW: sparse mask
    if doMono, r = isotonicFill(r); end % NEW: monotone
    plot(u, r, 'LineWidth', 1.8);
end

xlabel('Balls remaining (u)');
ylabel('R(u,10) (remaining ratio)');
title(sprintf('Era Shift in Empirical Curves (w=10) — %s', tag));
legend(eraNames, 'Location','best');
set(gcf,'Color','w');
exportgraphics(fig, fullfile(outFig, fname), 'Resolution',300);
close(fig);
end

function T = eraCurveTable(eraSum, eraCnt, totalBalls, eraNames, Nmin, doMono)
u = (0:totalBalls)';
T = table(u, 'VariableNames', {'BallsRemaining_u'});
for e = 1:numel(eraNames)
    r = eraSum(:,e) ./ max(eraCnt(:,e),1);
    r(eraCnt(:,e) < Nmin) = NaN;
    if doMono, r = isotonicFill(r); end
    vname = matlab.lang.makeValidName("R_"+string(eraNames{e}));
    T.(vname) = r;
end
end

function R = enforceMonotoneInU(R)
% R is (U+1) x 11. Enforce non-decreasing in u for each w column.
for w = 1:size(R,2)
    R(:,w) = isotonicFill(R(:,w));
end
end

function y = isotonicFill(x)
% NaN-aware isotonic regression (PAV) on observed points; keeps NaNs where unsupported.
y = x;
idx = find(~isnan(x));
if numel(idx) < 3
    return;
end
y(idx) = isotonicPAV(x(idx));
end

function z = isotonicPAV(y)
% Pool Adjacent Violators for non-decreasing fit
z = y(:);
n = numel(z);
w = ones(n,1);
i = 1;
while i < n
    if z(i) > z(i+1)
        % merge blocks i and i+1
        newz = (w(i)*z(i) + w(i+1)*z(i+1)) / (w(i)+w(i+1));
        z(i) = newz;
        w(i) = w(i) + w(i+1);
        z(i+1) = [];
        w(i+1) = [];
        n = n - 1;
        if i > 1, i = i - 1; end
    else
        i = i + 1;
    end
end
% expand back to length (block replication)
% We reconstruct by iterating blocks from left to right.
% (Simpler: rerun a block-expansion using original y length)
% For stability, do a second pass with cumulative means.
zz = zeros(numel(y),1);
% Identify blocks by scanning original y against fitted z changes:
% (We emulate block sizes by re-running PAV while storing block boundaries.)
z2 = y(:); w2 = ones(numel(y),1);
blocks = {};
i=1;
while i < numel(z2)
    if z2(i) > z2(i+1)
        z2(i) = (w2(i)*z2(i) + w2(i+1)*z2(i+1)) / (w2(i)+w2(i+1));
        w2(i) = w2(i) + w2(i+1);
        z2(i+1) = [];
        w2(i+1) = [];
        if i>1, i=i-1; end
    else
        i=i+1;
    end
end
% Now z2 are block means, w2 block sizes
pos = 1;
for b=1:numel(z2)
    zz(pos:pos+w2(b)-1) = z2(b);
    pos = pos + w2(b);
end
z = zz;
end
