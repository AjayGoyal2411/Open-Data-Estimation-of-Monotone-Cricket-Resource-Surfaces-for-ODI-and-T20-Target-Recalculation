function B = RevisedCodes_24_BuildRepository(C,D,A,report,here,U)
root=fullfile(report,C.ReleaseName);codeRoot=fullfile(root,'code');evidenceRoot=fullfile(root,'evidence');
prov=fullfile(root,'provenance');docs=fullfile(root,'documentation');verifyDir=fullfile(root,'verification');
for p=string({root,codeRoot,evidenceRoot,prov,docs,verifyDir}),if ~isfolder(p),mkdir(p);end,end

% Copy all discovered MATLAB sources. Exact duplicates are retained at their
% original relative paths because path provenance matters for frozen builds.
ReleasedSHA256=strings(height(D.Code),1);
for i=1:height(D.Code)
    dst=fullfile(codeRoot,strrep(D.Code.RelativePath(i),'/',filesep));U.CopyVerified(D.Code.SourcePath(i),dst,U);
    ReleasedSHA256(i)=U.Hash(dst);
end
CodeInventory=removevars(D.Code,'SourcePath');CodeInventory.ReleasedSHA256=ReleasedSHA256;
U.Write(CodeInventory,fullfile(prov,'CodeInventory.csv'));

% Copy successful evidence. Text outputs are path-sanitised without changing
% numeric content; source and released hashes are both retained.
ReleasedSHA256=strings(height(D.Artifacts),1);PathSanitized=false(height(D.Artifacts),1);
for i=1:height(D.Artifacts)
    dst=fullfile(evidenceRoot,strrep(D.Artifacts.RelativePath(i),'/',filesep));
    [ReleasedSHA256(i),PathSanitized(i)]=copyPublic(D.Artifacts.SourcePath(i),dst,C,U);
end
ArtifactInventory=removevars(D.Artifacts,'SourcePath');ArtifactInventory.ReleasedSHA256=ReleasedSHA256;
ArtifactInventory.PathSanitized=PathSanitized;U.Write(ArtifactInventory,fullfile(prov,'ArtifactInventory.csv'));
U.Write(D.Coverage,fullfile(prov,'StepCoverage.csv'));
U.Write(D.ThirdParty,fullfile(prov,'ThirdPartyInputInventory.csv'));
U.Write(D.ExcludedThirdPartyCopies,fullfile(prov,'ThirdPartyCopyExclusions.csv'));
U.Write(A.Closure,fullfile(prov,'ReviewerEditorEvidenceAudit.csv'));
U.Write(A.Summary,fullfile(prov,'ReviewerEditorEvidenceAuditSummary.csv'));
U.Write(A.Step22Gates,fullfile(prov,'Step22ScientificGates.csv'));
U.Write(A.Limitations,fullfile(prov,'ScientificLimitations.csv'));

writeReadme(fullfile(root,'README.md'),C,D,A);
writeClaims(fullfile(docs,'CLAIM_BOUNDARY.md'));
writeAvailability(fullfile(docs,'DATA_AVAILABILITY.md'),D);
writeLicences(fullfile(root,'LICENSE.md'),C);
writeCitation(fullfile(root,'CITATION.cff'),C);
writeEnvironment(fullfile(docs,'MATLAB_ENVIRONMENT.txt'),C);
writeThirdParty(fullfile(docs,'THIRD_PARTY_NOTICES.md'));
writeStatus(fullfile(docs,'RELEASE_STATUS.md'),D,A);
copyfile(fullfile(here,'RevisedCodes_24_VerifyRepository.m'),fullfile(verifyDir,'RevisedCodes_24_VerifyRepository.m'),'f');
writeVerifyRunner(fullfile(root,'VERIFY_RELEASE.m'));

Dictionary=makeDictionary(root);U.Write(Dictionary,fullfile(prov,'CSV_SchemaInventory.csv'));
all=dir(fullfile(root,'**','*'));all=all(~[all.isdir]);RelativePath=strings(numel(all),1);Bytes=zeros(numel(all),1);SHA256=strings(numel(all),1);
for i=1:numel(all),p=string(fullfile(all(i).folder,all(i).name));RelativePath(i)=U.Relative(root,p);Bytes(i)=all(i).bytes;SHA256(i)=U.Hash(p);end
Manifest=table(RelativePath,Bytes,SHA256);U.Write(Manifest,fullfile(root,'MANIFEST_SHA256.csv'));

% Manifest deliberately excludes itself; verifier enforces that convention.
zipPath=string(report)+"_"+C.ReleaseName+".zip";zip(zipPath,{'*'},root);
B=struct('Root',string(root),'Zip',zipPath,'Manifest',Manifest,'CodeFiles',height(CodeInventory), ...
    'ArtifactFiles',height(ArtifactInventory),'ThirdPartyFilesInventoried',height(D.ThirdParty), ...
    'FiguresCopied',nnz(D.Artifacts.Category=="FIGURE"),'DictionaryRows',height(Dictionary));
end

function [hash,sanitized]=copyPublic(src,dst,C,U)
[~,~,ext]=fileparts(src);ext=lower(string(ext));parent=fileparts(dst);if ~isfolder(parent),mkdir(parent);end
sanitized=false;
if ismember(ext,[".csv",".tsv",".md",".txt",".json",".yaml",".yml"])
    raw=fileread(src);clean=strrep(raw,char(C.ProjectRoot),'<PROJECT_ROOT>');
    clean=strrep(clean,strrep(char(C.ProjectRoot),'\','/'),'<PROJECT_ROOT>');sanitized=~strcmp(raw,clean);
    f=fopen(dst,'wt');assert(f>=0,'Cannot write %s',dst);c=onCleanup(@()fclose(f));fwrite(f,clean,'char');clear c
else
    [ok,msg]=copyfile(src,dst,'f');assert(ok,'Copy failed: %s',msg);
end
hash=U.Hash(dst);
end

function D=makeDictionary(root)
files=dir(fullfile(root,'**','*.csv'));File=strings(0,1);Variable=strings(0,1);DetectedClass=strings(0,1);ParseStatus=strings(0,1);
for i=1:numel(files)
    p=string(fullfile(files(i).folder,files(i).name));
    try
        T=readtable(p,'TextType','string','VariableNamingRule','preserve');names=string(T.Properties.VariableNames);
        for j=1:numel(names),File(end+1,1)=relative(root,p);Variable(end+1,1)=names(j);DetectedClass(end+1,1)=string(class(T.(names(j))));ParseStatus(end+1,1)="PARSED";end %#ok<AGROW>
    catch err
        File(end+1,1)=relative(root,p);Variable(end+1,1)="";DetectedClass(end+1,1)="";ParseStatus(end+1,1)="ERROR: "+string(err.identifier); %#ok<AGROW>
    end
end
D=table(File,Variable,DetectedClass,ParseStatus);
end

function r=relative(root,p)
r=extractAfter(string(p),strlength(string(root)));r=strip(r,'left',filesep);r=replace(r,string(filesep),"/");
end

function writeReadme(path,C,D,A)
f=fopen(path,'wt');assert(f>=0);c=onCleanup(@()fclose(f));
fprintf(f,'# %s\n\n',C.RepositoryTitle);fprintf(f,'Release: %s\n\n',C.ReleaseName);
fprintf(f,'This release preserves the complete MATLAB code discovered for Steps 1-23, successful derived analytical evidence, publication figures, model/result artifacts selected by the release policy, and independent provenance inventories.\n\n');
fprintf(f,'## Reproduce or audit\n\n1. Run `VERIFY_RELEASE.m` immediately after extraction.\n2. Inspect `provenance/Step22ScientificGates.csv` and `provenance/ScientificLimitations.csv` before making claims.\n3. Full regeneration requires MATLAB R2024b, the original project inputs listed in `provenance/ThirdPartyInputInventory.csv`, and third-party dependencies under the paths described in the associated Methods.\n\n');
fprintf(f,'Code files copied: %d. Evidence/model/figure files copied: %d. Third-party input files inventoried but not redistributed: %d. Byte-identical output-folder copies excluded: %d.\n\n',height(D.Code),height(D.Artifacts),height(D.ThirdParty),height(D.ExcludedThirdPartyCopies));
fprintf(f,'Reviewer/editor rows dispositioned: %d. Evidence unresolved: %d. Reviewer-bounded limitations: %d. Scientific limitation records: %d. Manuscript actions: %d.\n\n',A.Summary.AllComments,A.Summary.UnresolvedEvidence,A.Summary.DocumentedLimitations,height(A.Limitations),A.Summary.ManuscriptActions);
fprintf(f,'The archive does not claim external independent validation, universal fairness/superiority, exact modern professional DLS reproduction, or published DLMA reproduction unless the corresponding scientific gate explicitly passes.\n');clear c
end

function writeClaims(path)
f=fopen(path,'wt');assert(f>=0);c=onCleanup(@()fclose(f));fprintf(f,[ ...
'# Claim boundary\n\n- The primary evaluation is frozen held-out temporal evaluation, not external independent validation.\n' ...
'- Improvement over the linear-balls baseline does not establish universal superiority.\n' ...
'- Historical VJD 2002 is implemented only within its published 50-over integer-percentage table.\n' ...
'- Exact modern professional DLS and published DLMA performance are not reported without certified parameters and reproduction tests.\n' ...
'- Men and women are not pooled because the prespecified outcome-equivalence gate failed for ODI and T20.\n' ...
'- Reconstructed opponent metadata is accompanied by exclusion sensitivity and does not silently overwrite populated conflicts.\n']);clear c
end

function writeAvailability(path,D)
f=fopen(path,'wt');assert(f>=0);c=onCleanup(@()fclose(f));fprintf(f,[ ...
'# Data availability\n\nDerived analytical tables, figures, code and manifests are distributed in this release. ' ...
'Third-party match files are not distributed; their complete inventory and SHA-256 values are provided so authorised copies can be verified. ' ...
'Users must obtain Cricsheet and other third-party material under the original provider terms.\n\n']);
fprintf(f,'Third-party files inventoried: %d. Total bytes inventoried: %.0f. Byte-identical copies excluded from evidence: %d. See `provenance/ThirdPartyCopyExclusions.csv`.\n',height(D.ThirdParty),sum(D.ThirdParty.Bytes),height(D.ExcludedThirdPartyCopies));clear c
end

function writeLicences(path,C)
f=fopen(path,'wt');assert(f>=0);c=onCleanup(@()fclose(f));fprintf(f,[ ...
'# Licensing notice\n\nOriginal MATLAB code: %s.\n\nOriginal documentation and author-created derived tables: %s.\n\n' ...
'These declarations apply only to material owned by the authors. Cricsheet records, published comparator tables, journal articles, software libraries and other third-party material remain subject to their original terms. Confirm the final author list and institutional requirements before public deposition.\n\n' ...
'## MIT licence for original code\n\nCopyright (c) 2026 Ajay Goyal and manuscript co-authors\n\n' ...
'Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:\n\n' ...
'The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.\n\n' ...
'THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\n\n' ...
'## CC BY 4.0 for original documentation and author-created derived tables\n\nThe licence terms are available at https://creativecommons.org/licenses/by/4.0/ . Attribution to the associated manuscript and repository release is required.\n'],C.CodeLicense,C.DataLicense);clear c
end

function writeCitation(path,C)
f=fopen(path,'wt');assert(f>=0);c=onCleanup(@()fclose(f));fprintf(f,'cff-version: 1.2.0\nmessage: "Please cite the associated manuscript and this repository release."\ntitle: "%s"\ntype: software\nversion: 1.0.0\nauthors:\n  - family-names: "%s"\n    given-names: "%s"\n    affiliation: "%s"\n',C.RepositoryTitle,C.AuthorFamilyName,C.AuthorGivenName,C.AuthorAffiliation);clear c
end

function writeEnvironment(path,C)
f=fopen(path,'wt');assert(f>=0);c=onCleanup(@()fclose(f));fprintf(f,'Generated: %s\nMATLAB: %s\nComputer: %s\nProject root at build time: <PROJECT_ROOT>\n\nInstalled products:\n',string(datetime('now','Format','yyyy-MM-dd HH:mm:ss Z')),version,computer);
v=ver;for i=1:numel(v),fprintf(f,'%s | %s\n',v(i).Name,v(i).Version);end;fprintf(f,'\nConfigured code licence: %s\nConfigured derived-data licence: %s\n',C.CodeLicense,C.DataLicense);clear c
end

function writeThirdParty(path)
f=fopen(path,'wt');assert(f>=0);c=onCleanup(@()fclose(f));fprintf(f,[ ...
'# Third-party notices\n\n- Cricsheet match data must be obtained and used under the terms published by Cricsheet.\n' ...
'- SnakeYAML and any other libraries remain under their respective licences.\n' ...
'- The VJD table is a transcription of the cited 2002 publication and is limited to reproducibility and scholarly verification.\n' ...
'- No proprietary professional DLS implementation or parameter set is distributed.\n']);clear c
end

function writeStatus(path,D,A)
f=fopen(path,'wt');assert(f>=0);c=onCleanup(@()fclose(f));fprintf(f,'# Release status\n\n');
fprintf(f,'- Code inventory: %d files.\n- Evidence/model/figure inventory: %d files.\n- Figures located: %d.\n',height(D.Code),height(D.Artifacts),nnz(D.Artifacts.Category=="FIGURE"));
fprintf(f,'- Reviewer/editor evidence unresolved: %d.\n- Reviewer-bounded limitations: %d.\n- Scientific limitation records: %d.\n- Third-party copies excluded: %d.\n- Manuscript-only actions: %d.\n\n',A.Summary.UnresolvedEvidence,A.Summary.DocumentedLimitations,height(A.Limitations),height(D.ExcludedThirdPartyCopies),A.Summary.ManuscriptActions);
fprintf(f,'A documented scientific limitation is not converted into a passed comparison. Consult the provenance tables before drafting conclusions.\n');clear c
end

function writeVerifyRunner(path)
f=fopen(path,'wt');assert(f>=0);c=onCleanup(@()fclose(f));fprintf(f,"clear;clc;here=fileparts(mfilename('fullpath'));addpath(fullfile(here,'verification'));Verification=RevisedCodes_24_VerifyRepository(here);disp(Verification);\n");clear c
end
