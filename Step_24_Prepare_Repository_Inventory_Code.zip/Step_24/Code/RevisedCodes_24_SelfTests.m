function T = RevisedCodes_24_SelfTests(U)
Check = ["SHA-256 deterministic";"One-MiB chunk-boundary hash";"Relative path removes root";"Windows separators normalized"; ...
    "Step label extracted";"Truth parser accepts one";"Truth parser rejects zero"; ...
    "Blank detector";"Verified copy preserves hash";"Third-party hash exclusion logic"];
Passed = false(size(Check)); tmp = string(tempname); mkdir(tmp); c = onCleanup(@()cleanup(tmp));
p = fullfile(tmp,'a.txt'); f=fopen(p,'wt'); assert(f>=0); fprintf(f,'step24'); fclose(f);
Passed(1)=U.Hash(p)==U.Hash(p);
large=fullfile(tmp,'exactly_1MiB.bin');f=fopen(large,'wb');assert(f>=0);fwrite(f,zeros(1048576,1,'uint8'),'uint8');fclose(f);
Passed(2)=strlength(U.Hash(large))==64&&U.Hash(large)==U.Hash(large);
q=fullfile(tmp,'folder','file.csv'); Passed(3)=U.Relative(tmp,q)=="folder/file.csv";
Passed(4)=~contains(U.Relative(tmp,q),char(92));
Passed(5)=U.Stage('RevisedCodes_23_RunAll.m')=="STEP23";
Passed(6)=U.IsTrue("1"); Passed(7)=~U.IsTrue("0");
Passed(8)=~U.Nonblank(" ")&&U.Nonblank("x");
dst=fullfile(tmp,'copy','a.txt');U.CopyVerified(p,dst,U);Passed(9)=U.Hash(p)==U.Hash(dst);
Passed(10)=isequal(ismember(["derived";"raw"],["raw";"other"]),[false;true]);
T=table(Check,Passed);disp(T);assert(all(Passed),'Step24 self-test failed: %s',strjoin(Check(~Passed),', ')); clear c
end

function cleanup(path)
if isfolder(path), rmdir(path,'s'); end
end
