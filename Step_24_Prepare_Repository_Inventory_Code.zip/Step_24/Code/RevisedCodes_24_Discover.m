function D = RevisedCodes_24_Discover(C,U)
% Inventory original code, successful analytical artifacts, figures and
% third-party inputs. Raw third-party files are hashed but not redistributed.

codeFiles = dir(fullfile(C.ProjectRoot,'**','*.m')); codeFiles=codeFiles(~[codeFiles.isdir]);
SourcePath=strings(0,1);RelativePath=strings(0,1);FileName=strings(0,1);Stage=strings(0,1);
Bytes=zeros(0,1);SHA256=strings(0,1);DuplicateOf=strings(0,1);
for i=1:numel(codeFiles)
    p=string(fullfile(codeFiles(i).folder,codeFiles(i).name)); low=lower(replace(p,string(filesep),"/"));
    if startsWith(lower(p),lower(C.OutputRoot+filesep)) || contains(low,'/.git/') || contains(low,'/final_repository_release/'), continue; end
    rel=U.Relative(C.ProjectRoot,p); h=U.Hash(p); prior=find(SHA256==h,1);
    dup=""; if ~isempty(prior),dup=RelativePath(prior);end
    SourcePath(end+1,1)=p;RelativePath(end+1,1)=rel;FileName(end+1,1)=string(codeFiles(i).name); %#ok<AGROW>
    Stage(end+1,1)=U.Stage(rel);Bytes(end+1,1)=codeFiles(i).bytes;SHA256(end+1,1)=h;DuplicateOf(end+1,1)=dup; %#ok<AGROW>
end
Code=table(SourcePath,RelativePath,FileName,Stage,Bytes,SHA256,DuplicateOf);
assert(height(Code)>0,'No MATLAB source files discovered.');

failure=dir(fullfile(C.SourceOutputRoot,'**','*FAILURE.txt'));failedFolders=string(fullfile({failure.folder}))';
all=dir(fullfile(C.SourceOutputRoot,'**','*'));all=all(~[all.isdir]);
SourcePath=strings(0,1);RelativePath=strings(0,1);FileName=strings(0,1);Stage=strings(0,1);
Extension=strings(0,1);Bytes=zeros(0,1);SHA256=strings(0,1);Category=strings(0,1);
for i=1:numel(all)
    p=string(fullfile(all(i).folder,all(i).name)); low=lower(replace(p,string(filesep),"/"));
    if startsWith(lower(p),lower(C.OutputRoot+filesep)) || contains(low,'_failed_') || contains(lower(all(i).name),'failure'),continue;end
    if any(startsWith(lower(p),lower(failedFolders+filesep))),continue;end
    [~,name,ext]=fileparts(all(i).name);ext=lower(string(ext));take=ismember(ext,C.ArtifactExtensions);
    if ext==".mat" && C.IncludeModelMATFiles
        take=any(contains(lower(string(name)),C.ModelMATNameTokens)) && ~contains(lower(string(name)),'intermediate');
    end
    if ~take || all(i).bytes>C.MaxSingleArtifactBytes,continue;end
    rel=U.Relative(C.SourceOutputRoot,p);cat="EVIDENCE";if ismember(ext,[".png",".pdf",".fig"]),cat="FIGURE";elseif ext==".mat",cat="MODEL_ARTIFACT";end
    SourcePath(end+1,1)=p;RelativePath(end+1,1)=rel;FileName(end+1,1)=string(all(i).name);Stage(end+1,1)=U.Stage(rel); %#ok<AGROW>
    Extension(end+1,1)=ext;Bytes(end+1,1)=all(i).bytes;SHA256(end+1,1)=U.Hash(p);Category(end+1,1)=cat; %#ok<AGROW>
end
Artifacts=table(SourcePath,RelativePath,FileName,Stage,Extension,Bytes,SHA256,Category);
assert(height(Artifacts)>0,'No successful analytical artifacts discovered.');

Root=strings(0,1);RelativePath=strings(0,1);Bytes=zeros(0,1);SHA256=strings(0,1);Distributed=false(0,1);
for r=1:numel(C.ThirdPartyRoots)
    base=C.ThirdPartyRoots(r);if ~isfolder(base),continue;end
    files=dir(fullfile(base,'**','*'));files=files(~[files.isdir]);
    for i=1:numel(files)
        p=string(fullfile(files(i).folder,files(i).name));Root(end+1,1)=string(extractAfter(base,strlength(C.ProjectRoot)+1)); %#ok<AGROW>
        RelativePath(end+1,1)=U.Relative(base,p);Bytes(end+1,1)=files(i).bytes; %#ok<AGROW>
        if C.HashThirdPartyInputs,SHA256(end+1,1)=U.Hash(p);else,SHA256(end+1,1)="NOT_COMPUTED";end %#ok<AGROW>
        Distributed(end+1,1)=false; %#ok<AGROW>
    end
end
ThirdParty=table(Root,RelativePath,Bytes,SHA256,Distributed);

% Output folders can contain convenience copies of raw match files.  A file
% remains third-party even when it appears below paper_outputs_revisedcodes.
% Exclude every byte-identical copy from the public artifact set and retain
% an auditable mapping to the inventoried source instead.
copyMask=false(height(Artifacts),1);
if ~isempty(ThirdParty),copyMask=ismember(Artifacts.SHA256,ThirdParty.SHA256);end
E=Artifacts(copyMask,:);ArtifactRelativePath=E.RelativePath;SourceSHA256=E.SHA256;
ThirdPartyRoot=strings(height(E),1);ThirdPartyRelativePath=strings(height(E),1);
Reason=repmat("EXCLUDED_BYTE_IDENTICAL_THIRD_PARTY_INPUT",height(E),1);
for i=1:height(E)
    j=find(ThirdParty.SHA256==E.SHA256(i),1,'first');
    ThirdPartyRoot(i)=ThirdParty.Root(j);ThirdPartyRelativePath(i)=ThirdParty.RelativePath(j);
end
ExcludedThirdPartyCopies=table(ArtifactRelativePath,SourceSHA256,ThirdPartyRoot,ThirdPartyRelativePath,Reason);
Artifacts=Artifacts(~copyMask,:);

Step=(1:23)';CodeFiles=zeros(23,1);ArtifactFiles=zeros(23,1);FigureFiles=zeros(23,1);
for s=1:23
    label="STEP"+string(s);CodeFiles(s)=nnz(Code.Stage==label);ArtifactFiles(s)=nnz(Artifacts.Stage==label);
    FigureFiles(s)=nnz(Artifacts.Stage==label&Artifacts.Category=="FIGURE");
end
Coverage=table(Step,CodeFiles,ArtifactFiles,FigureFiles);
D=struct('Code',Code,'Artifacts',Artifacts,'ThirdParty',ThirdParty, ...
    'ExcludedThirdPartyCopies',ExcludedThirdPartyCopies,'Coverage',Coverage);
end
