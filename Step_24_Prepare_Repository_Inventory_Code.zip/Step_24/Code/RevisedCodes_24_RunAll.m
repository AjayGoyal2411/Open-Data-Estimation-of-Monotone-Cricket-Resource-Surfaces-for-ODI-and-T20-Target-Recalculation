function Results=RevisedCodes_24_RunAll(settings)
if nargin<1,settings=struct;end
C=RevisedCodes_24_Config(settings);U=RevisedCodes_24_Utils;here=fileparts(mfilename('fullpath'));
base=C.OutputRoot;resultFile=fullfile(base,'RevisedCodes_24_Result_v2.mat');
if isfile(resultFile)
    z=load(resultFile,'Results');Results=z.Results;
    assert(isfile(Results.RepositoryZip),'Stored repository ZIP missing.');
    assert(U.Hash(Results.RepositoryZip)==Results.RepositoryZipSHA256,'Stored repository ZIP changed.');
    fprintf('Existing final repository release verified and reused.\nRepository: %s\nChecks: %s\n',Results.RepositoryZip,Results.ChecksZip);return
end
report=string(tempname(base));mkdir(report);diary(fullfile(report,'RunLog.txt'));cleanup=onCleanup(@()diary('off')); %#ok<NASGU>
try
    fprintf('Step24 final repository release started %s\n',string(datetime('now')));
    Tests=RevisedCodes_24_SelfTests(U);U.Write(Tests,fullfile(report,'Step24_SelfTests.csv'));
    D=RevisedCodes_24_Discover(C,U);
    U.Write(removevars(D.Code,'SourcePath'),fullfile(report,'Step24_CodeInventory.csv'));
    U.Write(removevars(D.Artifacts,'SourcePath'),fullfile(report,'Step24_ArtifactInventory.csv'));
    U.Write(D.Coverage,fullfile(report,'Step24_StepCoverage.csv'));
    U.Write(D.ThirdParty,fullfile(report,'Step24_ThirdPartyInputInventory.csv'));
    U.Write(D.ExcludedThirdPartyCopies,fullfile(report,'Step24_ThirdPartyCopyExclusions.csv'));
    A=RevisedCodes_24_ClosureAudit(C,D,U);
    U.Write(A.Closure,fullfile(report,'Step24_ReviewerEditorEvidenceAudit.csv'));
    U.Write(A.Summary,fullfile(report,'Step24_ReviewerEditorEvidenceAuditSummary.csv'));
    U.Write(A.Limitations,fullfile(report,'Step24_ScientificLimitations.csv'));
    U.Write(A.Step22Gates,fullfile(report,'Step24_Step22ScientificGates.csv'));
    B=RevisedCodes_24_BuildRepository(C,D,A,report,here,U);
    Verification=RevisedCodes_24_VerifyRepository(B.Root);U.Write(Verification,fullfile(report,'Step24_RepositoryVerification.csv'));

    idx=lower([D.Artifacts.FileName;D.Artifacts.RelativePath]);
    core22=hasAll(idx,["Step22_PerformanceSummary.csv","Step22_PairedComparisons.csv","Step22_TestPopulation.csv","Step22_ExecutionGates.csv"]);
    core23=hasAll(idx,["Step23_GenderEquivalence.csv","Step23_GenderPoolingGate.csv","Step23_OpponentRecovery.csv","Step23_ComparatorRegister.csv"]);
    step23Figures=nnz(D.Artifacts.Category=="FIGURE"&contains(lower(D.Artifacts.FileName),'step23_'));
    noThirdPartyCopies=isempty(intersect(D.Artifacts.SHA256,D.ThirdParty.SHA256));
    Gate=["Step24 self-tests passed";"MATLAB code inventory nonempty";"Derived evidence inventory nonempty"; ...
        "Core Step22 evidence present";"Core Step23 evidence present";"Public manifest verified"; ...
        "Third-party inputs inventoried";"No byte-identical third-party copies released";"Reviewer/editor evidence audit completed"; ...
        "Step23 publication figures located";"No unresolved computational evidence"];
    Passed=[all(Tests.Passed);height(D.Code)>0;height(D.Artifacts)>0;core22;core23;Verification.RepositoryVerified; ...
        height(D.ThirdParty)>0;noThirdPartyCopies;height(A.Closure)>0;step23Figures>=9;A.Summary.UnresolvedEvidence==0];
    BlockingForPaper=[true;true;true;true;true;true;false;false;true;false;false];
    BlockingForDeposit=[true;true;true;true;true;true;true;true;true;true;true];
    Gates=table(Gate,Passed,BlockingForPaper,BlockingForDeposit);U.Write(Gates,fullfile(report,'Step24_ReleaseGates.csv'));
    ReadyForPaperWriting=all(Passed(BlockingForPaper));ReadyForExternalDeposit=all(Passed(BlockingForDeposit));
    RepositoryZipSHA256=U.Hash(B.Zip);
    Status="FINAL_REPOSITORY_RELEASE_COMPLETE";if ~ReadyForExternalDeposit,Status="REPOSITORY_BUILT_WITH_RECORDED_RELEASE_LIMITATIONS";end
    ThirdPartyCopiesExcluded=height(D.ExcludedThirdPartyCopies);ReviewerBoundedLimitations=A.Summary.DocumentedLimitations;
    DocumentedLimitations=height(A.Limitations);
    Summary=table(Status,ReadyForPaperWriting,ReadyForExternalDeposit,B.CodeFiles,B.ArtifactFiles,B.FiguresCopied, ...
        B.ThirdPartyFilesInventoried,ThirdPartyCopiesExcluded,A.Summary.UnresolvedEvidence,ReviewerBoundedLimitations, ...
        DocumentedLimitations,RepositoryZipSHA256, ...
        'VariableNames',{'Status','ReadyForPaperWriting','ReadyForExternalDeposit','CodeFiles','ArtifactFiles','FiguresCopied', ...
        'ThirdPartyFilesInventoried','ThirdPartyCopiesExcluded','UnresolvedEvidence','ReviewerBoundedLimitations', ...
        'DocumentedLimitations','RepositoryZipSHA256'});
    U.Write(Summary,fullfile(report,'Step24_FinalReleaseSummary.csv'));
    Results=struct('Status',Status,'ReadyForPaperWriting',ReadyForPaperWriting,'ReadyForExternalDeposit',ReadyForExternalDeposit, ...
        'RepositoryZip',B.Zip,'RepositoryZipSHA256',RepositoryZipSHA256,'ReportPath',report,'ChecksZip',"", ...
        'ReleaseGates',Gates,'ClosureSummary',A.Summary,'RepositoryVerification',Verification,'Settings',C);
    save(resultFile,'Results','-v7.3');
    checks=dir(fullfile(report,'Step24_*'));checks=checks(~[checks.isdir]);names=string({checks.name});
    Results.ChecksZip=report+"_Checks.zip";zip(Results.ChecksZip,cellstr(names),report);save(resultFile,'Results','-v7.3');
    disp(Summary);disp(Gates);fprintf('Upload %s\nFinal repository %s\n',Results.ChecksZip,Results.RepositoryZip);
catch err
    diary off;f=fopen(fullfile(report,'Step24_FAILURE.txt'),'wt');if f>=0,fprintf(f,'%s\n%s\n',err.identifier,getReport(err,'extended','hyperlinks','off'));fclose(f);end
    files=dir(fullfile(report,'*'));files=files(~[files.isdir]);names=string({files.name});zip(report+"_FAILED_Checks.zip",cellstr(names),report);
    fprintf('Upload %s\n',report+"_FAILED_Checks.zip");rethrow(err)
end
end

function tf=hasAll(index,tokens)
tf=true;for token=lower(string(tokens)),tf=tf&&any(contains(index,token));end
end
