function A = RevisedCodes_24_ClosureAudit(C,D,U)
% Re-evaluate closure from evidence. Unlike Step23, this routine never sets
% all rows to complete before testing them.
closurePath=U.Latest(C.SourceOutputRoot,'Step23_ReviewerComputationalClosure.csv');
T=U.Read(closurePath,["CommentID","Requirement","Evidence","Status","Remaining"],U);
for n=["CommentID","Requirement","Evidence","Status","Remaining"],T.(n)=string(T.(n));end
index=lower([D.Code.RelativePath;D.Artifacts.RelativePath;D.Code.FileName;D.Artifacts.FileName]);
manuscriptOnly=contains(T.Status,"OUT_OF_SCOPE_MANUSCRIPT_ONLY");
sourceLimited=contains(T.Status,"LIMITATION")|contains(T.Status,"SOURCE_LIMITED")|contains(T.Status,"SPARSE");
evidencePresent=false(height(T),1);evidenceTest=strings(height(T),1);

for i=1:height(T)
    id=T.CommentID(i);ev=T.Evidence(i);refs=stepReferences(ev);
    if manuscriptOnly(i)
        evidencePresent(i)=true;evidenceTest(i)="Tracked as manuscript-only; no computational pass asserted.";continue
    end
    if ~isempty(refs)
        ok=true;parts=strings(0,1);
        for s=refs
            hasCode=any(D.Code.Stage=="STEP"+string(s));hasArtifact=any(D.Artifacts.Stage=="STEP"+string(s));
            ok=ok&&(hasCode||hasArtifact);parts(end+1)=sprintf('Step%d:%d',s,hasCode||hasArtifact); %#ok<AGROW>
        end
        evidencePresent(i)=ok;evidenceTest(i)=strjoin(parts,'; ');
    else
        evidencePresent(i)=U.Nonblank(ev);evidenceTest(i)="Nonblank evidence statement; special test applied where defined.";
    end
    switch id
        case "Editor case studies"
            evidencePresent(i)=has(index,"step22_realmatchexamples.csv");evidenceTest(i)="Requires Step22_RealMatchExamples.csv";
        case "PLOS data availability"
            evidencePresent(i)=height(D.Code)>0&&height(D.Artifacts)>0;evidenceTest(i)="Requires discovered code and derived evidence; final bundle checked later.";
        case "R1 gender pooling"
            req=["step23_genderinnings.csv","step23_genderequivalence.csv","step23_gendersurfacecomparison.csv","step23_genderpoolinggate.csv"];
            evidencePresent(i)=hasAll(index,req);evidenceTest(i)="Requires four canonical Step23 gender outputs.";
        case "R1 competition and era curves"
            evidencePresent(i)=has(index,"step22_subgroups.csv");evidenceTest(i)="Requires Step22 subgroup evidence; classes remain algorithmic.";
        case "R2.7 dated team rankings"
            evidencePresent(i)=has(index,"step22_historycoverage.csv")&&has(index,"step23_opponentrecovery.csv");
            evidenceTest(i)="Requires past-only histories and opponent reconstruction; no official rankings claimed.";
        case "R2.13 full wicket T20"
            evidencePresent(i)=has(index,"step22_subgroups.csv")&&any(contains(index,"fullwicket"));
            evidenceTest(i)="Requires subgroup table and full-wicket figure/evidence.";
        case "R2.14 DLS VJD modified DLS"
            req=["vjd_table5_2002.csv","step23_vjdworkedexamples.csv","step23_comparatorregister.csv"];
            evidencePresent(i)=hasAll(index,req);evidenceTest(i)="Requires VJD table, worked examples and comparator register; DLS/DLMA remain source-limited.";
    end
end

Disposition=repmat("UNRESOLVED_EVIDENCE",height(T),1);
Disposition(manuscriptOnly)="MANUSCRIPT_ACTION_REQUIRED";
Disposition(evidencePresent&~manuscriptOnly&~sourceLimited)="COMPUTATION_EVIDENCE_PRESENT";
Disposition(evidencePresent&sourceLimited)="LIMITATION_DOCUMENTED_NOT_FULL_COMPARISON";
ComputationallyResolved=evidencePresent&~manuscriptOnly&~sourceLimited;
BoundedForManuscript=evidencePresent;
OriginalStep23Status=T.Status;OriginalStep23Remaining=T.Remaining;
T=addvars(T,OriginalStep23Status,OriginalStep23Remaining,evidenceTest,evidencePresent,sourceLimited, ...
    Disposition,ComputationallyResolved,BoundedForManuscript,'After','Evidence');
T.Status=[];T.Remaining=[];

AllComments=height(T);ManuscriptActions=nnz(manuscriptOnly);ComputationalEvidenceResolved=nnz(ComputationallyResolved);
DocumentedLimitations=nnz(Disposition=="LIMITATION_DOCUMENTED_NOT_FULL_COMPARISON");
UnresolvedEvidence=nnz(Disposition=="UNRESOLVED_EVIDENCE");
Summary=table(AllComments,ManuscriptActions,ComputationalEvidenceResolved,DocumentedLimitations,UnresolvedEvidence, ...
    all(BoundedForManuscript),'VariableNames',{'AllComments','ManuscriptActions','ComputationalEvidenceResolved', ...
    'DocumentedLimitations','UnresolvedEvidence','AllCommentsDispositioned'});

gatePath=U.Latest(C.SourceOutputRoot,'Step22_ExecutionGates.csv');
G=U.Read(gatePath,["Gate","Passed"],U);G.Gate=string(G.Gate);G.Passed=U.IsTrue(G.Passed);
failed=G(~G.Passed,:);Limitation=["Step22 gate not established: "+failed.Gate; ...
    "Modern professional DLS cannot be reproduced from disclosed public parameters"; ...
    "DLMA published-comparator reproduction remains disabled without certified fitted parameters"];
Type=[repmat("FAILED_SCIENTIFIC_GATE",height(failed),1);"SOURCE_LIMITATION";"SOURCE_LIMITATION"];
ClaimAllowed=[repmat("Do not claim this property",height(failed),1); ...
    "Do not report exact modern DLS performance";"Do not label a refit as published DLMA performance"];
Limitations=table(Type,Limitation,ClaimAllowed);
A=struct('Closure',T,'Summary',Summary,'Step22Gates',G,'Limitations',Limitations, ...
    'SourceClosurePath',closurePath,'SourceGatePath',gatePath);
end

function refs=stepReferences(text)
tok=regexp(char(text),'(?i)step\s*0*(\d{1,2})','tokens');refs=[];
for i=1:numel(tok),refs(end+1)=str2double(tok{i}{1});end %#ok<AGROW>
refs=unique(refs(isfinite(refs)&refs>=1&refs<=23));
end

function tf=has(index,token)
tf=any(contains(index,lower(string(token))));
end

function tf=hasAll(index,tokens)
tf=true;for token=lower(string(tokens)),tf=tf&&has(index,token);end
end
