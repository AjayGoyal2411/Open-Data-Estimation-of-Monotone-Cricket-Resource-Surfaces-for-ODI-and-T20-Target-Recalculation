function Verification=RevisedCodes_24_VerifyRepository(root)
if nargin<1,root=fileparts(mfilename('fullpath'));end
manifest=fullfile(root,'MANIFEST_SHA256.csv');assert(isfile(manifest),'MANIFEST_SHA256.csv missing.');
T=readtable(manifest,'TextType','string');assert(all(ismember(["RelativePath","Bytes","SHA256"],string(T.Properties.VariableNames))));
Exists=false(height(T),1);SizeMatches=false(height(T),1);HashMatches=false(height(T),1);
for i=1:height(T)
    p=fullfile(root,strrep(T.RelativePath(i),'/',filesep));Exists(i)=isfile(p);if ~Exists(i),continue;end
    d=dir(p);SizeMatches(i)=d.bytes==double(T.Bytes(i));HashMatches(i)=hashFile(p)==T.SHA256(i);
end
Verification=table(height(T),nnz(Exists),nnz(SizeMatches),nnz(HashMatches),all(Exists&SizeMatches&HashMatches), ...
    'VariableNames',{'ManifestRows','FilesPresent','SizesMatched','HashesMatched','RepositoryVerified'});
assert(Verification.RepositoryVerified,'Repository verification failed.');
end

function h=hashFile(p)
f=fopen(p,'rb');assert(f>=0);c=onCleanup(@()fclose(f));md=java.security.MessageDigest.getInstance('SHA-256');
while true
    b=fread(f,1048576,'*uint8');if isempty(b),break;end
    md.update(typecast(b(:).','int8'));
end
h=lower(string(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[])));clear c
end
