clear; clc;
here = fileparts(mfilename('fullpath'));
addpath(here);

% Normally no editing is required. If the project is elsewhere, use:
% settings = struct('ProjectRoot',"E:\\YourFolder");
settings = struct;
Results = RevisedCodes_24_RunAll(settings); %#ok<NASGU>

