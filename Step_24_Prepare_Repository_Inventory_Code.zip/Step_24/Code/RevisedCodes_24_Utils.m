function U = RevisedCodes_24_Utils
U.Hash = @hashFile;
U.Write = @writeTable;
U.Read = @readChecked;
U.Require = @requireColumns;
U.Nonblank = @nonblank;
U.Relative = @relativePath;
U.Stage = @stageLabel;
U.CopyVerified = @copyVerified;
U.IsTrue = @isTrue;
U.Latest = @latestFile;
end

function h = hashFile(path)
path = string(path); f = fopen(path,'rb'); assert(f >= 0,'Cannot hash %s',path);
c = onCleanup(@()fclose(f)); md = java.security.MessageDigest.getInstance('SHA-256');
while true
    b = fread(f,1048576,'*uint8'); if isempty(b), break; end
    md.update(typecast(b(:).','int8'));
end
h = lower(string(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[]))); clear c
end

function writeTable(T,path)
assert(istable(T)); parent = fileparts(path); if ~isfolder(parent), mkdir(parent); end
writetable(T,path);
end

function T = readChecked(path,columns,U)
assert(isfile(path),'Missing input: %s',path); T = readtable(path,'TextType','string');
U.Require(T,columns);
end

function requireColumns(T,names)
missing = setdiff(string(names),string(T.Properties.VariableNames));
assert(isempty(missing),'Missing columns: %s',strjoin(missing,', '));
end

function tf = nonblank(x)
s = strtrim(string(x)); tf = ~ismissing(s) & strlength(s) > 0;
end

function rel = relativePath(root,path)
root = string(root); path = string(path);
prefix = root + string(filesep); assert(startsWith(lower(path),lower(prefix)) || lower(path)==lower(root), ...
    'Path is outside root: %s',path);
rel = extractAfter(path,strlength(root)); rel = strip(rel,'left',filesep);
rel = replace(rel,string(filesep),"/");
end

function stage = stageLabel(path)
s = lower(replace(string(path),string(filesep),"/")); stage = "UNCLASSIFIED";
tok = regexp(char(s),'(?:revisedcodes_|run_|/|^)step[_-]?(\d{1,2})','tokens','once');
if isempty(tok), tok = regexp(char(s),'revisedcodes_(\d{2})','tokens','once'); end
if ~isempty(tok), stage = "STEP" + string(str2double(tok{1})); return; end
if contains(s,'pre20'), stage = "PRE20"; end
end

function copyVerified(src,dst,U)
src = string(src); dst = string(dst); assert(isfile(src),'Missing copy source: %s',src);
parent = fileparts(dst); if ~isfolder(parent), mkdir(parent); end
[ok,msg] = copyfile(src,dst,'f'); assert(ok,'Copy failed: %s',msg);
assert(U.Hash(src)==U.Hash(dst),'Copy hash mismatch: %s',src);
end

function tf = isTrue(x)
if islogical(x), tf=x; return; end
if isnumeric(x), tf=x~=0; return; end
s=lower(strtrim(string(x))); tf=ismember(s,["1","true","yes","pass","passed"]);
end

function path = latestFile(root,name)
d = dir(fullfile(root,'**',name)); d = d(~[d.isdir]);
assert(~isempty(d),'Could not find %s under %s',name,root);
[~,ix] = max([d.datenum]); path = string(fullfile(d(ix).folder,d(ix).name));
end
