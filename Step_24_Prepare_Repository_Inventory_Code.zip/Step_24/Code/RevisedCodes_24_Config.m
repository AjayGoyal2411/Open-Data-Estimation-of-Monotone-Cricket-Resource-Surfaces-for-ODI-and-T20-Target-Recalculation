function C = RevisedCodes_24_Config(settings)
if nargin < 1, settings = struct; end
assert(isstruct(settings) && isscalar(settings),'settings must be a scalar struct.');
allowed = ["ProjectRoot","ReleaseName","FigureVisible","IncludeModelMATFiles", ...
    "MaxSingleArtifactBytes","HashThirdPartyInputs","AuthorGivenName", ...
    "AuthorFamilyName","AuthorAffiliation","RepositoryTitle","CodeLicense", ...
    "DataLicense"];
assert(all(ismember(string(fieldnames(settings)),allowed)),'Unknown Step24 setting.');

C.ProjectRoot = "D:\VihaanProject1";
C.ReleaseName = "Vihaan_Cricket_Resource_Model_Research_Repository_v1_1";
C.FigureVisible = false;
C.IncludeModelMATFiles = true;
C.MaxSingleArtifactBytes = 2e9;
C.HashThirdPartyInputs = true;
C.AuthorGivenName = "Ajay";
C.AuthorFamilyName = "Goyal";
C.AuthorAffiliation = "Institute of Design, Nirma University, Ahmedabad, India";
C.RepositoryTitle = "Cricket resource and scoring-output model: reproducible computational repository";
C.CodeLicense = "MIT";
C.DataLicense = "CC-BY-4.0";
for n = reshape(string(fieldnames(settings)),1,[]), C.(n) = settings.(n); end

C.ProjectRoot = string(C.ProjectRoot);
C.ReleaseName = string(C.ReleaseName);
C.OutputRoot = fullfile(C.ProjectRoot,'paper_outputs_revisedcodes','final_repository_release');
C.OutputRoot = string(C.OutputRoot);
C.SourceOutputRoot = string(fullfile(C.ProjectRoot,'paper_outputs_revisedcodes'));
C.ThirdPartyRoots = string(fullfile(C.ProjectRoot, ...
    {'final_retained_dataset','clean_from_yaml','clean_from_json','JSONFiles','ALLYAML','lib'}));
C.ArtifactExtensions = [".csv",".tsv",".md",".txt",".json",".yaml",".yml", ...
    ".png",".pdf",".fig"];
C.ModelMATNameTokens = ["result","statepredictions","model","frozen","manifest"];

assert(isfolder(C.ProjectRoot),'ProjectRoot not found: %s',C.ProjectRoot);
if ~isfolder(C.OutputRoot), mkdir(C.OutputRoot); end
assert(C.MaxSingleArtifactBytes > 0 && isfinite(C.MaxSingleArtifactBytes));
assert(islogical(C.IncludeModelMATFiles) && isscalar(C.IncludeModelMATFiles));
assert(islogical(C.HashThirdPartyInputs) && isscalar(C.HashThirdPartyInputs));
end
