function Result=RevisedCodes_19_02_FreezeProtocol(I,Lock,Confirmation,c)
U=RevisedCodes_19_Utils;V=RevisedCodes_14_Utils;
assert(string(Confirmation.Status)=="CONFIRMATION_PASSED_FIXED_CHOICES"&&all(Confirmation.Checks.Passed),'Confirmation failed; freeze is prohibited.');
U.Verify(Confirmation.ArtifactHashes);report=fullfile(c.Root,'reports');
folder=fullfile(c.Root,'frozen',"build_"+string(datetime('now','Format','yyyyMMdd_HHmmss_SSS')));
out=fullfile(c.Root,'RevisedCodes_19_02_Result.mat');
if isfile(out),z=load(out,'Result');Result=z.Result;U.Verify(Result.Hashes);fprintf('Existing freeze verified; no refit or overwrite.\n');return;end
% A final test from a preceding attempt must not silently become development evidence.
prior=dir(fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','**','RevisedCodes_22*Result.mat'));
assert(isempty(prior),'A Step22 result exists. A new freeze would require a documented exploratory revision.');
if ~isfolder(folder),mkdir(folder);end
Models=cell(height(Lock.Index),1);RefitAudit=table;Policies=struct;History=table;TargetChecks=table;
for fmt=["ODI","T20"]
 j=find(Confirmation.Data.Format==fmt);assert(isscalar(j));z=load(Confirmation.Data.Path(j),'Features','Audit');
 ix=find(Lock.Index.Format==fmt);[MM,A,H]=RevisedCodes_19_Refit(z.Features,z.Audit,Lock.Index(ix,:),Lock.Models(ix),Lock);
 Models(ix)=MM;RefitAudit=[RefitAudit;A];History=[History;H]; %#ok<AGROW>
 k=find(Lock.Index.Format==fmt&Lock.Index.Role=="PrimaryResource");M=Models{k};policy=V.DefaultPolicy(M,Lock.PolicyConfig);Policies.(char(fmt))=policy;
 S=V.SyntheticScenarios(M.Horizon);
 for q=1:numel(S)
  R=V.Apply(M,M.FullStartMean,S(q).First,S(q).Second,policy);
  T=R.Target;T.Format=fmt;T.Scenario=string(S(q).Name);TargetChecks=[TargetChecks;T]; %#ok<AGROW>
 end
end
U.Write(report,'19_02_RefitAudit',RefitAudit);U.Write(report,'19_02_TargetPolicyChecks',TargetChecks);
RevisedCodes_19_Publication(Lock.Index,Models,c);
% Final bundle contains actual refitted objects, not just source paths.
Frozen=struct('SchemaVersion',"19.1.0",'Index',Lock.Index,'Models',{Models},'Policies',Policies, ...
 'TrainingCutoffExclusive',datetime(2024,1,1),'Protocol',Lock.Protocol,'Settings',Lock.Settings, ...
 'Selection',Lock.Selection,'RefitSettings',Lock.RefitSettings,'SourceHashes',Lock.Sources, ...
 'ModelSelected',true,'PolicyFrozen',true,'IndependentPerformanceEvaluated',false, ...
 'ConfirmationModelsDifferFromFinalRefit',true,'CreatedUTC',datetime('now','TimeZone','UTC'), ...
 'Scope','Men ODI/T20 standard primary first-innings capacity; history forecast separate; revised-match sources require later verification');
path=fullfile(folder,'RevisedCodes_19_FrozenModels.mat');save(path,'Frozen','-v7.3');
z=load(path,'Frozen');assert(isequaln(z.Frozen.Index,Frozen.Index));
for k=1:numel(Models)
 assert(isequaln(z.Frozen.Models{k},Models{k}),'Frozen serialization mismatch');
end
U.Write(folder,'Frozen_TrainingHistory',History);U.Write(folder,'Frozen_Protocol',Lock.Protocol);U.Write(folder,'Frozen_RefitAudit',RefitAudit);
% Preserve code dependencies alongside the artifact. Existing upstream files stay untouched.
codeFolder=fullfile(folder,'code');if ~isfolder(codeFolder),mkdir(codeFolder);end
names=dir(fullfile(c.ProjectRoot,'RevisedCodes_*.m'));copied=strings(0,1);
for k=1:numel(names)
 source=fullfile(names(k).folder,names(k).name);dest=fullfile(codeFolder,names(k).name);copyfile(source,dest);copied(end+1,1)=string(dest); %#ok<AGROW>
end
% Include Step19 functions even if the package was added from a separate folder.
for k=1:height(Lock.Code)
 source=Lock.Code.Path(k);[~,n,e]=fileparts(source);dest=fullfile(codeFolder,n+e);copyfile(source,dest);copied(end+1,1)=string(dest); %#ok<AGROW>
end
assert(~isempty(copied),'No project code files available for snapshot.');
U.Write(folder,'Frozen_SourceHashes',Lock.Sources);U.Write(folder,'Frozen_Selection',Lock.Selection);
% Verify sources/code still match the pre-confirmation lock before committing.
U.Verify(Lock.Sources);U.Verify(Lock.Code);
files=dir(fullfile(folder,'*'));files=files(~[files.isdir]);paths=string(fullfile({files.folder},{files.name}))';
Hashes=U.Hashes([paths;copied]);U.Write(report,'19_02_FrozenArtifactHashes',Hashes);
save(fullfile(folder,'FrozenIntegrity.mat'),'Hashes');
Result=struct('Status',"FROZEN_THROUGH2023_CASES_COMPARATORS_AND_TEMPORAL_TEST_PENDING", ...
 'FrozenModelPath',string(path),'Hashes',Hashes,'RefitAudit',RefitAudit,'PolicyFrozen',true, ...
 'IndependentPerformanceEvaluated',false,'IntegrityPath',string(fullfile(folder,'FrozenIntegrity.mat')));
save(out,'Result','-v7.3');
U.Write(report,'19_02_Status',table(string(Result.Status),true,false,'VariableNames',{'Status','PolicyFrozen','IndependentPerformanceEvaluated'}));
fprintf('Step19 models refitted through 2023 and frozen. No case or final-test predictions computed.\n');
end
