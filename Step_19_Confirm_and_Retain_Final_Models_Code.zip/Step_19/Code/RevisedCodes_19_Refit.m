function [Models,Audit,History]=RevisedCodes_19_Refit(F,A,Index,Old,Lock)
% Retained specifications only. No tuning on 2023 or final-test observations.
U=RevisedCodes_19_Utils;V=RevisedCodes_10_Utils;W=RevisedCodes_11_Utils;P=RevisedCodes_12_Utils;
assert(all(A.MatchDate<datetime(2024,1,1))&&all(ismember(string(A.Split),["train","validation"])));
fmt=Index.Format(1);assert(all(A.Format==fmt));
[~,first,g]=unique(V.Key(A),'stable');counts=accumarray(g,1);
L=table(string(A.MatchID(first)),double(A.InningsIndex(first)),A.MatchDate(first),counts, ...
 double(A.FinalDeliveryRuns(first)),'VariableNames',{'MatchID','InningsIndex','Date','CachedPrimaryStates','DeliveryRuns'});
assert(numel(unique(L.MatchID))==height(L));
O=struct('u',double(F.BallsRemaining),'w',double(F.WicketsInHand),'Y',double(A.RemainingRuns),'Innings',g);
S=V.Estimate(O,L,fmt,Lock.RefitSettings.Step10);S.PackageID="FINAL_THROUGH2023_"+fmt;
S.Cohort="FINAL_THROUGH2023";S.TrainingCutoffExclusive=datetime(2024,1,1);
History=table(L.MatchID,dateshift(L.Date,'start','day'),repmat(fmt,height(L),1),string(F.BattingTeam(first)),string(F.Opponent(first)), ...
 string(F.Venue(first)),string(F.EventName(first)),L.DeliveryRuns, ...
 'VariableNames',{'MatchID','Date','Format','BattingTeam','Opponent','Venue','EventName','DeliveryRuns'});
C=V.Candidates();Models=cell(height(Index),1);Audit=table;
for j=1:height(Index)
 old=Old{j};id=Index.ModelID(j);role=Index.Role(j);cc=Lock.RefitSettings.Step12;
 if role=="Baseline"
  [u,~]=ndgrid(0:S.Horizon,0:10);R=u/S.Horizon;R(:,1)=0;
  M=struct('Resource',R,'Horizon',S.Horizon,'FullStartMean',S.FullStartMean,'Supported',true(size(R)));
 elseif isfield(old,'ForecastOnly')&&old.ForecastOnly
  FF=U.Histories(F,A,old.HistoryK,datetime(2024,1,1));
  M=fitContext(FF,A,S.Horizon,S.FullStartMean,old,Lock.RefitSettings.Context);
 elseif startsWith(id,"Compact::")
  ref=old.SourceReferenceID;ci=find(C.CandidateID==ref);assert(isscalar(ci));
  [M,Q]=W.Solve(S,C(ci,:),Lock.RefitSettings.Step11,Lock.RefitSettings.Step10);
  [params,starts,D]=P.CompactFit(M,cc);M.ReferenceCertificate=Q;M.Resource=P.CompactGrid(params,S.Horizon);
  M.Parameters=params;M.Multistarts=starts;M.FitDiagnostics=D;M.SourceReferenceID=ref;
  M.ModelFamily="Compact";M.GlobalOptimumCertified=false;M.Certified=false;M.ObjectiveGapBound=NaN;
  M.CompletionAssumption="Compact-family interpolation/extrapolation; unsupported cells have no empirical accuracy guarantee";
 elseif startsWith(id,"Bernstein::")
  cc=Lock.RefitSettings.Flexible;
  ref=old.SourceReferenceID;ci=find(C.CandidateID==ref);assert(isscalar(ci));
  [M,Q]=W.Solve(S,C(ci,:),Lock.RefitSettings.Step11,Lock.RefitSettings.Step10);
  if startsWith(old.FitBasis,"direct_")
   [target,weights,constant,support]=P.DirectTarget(S,extractAfter(old.FitBasis,"direct_"));
  else,target=M.Resource(:);weights=M.DataWeights(:);support=M.Supported(:);constant=0;end
  [coef,R,D,attempts]=P.BernsteinFit(S.Horizon,old.Degree,target,weights,old.Smoothing,cc);
  M.ReferenceCertificate=Q;M.Resource=R;M.Coefficients=coef;M.Degree=old.Degree;M.Smoothing=old.Smoothing;
  M.Supported=reshape(support,size(R));M.DataWeights=reshape(weights,size(R));M.FitDiagnostics=D;
  M.OptimizerAttempts=attempts;M.FitBasis=old.FitBasis;M.SourceReferenceID=ref;
  M.DirectOutcomeVarianceConstant=constant;M.ModelFamily="Bernstein";M.GlobalOptimumCertified=true;M.ObjectiveGapBound=D.ObjectiveGapBound;
  M.CompletionAssumption="Monotone polynomial completion; unsupported cells have no empirical accuracy guarantee";
 else,error('No retained-specification refit adapter for %s',id);
 end
 residual=NaN;
 if isfield(M,'Resource')
  if role~="Baseline",residual=V.Residual(M.Resource(:),M.Horizon);assert(residual<=cc.ConstraintTolerance,'Refitted resource violates constraints.');end
  assert(all(isfinite(M.Resource),'all'));
 end
 M.TrainingCutoffExclusive=datetime(2024,1,1);M.Format=fmt;M.ModelID=id;M.Role=role;
 M.TrainingInnings=height(L);M.TrainingStates=height(A);M.ModelSelected=ismember(role,["PrimaryResource","PrimaryForecast"]);
 M.PolicyFrozen=true;M.TrainingHistory=History;M.HistoryPolicy="Strict earlier dates; frozen source ledger ending before 2024; no test updates";
 take=unique(round(linspace(1,height(A),min(100,height(A)))))';
 Query=F(take,:);if isfield(M,'ForecastOnly')&&M.ForecastOnly,Query=FF(take,:);end
 Query.MatchID=string(A.MatchID(take));Query.MatchDate=A.MatchDate(take);
 bundle=struct('PolicyFrozen',true,'Index',Index(j,:),'Models',{{M}});
 J=RevisedCodes_15_16_Utils;expected=J.Predict(M,Query);
 actual=RevisedCodes_19_PredictFrozen(bundle,fmt,role,Query);
 interfaceError=max(abs(actual-expected));assert(interfaceError<1e-7,'Frozen inference interface differs from refit evaluator.');
 Models{j}=M;
 Audit=[Audit;table(fmt,role,id,height(L),height(A),min(L.Date),max(L.Date),S.FullStartMean,residual,interfaceError, ...
  'VariableNames',{'Format','Role','ModelID','TrainingInnings','TrainingStates','Earliest','Latest','FullStartMean','ResourceConstraintResidual','FrozenInterfaceMaximumDifference'})]; %#ok<AGROW>
end
end
function M=fitContext(F,A,H,mu,old,c)
W=RevisedCodes_12_ContextUtils;V=RevisedCodes_10_Utils;labels=W.Labels();ablation=find(labels==old.Ablation);assert(isscalar(ablation));
[~,first,g]=unique(V.Key(A),'stable');count=accumarray(g,1);weight=ones(height(A),1);
if string(c.ContextWeighting)=="innings",weight=1./count(g);else,assert(string(c.ContextWeighting)=="state");end
tw=sum(weight);Cat=W.Categories(F(first,:),c);sw=[];sx=[];sx2=[];
for k=1:20000:height(F)
 ix=k:min(k+19999,height(F));[X,names,groups]=W.Raw(F(ix,:),H,mu,Cat,old.HistoryK);valid=isfinite(X);X(~valid)=0;ww=weight(ix);
 if isempty(sw),sw=zeros(1,size(X,2));sx=sw;sx2=sw;end
 sw=sw+ww'*double(valid);sx=sx+ww'*X;sx2=sx2+ww'*(X.^2);
end
P=W.Preprocessor(sw,sx,sx2,names,groups,Cat,tw);cols=find(~P.Constant&groups<=ablation);n=numel(cols)+1;
G=zeros(n);b=zeros(n,1);y2=0;
for k=1:20000:height(F)
 ix=k:min(k+19999,height(F));X=W.Encode(F(ix,:),H,mu,P,old.HistoryK);X=[ones(numel(ix),1),X(:,cols)];y=A.RemainingRuns(ix)/mu;ww=weight(ix);
 G=G+X'*(X.*ww);b=b+X'*(ww.*y);y2=y2+sum(ww.*y.^2);
end
[beta,D]=W.Solve(G/tw,b/tw,y2/tw,old.Lambda);
M=struct('Horizon',H,'FullStartMean',mu,'HistoryK',old.HistoryK,'Ablation',old.Ablation, ...
 'Lambda',old.Lambda,'Preprocessor',P,'Columns',cols,'Beta',beta,'FeatureNames',["Intercept",names(cols)], ...
 'ForecastOnly',true,'OfficialRankings',false,'FitDiagnostics',D,'ContextWeighting',c.ContextWeighting);
end
