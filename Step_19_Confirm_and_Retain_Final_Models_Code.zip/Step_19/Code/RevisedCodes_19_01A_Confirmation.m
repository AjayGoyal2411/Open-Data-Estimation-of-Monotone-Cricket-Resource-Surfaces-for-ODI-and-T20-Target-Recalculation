function Result=RevisedCodes_19_01A_Confirmation(I,Lock,c)
% The locked models are scored once on 2023; no selection or parameter fitting.
U=RevisedCodes_19_Utils;V=RevisedCodes_15_16_Utils;
out=fullfile(c.Root,'RevisedCodes_19_01A_Result.mat');
if isfile(out)
 z=load(out,'Result');Result=z.Result;U.Verify(Result.ArtifactHashes);fprintf('2023 confirmation result verified and reused; no reselection.\n');return;
end
% Persist an opening record before labels are selected. Partial failures resume only the same lock.
Opened=struct('StartedUTC',datetime('now','TimeZone','UTC'),'ProtocolSHA256', ...
 U.Hash(fullfile(c.Root,'19_00_ProtocolLock.mat')));p=fullfile(c.Root,'19_01A_OpeningRecord.mat');
if isfile(p),z=load(p,'Opened');assert(z.Opened.ProtocolSHA256==Opened.ProtocolSHA256,'Confirmation lock changed.');else,save(p,'Opened');end
report=fullfile(c.Root,'reports');Scores=table;Pairs=table;Groups=table;Populations=table;Data=table;PredictionFiles=strings(0,1);Checks=table;
for fmt=["ODI","T20"]
 [F,A]=RevisedCodes_19_Data(I,fmt,c);idx=find(Lock.Index.Format==fmt);Models=Lock.Models(idx);Index=Lock.Index(idx,:);
 historyK=[];for j=1:numel(Models),if isfield(Models{j},'HistoryK'),historyK(end+1)=Models{j}.HistoryK;end;end %#ok<AGROW>
 for k=unique(historyK)
  F=U.Histories(F,A,k,datetime(2023,1,1));mu=double(F.OriginalHistoryFormatMean);oldK=I.OriginalContext.ShrinkagePseudoInnings;
  for entity=["Format","Batting","Opponent","Venue","Event"]
   n=double(F.("OriginalHistory"+entity+"N"));expected=double(F.("OriginalHistory"+entity+"Mean"));
   if entity~="Format",expected=(expected.*(n+oldK)-oldK*mu+k*mu)./(n+k);end
   assert(isequal(double(F.("History"+entity+"N")),n),'Recomputed history counts differ from Step09.');
   assert(all(abs(double(F.("History"+entity+"Mean_K"+string(k)))-expected)<=1e-6), ...
    'Step19:HistoryReconciliation','Recomputed frozen-source history differs from Step09 for %s.',entity);
  end
 end
 Features=F;Audit=A;dataPath=fullfile(c.Root,char("19_TrainAnd2023_"+fmt+".mat")); %#ok<NASGU>
 save(dataPath,'Features','Audit','-v7.3');Data=[Data;table(fmt,string(dataPath),'VariableNames',{'Format','Path'})]; %#ok<AGROW>
 q=year(A.MatchDate)==2023;F=F(q,:);A=A(q,:);assert(~isempty(A));
 assert(all(A.Split=="validation")&&all(A.MatchDate>=datetime(2023,1,1)&A.MatchDate<datetime(2024,1,1)));
 Populations=[Populations;table(fmt,numel(unique(string(A.MatchID))),height(A),min(A.MatchDate),max(A.MatchDate), ...
  'VariableNames',{'Format','Matches','States','Earliest','Latest'})]; %#ok<AGROW>
 assert(Populations.Matches(end)>=c.MinGroupInnings,'Insufficient 2023 confirmation matches.');
 Prediction=zeros(height(A),numel(Models));RawPrediction=Prediction;Clusters=table;
 ri=find(Index.Role=="PrimaryResource");[~,~,commonSupport]=V.Predict(Models{ri},F);
 for j=1:numel(Models)
  [p,raw]=V.Predict(Models{j},F);Prediction(:,j)=p;RawPrediction(:,j)=raw;
  C=V.Score(A,p,raw);C.PackageID=repmat("Confirmation2023",height(C),1);C.ModelID=repmat(Index.ModelID(j),height(C),1);C.Role=repmat(Index.Role(j),height(C),1);
  Clusters=[Clusters;C];Q=V.Summary(C);Q.Format=fmt;Q.ModelID=Index.ModelID(j);Q.Role=Index.Role(j);Scores=[Scores;Q]; %#ok<AGROW>
  G=U.Subgroups(A,F,p,raw,commonSupport,Models{j},c);G.Format=repmat(fmt,height(G),1);G.Role=repmat(Index.Role(j),height(G),1);Groups=[Groups;G]; %#ok<AGROW>
 end
 for j=2:height(Index)
  C=Clusters(Clusters.Role==Index.Role(j),:);B=Clusters(Clusters.Role=="Baseline",:);
  Q=U.Pair(B,C,c);Q.Format=fmt;Q.Role=Index.Role(j);Q.Comparator="Baseline";Pairs=[Pairs;Q]; %#ok<AGROW>
 end
 % Directly compare the locked parsimonious choices to their development leaders.
 for pair=["FlexibleComparator","LiveScoreComparator";"PrimaryResource","PrimaryForecast"]
  B=Clusters(Clusters.Role==pair(1),:);C=Clusters(Clusters.Role==pair(2),:);
  Q=U.Pair(B,C,c);Q.Format=fmt;Q.Role=pair(2);Q.Comparator=pair(1);Pairs=[Pairs;Q]; %#ok<AGROW>
 end
 for role=["PrimaryResource","PrimaryForecast"]
  track="Resource";if role=="PrimaryForecast",track="Context";end
  s=Lock.Selection(Lock.Selection.Format==fmt&Lock.Selection.Track==track,:);assert(height(s)==1);
  Q=Pairs(Pairs.Format==fmt&Pairs.Role==role&Pairs.Comparator=="Baseline",:);
  passed=-Q.GainLower95<=s.PracticalMarginRuns;
  Checks=[Checks;table(fmt,role,s.PracticalMarginRuns,-Q.GainLower95,passed, ...
   'VariableNames',{'Format','Role','LockedMarginRuns','Upper95ExcessRMSEvsBaseline','Passed'})]; %#ok<AGROW>
 end
 Audit=A;Features=F;path=fullfile(c.Root,char("19_2023_Predictions_"+fmt+".mat")); %#ok<NASGU>
 save(path,'Audit','Features','Prediction','RawPrediction','Clusters','Index','Models','commonSupport','-v7.3');PredictionFiles(end+1,1)=string(path); %#ok<AGROW>
end
U.Write(report,'19_01A_ConfirmationScores',Scores);U.Write(report,'19_01A_PairedComparisons',Pairs);
U.Write(report,'19_01A_Subgroups',Groups);U.Write(report,'19_01A_Populations',Populations);U.Write(report,'19_01A_ConfirmationGates',Checks);
status="CONFIRMATION_PASSED_FIXED_CHOICES";if ~all(Checks.Passed),status="BLOCKED_CONFIRMATION_PERFORMANCE";end
Result=struct('Status',status,'Scores',Scores,'Pairs',Pairs,'Checks',Checks,'Data',Data,'PredictionFiles',PredictionFiles, ...
 'ProtocolSHA256',Opened.ProtocolSHA256,'ArtifactHashes',U.Hashes([Data.Path;PredictionFiles]));
save(out,'Result','-v7.3');
fig=figure('Visible','off','Color','w','Position',[100 100 1100 450]);tiledlayout(1,2,'Padding','compact');
for fmt=["ODI","T20"]
 T=Pairs(Pairs.Format==fmt&Pairs.Comparator=="Baseline",:);nexttile;
 errorbar(1:height(T),T.RMSEGain,T.RMSEGain-T.GainLower95,T.GainUpper95-T.RMSEGain,'o');
 xticks(1:height(T));xticklabels(T.Role);xtickangle(25);yline(0);ylabel('RMSE reduction versus linear baseline (runs)');title(fmt+": locked 2023 confirmation");
end
U.Figure(fig,report,"F19_2023Confirmation");
end
