function Results=RevisedCodes_19_RunAll(settings)
% Complete Step19: lock -> development diagnostics -> 2023 confirmation -> refit/freeze.
% No Step20/21/22 evaluation is invoked.
if nargin<1,settings=struct;end
c=RevisedCodes_19_00_Config(settings);U=RevisedCodes_19_Utils;report=fullfile(c.Root,'reports');
if ~isfolder(report),mkdir(report);end
Results=struct;
try
 Results.SelfTests=RevisedCodes_19_SelfTests(c);U.Write(report,'19_SelfTests',Results.SelfTests);
 Results.ReviewerMap=RevisedCodes_19_ReviewerMap(c);
 I=U.Inputs(c);Lock=RevisedCodes_19_00_LockProtocol(I,c);
 Results.GenderObservationAudit=RevisedCodes_19_00_GenderStateAudit(I,c);
 Results.Interpretation=RevisedCodes_19_01_ContextInterpretation(I,Lock,c);
 Results.Chases=RevisedCodes_19_01B_ChaseEvidence(I,c);
 Results.Confirmation=RevisedCodes_19_01A_Confirmation(I,Lock,c);
 if startsWith(Results.Confirmation.Status,"BLOCKED")
  Results.Status="BLOCKED_CONFIRMATION_NO_FREEZE";
 else
  Results.Freeze=RevisedCodes_19_02_FreezeProtocol(I,Lock,Results.Confirmation,c);
  Results.Status=Results.Freeze.Status;
 end
 U.Write(report,'19_RunStatus',table(string(Results.Status),'VariableNames',{'Status'}));
 failurePath=fullfile(report,'19_Failure.csv');
 if isfile(failurePath)
  history=fullfile(c.Root,'failure_history');if ~isfolder(history),mkdir(history);end
  movefile(failurePath,fullfile(history,"Failure_"+string(datetime('now','Format','yyyyMMdd_HHmmss_SSS'))+".csv"));
 end
 Results.ReportZIP=U.SaveReport(c,report);save(fullfile(c.Root,'RevisedCodes_19_Result.mat'),'Results','-v7.3');
 publication=fullfile(c.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady');
 % Concise main assets plus complete supplementary ledgers, with separate purpose folders.
 td=fullfile(publication,'Results','Tables','Step19');fd=fullfile(publication,'Results','Figures','Step19');
 sd=fullfile(publication,'Supplementary','Step19');md=fullfile(publication,'Methodology','Tables','Step19');
 for p=string({td,fd,sd,md}),if ~isfolder(p),mkdir(p);end;end
 files=dir(fullfile(report,'*'));for j=1:numel(files)
  if files(j).isdir,continue;end;n=string(files(j).name);dest=sd;
  if startsWith(n,'F19_'),dest=fd;
  elseif contains(n,["InputDecision","Protocol","LockedModels"]),dest=md;
  elseif contains(n,["ChasePooledScores","ChasePairedGain","ConfirmationScores","PairedComparisons","RefitAudit","CompactParameters"]),dest=td;end
  copyfile(fullfile(files(j).folder,files(j).name),fullfile(dest,files(j).name));
 end
 fprintf('Step19 %s. Upload %s\n',Results.Status,Results.ReportZIP);
catch ex
 Failure=table(string(ex.identifier),string(ex.message),'VariableNames',{'Identifier','Message'});
 U.Write(report,'19_Failure',Failure);U.Write(report,'19_RunStatus',table("BLOCKED_RUN_ERROR",'VariableNames',{'Status'}));U.SaveReport(c,report);
 fprintf('Step19 stopped. Upload RevisedCodes_19_Checks.zip with the MATLAB error.\n');rethrow(ex);
end
end
