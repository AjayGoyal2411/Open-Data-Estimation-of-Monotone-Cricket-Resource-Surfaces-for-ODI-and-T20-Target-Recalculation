function [F,A]=RevisedCodes_19_Data(I,fmt,c)
% Extract only primary, nonreserved train/2023 states from aligned Step09 caches.
V=RevisedCodes_10_Utils;W=RevisedCodes_12_ContextUtils;U=RevisedCodes_19_Utils;
L=I.Exceptional.Ledger;allow=L.PrimaryModelEligible&~L.CaseStudyReserved&L.Format==fmt& ...
 L.Date<datetime(2024,1,1)&ismember(string(L.Split),["train","validation"]);
L=L(allow,:);assert(~isempty(L));keys=V.Key(L);seen=zeros(height(L),1);F=table;A=table;Examples=table;
allowed=["BallsRemaining","WicketsInHand","ScoreBefore","LegalBallsSinceDismissal", ...
 "NoDismissalYet","RetiredNotOutEventsBefore","RunRateBefore","NoLegalBallYet", ...
 "Recent30Runs","Recent30LegalBalls","Recent30RunRate","Opponent","BattingTeam","Venue","EventName"];
assert(height(I.States.Partitions)==height(I.OriginalContext.Partitions));
for part=1:height(I.States.Partitions)
 z=load(I.States.Partitions.Path(part),'States');S=z.States;
 z=load(I.OriginalContext.Partitions.Path(part),'Features');X=z.Features;
 assert(isequal(W.StateKey(S),W.StateKey(X)),'Source/context state keys differ.');
 % Worked genuine-reset / retirement examples: pre-2023 source events only.
 if height(Examples)<20
  mask=string(S.StateType)=="delivery"&S.Format==fmt&S.InningsIndex==1&~S.CaseReserved&S.MatchDate<datetime(2023,1,1)& ...
   ismember(lower(string(S.Gender)),["men","male"])& ...
   (S.GenuineDismissalsOnDelivery>0|S.RetiredNotOutEvents>0);
  for j=find(mask)'
   if j==height(S)||S.MatchID(j+1)~=S.MatchID(j)||S.InningsIndex(j+1)~=1||string(S.StateType(j+1))~="delivery",continue;end
   kind="Genuine dismissal";if S.RetiredNotOutEvents(j)>0,kind="Retired not out";end
   if ~isempty(Examples)&&nnz(Examples.Event==kind)>=10,continue;end
   expected=S.LegalBallsSinceDismissal(j)+S.CorrectedIsLegalBall(j);if S.GenuineDismissalsOnDelivery(j)>0,expected=0;end
   assert(S.LegalBallsSinceDismissal(j+1)==expected,'Partnership reset mismatch.');
   assert(S.WicketsInHand(j+1)==S.WicketsInHand(j)-S.GenuineDismissalsOnDelivery(j),'Dismissal capacity mismatch.');
   T=table(string(S.MatchID(j)),fmt,S.DeliverySeq(j),kind,S.GenuineDismissalsOnDelivery(j),S.RetiredNotOutEvents(j),S.WicketsInHand(j),S.WicketsInHand(j+1), ...
    S.LegalBallsSinceDismissal(j),S.LegalBallsSinceDismissal(j+1),expected, ...
    'VariableNames',{'MatchID','Format','DeliverySeq','Event','GenuineDismissalsOnDelivery','RetiredNotOutEvents','WicketsBefore','WicketsNextState','PartnershipBefore','PartnershipNextState','ExpectedNextPartnership'});
   Examples=[Examples;T]; %#ok<AGROW>
  end
 end
 keep=S.PrimaryEligibleObservation&~S.CaseReserved&S.Format==fmt&S.InningsIndex==1& ...
  S.MatchDate<datetime(2024,1,1)&ismember(string(S.Split),["train","validation"]);
 S=S(keep,:);X=X(keep,:);if isempty(S),continue;end
 assert(all((S.MatchDate<datetime(2023,1,1)&S.Split=="train")| ...
  (year(S.MatchDate)==2023&S.Split=="validation")),'Date/split conflict.');
 assert(all(string(S.StateType)=="delivery"&S.CorrectedIsLegalBall==1&S.WicketsInHand>0));
 [ok,j]=ismember(V.Key(S),keys);assert(all(ok),'Unexpected primary innings.');
 assert(all(S.FinalDeliveryRuns==L.DeliveryRuns(j))&&all(S.PrimaryRemainingRuns==S.FinalDeliveryRuns-S.DeliveryScoreBefore));
 seen=seen+accumarray(j,1,[height(L),1]);
 B=S(:,{'MatchID','InningsIndex','DeliverySeq','StateType','MatchDate','Gender','Format','EventName','Venue','FinalDeliveryRuns','Split'});
 B.RemainingRuns=double(S.PrimaryRemainingRuns);XX=X(:,cellstr(allowed));
 for entity=["Format","Batting","Opponent","Venue","Event"]
  XX.("OriginalHistory"+entity+"Mean")=X.("History"+entity+"Mean");
  XX.("OriginalHistory"+entity+"N")=X.("History"+entity+"N");
 end
 F=[F;XX];A=[A;B]; %#ok<AGROW>
 if mod(part,16)==0,fprintf('Step19 %s primary train/2023 extraction %d/%d\n',fmt,part,height(I.States.Partitions));end
end
assert(isequal(seen,double(L.CachedPrimaryStates)),'2023/train inventory does not reconcile.');
assert(numel(unique(W.StateKey(A)))==height(A),'Repeated primary state.');
assert(all(ismember(lower(string(A.Gender)),["men","male"])),'Primary gender scope changed.');
if isempty(Examples),Examples=table("No eligible source examples found",'VariableNames',{'Status'});end
U.Write(fullfile(c.Root,'reports'),"19_01_ResetExamples_"+fmt,Examples);
end
