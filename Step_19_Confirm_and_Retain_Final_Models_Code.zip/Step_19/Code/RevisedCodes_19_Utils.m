function U=RevisedCodes_19_Utils
U.Inputs=@inputs;U.Pair=@paired;U.Write=@write;U.Figure=@figureSave;
U.Hash=@hashFile;U.Hashes=@hashes;U.Verify=@verify;U.Model=@model;
U.Histories=@histories;U.Subgroups=@subgroups;U.SaveReport=@saveReport;
end
function I=inputs(c)
V=RevisedCodes_15_16_Utils;I=V.Inputs();root=fullfile(c.ProjectRoot,'paper_outputs_revisedcodes');
paths=string({fullfile(root,'step15','RevisedCodes_15_01_Result.mat'); ...
 fullfile(root,'step16','RevisedCodes_16_01_Result.mat'); ...
 fullfile(root,'step17_19','step17','RevisedCodes_17_Result.mat'); ...
 fullfile(root,'step17_19','step18','RevisedCodes_18_Result.mat')});
assert(all(isfile(paths)),'Steps15,16,17,18 results are required.');
z=load(paths(1),'Validation');I.Validation=z.Validation;V.Validate(I.Validation);
z=load(paths(2));names=fieldnames(z);assert(numel(names)==1,'Ambiguous Step16 result');I.Sensitivity=z.(names{1});V.Validate(I.Sensitivity);
z=load(paths(3),'Result');I.Step17=z.Result;
z=load(paths(4),'Result');I.Step18=z.Result;
assert(string(I.Step18.Status)=="INNINGS_SELECTION_COMPLETE_CENSORING_LIMITATION_RETAINED",'Step18 has not completed.');
assert(all(I.Step18.Gates.Passed),'Step18 gates failed.');
W=RevisedCodes_17_19_Utils;cc=W.Config(struct);[~,~,cache]=RevisedCodes_18_00_LoadCache(cc);
I.ChaseCache=cache.Path;I.Paths=unique([I.Paths;paths;I.Validation.Packages.Path;I.Validation.ClusterPath;cache.Path;string(I.Step17.Cache.Path)],'stable');
cp=fullfile(I.cfg.OutputRoot,'context','RevisedCodes_09_02_Result.mat');z=load(cp,'Context');I.OriginalContext=z.Context;
assert(I.OriginalContext.InitialPriorODI==250&&I.OriginalContext.InitialPriorT20==150, ...
 'History startup priors differ from the verified reconstruction contract. An explicit adapter is required.');
sp=fullfile(I.cfg.OutputRoot,'RevisedCodes_09_Result.mat');z=load(sp,'Result');I.States=z.Result;
I.Paths=unique([I.Paths;string(cp);string(sp);string(I.OriginalContext.Partitions.Path)],'stable');
end
function M=model(I,fmt,id)
package="FULL_TRAIN_"+fmt;
if id=="B0_LinearBalls"
 j=find(I.Empirical.Packages.PackageID==package);assert(isscalar(j));z=load(I.Empirical.Packages.Path(j),'Surface');S=z.Surface;
 [u,~]=ndgrid(0:S.Horizon,0:10);R=u/S.Horizon;R(:,1)=0;
 M=struct('Resource',R,'Horizon',S.Horizon,'FullStartMean',S.FullStartMean,'Supported',true(size(R)), ...
  'TrainingCutoffExclusive',datetime(2023,1,1));return;
end
names=["Compact","Bernstein","Reference","Context"];P={I.Compact,I.Flexible,I.Reference,I.Forecast};
for k=1:numel(names)
 prefix=names(k)+"::";if ~startsWith(id,prefix),continue;end
 Q=P{k};candidate=extractAfter(id,prefix);
 field='CandidateID';if names(k)=="Context",field='ModelID';end
 j=find(Q.Index.PackageID==package&Q.Index.(field)==candidate);assert(isscalar(j),'Model not uniquely found: %s %s',fmt,id);
 M=Q.Models{j};return;
end
error('Step19:UnsupportedSpecification','No audited full-training adapter for %s. Do not substitute a model.',id);
end
function T=paired(base,alt,c)
% One row per match and disjoint assessment fold. Positive gain favours alt.
req={'MatchID','PackageID','MSE'};assert(all(ismember(req,base.Properties.VariableNames))&&all(ismember(req,alt.Properties.VariableNames)));
k=string(base.MatchID)+"|"+string(base.PackageID);ka=string(alt.MatchID)+"|"+string(alt.PackageID);
assert(numel(unique(k))==height(base)&&numel(unique(ka))==height(alt)&&height(base)==height(alt));
[ok,j]=ismember(k,ka);assert(all(ok),'Paired populations differ');alt=alt(j,:);
if ismember('States',base.Properties.VariableNames)&&ismember('States',alt.Properties.VariableNames)
 assert(isequal(base.States,alt.States)&&all(base.States>0),'Paired state counts differ.');
end
assert(numel(unique(string(base.MatchID)))==height(base),'Assessment matches overlap folds.');
x=double(base.MSE);y=double(alt.MSE);assert(all(isfinite(x)&x>=0&isfinite(y)&y>=0));
assert(numel(x)>=2,'At least two match clusters are required.');
point=sqrt(mean(x))-sqrt(mean(y));stream=RandStream('mt19937ar','Seed',c.Seed);
rep=zeros(c.BootstrapReplicates,1);folds=unique(string(base.PackageID));
for b=1:numel(rep)
 ix=zeros(0,1);
 for f=folds',a=find(string(base.PackageID)==f);ix=[ix;a(randi(stream,numel(a),numel(a),1))];end %#ok<AGROW>
 rep(b)=sqrt(mean(x(ix)))-sqrt(mean(y(ix)));
end
ci=quantile(rep,[.025 .975]);n=numel(x);
leave=sqrt(max(0,(sum(x)-x)/(n-1)))-sqrt(max(0,(sum(y)-y)/(n-1)));
T=table(n,sqrt(mean(x)),sqrt(mean(y)),point,ci(1),ci(2),std(rep),min(leave),max(leave), ...
 'VariableNames',{'Matches','BaselineRMSE','CandidateRMSE','RMSEGain','GainLower95','GainUpper95', ...
 'BootstrapSE','LeaveOneMatchOutGainMin','LeaveOneMatchOutGainMax'});
end
function F=histories(F,A,K,cutoff)
% Source totals belong only to eligible first innings, strictly earlier days.
W=RevisedCodes_10_Utils;[~,first,g]=unique(W.Key(A),'stable');D=dateshift(A.MatchDate(first),'start','day');
assert(numel(unique(string(A.MatchID(first))))==numel(first),'Multiple primary innings per match.');
total=A.FinalDeliveryRuns(first);assert(all(isfinite(total)&total>=0));
fields=["Format","Batting","Opponent","Venue","Event"];source=["","BattingTeam","Opponent","Venue","EventName"];
means=zeros(numel(first),5);counts=means;maxDate=NaT(numel(first),1);
fmt=string(A.Format(first));
for j=1:numel(first)
 q=D<D(j)&D<cutoff&fmt==fmt(j);prior=150;if fmt(j)=="ODI",prior=250;end
 if any(q),mu=mean(total(q));maxDate(j)=max(D(q));else,mu=prior;end
 means(j,1)=mu;counts(j,1)=nnz(q);
 for k=2:5
  label=string(F.(source(k))(first));v=label(j);
  if ismissing(v)||strlength(strtrim(v))==0,keep=false(size(q));else,keep=q&label==v;keep(ismissing(label))=false;end
  counts(j,k)=nnz(keep);means(j,k)=(sum(total(keep))+K*mu)/(nnz(keep)+K);
 end
end
assert(all(isnat(maxDate)|(maxDate<D&maxDate<cutoff)),'History leakage.');
for k=1:5,F.("History"+fields(k)+"N")=counts(g,k);F.("History"+fields(k)+"Mean_K"+string(K))=means(g,k);end
end
function G=subgroups(A,F,p,raw,supported,M,c)
V=RevisedCodes_15_16_Utils;G=V.Subgroups(A,F,p,raw,supported,c.MinGroupInnings,M.Horizon);
if ~isfield(M,'ForecastOnly')||~M.ForecastOnly,return;end
for entity=["Batting","Opponent","Venue","Event"]
 values=double(F.("History"+entity+"N"))==0;
 for flag=[false true]
  q=values==flag;if ~any(q),continue;end
  R=V.Summary(V.Score(A(q,:),p(q),raw(q)));R.GroupType=entity+"NoHistory";R.Group=string(flag);R.SufficientGroup=R.Innings>=c.MinGroupInnings;G=[G;R]; %#ok<AGROW>
 end
end
for field=["Venue","EventName"]
 value=string(F.(field));seen=M.Preprocessor.Categories.(field+"Seen");selected=M.Preprocessor.Categories.(field);
 label=repmat("Unseen",height(F),1);label(ismember(value,seen))="SeenRare";label(ismember(value,selected))="SelectedCategory";
 label(ismissing(value)|strlength(strtrim(value))==0)="Missing";
 for v=unique(label)'
  q=label==v;R=V.Summary(V.Score(A(q,:),p(q),raw(q)));R.GroupType=field+"CategorySupport";R.Group=v;
  R.SufficientGroup=R.Innings>=c.MinGroupInnings;G=[G;R]; %#ok<AGROW>
 end
end
end
function write(folder,name,T)
assert(istable(T),'%s must be a table',name);if ~isfolder(folder),mkdir(folder);end
writetable(T,fullfile(folder,char(string(name)+".csv")));
end
function figureSave(fig,folder,name)
set(findall(fig,'Type','axes'),'TickLabelInterpreter','none');
exportgraphics(fig,fullfile(folder,char(name+".png")),'Resolution',300);
exportgraphics(fig,fullfile(folder,char(name+".pdf")),'ContentType','vector');savefig(fig,fullfile(folder,char(name+".fig")));close(fig);
end
function h=hashFile(p)
V=RevisedCodes_18_00_Utils;h=V.Hash(p);
end
function T=hashes(paths)
paths=unique(string(paths(:)),'stable');h=strings(numel(paths),1);
for j=1:numel(paths),h(j)=hashFile(paths(j));if mod(j,25)==0,fprintf('Step19 source fingerprint %d/%d\n',j,numel(paths));end;end
T=table(paths,h,'VariableNames',{'Path','SHA256'});
end
function verify(T)
assert(all(isfile(T.Path)),'Step19 dependency missing.');
for j=1:height(T),assert(hashFile(T.Path(j))==T.SHA256(j),'Step19:ChangedDependency','Changed file: %s',T.Path(j));end
end
function path=saveReport(c,folder)
files=dir(fullfile(folder,'*'));files=files(~[files.isdir]);assert(~isempty(files));
path=string(fullfile(c.ProjectRoot,'RevisedCodes_19_Checks.zip'));zip(path,{files.name},folder);
end
