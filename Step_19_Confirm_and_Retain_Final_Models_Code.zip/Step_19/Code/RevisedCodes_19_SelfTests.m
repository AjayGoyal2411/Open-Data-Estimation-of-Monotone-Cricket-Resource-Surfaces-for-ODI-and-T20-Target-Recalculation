function T=RevisedCodes_19_SelfTests(c)
U=RevisedCodes_19_Utils;c.BootstrapReplicates=500;names=strings(0,1);
B=table(["001";"002";"003";"004"],["F1";"F1";"F2";"F2"],[4;4;9;9], ...
 'VariableNames',{'MatchID','PackageID','MSE'});A=B;A.MSE=[1;1;4;4];
R=U.Pair(B,A,c);assert(abs(R.RMSEGain-(sqrt(6.5)-sqrt(2.5)))<1e-12);names(end+1)="Pooled RMSE uses squared errors, not mean fold RMSE";
Q=U.Pair(B,A([4 2 1 3],:),c);assert(isequaln(R,Q));names(end+1)="Paired matching preserves numeric-looking IDs and row-order invariance";
Q=U.Pair(B,B,c);assert(Q.RMSEGain==0&&Q.GainLower95==0&&Q.GainUpper95==0);names(end+1)="Identical predictions have zero paired difference";
A=B;A.MatchID(4)="999";assertThrows(@()U.Pair(B,A,c));names(end+1)="Different comparison populations rejected";
A=B;A.MatchID(4)=A.MatchID(1);assertThrows(@()U.Pair(A,A,c));names(end+1)="Overlapping assessment matches rejected";
A=B;A.MSE(1)=NaN;assertThrows(@()U.Pair(B,A,c));names(end+1)="Nonfinite match errors rejected";
A=table(["a";"b";"c";"d"],ones(4,1),datetime([2021;2021;2022;2023],ones(4,1),ones(4,1)), ...
 repmat("T20",4,1),[100;200;300;9999], ...
 'VariableNames',{'MatchID','InningsIndex','MatchDate','Format','FinalDeliveryRuns'});
F=table(repmat("A",4,1),repmat("B",4,1),repmat("V",4,1),repmat("E",4,1), ...
 'VariableNames',{'BattingTeam','Opponent','Venue','EventName'});
X=U.Histories(F,A,20,datetime(2023,1,1));assert(isequal(X.HistoryFormatN,[0;0;2;3]));
assert(isequal(X.HistoryFormatMean_K20,[150;150;150;200]));names(end+1)="Histories exclude same-day and future outcomes";
A.FinalDeliveryRuns(4)=88888;Y=U.Histories(F,A,20,datetime(2023,1,1));assert(isequaln(X,Y));names(end+1)="2023 outcome perturbation cannot alter confirmation predictors";
scale=[.8;1;1.2];assert(all(abs((.3*scale)./scale-.3)<1e-12));names(end+1)="Multiplicative context scale cancels on normalization";
[u,w]=ndgrid(0:2,0:10);M=struct('Resource',(u/2).*(w/10),'FullStartMean',100,'Supported',true(3,11),'Horizon',2);
Frozen=struct('PolicyFrozen',true,'Index',table("T20","PrimaryResource",'VariableNames',{'Format','Role'}),'Models',{{M}});
F=table(1.5,5,'VariableNames',{'BallsRemaining','WicketsInHand'});
[p,Q]=RevisedCodes_19_PredictFrozen(Frozen,"T20","PrimaryResource",F);assert(p==37.5&&Q.EmpiricallySupported);names(end+1)="Frozen resource uses linear ball interpolation";
F.FinalOutcome=999999;p2=RevisedCodes_19_PredictFrozen(Frozen,"T20","PrimaryResource",F);assert(p==p2);names(end+1)="Outcome columns cannot change frozen resource prediction";
F.WicketsInHand=.5;assertThrows(@()RevisedCodes_19_PredictFrozen(Frozen,"T20","PrimaryResource",F));names(end+1)="Fractional wickets rejected";
V=RevisedCodes_14_Utils;pc=RevisedCodes_14_00_Config;P=V.DefaultPolicy(M,pc);
Q=V.Target(100,.8,.6,P);assert(Q.IntegerParScore==75&&Q.WinningTarget==76);names(end+1)="Locked policy keeps par and winning target distinct";
T=table(names(:),true(numel(names),1),'VariableNames',{'Check','Passed'});disp(T);
end
function assertThrows(f)
thrown=false;try,f();catch,thrown=true;end;assert(thrown,'Expected an assertion failure.');
end
