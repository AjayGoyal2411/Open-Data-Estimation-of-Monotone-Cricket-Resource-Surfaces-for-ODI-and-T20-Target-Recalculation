function [Prediction,Info]=RevisedCodes_19_PredictFrozen(Frozen,format,role,F)
% F supplies pre-delivery predictors only; no outcome is required or consumed.
assert(Frozen.PolicyFrozen,'Load a verified bundle using RevisedCodes_19_LoadFrozen.');
j=find(Frozen.Index.Format==string(format)&Frozen.Index.Role==string(role));assert(isscalar(j));M=Frozen.Models{j};
u=double(F.BallsRemaining);w=double(F.WicketsInHand);
assert(all(isfinite(u)&u>=0&u<=M.Horizon&isfinite(w)&w==floor(w)&w>=0&w<=10),'Invalid balls/wickets query.');
if isfield(M,'ForecastOnly')&&M.ForecastOnly
 required={'MatchID','MatchDate','BattingTeam','Opponent','Venue','EventName'};
 assert(all(ismember(required,F.Properties.VariableNames)),'Forecast query requires identity/date metadata and pre-state covariates.');
 [~,first,g]=unique(string(F.MatchID),'stable');D=dateshift(F.MatchDate(first),'start','day');
 assert(all(~isnat(D))&&all(F.MatchDate==F.MatchDate(first(g))),'Invalid or inconsistent query date.');
 H=M.TrainingHistory;entities=["Format","Batting","Opponent","Venue","Event"];fields=["","BattingTeam","Opponent","Venue","EventName"];
 means=zeros(numel(first),5);counts=means;
 for k=2:5
  value=string(F.(fields(k)));assert(isequaln(value,value(first(g))),'Query metadata differs within a match.');
 end
 for k=1:numel(first)
  q=H.Date<D(k)&H.Date<M.TrainingCutoffExclusive;
  prior=150;if string(format)=="ODI",prior=250;end
  if any(q),mu=mean(H.DeliveryRuns(q));else,mu=prior;end
  means(k,1)=mu;counts(k,1)=nnz(q);
  for e=2:5
   v=string(F.(fields(e))(first(k)));labels=string(H.(fields(e)));
   if ismissing(v)||strlength(strtrim(v))==0,keep=false(size(q));else,keep=q&labels==v;keep(ismissing(labels))=false;end
   counts(k,e)=nnz(keep);means(k,e)=(sum(H.DeliveryRuns(keep))+M.HistoryK*mu)/(nnz(keep)+M.HistoryK);
  end
 end
 for e=1:5,F.("History"+entities(e)+"N")=counts(g,e);F.("History"+entities(e)+"Mean_K"+string(M.HistoryK))=means(g,e);end
 W=RevisedCodes_12_ContextUtils;[Prediction,raw]=W.Predict(M,F);
 Info=table(raw,raw<0,'VariableNames',{'RawForecast','LowerBoundApplied'});
 Info.RetrospectiveQuery=F.MatchDate<M.TrainingCutoffExclusive;
else
 u=double(F.BallsRemaining);w=double(F.WicketsInHand);
 assert(all(isfinite(u)&u>=0&u<=M.Horizon&isfinite(w)&w==floor(w)&w>=0&w<=10));
 lo=floor(u);hi=ceil(u);a=u-lo;i=sub2ind(size(M.Resource),lo+1,w+1);k=sub2ind(size(M.Resource),hi+1,w+1);
 resource=(1-a).*M.Resource(i)+a.*M.Resource(k);Prediction=resource*M.FullStartMean;
 supported=M.Supported(i)&M.Supported(k);Info=table(resource,supported,~supported, ...
  'VariableNames',{'NormalizedCapacity','EmpiricallySupported','UsesUnsupportedCompletion'});
end
assert(all(isfinite(Prediction)),'Nonfinite frozen prediction.');
end
