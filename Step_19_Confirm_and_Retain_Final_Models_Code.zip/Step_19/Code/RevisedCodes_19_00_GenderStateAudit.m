function Summary=RevisedCodes_19_00_GenderStateAudit(I,c)
% Quantify the known legacy Step17 observation-unit difference, without promoting it.
U=RevisedCodes_19_Utils;V=RevisedCodes_17_19_Utils;
p=I.Step17.Cache.Path;assert(isfile(p),'Step17 cache missing');z=load(p,'C','M');M=z.M;
actual=accumarray(double(z.C.MetaRow),1,[height(M),1]);clear z;
H=120*ones(height(M),1);H(M.Format=="ODI")=300;
base=M.CacheEligible&V.Number(M.InningsIndex)==1&V.Logical(M.ResponseEligible)&V.Number(M.InitialAllocatedBalls)==H& ...
 M.Date<datetime(2023,1,1)&ismember(M.Gender,["men","women"]);
legacy=zeros(height(M),1);legal=legacy;initial=legacy;terminal=legacy;illegal=legacy;
for k=1:height(I.States.Partitions)
 z=load(I.States.Partitions.Path(k),'States');S=z.States;
 key=string(S.MatchID)+"|"+string(S.InningsIndex);[ok,j]=ismember(key,M.Key);q=ok;q(ok)=base(j(ok));
 y=double(S.FinalDeliveryRuns)-double(S.DeliveryScoreBefore);
 q=q&isfinite(y)&y>=0&double(S.BallsRemaining)>=0&double(S.WicketsInHand)>=0&double(S.WicketsInHand)<=10;
 legacy=legacy+accumarray(j(q),1,[height(M),1]);
 a=q&string(S.StateType)=="initial";initial=initial+accumarray(j(a),1,[height(M),1]);
 a=q&string(S.StateType)=="terminal";terminal=terminal+accumarray(j(a),1,[height(M),1]);
 a=q&string(S.StateType)=="delivery"&double(S.CorrectedIsLegalBall)==0;illegal=illegal+accumarray(j(a),1,[height(M),1]);
 a=q&string(S.StateType)=="delivery"&double(S.CorrectedIsLegalBall)==1&S.WicketsInHand>0&S.BallsRemaining>0;
 legal=legal+accumarray(j(a),1,[height(M),1]);
 if mod(k,24)==0,fprintf('Step19 legacy gender row audit %d/%d\n',k,height(I.States.Partitions));end
end
assert(isequal(actual(base),legacy(base)),'Step17 cache differs from its recorded source-row contract.');
Summary=table;
for fmt=["ODI","T20"],for gender=["men","women"]
 q=base&M.Format==fmt&M.Gender==gender;
 T=table(fmt,gender,nnz(q),sum(actual(q)),sum(legal(q)),sum(initial(q)),sum(terminal(q)),sum(illegal(q)), ...
  any(actual(q)~=legal(q)), ...
  'VariableNames',{'Format','Gender','Innings','LegacyCachedStates','CanonicalLegalPreStates','InitialRows','TerminalRows','IllegalDeliveryRows','RequiresGenderRefit'});
 Summary=[Summary;T]; %#ok<AGROW>
end,end
U.Write(fullfile(c.Root,'reports'),'19_00_GenderObservationUnitAudit',Summary);
end
