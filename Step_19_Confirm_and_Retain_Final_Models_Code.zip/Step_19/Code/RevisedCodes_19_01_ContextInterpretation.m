function Result=RevisedCodes_19_01_ContextInterpretation(I,Lock,c)
% Development evidence only. Original inputs and upstream results are unchanged.
U=RevisedCodes_19_Utils;V=RevisedCodes_15_16_Utils;W=RevisedCodes_12_ContextUtils;
if nargin<3
 settings=struct;if nargin==1,settings=I;end
 c=RevisedCodes_19_00_Config(settings);I=U.Inputs(c);Lock=RevisedCodes_19_00_LockProtocol(I,c);
end
report=fullfile(c.Root,'reports');z=load(I.Validation.ClusterPath,'Clusters');C=z.Clusters;
Pairs=table;Coefficients=table;Groups=table;Drift=table;Redundancy=table;Influence=table;
labels=W.Labels();
for fmt=["ODI","T20"]
 B=C(C.Format==fmt,:);ids=unique(string(B.ModelID));
 for id=ids'
  if ~startsWith(id,'Context::C1_'),continue;end
  base="B0_LinearBalls";
  for a=2:numel(labels)
   if contains(id,"C1_"+labels(a)+"_lambda"),base=replace(id,"C1_"+labels(a),"C1_"+labels(a-1));end
  end
  assert(any(ids==base),'Missing adjacent ablation at identical lambda.');
  R=U.Pair(B(B.ModelID==base,:),B(B.ModelID==id,:),c);R.Format=fmt;R.Baseline=base;R.Candidate=id;
  R.Interpretation="Exploratory development comparison; many correlated contrasts; no significance-based reselection";Pairs=[Pairs;R]; %#ok<AGROW>
 end
end
for h=1:height(I.Validation.Packages)
 row=I.Validation.Packages(h,:);fprintf('Step19 context diagnostics %s\n',row.PackageID);
 z=load(row.Path,'Audit','Features','Prediction','RawPrediction','CommonReferenceSupport','Index','Models');
 A=z.Audit;F=z.Features;assert(all(A.MatchDate<datetime(2023,1,1)&year(A.MatchDate)>=2020));
 for role=["PrimaryForecast","LiveScoreComparator"]
  ix=find(Lock.Index.Format==row.Format&Lock.Index.Role==role);id=Lock.Index.ModelID(ix);
  j=find(z.Index.ModelID==id);assert(isscalar(j));M=z.Models{j};
  G=U.Subgroups(A,F,z.Prediction(:,j),z.RawPrediction(:,j),z.CommonReferenceSupport,M,c);
  G.PackageID=repmat(row.PackageID,height(G),1);G.Format=repmat(row.Format,height(G),1);G.ModelID=repmat(id,height(G),1);Groups=[Groups;G]; %#ok<AGROW>
  names=M.FeatureNames(:);beta=M.Beta(:)*M.FullStartMean;
  T=table(repmat(row.PackageID,numel(beta),1),repmat(row.Format,numel(beta),1),repmat(id,numel(beta),1),names,beta, ...
   'VariableNames',{'PackageID','Format','ModelID','Term','RunsPerTrainingSD'});
  % Category indices are fold-specific; their coefficients must not be pooled by index.
  T.SemanticallyComparable=~contains(names,'Category');Coefficients=[Coefficients;T]; %#ok<AGROW>
  [~,~,g]=unique(string(A.MatchID));count=accumarray(g,1);weight=1./count(g);tw=sum(weight);
  sx=zeros(1,numel(M.Columns));sx2=sx;gram=zeros(numel(sx));
  for k=1:20000:height(F)
   ii=k:min(k+19999,height(F));X=W.Encode(F(ii,:),M.Horizon,M.FullStartMean,M.Preprocessor,M.HistoryK);X=X(:,M.Columns);ww=weight(ii);
   sx=sx+ww'*X;sx2=sx2+ww'*(X.^2);gram=gram+X'*(X.*ww);
  end
  mu=sx/tw;sd=sqrt(max(0,sx2/tw-mu.^2));terms=names(2:end);
  T=table(repmat(row.PackageID,numel(terms),1),repmat(row.Format,numel(terms),1),repmat(id,numel(terms),1),terms,mu',sd', ...
   'VariableNames',{'PackageID','Format','ModelID','Term','AssessmentMeanInTrainingSD','AssessmentSDInTrainingSD'});Drift=[Drift;T]; %#ok<AGROW>
  covar=gram/tw-mu'*mu;den=sd'*sd;corr=covar./max(den,eps);
  indicator=contains(terms,["Missing","History","Other"]); % report actual term names, not causal interpretations
  [a,b]=find(triu(abs(corr)>=.95,1)&(double(indicator)*double(indicator)')&den>1e-12);
  for k=1:numel(a)
   Redundancy=[Redundancy;table(row.PackageID,row.Format,id,terms(a(k)),terms(b(k)),corr(a(k),b(k)), ...
    'VariableNames',{'PackageID','Format','ModelID','Term1','Term2','AssessmentCorrelation'})]; %#ok<AGROW>
  end
  base=C(C.PackageID==row.PackageID&C.ModelID=="B0_LinearBalls",:);alt=C(C.PackageID==row.PackageID&C.ModelID==id,:);
  [ok,k]=ismember(string(base.MatchID),string(alt.MatchID));assert(all(ok));alt=alt(k,:);
  T=table(string(base.MatchID),repmat(row.PackageID,height(base),1),repmat(row.Format,height(base),1), ...
   repmat(id,height(base),1),base.MSE-alt.MSE,'VariableNames',{'MatchID','PackageID','Format','ModelID','PerMatchMSEGain'});
  Influence=[Influence;T]; %#ok<AGROW>
 end
end
if isempty(Redundancy),Redundancy=table("No pair meets |correlation| >= .95",'VariableNames',{'Status'});end
T=Coefficients(Coefficients.SemanticallyComparable,:);Stability=groupsummary(T,{'Format','ModelID','Term'},{'min','max','mean'},'RunsPerTrainingSD');
Stability.SignChanges=Stability.min_RunsPerTrainingSD<0&Stability.max_RunsPerTrainingSD>0;
InputDecision=table(["Balls remaining";"Wickets in hand";"Team/opponent history";"Partnership/reset"; ...
 "Current score/recent rate";"Venue/event labels";"Gender pooling";"Chase target/required rate"; ...
 "Official team rankings";"Retired hurt";"Final scores/outcomes/identifiers"], ...
 ["target_and_forecast";"target_and_forecast";"forecast_only";"forecast_only";"forecast_comparator_only"; ...
 "sensitivity_only";"sensitivity_only";"second_innings_forecast_sensitivity_only";"not_available"; ...
 "state_correction_and_forecast_covariate";"labels_or_audit_only"], ...
 ["Resource availability input";"Genuine dismissal capacity input";"Strict earlier-date scoring proxy; not official ranking"; ...
 "Conditional association; no counterfactual innings-start partnership for a target policy"; ...
 "Live tactical state; predictive ceiling does not identify intrinsic capacity";"Sparse/unseen labels and composition must remain visible"; ...
 "Legacy Step17 observation-unit correction and competition/equivalence analysis remain necessary";"Explicit targets and informative censoring preclude neutral capacity interpretation"; ...
 "No dated official ranking series introduced";"Retired hurt is not automatically a genuine wicket; raw examples reported separately"; ...
 "Not permissible forecast predictors"],'VariableNames',{'Input','Role','Reason'});
U.Write(report,'19_01_PairedContextAblations',Pairs);U.Write(report,'19_01_ContextCoefficients',Coefficients);
U.Write(report,'19_01_CoefficientStability',Stability);U.Write(report,'19_01_Subgroups',Groups);
U.Write(report,'19_01_FeatureDrift',Drift);U.Write(report,'19_01_IndicatorRedundancy',Redundancy);
U.Write(report,'19_01_MatchInfluence',Influence);U.Write(report,'19_01_InputDecision',InputDecision);
% Algebraic cancellation is an identity, not evidence of empirical accuracy.
scale=[.8;1;1.2];Cancellation=table(scale,.3*scale,scale,(.3*scale)./scale, ...
 'VariableNames',{'ContextScale','RemainingMean','StartMean','NormalizedCapacity'});
assert(max(abs(Cancellation.NormalizedCapacity-.3))<1e-12);U.Write(report,'19_01_ScaleCancellation',Cancellation);
fig=figure('Visible','off','Color','w','Position',[100 100 1200 750]);tiledlayout(2,2,'Padding','compact');
for fmt=["ODI","T20"]
 j=find(Lock.Index.Format==fmt&Lock.Index.Role=="PrimaryForecast");lambda=Lock.Models{j}.Lambda;
 T=Pairs(Pairs.Format==fmt&endsWith(Pairs.Candidate,"_lambda"+string(lambda)),:);
 nexttile;errorbar(1:height(T),T.RMSEGain,T.RMSEGain-T.GainLower95,T.GainUpper95-T.RMSEGain,'o');
 xticks(1:height(T));xticklabels(erase(T.Candidate,["Context::C1_","_lambda"+string(lambda)]));xtickangle(25);
 yline(0);ylabel('Incremental RMSE reduction (runs)');title(fmt+": adjacent ablations, development only");
 nexttile;T=Drift(Drift.Format==fmt&Drift.ModelID==Lock.Index.ModelID(j),:);
 G=groupsummary(T,'Term','mean','AssessmentMeanInTrainingSD');[~,ix]=sort(abs(G.mean_AssessmentMeanInTrainingSD),'descend');G=G(ix(1:min(8,numel(ix))),:);
 barh(G.mean_AssessmentMeanInTrainingSD);yticks(1:height(G));yticklabels(G.Term);xlabel('Assessment mean in training SD units');title(fmt+": largest mean feature shifts");
end
U.Figure(fig,report,"F19_ContextInterpretation");
Result=struct('Status',"DEVELOPMENT_INTERPRETATION_COMPLETE_LIMITATIONS_RETAINED",'Pairs',Pairs,'InputDecision',InputDecision);
save(fullfile(c.Root,'RevisedCodes_19_01_Result.mat'),'Result','-v7.3');
end
