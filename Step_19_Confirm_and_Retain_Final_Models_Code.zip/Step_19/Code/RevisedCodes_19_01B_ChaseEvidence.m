function Result=RevisedCodes_19_01B_ChaseEvidence(I,c)
% Reproduce Step18 fits exactly, retain paired match errors and correct figures.
U=RevisedCodes_19_Utils;V=RevisedCodes_17_19_Utils;cfg=V.Config(struct);
z=load(I.ChaseCache,'C','M','info');C=z.C;M=z.M;H=RevisedCodes_18_00_Utils;H.CheckDependencies(z.info);
first=M.CacheEligible&M.InningsIndex==1&V.Logical(M.ResponseEligible);
second=M.CacheEligible&M.ChaseAllocationVerified&M.ChaseTargetVerified;
complete=second&(contains(M.CompletionClass,'chase_all_out')|contains(M.CompletionClass,'chase_full_length'));
success=second&M.CompletionClass=="chase_success_verified_censored";
Clusters=table;Coefficients=table;Summary=table;Pairs=table;
for fmt=["ODI","T20"]
 horizon=120;if fmt=="ODI",horizon=300;end
 for yr=2020:2022
  train=M.Format==fmt&M.Date<datetime(yr,1,1);assess=M.Format==fmt&year(M.Date)==yr;
  base=V.FitSingle(C,M,first&train,fmt,cfg);
  [p,X,y,mid]=design(C,M,complete&train,base,horizon);mu=mean(X(:,2:end),1);sd=std(X(:,2:end),0,1);sd(sd<1e-10)=1;
  Z=[ones(size(X,1),1),(X(:,2:end)-mu)./sd];P=eye(5);P(1,1)=0;beta=[Z;sqrt(1e-3)*P]\[y-p;zeros(5,1)];
  terms=["Intercept";"RequiredRate";"WicketsInHand";"RemainingFraction";"CurrentRunRate"];
  original=[beta(1)-sum(beta(2:end)'.*mu./sd);beta(2:end)./sd'];
  T=table(repmat(fmt,5,1),repmat("Fold_"+yr,5,1),terms,beta,[NaN;mu'],[NaN;sd'],original, ...
   'VariableNames',{'Format','Fold','Term','CoefficientOnStandardizedPredictor','TrainingMean','TrainingSD','CoefficientOnOriginalPredictor'});
  Coefficients=[Coefficients;T]; %#ok<AGROW>
  for cohort=["completed_comparable","successful_censored_descriptive"]
   mask=complete;if cohort=="successful_censored_descriptive",mask=success;end
   [p,X,y,mid]=design(C,M,mask&assess,base,horizon);if isempty(y),continue;end
   prediction=p+[ones(size(X,1),1),(X(:,2:end)-mu)./sd]*beta;
   [ids,~,g]=unique(mid);n=accumarray(g,1);
   for model=["resource_only","target_aware_forecast"]
    value=p;if model=="target_aware_forecast",value=prediction;end;e=value-y;
    T=table(string(M.MatchID(ids)),repmat("Fold_"+yr,numel(ids),1),repmat(fmt,numel(ids),1), ...
     repmat(cohort,numel(ids),1),repmat(model,numel(ids),1),n,accumarray(g,e.^2)./n,accumarray(g,abs(e))./n,accumarray(g,e)./n, ...
     'VariableNames',{'MatchID','PackageID','Format','Cohort','ModelID','States','MSE','MAE','Bias'});
    Clusters=[Clusters;T]; %#ok<AGROW>
    old=I.Step18.Scores;old=old(old.Format==fmt&old.Fold=="Fold_"+yr&old.Cohort==cohort&old.Model==model,:);
    assert(height(old)==1&&old.Innings==height(T)&&abs(old.EqualInningsRMSE-sqrt(mean(T.MSE)))<1e-6, ...
     'Step19:ChaseReproduction','Step18 scores did not reproduce. Stop before confirmation.');
   end
  end
 end
 for cohort=["completed_comparable","successful_censored_descriptive"]
  for model=["resource_only","target_aware_forecast"]
   T=Clusters(Clusters.Format==fmt&Clusters.Cohort==cohort&Clusters.ModelID==model,:);
   assert(~isempty(T));Q=table(fmt,cohort,model,height(T),sqrt(mean(T.MSE)),mean(T.MAE),mean(T.Bias), ...
    'VariableNames',{'Format','Cohort','Model','Innings','EqualInningsRMSE','EqualInningsMAE','EqualInningsBias'});Summary=[Summary;Q]; %#ok<AGROW>
  end
 end
 B=Clusters(Clusters.Format==fmt&Clusters.Cohort=="completed_comparable",:);
 for fold=["Pooled",unique(B.PackageID)']
  T=B;if fold~="Pooled",T=T(T.PackageID==fold,:);end
  Q=U.Pair(T(T.ModelID=="resource_only",:),T(T.ModelID=="target_aware_forecast",:),c);Q.Format=fmt;Q.Fold=fold;Pairs=[Pairs;Q]; %#ok<AGROW>
 end
end
report=fullfile(c.Root,'reports');U.Write(report,'19_01B_ChaseMatchErrors',Clusters);U.Write(report,'19_01B_ChasePairedGain',Pairs);
U.Write(report,'19_01B_ChasePooledScores',Summary);U.Write(report,'19_01B_ChaseCoefficientUnits',Coefficients);
% Admission coverage from the full ledger, not only admitted matches.
meta=M;scope=meta.InningsIndex==2&meta.Gender=="men"&~V.Logical(meta.CaseStudyReserved)& ...
 lower(string(meta.Split))=="train"&meta.Date<datetime(2023,1,1)&ismember(meta.Format,["ODI","T20"]);
Coverage=table;
for fmt=["ODI","T20"],for yr=unique(year(meta.Date(scope&meta.Format==fmt)))'
 q=scope&meta.Format==fmt&year(meta.Date)==yr;n=nnz(q);a=nnz(q&second);
 Coverage=[Coverage;table(fmt,yr,n,a,a/n,'VariableNames',{'Format','Year','InScope','Accepted','AcceptanceFraction'})]; %#ok<AGROW>
end,end
U.Write(report,'19_01B_ChaseAcceptanceByYear',Coverage);
fig=figure('Visible','off','Color','w','Position',[100 100 1250 750]);tiledlayout(2,2,'Padding','compact');
nexttile;T=Summary(Summary.Cohort=="completed_comparable",:);bar(T.EqualInningsRMSE);xticks(1:height(T));xticklabels(T.Format+" "+replace(T.Model,'_',' '));xtickangle(25);ylabel('Pooled equal-innings RMSE (runs)');title('Completed selected chases');
nexttile;T=Pairs(Pairs.Fold=="Pooled",:);errorbar(1:height(T),T.RMSEGain,T.RMSEGain-T.GainLower95,T.GainUpper95-T.RMSEGain,'o');xticks(1:height(T));xticklabels(T.Format);yline(0);ylabel('RMSE reduction (runs)');title('Paired match-bootstrap 95% intervals');
nexttile;values=zeros(4,2);labels=strings(4,1);k=0;
for fmt=["ODI","T20"],for cohort=["completed_comparable","successful_censored_descriptive"]
 k=k+1;T=Summary(Summary.Format==fmt&Summary.Cohort==cohort,:);
 values(k,:)=[T.EqualInningsBias(T.Model=="resource_only"),T.EqualInningsBias(T.Model=="target_aware_forecast")];
 short="completed";if cohort=="successful_censored_descriptive",short="successful/censored";end;labels(k)=fmt+" "+short;
end,end
bar(values);xticks(1:4);xticklabels(labels);xtickangle(20);legend('Resource only','Target-aware forecast','Location','best');ylabel('Bias (runs)');title('Successful chases: descriptive only');
nexttile;hold on;for fmt=["ODI","T20"],T=Coverage(Coverage.Format==fmt,:);plot(T.Year,100*T.AcceptanceFraction,'-o','DisplayName',fmt);end;legend('Location','best');ylabel('Accepted (%)');xlabel('Year');title('Selection into reconstructed subset');
U.Figure(fig,report,"F19_ChaseEvidence");
Result=struct('Pairs',Pairs,'Summary',Summary,'Coverage',Coverage,'Status',"STEP18_REPRODUCED_PAIRED_INFERENCE_ADDED");
save(fullfile(c.Root,'RevisedCodes_19_01B_Result.mat'),'Result','-v7.3');
end
function [p,X,y,mid]=design(C,M,mask,base,H)
rows=mask(double(C.MetaRow));u=double(C.U(rows));w=double(C.W(rows));mid=double(C.MetaRow(rows));
p=base.Surface(u+1+(H+1)*w)*base.Scale;score=double(C.Score(rows));required=max(M.Target(mid)-score,0);
X=[ones(numel(u),1),6*required./max(u,1),w,u/H,6*score./max(double(C.BallsBowled(rows)),1)];
y=double(C.Outcome(rows));
end
