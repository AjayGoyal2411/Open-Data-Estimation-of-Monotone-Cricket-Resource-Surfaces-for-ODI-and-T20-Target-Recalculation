function c=RevisedCodes_19_00_Config(settings)
if nargin<1,settings=struct;end
cfg=RevisedCodes_09_00_Config;
c=struct('Version',"19.1.0",'ProjectRoot',cfg.ProjectRoot, ...
 'Root',fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step19_final'), ...
 'BootstrapReplicates',2000,'Seed',190019,'MinGroupInnings',20);
for f=fieldnames(settings)'
 assert(isfield(c,f{1}),'Unknown Step19 setting: %s',f{1});c.(f{1})=settings.(f{1});
end
assert(strcmp(c.ProjectRoot,cfg.ProjectRoot),'Use the existing Step09 project configuration.');
validateattributes(c.BootstrapReplicates,{'numeric'},{'scalar','integer','>=',500});
validateattributes(c.Seed,{'numeric'},{'scalar','integer','nonnegative'});
validateattributes(c.MinGroupInnings,{'numeric'},{'scalar','integer','>=',2});
if ~isfolder(c.Root),mkdir(c.Root);end
end
