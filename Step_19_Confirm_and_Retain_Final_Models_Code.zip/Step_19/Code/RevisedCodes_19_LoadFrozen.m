function Frozen=RevisedCodes_19_LoadFrozen(root)
if nargin<1,c=RevisedCodes_19_00_Config;root=c.Root;end
U=RevisedCodes_19_Utils;z=load(fullfile(root,'RevisedCodes_19_02_Result.mat'),'Result');
assert(z.Result.PolicyFrozen,'No committed freeze.');U.Verify(z.Result.Hashes);
T=z.Result.Hashes;
for k=1:height(T)
 [folder,name,ext]=fileparts(T.Path(k));
 if ext~=".m"||~endsWith(folder,string(filesep)+"code"),continue;end
 current=which(char(name));
 if ~isempty(current),assert(U.Hash(current)==T.SHA256(k),'Runtime code differs from frozen copy: %s',name);end
end
z=load(z.Result.FrozenModelPath,'Frozen');Frozen=z.Frozen;
assert(Frozen.PolicyFrozen&&~Frozen.IndependentPerformanceEvaluated,'Unexpected frozen bundle state.');
end
