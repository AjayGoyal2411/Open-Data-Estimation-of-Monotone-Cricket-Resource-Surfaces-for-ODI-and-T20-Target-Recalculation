function RevisedCodes_19_Publication(Index,Models,c)
% Final refit coefficients and grid data, distinct from pre-2023 confirmation fits.
U=RevisedCodes_19_Utils;P=RevisedCodes_12_Utils;report=fullfile(c.Root,'reports');
Parameters=table;Grid=table;Coefficients=table;Preprocessing=table;Dictionary=table;Shapes=table;
for j=1:height(Index)
 M=Models{j};fmt=Index.Format(j);role=Index.Role(j);
 if role=="PrimaryResource"
  p=M.Parameters(:)';T=table(fmt,p(1),p(2),p(3),p(4),p(5),p(6),M.FullStartMean, ...
   'VariableNames',{'Format','a','b','c','d','e','f','FullStartMean'});Parameters=[Parameters;T]; %#ok<AGROW>
  [~,Z,k]=P.CompactGrid(M.Parameters,M.Horizon);
  Shapes=[Shapes;table(repmat(fmt,11,1),(0:10)',Z(:),k(:), ...
   'VariableNames',{'Format','WicketsInHand','NormalizedFullHorizonCapacity','TimeShapeRate'})]; %#ok<AGROW>
 end
 if ismember(role,["PrimaryResource","FlexibleComparator"])
  [u,w]=ndgrid(0:M.Horizon,0:10);n=numel(u);
  Grid=[Grid;table(repmat(fmt,n,1),repmat(role,n,1),u(:),w(:),M.Resource(:),M.Supported(:),M.DataWeights(:), ...
   'VariableNames',{'Format','Role','BallsRemaining','WicketsInHand','NormalizedCapacity','FittingSupport','DataWeight'})]; %#ok<AGROW>
 end
 if isfield(M,'ForecastOnly')&&M.ForecastOnly
  names=M.FeatureNames(:);n=numel(names);
  Coefficients=[Coefficients;table(repmat(fmt,n,1),repmat(role,n,1),names,M.Beta(:),M.Beta(:)*M.FullStartMean, ...
   'VariableNames',{'Format','Role','Term','NormalizedCoefficient','RunsPerTrainingSD'})]; %#ok<AGROW>
  PP=M.Preprocessor;n=numel(PP.Names);
  Preprocessing=[Preprocessing;table(repmat(fmt,n,1),repmat(role,n,1),PP.Names(:),PP.Mean(:),PP.Scale(:),PP.Constant(:),PP.AllMissing(:), ...
   'VariableNames',{'Format','Role','Term','TrainingMean','TrainingScale','Constant','AllMissing'})]; %#ok<AGROW>
  D=PP.Categories.Dictionary;D.Format=repmat(fmt,height(D),1);D.Role=repmat(role,height(D),1);D.EncodedCategoryIndex=zeros(height(D),1);
  for entity=["Venue","EventName"]
   q=D.Entity==entity;[ok,k]=ismember(D.RawLabel(q),PP.Categories.(entity));k(~ok)=0;D.EncodedCategoryIndex(q)=k;
  end
  Dictionary=[Dictionary;D]; %#ok<AGROW>
 end
end
U.Write(report,'19_02_CompactParameters',Parameters);U.Write(report,'19_02_CapacityShapeFunctions',Shapes);
U.Write(report,'19_02_ResourceGrid',Grid);U.Write(report,'19_02_ContextCoefficients',Coefficients);
U.Write(report,'19_02_FeaturePreprocessing',Preprocessing);U.Write(report,'19_02_CategoryDictionary',Dictionary);
fig=figure('Visible','off','Color','w','Position',[100 100 1200 750]);tiledlayout(2,2,'Padding','compact');
for fmt=["ODI","T20"]
 j=find(Index.Format==fmt&Index.Role=="PrimaryResource");M=Models{j};k=find(Index.Format==fmt&Index.Role=="FlexibleComparator");B=Models{k};
 nexttile;hold on;colors=lines(4);ws=[10 7 5 3];
 for k=1:4
  w=ws(k);plot(0:M.Horizon,M.Resource(:,w+1),'Color',colors(k,:),'DisplayName',"Compact, w="+w);
  plot(0:M.Horizon,B.Resource(:,w+1),'--','Color',colors(k,:),'DisplayName',"Bernstein, w="+w);
 end
 xlabel('Balls remaining');ylabel('Normalized capacity');title(fmt+": final through-2023 refit");legend('Location','best','FontSize',8);
 nexttile;imagesc(0:M.Horizon,0:10,double(M.Supported'));set(gca,'YDir','normal');clim([0 1]);
 cb=colorbar;cb.Ticks=[0 1];cb.TickLabels={'Unsupported','Supported'};
 xlabel('Balls remaining');ylabel('Wickets in hand');title(fmt+": primary fitting support, not accuracy");
end
U.Figure(fig,report,"F19_FrozenResourceAndSupport");
end
