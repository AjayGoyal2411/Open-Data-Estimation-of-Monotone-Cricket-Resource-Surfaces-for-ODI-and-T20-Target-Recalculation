function Exceptional=RevisedCodes_09_04_RecoveredMatchAudit(settings)
% Audits exceptional cohorts from completed Step8A and corrected partitions.
% No new raw parser or retained-CSV scan; no automatic eligibility promotion.
if nargin<1,settings=struct;end
cfg=RevisedCodes_09_00_Config;U=RevisedCodes_09_Utils;
o=U.Options(struct('ForceRebuild',false),settings);
prereq=fullfile(cfg.PrerequisiteRoot,'RevisedCodes_Step8A_Result.mat');
assert(isfile(prereq),'Step8A result missing.');z=load(prereq,'Check');Q=z.Check;
M=Q.Manifest;A=Q.InningsAudit;M.MatchID=string(M.MatchID);A.MatchID=string(A.MatchID);
assert(numel(unique(M.MatchID))==height(M),'Duplicate match manifest ID.');
assert(numel(unique(U.Key(A)))==height(A),'Duplicate audit innings key.');
assert(all(A.MatchRow>=1&A.MatchRow<=height(M))&& ...
 isequal(A.MatchID,M.MatchID(A.MatchRow)),'Audit MatchRow mapping differs.');
[I,source]=U.Inventory(cfg);z=load(source,'Result');R=z.Result;
tab=fullfile(cfg.PrerequisiteRoot,'tables');
recovered=fullfile(tab,'Step8A_UnmatchedIDMetadata.csv');
yaml=fullfile(tab,'Step8A_YAMLInningsAudit.csv');corrections=fullfile(tab,'Step8_DeliveryCorrections.csv');
paths=[string(prereq);string(source);R.Partitions.Path;string(R.Signature.Delivery.Path); ...
 string(recovered);string(yaml);string(corrections)];
assert(all(isfile(paths)),'Required completed audit files missing; restore reports first.');
sig=U.Signature('09.04.1',o,paths,[mfilename('fullpath') '.m']);
root=fullfile(cfg.OutputRoot,'exceptional_audit');U.Ensure(root);
out=fullfile(root,'RevisedCodes_09_04_Result.mat');
if ~o.ForceRebuild&&U.CacheValid(out,'Exceptional',sig)
 z=load(out,'Exceptional');Exceptional=z.Exceptional;
 fprintf('09_04 cache reused. Upload %s\n',Exceptional.ReportZIP);return;
end
[g,report]=U.Generation(root);
D=U.Read(recovered,["MatchID","Format","Gender","Team1","Team2","DateRaw"]);
Y=U.Read(yaml,["MatchID","BattingTeam"]);
C=U.Read(corrections,["MatchID","Reason"]);
assert(numel(unique(D.MatchID))==height(D),'Duplicate recovered metadata ID.');
assert(numel(unique(U.Key(Y)))==height(Y),'Duplicate YAML audit innings ID.');
assert(~any(C.NeedsReview),'Unresolved correction entries.');
% Metadata-only recovered matches are not members of the corrected primary
% caches unless explicitly integrated and audited upstream. ODM stays ODM.
Recovered=D;Recovered.FormatCanonical=upper(strtrim(string(D.Format)));
Recovered.GenderCanonical=lower(strtrim(string(D.Gender)));
Recovered.GenderCanonical(ismember(Recovered.GenderCanonical,["female","women"]))="women";
Recovered.GenderCanonical(ismember(Recovered.GenderCanonical,["male","men"]))="men";
Recovered.Date=parseRecoveredDate(D.DateRaw);
Recovered.InMatchManifest=ismember(D.MatchID,M.MatchID);
Recovered.InStateCache=ismember(D.MatchID,I.MatchID);
Recovered.RawAuditInnings=zeros(height(D),1);Recovered.RawValuesValid=false(height(D),1);
Recovered.SixBallSchedule=false(height(D),1);Recovered.SensitivityStatus=strings(height(D),1);
Recovered.PrimaryPromoted=false(height(D),1);
for j=1:height(D)
 h=Y(Y.MatchID==D.MatchID(j),:);Recovered.RawAuditInnings(j)=height(h);
 valid=~isempty(h)&&all(~h.InvalidRawValues)& ...
  all(isfinite(h.LegalBalls)&h.LegalBalls>=0)&all(isfinite(h.DeliveryRuns)&h.DeliveryRuns>=0)& ...
  all(isfinite(h.GenuineDismissals)&h.GenuineDismissals>=0&h.GenuineDismissals<=10);
 Recovered.RawValuesValid(j)=valid;
 Recovered.SixBallSchedule(j)=D.BallsPerOver(j)==6&&isfinite(D.ScheduledOvers(j));
 if Recovered.FormatCanonical(j)=="ODM"
  Recovered.SensitivityStatus(j)="ODM retained; verify competition/format equivalence before any ODI comparison";
 elseif Recovered.FormatCanonical(j)=="T20"&&Recovered.GenderCanonical(j)=="women"&& ...
   valid&&Recovered.SixBallSchedule(j)&&~isnat(Recovered.Date(j))&&D.ScheduledOvers(j)==20
  Recovered.SensitivityStatus(j)="Auxiliary reconstruction candidate; metadata/raw aggregates are insufficient for integration";
 else
  Recovered.SensitivityStatus(j)="Metadata, raw values or format rules require further review";
 end
 if Recovered.InStateCache(j)
  Recovered.SensitivityStatus(j)=Recovered.SensitivityStatus(j)+"; cached presence does not establish eligible use";
 end
end
% Full eligibility ledger spans all audited innings; every flag has a stated
% unit and missing state caches remain visible.
Ledger=A(:,{'MatchID','InningsIndex','BattingTeam','LegalBalls','DeliveryRuns','GenuineDismissals', ...
 'RetiredHurtEvents','BallsPerOver','NominalBalls','InitialAllocatedBalls','CompletionClass', ...
 'EligibilityReason','RecordIntegrityOK','ResponseEligible','PrimaryModelEligible', ...
 'CaseStudyReserved','Split','RawVerificationSource','PenaltyPre','PenaltyPost','AbsentHurtCount'});
Ledger.Format=M.FormatFamily(A.MatchRow);Ledger.Gender=M.GenderCanon(A.MatchRow);
Ledger.Date=M.StartDate(A.MatchRow);
Ledger.VerifiedRaw=A.RawMetadataVerified|A.YAMLVerified;
Ledger.MiscountRecorded=A.MiscountedOvers;
Ledger.ExceedsNominal=isfinite(A.NominalBalls)&A.LegalBalls>A.NominalBalls;
Ledger.ExceedsInitial=isfinite(A.InitialAllocatedBalls)&A.LegalBalls>A.InitialAllocatedBalls;
Ledger.FiveBallFormat=A.BallsPerOver==5;
Ledger.NumericOrSequenceErrors=A.NumericErrors>0|A.SequenceErrors>0|A.RunIdentityErrors>0;
Ledger.RetirementWithIntegrityIssue=A.RetiredHurtEvents>0&(~A.RecordIntegrityOK|Ledger.NumericOrSequenceErrors);
Ledger.RetirementReturnStatus=repmat("not_applicable",height(A),1);
Ledger.RetirementReturnStatus(A.RetiredHurtEvents>0)= ...
 "not_assessed; player-level retirement/return events required before availability inference";
Ledger.CachedStateAvailable=false(height(A),1);Ledger.CachedReconstructionPassed=false(height(A),1);
Ledger.CachedPrimary=false(height(A),1);Ledger.CachedPrimaryStates=zeros(height(A),1);
Ledger.CachedInitialBalls=nan(height(A),1);Ledger.NegativeCachedHorizon=false(height(A),1);
[found,ii]=ismember(U.Key(A),U.Key(I));
Ledger.CachedStateAvailable=found;
Ledger.CachedReconstructionPassed(found)=I.ReconstructionPassed(ii(found));
Ledger.CachedPrimary(found)=I.Primary(ii(found));
Ledger.CachedPrimaryStates(found)=I.PrimaryStates(ii(found));
Ledger.CachedInitialBalls(found)=I.InitialBallsRemaining(ii(found));
% Detect prohibited eligibility drift between Step8A and Step09_01.
primary=A.PrimaryModelEligible;
assert(all(found(primary)),'Primary audit innings absent from corrected cache.');
assert(isequal(Ledger.CachedPrimary,primary),'Primary cohort drift between audit and cached states.');
assert(all(Ledger.CachedReconstructionPassed(primary)&Ledger.VerifiedRaw(primary)& ...
 Ledger.RecordIntegrityOK(primary)&~Ledger.CaseStudyReserved(primary)), ...
 'Primary raw integrity/reservation gate failed.');
assert(all(~Ledger.ExceedsNominal(primary)&~Ledger.FiveBallFormat(primary)), ...
 'Exceptional horizon/format entered primary cohort.');
matchMismatches=table(strings(0,1),zeros(0,1),strings(0,1), ...
 'VariableNames',{'MatchID','InningsIndex','Mismatch'});
for j=find(found)'
 a=I(ii(j),:);problems=strings(0,1);
 if a.LegalBalls~=A.LegalBalls(j),problems(end+1)="LegalBalls";end
 if a.FinalDeliveryRuns~=A.DeliveryRuns(j),problems(end+1)="DeliveryRuns";end
 if a.GenuineDismissals~=A.GenuineDismissals(j),problems(end+1)="GenuineDismissals";end
 if a.RetiredNotOutEvents~=A.RetiredHurtEvents(j),problems(end+1)="RetirementEvents";end
 if a.Format~=M.FormatFamily(A.MatchRow(j)),problems(end+1)="Format";end
 if a.Split~=A.Split(j),problems(end+1)="Split";end
 if ~isempty(problems)
  matchMismatches=[matchMismatches;table(A.MatchID(j),A.InningsIndex(j),join(problems,'; '), ...
   'VariableNames',matchMismatches.Properties.VariableNames)]; %#ok<AGROW>
  assert(~primary(j),'Primary cache/audit aggregate mismatch.');
 end
end
% Audit correction applications against the actual corresponding deliveries.
Application=C;Application.StateFound=false(height(C),1);Application.AppliedCorrectly=false(height(C),1);
Application.PrimaryInnings=false(height(C),1);
[cf,ci]=ismember(U.Key(C),U.Key(I));
for k=1:height(R.Partitions)
 selected=find(cf);selected=selected(I.Partition(ci(selected))==k);
 if isempty(selected),continue;end
 z=load(R.Partitions.Path(k),'States');S=z.States;
 for j=selected'
  a=I(ci(j),:);rows=(a.InitialRow:a.TerminalRow)';
  rows=rows(S.StateType(rows)=="delivery"&S.DeliverySeq(rows)==C.DeliverySeqInInnings(j));
  assert(numel(rows)<=1,'Duplicate corrected delivery key.');
  Application.PrimaryInnings(j)=a.Primary;
  if isempty(rows),continue;end
  r=rows(1);Application.StateFound(j)=true;
  Application.AppliedCorrectly(j)=S.CorrectedIsLegalBall(r)==C.CorrectedIsLegalBall(j)&& ...
   S.GenuineDismissalsOnDelivery(r)==C.GenuineDismissalsOnDelivery(j)&& ...
   S.RetiredNotOutEvents(r)==C.RetiredNotOutEvents(j);
 end
 % Horizon checks are performed in the separate complete pass below.
end
assert(all(Application.StateFound(Application.PrimaryInnings)& ...
 Application.AppliedCorrectly(Application.PrimaryInnings)),'Primary correction not applied.');
for k=1:height(R.Partitions)
 z=load(R.Partitions.Path(k),'States');S=z.States;
 candidates=find(found);candidates=candidates(I.Partition(ii(candidates))==k);
 for j=candidates'
  a=I(ii(j),:);u=S.BallsRemaining(a.InitialRow:a.TerminalRow);
  Ledger.NegativeCachedHorizon(j)=any(isfinite(u)&u<0);
 end
 assert(~any(S.PrimaryEligibleObservation&(~isfinite(S.BallsRemaining)|S.BallsRemaining<0)), ...
  'Invalid primary remaining-ball horizon.');
end
Ledger.SensitivityRole=repmat("excluded_pending_review",height(A),1);
Ledger.SensitivityRole(Ledger.ResponseEligible&Ledger.VerifiedRaw&Ledger.RecordIntegrityOK)= ...
 "completed_response_candidate_same_declared_estimand";
Ledger.SensitivityRole(Ledger.InningsIndex~=1)="second_innings_selected_or_censored; Step18 required";
Ledger.SensitivityRole(Ledger.MiscountRecorded|Ledger.ExceedsNominal|Ledger.ExceedsInitial)= ...
 "miscount/allocation audit only; separate allocation estimand required";
Ledger.SensitivityRole(Ledger.FiveBallFormat)="separate format; excluded from six-ball primary model";
Ledger.SensitivityRole(Ledger.RetirementWithIntegrityIssue)="retirement/integrity unresolved; no aggregate-only promotion";
Ledger.SensitivityRole(Ledger.CaseStudyReserved)="reserved case; source ledger required, never fitting";
Ledger.SensitivityRole(primary)="primary cohort unchanged";
Ledger.MinimumLength60ODI30T20=false(height(A),1);
Ledger.MinimumLength60ODI30T20(Ledger.Format=="ODI")=Ledger.LegalBalls(Ledger.Format=="ODI")>=60;
Ledger.MinimumLength60ODI30T20(Ledger.Format=="T20")=Ledger.LegalBalls(Ledger.Format=="T20")>=30;
Ledger.EarlyAllOut=Ledger.CompletionClass=="completed_early_all_out";
Ledger.ObservedLengthRatio=Ledger.LegalBalls./Ledger.NominalBalls;
% ObservedLengthRatio describes innings length, NOT record completeness.
Excess=Ledger(Ledger.MiscountRecorded|Ledger.ExceedsNominal|Ledger.ExceedsInitial,:);
Retirement=Ledger(Ledger.RetiredHurtEvents>0|Ledger.RetirementWithIntegrityIssue,:);
FiveMatches=M(M.BallsPerOver==5,:);
Counts=groupsummary(Ledger,{'Format','Gender','Split','CompletionClass'},'sum','CachedPrimaryStates');
Coverage=groupsummary(Ledger,{'Format','Gender','SensitivityRole'});
PrimaryPopulation=table;
for fmt=["ODI","T20"]
 for split=["train","validation","test"]
  keep=primary&Ledger.Format==fmt&Ledger.Split==split;
  B=table(fmt,split,numel(unique(Ledger.MatchID(keep))),nnz(keep), ...
   sum(Ledger.CachedPrimaryStates(keep)),nnz(keep&Ledger.EarlyAllOut), ...
   nnz(keep&~Ledger.MinimumLength60ODI30T20),nnz(keep&Ledger.RetiredHurtEvents>0), ...
   'VariableNames',{'Format','Split','Matches','Innings','States','EarlyAllOut', ...
   'BelowOriginalLengthCutoff','RetirementEventInnings'});
  PrimaryPopulation=[PrimaryPopulation;B]; %#ok<AGROW>
 end
end
Expected=table(["Recovered metadata records";"Recovered women T20 records";"Recovered women ODM records"; ...
 "First innings exceeding nominal allocation";"Five-ball match metadata records"], ...
 [25;17;8;54;322], ...
 [height(D);nnz(Recovered.FormatCanonical=="T20"&Recovered.GenderCanonical=="women"); ...
 nnz(Recovered.FormatCanonical=="ODM"&Recovered.GenderCanonical=="women"); ...
 nnz(Ledger.InningsIndex==1&Ledger.ExceedsNominal);height(FiveMatches)], ...
 'VariableNames',{'Metric','HandoverCount','ObservedCount'});
Expected.MatchesHandover=Expected.HandoverCount==Expected.ObservedCount;
% These reported historical counts are comparisons, not eligibility criteria.
Checks=table(["Primary caches present";"Primary integrity and raw verification";"Primary cohort unchanged"; ...
 "Primary corrections applied";"No exceptional primary horizons/formats";"No recovered metadata automatically promoted"], ...
 true(6,1),'VariableNames',{'Check','Passed'});
QC=table(["AuditedInnings";"CachedInnings";"PrimaryInnings";"PrimaryStates"; ...
 "AuxiliaryCacheAggregateMismatches";"CorrectionRows";"CorrectionsApplied"; ...
 "CorrectionRowsWithoutStates";"UnresolvedRetirementIntegrityInnings";"NegativeCachedHorizons"; ...
 "HandoverCountDiscrepancies"], ...
 [height(A);height(I);nnz(primary);sum(Ledger.CachedPrimaryStates);height(matchMismatches); ...
 height(C);nnz(Application.AppliedCorrectly);nnz(~Application.StateFound); ...
 nnz(Ledger.RetirementWithIntegrityIssue);nnz(Ledger.NegativeCachedHorizon);nnz(~Expected.MatchesHandover)], ...
 'VariableNames',{'Metric','Value'});
reportTables={Recovered,Ledger,Excess,Retirement,FiveMatches,Application,matchMismatches,Counts,Coverage,Expected,Checks,QC};
names={'RecoveredMetadata','SensitivityEligibility','MiscountsAndAllocations','RetirementIntegrity', ...
 'FiveBallMatches','CorrectionApplications','AuxiliaryCacheMismatches','PopulationCounts', ...
 'SensitivityCoverage','HandoverCountComparison','GateChecks','QC_Summary'};
for j=1:numel(names),writetable(reportTables{j},fullfile(report,['09_04_' names{j} '.csv']));end
writetable(PrimaryPopulation,fullfile(report,'09_04_PrimaryPopulations.csv'));
summary=[panel(1,["T20 women","ODM women","Other"], ...
 [Expected.ObservedCount(2),Expected.ObservedCount(3),height(D)-Expected.ObservedCount(2)-Expected.ObservedCount(3)],"Recovered metadata records"); ...
 panel(2,["Recorded miscount","Exceeds nominal","Exceeds initial"], ...
 [nnz(Ledger.MiscountRecorded),nnz(Ledger.ExceedsNominal),nnz(Ledger.ExceedsInitial)],"Innings allocation exceptions"); ...
 panel(3,["Retirement innings","With integrity issue"], ...
 [height(Retirement),nnz(Ledger.RetirementWithIntegrityIssue)],"Retirement audit"); ...
 panel(4,["Primary innings","Primary early all-out","Five-ball matches"], ...
 [nnz(primary),nnz(primary&Ledger.EarlyAllOut),height(FiveMatches)],"Eligibility populations; units labelled")];
tables=struct('Name',{"T_M11_ExceptionalRecordSummary","T_S09_04_RecoveredMetadata", ...
 'T_S09_04_SensitivityEligibility','T_S09_04_Miscounts','T_S09_04_RetirementIntegrity', ...
 'T_S09_04_CorrectionApplications','T_S09_04_HandoverCountComparison','T_M12_PrimaryEligibilityPopulations'}, ...
 'Data',{QC,Recovered,Ledger,Excess,Retirement,Application,Expected,PrimaryPopulation}, ...
 'Main',{true,false,false,false,false,false,false,true});
pub=U.Publish(cfg,"09_04",tables,summary, ...
 "Exceptional-record and eligibility audit. Recovered metadata remain reconstruction candidates; ODM is not relabelled ODI. Recorded miscounts, excess legal deliveries and five-ball formats are reported separately. Retirement integrity issues remain excluded pending source reconciliation. Observed innings length is not record completeness; primary eligibility remains unchanged.",report);
Exceptional=struct('Stage',"09_04",'Status',"PRIMARY_READY_AUXILIARY_REVIEW_PENDING", ...
 'PrimaryReady',true,'Ledger',Ledger,'Recovered',Recovered,'Corrections',Application, ...
 'ExpectedCounts',Expected,'AuxiliaryMismatches',matchMismatches,'Checks',Checks);
Exceptional=U.Finish(cfg,'Exceptional',out,sig,g,report,Exceptional,pub);
end
function d=parseRecoveredDate(s)
% Cached YAML dates can carry timestamps; retain DateRaw in the table.
s=string(s);d=NaT(size(s));
for j=1:numel(s)
 t=regexp(char(s(j)),'^\d{4}-\d{2}-\d{2}','match','once');
 if isempty(t),continue;end
 try,d(j)=datetime(t,'InputFormat','yyyy-MM-dd');catch,continue;end
end
end
function T=panel(p,labels,values,title)
T=table(repmat(p,numel(values),1),string(labels(:)),values(:),repmat(string(title),numel(values),1), ...
 'VariableNames',{'Panel','Label','Value','Title'});
end
