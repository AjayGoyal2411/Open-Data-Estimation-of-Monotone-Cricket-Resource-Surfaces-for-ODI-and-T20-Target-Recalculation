function RevisedCodes_09_RepairPublicationCache
% One-time compatibility migration for ONLY the two filename-export fixes.
% Does not change inventory data, source stamps, cohorts or model settings.
cfg=RevisedCodes_09_00_Config;U=RevisedCodes_09_Utils;
p=fullfile(cfg.OutputRoot,'support09','09_InningsInventory.mat');
if ~isfile(p)
 fprintf('No completed inventory exists; normal inventory build will be required.\n');return;
end
z=load(p,'InventorySignature');assert(isfield(z,'InventorySignature'),'Inventory signature missing.');
InventorySignature=z.InventorySignature;
current=fileread(which('RevisedCodes_09_Utils'));
assert(isequal(InventorySignature.Sources,U.Stamps(InventorySignature.Sources.Path)), ...
 'Inventory sources changed. Compatibility migration refused; reconcile source provenance.');
if strcmp(normalize(InventorySignature.Code),normalize(current))&& ...
 strcmp(normalize(InventorySignature.UtilityCode),normalize(current))
 fprintf('Inventory signature already matches the current utility.\n');return;
end
assert(strcmp(patchOnly(InventorySignature.Code),normalize(current))&& ...
 strcmp(patchOnly(InventorySignature.UtilityCode),normalize(current)), ...
 'Utility changes exceed the two publication filename fixes; inventory migration refused.');
InventorySignature.Code=current;InventorySignature.UtilityCode=current;
save(p,'InventorySignature','-append');
fprintf('Completed innings inventory preserved. Only publication-fix code compatibility was updated.\n');
end
function text=patchOnly(text)
text=normalize(text);
text=strrep(text,'char(t.Name+''.csv'')','char(string(t.Name)+".csv")');
text=strrep(text,'char(t.Name+''.xlsx'')','char(string(t.Name)+".xlsx")');
end
function text=normalize(text)
text=strrep(char(text),sprintf('\r\n'),sprintf('\n'));
text=strrep(text,sprintf('\r'),sprintf('\n'));
end
