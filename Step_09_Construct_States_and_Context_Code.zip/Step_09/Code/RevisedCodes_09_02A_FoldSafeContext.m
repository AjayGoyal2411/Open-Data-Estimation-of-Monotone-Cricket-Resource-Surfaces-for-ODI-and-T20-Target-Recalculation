function Development = RevisedCodes_09_02A_FoldSafeContext(settings)
% R2024b. Audits 09_01/09_02 and rebuilds chronological development histories.
% Run: Development=RevisedCodes_09_02A_FoldSafeContext;
% Optional settings override ONLY this stage, never 09_00 or source caches.
% No outcome prediction, test-performance evaluation, or model selection here.
% Future 10--19 codes MUST fit surfaces/scales/preprocessing within each fold.
if nargin<1,settings=struct;end
cfg=RevisedCodes_09_00_Config;
opt=defaults(settings);
source=fullfile(cfg.OutputRoot,'RevisedCodes_09_Result.mat');
context=fullfile(cfg.OutputRoot,'context','RevisedCodes_09_02_Result.mat');
assert(isfile(source)&&isfile(context),'Completed 09_01 and 09_02 manifests required.');
z=load(source,'Result');R=z.Result;z=load(context,'Context');C=z.Context;
assert(height(R.Partitions)==height(C.Partitions),'Partition count mismatch.');
assert(all(isfile(R.Partitions.Path))&&all(isfile(C.Partitions.Path)), ...
 'Missing source partition. Restore it; do not rerun expensive reconstruction automatically.');
assert(isequal(string(C.SourcePartitions.Path),string(R.Partitions.Path)), ...
 '09_02 is linked to a different state generation.');
root=fullfile(cfg.OutputRoot,'development_context');ensure(root);
out=fullfile(root,'RevisedCodes_09_02A_Result.mat');
sig=struct('Version','09.02A.1','Options',opt,'Config',cfg, ...
 'CodeSHA256',hashText(fileread([mfilename('fullpath') '.m'])), ...
 'StateManifest',fileStamp(source),'ContextManifest',fileStamp(context), ...
 'StatePartitions',stamps(R.Partitions.Path),'ContextPartitions',stamps(C.Partitions.Path));
if isfile(out)&&~opt.ForceRebuild
 z=load(out,'Development');D=z.Development;
 if isequaln(D.Signature,sig)&&all(isfile(D.Partitions.Path))&& ...
   all(isfile(D.ArtifactPaths))&&isfile(D.ReportZIP)
  Development=D;fprintf('Valid 09_02A cache reused. Upload %s\n',D.ReportZIP);return;
 end
end
selfTest;
gen=fullfile(root,['generation_' char(datetime('now','Format','yyyyMMdd_HHmmss_SSS'))]);
ensure(gen);report=fullfile(gen,'reports');ensure(report);
audit=table;I=table;
fprintf('Auditing source/context partitions and pre-state features...\n');
for k=1:height(R.Partitions)
 z=load(R.Partitions.Path(k),'States');S=z.States;
 z=load(C.Partitions.Path(k),'Features');F=z.Features;
 assert(height(S)==R.Partitions.States(k)&&height(F)==C.Partitions.Rows(k), ...
  'Manifest row count differs at partition %d.',k);
 assert(height(S)==height(F)&&isequal(keys(S),keys(F)),'Row key/order mismatch at %d.',k);
 assert(numel(unique(keys(S)))==height(S),'Duplicate state keys at %d.',k);
 forbidden=contains(lower(string(F.Properties.VariableNames)), ...
  ["final","future","remainingruns","observedfraction","observedremaining","historicaltotal"]);
 assert(~any(forbidden),'Outcome-like field in predictor table at %d.',k);
 metadata={'Format','Split','CaseReserved','PrimaryEligibleObservation','PrimaryFitObservation'};
 for v=metadata
  assert(isequaln(S.(v{1}),F.(v{1})),'Metadata mismatch: %s.',v{1});
 end
 [recent,balls,retired,partnership,noDismissal]=prestate(S);
 assert(isequaln(recent,F.Recent30Runs)&&isequaln(balls,F.Recent30LegalBalls), ...
  'Recent-window discrepancy at %d.',k);
 assert(isequaln(retired,F.RetiredNotOutEventsBefore),'Retirement timing discrepancy.');
 assert(isequaln(partnership,F.LegalBallsSinceDismissal)&& ...
  isequaln(noDismissal,F.NoDismissalYet),'Partnership reset discrepancy.');
 assert(isequaln(S.BallsRemaining,F.BallsRemaining)&& ...
  isequaln(S.WicketsInHand,F.WicketsInHand)&& ...
  isequaln(S.DeliveryScoreBefore,F.ScoreBefore),'Core pre-state feature mismatch.');
 rate=nan(height(S),1);v=S.LegalBallsBowled>0;
 rate(v)=6*S.DeliveryScoreBefore(v)./S.LegalBallsBowled(v);
 recentRate=nan(height(S),1);v=balls>0;recentRate(v)=6*recent(v)./balls(v);
 assert(isequaln(rate,F.RunRateBefore)&&isequaln(recentRate,F.Recent30RunRate)&& ...
  isequal(S.LegalBallsBowled==0,F.NoLegalBallYet),'Rate/missingness timing discrepancy.');
 v=S.PrimaryEligibleObservation;
 assert(all(~S.CaseReserved(v)&~isnat(S.MatchDate(v))),'Reserved/missing-date primary state.');
 assert(all(S.PrimaryRemainingRuns(v)==S.FinalDeliveryRuns(v)-S.DeliveryScoreBefore(v)), ...
  'Remaining-run outcome does not reconcile.');
 assert(all(isfinite(S.PrimaryRemainingRuns(v))&S.PrimaryRemainingRuns(v)>=0), ...
  'Invalid primary outcome.');
 assert(isequal(S.PrimaryFitObservation,v&S.Split=="train"),'Primary fitting mask differs.');
 historyNames=historyFields;
 for h=6:10
  a=F.(historyNames{h});
  assert(all(isfinite(a(v))&a(v)>=0&a(v)==floor(a(v))),'Invalid primary history counts.');
 end
 first=find(S.StateType=="initial");last=find(S.StateType=="terminal");
 assert(numel(first)==numel(last)&&all(first<last),'Invalid innings boundaries.');
 for j=1:numel(first)
  a=first(j);b=last(j);rows=a:b;
  assert(all(S.MatchID(rows)==S.MatchID(a)&S.InningsIndex(rows)==S.InningsIndex(a)), ...
   'Noncontiguous innings block.');
  opp=S.Team1(a);if S.BattingTeam(a)==S.Team1(a),opp=S.Team2(a);end
  if ~any(S.BattingTeam(a)==[S.Team1(a),S.Team2(a)]),opp="";end
  B=table(S.MatchID(a),S.InningsIndex(a),S.Format(a), ...
   dateshift(S.MatchDate(a),'start','day'),S.Split(a),S.CaseReserved(a), ...
   S.BattingTeam(a),opp,S.Venue(a),S.EventName(a),any(v(rows)), ...
   S.FinalDeliveryRuns(b),nnz(v(rows)),S.Gender(a), ...
   'VariableNames',{'MatchID','InningsIndex','Format','Date','Split','CaseReserved', ...
   'BattingTeam','Opponent','Venue','EventName','Primary','HistoricalTotal','States','Gender'});
  % Preserve original per-innings histories for independent reconstruction.
  for h=1:10,B.(historyNames{h})=F.(historyNames{h})(a);end
  I=[I;B]; %#ok<AGROW>
 end
 A=table(k,height(S),height(F),numel(first),nnz(v),true, ...
  'VariableNames',{'Partition','StateRows','ContextRows','Innings','PrimaryStates','Passed'});
 audit=[audit;A]; %#ok<AGROW>
 fprintf('Source audit %d/%d passed\n',k,height(R.Partitions));
end
ik=inningsKeys(I);assert(numel(unique(ik))==height(I),'Duplicate innings across partitions.');
assert(sum(audit.StateRows)==sum(R.Partitions.States),'Total source rows differ.');
% Match-level metadata must not disagree between its innings.
[~,~,g]=unique(I.MatchID);
for j=1:max(g)
 a=find(g==j);assert(numel(unique(I.Split(a)))==1&& ...
  numel(unique(I.CaseReserved(a)))==1&&numel(unique(I.Date(a)))==1, ...
  'Conflicting match date/split/reservation metadata.');
end
H=I(I.Primary&I.Split=="train"&~I.CaseReserved,:);
assert(all(year(H.Date)<2023)&all(~isnat(H.Date)),'Invalid training chronology.');
assert(all(isfinite(H.HistoricalTotal)&H.HistoricalTotal>=0),'Invalid training totals.');
assert(all(ismember(H.Format,["ODI","T20"])),'Unexpected primary format.');
% Recompute all original histories from outcomes; prediction scores not used.
base=histories(I,H,C.ShrinkagePseudoInnings,C.InitialPriorODI,C.InitialPriorT20);
names=historyFields;discrepancy=zeros(10,1);
for h=1:10
 a=I.(names{h});b=base.(names{h});
 same=(isnan(a)&isnan(b)) | (isfinite(a)&isfinite(b)&abs(a-b)<=1e-9.*max(1,abs(b)));
 discrepancy(h)=nnz(~same);
end
assert(all(discrepancy==0),'Original history values disagree with independent reconstruction.');
write(table(string(names(:)),discrepancy,'VariableNames',{'Feature','Discrepancies'}), ...
 fullfile(report,'09_02A_OriginalHistoryAudit.csv'));
write(audit,fullfile(report,'09_02A_PartitionAudit.csv'));
folds=makeFolds(H,opt);write(folds,fullfile(report,'09_02A_FoldLedger.csv'));
sourceLedger=table;membership=table;support=table;
P=table(strings(0,1),strings(0,1),zeros(0,1),zeros(0,1), ...
 'VariableNames',{'FoldID','Path','SourcePartition','Rows'});
for f=1:height(folds)
 id=folds.FoldID(f);cut=folds.AssessmentStart(f);stop=folds.AssessmentEndExclusive(f);
 fit=H.Date<cut;assess=H.Date>=cut&H.Date<stop;
 permitted=H(fit,:);Q=H(fit|assess,:);
 roles=repmat("fit",height(Q),1);roles(Q.Date>=cut)="assessment";
 assert(~any(permitted.CaseReserved)&&all(permitted.Date<cut),'Forbidden fold source.');
 M=table(repmat(id,height(Q),1),Q.MatchID,Q.InningsIndex,Q.Format,Q.Date,roles,Q.States, ...
  'VariableNames',{'FoldID','MatchID','InningsIndex','Format','Date','Role','States'});
 membership=[membership;M]; %#ok<AGROW>
 L=table(repmat(id,height(permitted),1),permitted.MatchID,permitted.InningsIndex, ...
  permitted.Format,permitted.Date,'VariableNames',{'FoldID','MatchID','InningsIndex','Format','SourceDate'});
 sourceLedger=[sourceLedger;L]; %#ok<AGROW>
 % Do not normalize from state-weighted totals. Store one outcome per innings.
 Labels=Q(:,{'MatchID','InningsIndex','Format','HistoricalTotal'});
 Labels.Properties.VariableNames{4}='FinalDeliveryRuns';
 save(fullfile(gen,char(id+'_InningsOutcomes.mat')),'Labels','-v7.3');
 foldDir=fullfile(gen,char(id));ensure(foldDir);
 Qkey=inningsKeys(Q);
 % Raw history counts/max date do not depend on shrinkage strength.
 candidateHist=cell(numel(opt.ShrinkageCandidates),1);
 for c=1:numel(candidateHist)
  candidateHist{c}=histories(Q,permitted,opt.ShrinkageCandidates(c),opt.InitialPriorODI,opt.InitialPriorT20);
 end
 Hist=candidateHist{1};
 assert(all(isnat(Hist.HistoryMaxSourceDate)| ...
  (Hist.HistoryMaxSourceDate<Q.Date&Hist.HistoryMaxSourceDate<cut)),'Fold history chronology failure.');
 for fmt=["ODI","T20"]
  for role=["fit","assessment"]
   keep=Q.Format==fmt&roles==role;B=Hist(keep,:);weights=Q.States(keep);
   for entity=2:5
    unsupported=B.(names{entity+5})==0;
    row=table(id,fmt,role,string(names{entity+5}),height(B),sum(weights), ...
     nnz(unsupported),sum(weights(unsupported)), ...
     'VariableNames',{'FoldID','Format','Role','HistoryCountField','Innings','States', ...
     'UnsupportedInnings','UnsupportedStates'});
    support=[support;row]; %#ok<AGROW>
   end
  end
 end
 for k=1:height(R.Partitions)
  z=load(C.Partitions.Path(k),'Features');F=z.Features;
  [found,ii]=ismember(inningsKeys(F),Qkey);keep=found&F.PrimaryEligibleObservation;
  if ~any(keep),continue;end
  F=F(keep,:);ii=ii(keep);
  % Fold roles/masks are separate metadata, never predictors.
  Membership=table(F.MatchID,F.InningsIndex,F.DeliverySeq,F.StateType,roles(ii), ...
   roles(ii)=="fit",roles(ii)=="assessment", ...
   'VariableNames',{'MatchID','InningsIndex','DeliverySeq','StateType','Role','FoldFit','FoldAssessment'});
  identifiers={'MatchID','InningsIndex','DeliverySeq','StateType'};
  Identities=F(:,identifiers);
  Features=F(:,{'BallsRemaining','WicketsInHand','ScoreBefore','LegalBallsSinceDismissal', ...
   'NoDismissalYet','RetiredNotOutEventsBefore','RunRateBefore','NoLegalBallYet', ...
   'Recent30Runs','Recent30LegalBalls','Recent30RunRate','Opponent','BattingTeam', ...
   'Venue','EventName','HistoryMissingDate','OpponentIdentityMissing'});
  for h=6:10,Features.(names{h})=Hist.(names{h})(ii);end
  for c=1:numel(candidateHist)
   ch=candidateHist{c};suffix=sprintf('_K%d',opt.ShrinkageCandidates(c));
   for h=1:5,Features.([names{h} suffix])=ch.(names{h})(ii);end
  end
  Features.NoFormatHistory=Features.HistoryFormatN==0;
  Features.NoBattingHistory=Features.HistoryBattingN==0;
  Features.NoOpponentHistory=Features.HistoryOpponentN==0;
  Features.NoVenueHistory=Features.HistoryVenueN==0;
  Features.NoEventHistory=Features.HistoryEventN==0;
  Provenance=table(Identities.MatchID,Identities.InningsIndex, ...
   Q.Date(ii),Hist.HistoryMaxSourceDate(ii),repmat(cut,height(F),1), ...
   'VariableNames',{'MatchID','InningsIndex','PredictionDate','MaxHistorySourceDate','SourceCutoffExclusive'});
  path=fullfile(foldDir,sprintf('09_02A_Part%04d.mat',k));
  save(path,'Identities','Features','Membership','Provenance','-v7.3');
  P=[P;table(id,string(path),k,height(F),'VariableNames',P.Properties.VariableNames)]; %#ok<AGROW>
 end
 assert(sum(P.Rows(P.FoldID==id))==sum(Q.States),'Fold output row count differs.');
 fprintf('%s histories and partitions complete\n',id);
end
write(P,fullfile(report,'09_02A_PartitionManifest.csv'));
write(membership,fullfile(report,'09_02A_InningsMembership.csv'));
write(sourceLedger,fullfile(report,'09_02A_HistorySourceLedger.csv'));
write(support,fullfile(report,'09_02A_ContextSupport.csv'));
T=table(["Exact source/context keys";"Pre-state windows and resets";"Original history reconstruction"; ...
 "Fold source chronology";"Held-out perturbation self-test";"Duplicate innings"], ...
 true(6,1),'VariableNames',{'Check','Passed'});
write(T,fullfile(report,'09_02A_GateChecks.csv'));
dictionary=table(["Identities";"Features";"Membership";"Provenance";"InningsOutcomes"], ...
 ["State join keys only";"Predictor-only pre-state values; choose one K candidate or no-history ablation"; ...
 "Use FoldFit/FoldAssessment explicitly; original PrimaryFitObservation is insufficient"; ...
 "Prediction dates and permitted history maximum; diagnostic metadata"; ...
 "Final delivery-run labels stored separately, one row per innings; never predictors"], ...
 'VariableNames',{'Object','Use'});
write(dictionary,fullfile(report,'09_02A_DataContract.csv'));
write(table("PENDING", ...
 "Steps 10--19 must refit empirical surfaces, full-start means, projections, models and preprocessing separately for each fold. This stage does not fit those components or certify model accuracy.", ...
 'VariableNames',{'Status','RequiredNextAction'}),fullfile(report,'09_02A_DownstreamRequirements.csv'));
pubPaths=publication(cfg,folds,support,dictionary,opt,report);
reportZIP=fullfile(cfg.ProjectRoot,'RevisedCodes_09_02A_Checks.zip');
files=dir(fullfile(report,'*.csv'));
zip(reportZIP,[{files.name},{'09_02A_FoldPreview.png'}],report);
artifacts=[string(fullfile(report,{files.name}))'; ...
 string(fullfile(gen,cellstr(folds.FoldID+'_InningsOutcomes.mat')));pubPaths(:); ...
 string(fullfile(report,'09_02A_FoldPreview.png'))];
assert(isequal(sig.StatePartitions,stamps(R.Partitions.Path))&& ...
 isequal(sig.ContextPartitions,stamps(C.Partitions.Path))&& ...
 isequal(sig.StateManifest,fileStamp(source))&&isequal(sig.ContextManifest,fileStamp(context)), ...
 'Source cache changed during execution. Completion manifest withheld.');
Development=struct('Signature',sig,'Partitions',P,'Folds',folds,'Generation',string(gen), ...
 'InningsMembership',membership,'HistorySourceLedger',sourceLedger,'Support',support, ...
 'ArtifactPaths',artifacts,'ReportZIP',reportZIP,'Status','CONTEXT_READY_MODELS_PENDING', ...
 'HistoryPolicy','primary train only; strict earlier calendar date; source cutoff exclusive', ...
 'Options',opt);
save(out,'Development','-v7.3');
fprintf('09_02A COMPLETE. Model-fitting components remain pending. Upload %s\n',reportZIP);
end

function opt=defaults(s)
opt=struct('AssessmentYears',[],'MaximumFolds',3,'MinTrainMatchesPerFormat',100, ...
 'MinAssessmentMatchesPerFormat',20,'ShrinkageCandidates',[5 20 50], ...
 'InitialPriorODI',250,'InitialPriorT20',150,'ForceRebuild',false);
assert(isstruct(s)&&isscalar(s),'Settings must be a scalar struct.');
for n=fieldnames(s)'
 assert(isfield(opt,n{1}),'Unknown setting %s.',n{1});opt.(n{1})=s.(n{1});
end
validateattributes(opt.ShrinkageCandidates,{'numeric'},{'vector','finite','positive','integer'});
assert(numel(unique(opt.ShrinkageCandidates))==numel(opt.ShrinkageCandidates),'Duplicate shrinkage candidates.');
validateattributes(opt.MaximumFolds,{'numeric'},{'scalar','positive','integer'});
validateattributes(opt.MinTrainMatchesPerFormat,{'numeric'},{'scalar','positive','integer'});
validateattributes(opt.MinAssessmentMatchesPerFormat,{'numeric'},{'scalar','positive','integer'});
validateattributes(opt.InitialPriorODI,{'numeric'},{'scalar','finite','positive'});
validateattributes(opt.InitialPriorT20,{'numeric'},{'scalar','finite','positive'});
if ~isempty(opt.AssessmentYears)
 validateattributes(opt.AssessmentYears,{'numeric'},{'vector','finite','integer','<',2023});
end
end
function F=makeFolds(H,opt)
years=unique(year(H.Date));explicit=~isempty(opt.AssessmentYears);
if explicit,years=unique(opt.AssessmentYears);end
F=table;
for y=years(:)'
 cut=datetime(y,1,1);stop=datetime(y+1,1,1);n=zeros(1,4);
 for f=1:2
  formats=["ODI","T20"];v=H.Format==formats(f);
  n(f)=numel(unique(H.MatchID(v&H.Date<cut)));
  n(f+2)=numel(unique(H.MatchID(v&H.Date>=cut&H.Date<stop)));
 end
 adequate=all(n(1:2)>=opt.MinTrainMatchesPerFormat)&& ...
  all(n(3:4)>=opt.MinAssessmentMatchesPerFormat);
 if explicit,assert(adequate,'Requested assessment year %d has insufficient per-format support.',y);end
 if ~adequate,continue;end
 B=table("Fold_"+string(y),cut,stop,n(1),n(2),n(3),n(4), ...
  'VariableNames',{'FoldID','AssessmentStart','AssessmentEndExclusive', ...
  'TrainODIMatches','TrainT20Matches','AssessmentODIMatches','AssessmentT20Matches'});
 F=[F;B]; %#ok<AGROW>
end
assert(~isempty(F),'No supported development folds. Inspect years before changing support requirements.');
if ~explicit,F=F(max(1,height(F)-opt.MaximumFolds+1):end,:);end
end
function names=historyFields
names={'HistoryFormatMean','HistoryBattingMean','HistoryOpponentMean', ...
 'HistoryVenueMean','HistoryEventMean','HistoryFormatN','HistoryBattingN', ...
 'HistoryOpponentN','HistoryVenueN','HistoryEventN'};
end
function B=histories(Q,H,K,odi,t20)
names=historyFields;B=table;
for n=names,B.(n{1})=nan(height(Q),1);end
B.HistoryMaxSourceDate=NaT(height(Q),1);
entities={'BattingTeam','Opponent','Venue','EventName'};
for j=1:height(Q)
 if isnat(Q.Date(j)),continue;end
 h=H(H.Format==Q.Format(j)&H.Date<Q.Date(j),:);
 prior=t20;if Q.Format(j)=="ODI",prior=odi;end
 mu=prior;if ~isempty(h),mu=mean(h.HistoricalTotal);B.HistoryMaxSourceDate(j)=max(h.Date);end
 B.HistoryFormatMean(j)=mu;B.HistoryFormatN(j)=height(h);
 for e=1:4
  value=Q.(entities{e})(j);keep=h.(entities{e})==value;
  if ismissing(value)||strlength(strtrim(value))==0,keep(:)=false;end
  n=nnz(keep);B.(names{e+1})(j)=(sum(h.HistoricalTotal(keep))+K*mu)/(n+K);
  B.(names{e+6})(j)=n;
 end
end
end
function [r,b,retired,p,noDismissal]=prestate(S,L)
if nargin<2,L=30;end
n=height(S);r=zeros(n,1);b=r;retired=r;p=r;noDismissal=false(n,1);
first=find(S.StateType=="initial");last=find(S.StateType=="terminal");
assert(numel(first)==numel(last),'Unpaired innings boundaries.');
for j=1:numel(first)
 rows=(first(j):last(j))';d=rows(S.StateType(rows)=="delivery");
 ends=find(S.CorrectedIsLegalBall(d)==1);bound=[0;cumsum(S.DeliveryRuns(d))];
 events=S.RetiredNotOutEvents(rows);retired(rows)=[0;cumsum(events(1:end-1))];
 since=0;lost=0;
 for k=rows'
  p(k)=since;noDismissal(k)=lost==0;
  done=S.LegalBallsBowled(k);b(k)=min(L,done);cut=done-b(k);base=0;
  if cut>0,base=bound(ends(cut)+1);end
  r(k)=S.DeliveryScoreBefore(k)-base;
  if S.StateType(k)=="delivery"
   since=since+S.CorrectedIsLegalBall(k);
   if S.GenuineDismissalsOnDelivery(k)>0,since=0;end
   lost=lost+S.GenuineDismissalsOnDelivery(k);
  end
 end
end
assert(all(r>=0&b>=0&b<=L),'Invalid recent scoring.');
end
function k=keys(T)
k=inningsKeys(T)+"|"+string(T.DeliverySeq)+"|"+T.StateType;
end
function k=inningsKeys(T)
k=T.MatchID+"|"+string(T.InningsIndex);
end
function ensure(p)
if ~isfolder(p),mkdir(p);end
end
function write(T,p)
writetable(T,p);
end
function s=fileStamp(p)
d=dir(p);assert(numel(d)==1,'Expected one file: %s',p);
s=struct('Path',string(p),'Bytes',d.bytes,'Modified',d.datenum);
end
function T=stamps(paths)
bytes=zeros(numel(paths),1);modified=bytes;
for k=1:numel(paths),d=fileStamp(paths(k));bytes(k)=d.Bytes;modified(k)=d.Modified;end
T=table(string(paths(:)),bytes,modified,'VariableNames',{'Path','Bytes','Modified'});
end
function h=hashText(s)
md=java.security.MessageDigest.getInstance('SHA-256');
md.update(unicode2native(s,'UTF-8'));
bytes=typecast(md.digest(),'uint8');h=lower(reshape(dec2hex(bytes,2)',1,[]));
end
function paths=publication(cfg,F,S,D,opt,report)
pub=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady');
t=fullfile(pub,'Methodology','Tables');g=fullfile(pub,'Methodology','Figures');
src=fullfile(pub,'SourceData');idx=fullfile(pub,'CaptionsAndIndex');
for p=string({t,g,src,idx}),ensure(p);end
S.UnsupportedInningsPct=100*S.UnsupportedInnings./S.Innings;
S.UnsupportedStatesPct=100*S.UnsupportedStates./S.States;
paths=string({fullfile(t,'T_M07_DevelopmentFolds.csv'), ...
 fullfile(t,'T_M08_FoldContextSupport.csv'),fullfile(t,'T_M09_FoldDataContract.csv'), ...
 fullfile(t,'09_02A_MethodologyTables.xlsx'),fullfile(src,'F_M04_FoldSourceData.csv'), ...
 fullfile(idx,'09_02A_PublicationIndex.csv')})';
write(F,paths(1));write(S,paths(2));write(D,paths(3));
% XLSX is a publication export only; no spreadsheet analysis is performed.
writetable(F,paths(4),'Sheet','Folds');writetable(S,paths(4),'Sheet','Support');
writetable(D,paths(4),'Sheet','Contract');write(F,paths(5));
fig=figure('Visible','off','Color','w','Position',[100 100 1100 720]);
cleanup=onCleanup(@()close(fig)); %#ok<NASGU>
tiledlayout(2,2,'TileSpacing','compact','Padding','compact');
cols={'TrainODIMatches','TrainT20Matches','AssessmentODIMatches','AssessmentT20Matches'};
labels={'ODI training','T20 training','ODI assessment','T20 assessment'};
for k=1:4
 nexttile;bar(F.(cols{k}),'FaceColor',[.15 .4 .65]);
 xticks(1:height(F));xticklabels(string(year(F.AssessmentStart)));
 xlabel('Assessment year');ylabel('Matches');title(sprintf('(%c) %s',64+k,labels{k}));
 set(gca,'FontName','Times New Roman','FontSize',10,'Box','off');grid on;
end
base=fullfile(g,'F_M04_DevelopmentFoldPopulations');
exportgraphics(fig,[base '.png'],'Resolution',600);
exportgraphics(fig,[base '.pdf'],'ContentType','vector');savefig(fig,[base '.fig']);
exportgraphics(fig,fullfile(report,'09_02A_FoldPreview.png'),'Resolution',110);
paths=[paths;string([base '.png']);string([base '.pdf']);string([base '.fig'])];
caption="Expanding-window development cohorts. Each assessment year uses only earlier primary training matches. Historical scoring inputs additionally require strict earlier calendar dates. Validation (2023), temporal test and reserved cases are excluded from these folds. Counts represent correlated match clusters, not independent delivery samples. Shrinkage candidates: "+join(string(opt.ShrinkageCandidates),', ')+" pseudo-innings. No predictive performance is shown.";
write(table("F_M04_DevelopmentFoldPopulations",caption,string(mfilename), ...
 'VariableNames',{'Asset','Caption','ProducingCode'}),paths(6));
end
function selfTest
% Current-delivery runs, retirements and dismissals enter only later states.
S=table(["initial";"delivery";"delivery";"delivery";"delivery";"terminal"], ...
 [0;0;0;1;2;3],[0;0;2;6;7;10],[0;0;1;1;1;0],[0;2;4;1;3;0], ...
 [0;0;0;1;0;0],[0;1;0;0;0;0], ...
 'VariableNames',{'StateType','LegalBallsBowled','DeliveryScoreBefore', ...
 'CorrectedIsLegalBall','DeliveryRuns','GenuineDismissalsOnDelivery','RetiredNotOutEvents'});
[r,b,retired,p,noDismissal]=prestate(S,2);
assert(isequal(r,[0;0;2;6;7;4])&&isequal(b,[0;0;0;1;2;2]),'Pre-state recent window failed.');
assert(isequal(retired,[0;0;1;1;1;1])&&isequal(p,[0;0;0;1;0;1])&& ...
 isequal(noDismissal,logical([1;1;1;1;0;0])),'Retirement/dismissal timing failed.');
% Dates tied within a day must not source each other's outcomes.
H=table(["a";"b";"c"],[1;1;1],repmat("T20",3,1), ...
 datetime(2020,1,[1;1;2]),[100;200;900],repmat("A",3,1), ...
 repmat("B",3,1),repmat("V",3,1),repmat("E",3,1), ...
 'VariableNames',{'MatchID','InningsIndex','Format','Date','HistoricalTotal', ...
 'BattingTeam','Opponent','Venue','EventName'});
Q=H;B=histories(Q,H,20,250,150);
assert(isequal(B.HistoryFormatN,[0;0;2])&&B.HistoryFormatMean(3)==150, ...
 'Same-date history isolation failed.');
% Assessment labels cannot affect training or another assessment prediction.
allowed=H(1:2,:);B=histories(Q,allowed,20,250,150);
Q.HistoricalTotal(3)=1e6;B2=histories(Q,allowed,20,250,150);
assert(isequaln(B,B2),'Held-out label perturbation changed history.');
assert(isnat(B.HistoryMaxSourceDate(1))&&B.HistoryMaxSourceDate(3)<Q.Date(3), ...
 'Source chronology failed.');
fprintf('History chronology/held-out perturbation self-tests passed.\n');
end
