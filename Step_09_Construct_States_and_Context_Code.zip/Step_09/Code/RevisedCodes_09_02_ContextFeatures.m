function Context=RevisedCodes_09_02_ContextFeatures
% R2024b. Run after 09_01. Reads cached states only; never changes their labels.
% Histories use primary TRAINING innings completed on STRICTLY earlier dates.
% Validation/test/cases never update histories. These are descriptive scoring
% proxies, not official rankings. No future score appears in predictor tables.
% Histories must be recomputed under each development-fold cutoff if that
% cutoff differs from the chronological source policy implemented here.
cfg=RevisedCodes_09_00_Config;
source=fullfile(cfg.OutputRoot,'RevisedCodes_09_Result.mat');
assert(isfile(source),'Run 09_01 first.'); z=load(source,'Result'); R=z.Result;
assert(all(isfile(R.Partitions.Path)),'Missing corrected state partition.');
root=fullfile(cfg.OutputRoot,'context');if ~isfolder(root),mkdir(root);end
out=fullfile(root,'RevisedCodes_09_02_Result.mat');
sig=struct('Version','09.02.1','Source',stamp(source),'Code',fileread([mfilename('fullpath') '.m']));
if isfile(out)
 z=load(out,'Context');
 if isequaln(z.Context.Signature,sig) && all(isfile(z.Context.Partitions.Path))
  Context=z.Context;fprintf('Context cache reused. Upload %s\n',Context.ReportZIP);return;
 end
end
selfTest;
% One row per reconstructed innings; initial metadata and terminal score.
I=table;
for k=1:height(R.Partitions)
 z=load(R.Partitions.Path(k),'States');S=z.States;
 a=S(S.StateType=="initial",:); t=S(S.StateType=="terminal",:);
 assert(isequal(a.MatchID,t.MatchID)&&isequal(a.InningsIndex,t.InningsIndex),'Innings pairing failed.');
 opponent=a.Team1;v=a.BattingTeam==a.Team1;opponent(v)=a.Team2(v);
 validOpponent=a.BattingTeam==a.Team1 | a.BattingTeam==a.Team2;
 opponent(~validOpponent)="";
 primary=false(height(a),1);
 for j=1:height(a)
  primary(j)=any(S.PrimaryEligibleObservation & S.MatchID==a.MatchID(j) & S.InningsIndex==a.InningsIndex(j));
 end
 B=table(a.MatchID,a.InningsIndex,a.Format,a.MatchDate,a.Split,a.CaseReserved, ...
  a.BattingTeam,opponent,a.Venue,a.EventName,primary,t.FinalDeliveryRuns, ...
  'VariableNames',{'MatchID','InningsIndex','Format','Date','Split','CaseReserved', ...
  'BattingTeam','Opponent','Venue','EventName','Primary','HistoricalTotal'});
 I=[I;B]; %#ok<AGROW>
 fprintf('Context inventory %d/%d\n',k,height(R.Partitions));
end
keys=I.MatchID+"|"+string(I.InningsIndex);assert(numel(unique(keys))==height(I),'Duplicate innings.');
assert(isdatetime(I.Date),'MatchDate must be datetime from corrected cache.');
I.Date=dateshift(I.Date,'start','day');
H=I(I.Primary & I.Split=="train" & ~I.CaseReserved & ~isnat(I.Date),:);
assert(all(year(H.Date)<2023),'Unexpected training history dates.');
assert(all(isfinite(H.HistoricalTotal) & H.HistoricalTotal>=0),'Invalid training historical totals.');
% Shrinkage strength is a declared candidate hyperparameter, NOT fitted here.
% These raw context features are exploratory; tune strength on development
% only and compare with models that exclude historical outcomes completely.
strength=20; priorODI=250;priorT20=150;
n=height(I); names={'HistoryFormatMean','HistoryBattingMean','HistoryOpponentMean', ...
 'HistoryVenueMean','HistoryEventMean','HistoryFormatN','HistoryBattingN', ...
 'HistoryOpponentN','HistoryVenueN','HistoryEventN'};
for v=names,I.(v{1})=nan(n,1);end
I.HistoryMaxSourceDate=NaT(n,1); I.HistoryMissingDate=isnat(I.Date);
for j=1:n
 if isnat(I.Date(j)),continue;end
 h=H(H.Format==I.Format(j) & H.Date<I.Date(j),:);
 prior=priorT20;if I.Format(j)=="ODI",prior=priorODI;end
 if isempty(h),base=prior;else,base=mean(h.HistoricalTotal);I.HistoryMaxSourceDate(j)=max(h.Date);end
 I.HistoryFormatMean(j)=base;I.HistoryFormatN(j)=height(h);
 mask={h.BattingTeam==I.BattingTeam(j),h.Opponent==I.Opponent(j), ...
  h.Venue==I.Venue(j),h.EventName==I.EventName(j)};
 values=[I.BattingTeam(j),I.Opponent(j),I.Venue(j),I.EventName(j)];
 for e=1:4
  keep=mask{e};if ismissing(values(e))||strlength(strtrim(values(e)))==0,keep(:)=false;end
  count=nnz(keep);mu=(sum(h.HistoricalTotal(keep))+strength*base)/(count+strength);
  I.(names{e+1})(j)=mu;I.(names{e+6})(j)=count;
 end
 if mod(j,1000)==0,fprintf('Chronological histories %d/%d\n',j,n);end
end
assert(all(isnat(I.HistoryMaxSourceDate) | I.HistoryMaxSourceDate<I.Date),'Future history leakage.');
% Do not export future historical totals in the match-feature ledger.
Ledger=removevars(I,'HistoricalTotal');
writetable(Ledger,fullfile(root,'09_02_InningsContextLedger.csv'));
generation=fullfile(root,['features_' char(datetime('now','Format','yyyyMMdd_HHmmss_SSS'))]);mkdir(generation);
P=table(strings(0,1),zeros(0,1),'VariableNames',{'Path','Rows'});
Coverage=table;total=0;
for k=1:height(R.Partitions)
 z=load(R.Partitions.Path(k),'States');S=z.States;
 [found,ii]=ismember(S.MatchID+"|"+string(S.InningsIndex),keys);assert(all(found),'Missing context key.');
 Features=S(:,{'MatchID','InningsIndex','DeliverySeq','StateType','Format','Split', ...
 'TrainingFold','CaseReserved','PrimaryEligibleObservation','PrimaryFitObservation'});
 Features.BallsRemaining=S.BallsRemaining;Features.WicketsInHand=S.WicketsInHand;
 horizon=120*ones(height(S),1);horizon(S.Format=="ODI")=300;
 Features.ElapsedFraction=S.LegalBallsBowled./horizon;
 Features.ScoreBefore=S.DeliveryScoreBefore;
 Features.LegalBallsSinceDismissal=S.LegalBallsSinceDismissal;
 Features.NoDismissalYet=S.NoDismissalYet;
 Features.RetiredNotOutEventsBefore=zeros(height(S),1);
 first=find(S.StateType=="initial");last=find(S.StateType=="terminal");
 for j=1:numel(first)
  rows=(first(j):last(j))';events=S.RetiredNotOutEvents(rows);
  Features.RetiredNotOutEventsBefore(rows)=[0;cumsum(events(1:end-1))];
 end
 Features.RunRateBefore=nan(height(S),1);v=S.LegalBallsBowled>0;
 Features.RunRateBefore(v)=6*S.DeliveryScoreBefore(v)./S.LegalBallsBowled(v);
 Features.NoLegalBallYet=~v;
 [recent,balls]=recentRuns(S,30);
 Features.Recent30Runs=recent;Features.Recent30LegalBalls=balls;
 Features.Recent30RunRate=nan(height(S),1);v=balls>0;
 Features.Recent30RunRate(v)=6*recent(v)./balls(v);
 Features.Opponent=I.Opponent(ii);Features.BattingTeam=S.BattingTeam;
 Features.Venue=S.Venue;Features.EventName=S.EventName;
 for v=names,Features.(v{1})=I.(v{1})(ii);end
 Features.HistoryMissingDate=I.HistoryMissingDate(ii);
 Features.OpponentIdentityMissing=ismissing(Features.Opponent) | strlength(Features.Opponent)==0;
 assert(~any(contains(Features.Properties.VariableNames,{'Final','Future','RemainingRuns','ObservedFraction'})), ...
  'Outcome field in predictor table.');
 path=fullfile(generation,sprintf('09_Context_Part%04d.mat',k));save(path,'Features','-v7.3');
 P=[P;table(string(path),height(Features),'VariableNames',P.Properties.VariableNames)]; %#ok<AGROW>
 q=Features(Features.PrimaryEligibleObservation,:);
 for f=["ODI","T20"]
  for split=["train","validation","test"]
   b=q(q.Format==f & q.Split==split,:);
   row=table(f,split,height(b),nnz(b.HistoryFormatN==0),nnz(b.HistoryBattingN==0), ...
    nnz(b.HistoryOpponentN==0),nnz(b.HistoryVenueN==0),nnz(b.HistoryEventN==0), ...
    nnz(b.HistoryMissingDate),'VariableNames',{'Format','Split','States','NoFormatHistory', ...
    'NoBattingHistory','NoOpponentHistory','NoVenueHistory','NoEventHistory','MissingDate'});
   Coverage=[Coverage;row]; %#ok<AGROW>
  end
 end
 total=total+height(S);fprintf('Context partitions %d/%d\n',k,height(R.Partitions));
end
assert(total==sum(R.Partitions.States),'Context/source row count differs.');
Coverage=groupsummary(Coverage,{'Format','Split'},'sum',Coverage.Properties.VariableNames(3:end));
Coverage=removevars(Coverage,'GroupCount');Coverage.Properties.VariableNames=erase(Coverage.Properties.VariableNames,'sum_');
Dictionary=definitions;
Audit=table(["SourceStates";"ContextStates";"HistorySourceInnings";"ReservedHistorySources"; ...
 "ValidationTestHistorySources";"HistoryDateViolations";"ShrinkagePseudoInnings";"InitialODIPrior";"InitialT20Prior"], ...
 [sum(R.Partitions.States);total;height(H);nnz(H.CaseReserved);nnz(H.Split~="train"); ...
 nnz(~isnat(I.HistoryMaxSourceDate)&I.HistoryMaxSourceDate>=I.Date);strength;priorODI;priorT20], ...
 'VariableNames',{'Metric','Value'});
writetable(Audit,fullfile(root,'09_02_QC_Summary.csv'));writetable(Coverage,fullfile(root,'09_02_ContextCoverage.csv'));
writetable(Dictionary,fullfile(root,'09_02_FeatureDictionary.csv'));writetable(P,fullfile(root,'09_02_PartitionManifest.csv'));
publication(cfg,Coverage,Dictionary);
reportZIP=fullfile(cfg.ProjectRoot,'RevisedCodes_09_02_Checks.zip');
zip(reportZIP,{'09_02_QC_Summary.csv','09_02_ContextCoverage.csv','09_02_FeatureDictionary.csv', ...
 '09_02_InningsContextLedger.csv','09_02_PartitionManifest.csv'},root);
Context=struct('Signature',sig,'Partitions',P,'SourcePartitions',R.Partitions, ...
 'HistoricalPolicy','primary-training-only, strict earlier calendar date, no case updates', ...
 'ShrinkagePseudoInnings',strength,'InitialPriorODI',priorODI,'InitialPriorT20',priorT20, ...
 'Coverage',Coverage,'ReportZIP',reportZIP);
save(out,'Context','-v7.3');disp(Audit);fprintf('COMPLETE. Upload %s\n',reportZIP);
end
function [r,b]=recentRuns(S,L)
r=zeros(height(S),1);b=r;
starts=find(S.StateType=="initial");ends=find(S.StateType=="terminal");
assert(numel(starts)==numel(ends),'Incomplete innings.');
for j=1:numel(starts)
 rows=(starts(j):ends(j))';d=rows(S.StateType(rows)=="delivery");
 legal=S.CorrectedIsLegalBall(d);runs=S.DeliveryRuns(d);
 % Boundary immediately AFTER each completed legal delivery. Subsequent
 % illegal-delivery runs belong to the next legal-ball interval.
 boundary=[0;cumsum(runs)];legalEnd=find(legal==1);
 for k=rows'
  done=S.LegalBallsBowled(k);b(k)=min(L,done);cut=done-b(k);base=0;
  if cut>0,base=boundary(legalEnd(cut)+1);end
  r(k)=S.DeliveryScoreBefore(k)-base;
 end
end
assert(all(r>=0 & b>=0 & b<=L),'Invalid recent scoring window.');
end
function D=definitions
D=table(["u,w";"RetiredNotOutEventsBefore";"ElapsedFraction";"ScoreBefore / RunRateBefore";"Recent30Runs / Recent30RunRate"; ...
 "LegalBallsSinceDismissal";"HistoryFormatMean";"HistoryBattingMean";"HistoryOpponentMean"; ...
 "HistoryVenueMean / HistoryEventMean";"History*N / missing flags";"Identity fields"], ...
 ["Resource core; u only when allocation verified";"Cumulative pre-state retired-not-out events; does not establish whether a player can return";"Legal balls bowled divided by nominal format length; redundant with u in standard innings"; ...
 "Pre-state delivery runs; rate per six legal balls, missing before first legal ball"; ...
 "Pre-state runs after boundary 30 legal balls earlier; includes intervening extras; shorter initial window"; ...
 "Pre-state legal balls since genuine dismissal, no retirement reset"; ...
 "Mean total of earlier-date primary training innings in same format; initial prior 250 ODI / 150 T20"; ...
 "Earlier-date batting-team totals shrunk towards format mean with 20 pseudo-innings"; ...
 "Earlier-date totals conceded by opponent, same shrinkage; not an official strength ranking"; ...
 "Earlier-date same-label venue/event totals, same shrinkage; labels are not geographically canonicalized"; ...
 "Support counts and missingness permit training-fitted imputation and unsupported-context diagnostics"; ...
 "Raw identities available for provenance; any fitted encoding must use development data only"], ...
 ["Resource and forecast";"Availability diagnostic; requires later return-event audit";"Forecast; optional resource shape";"Conditional forecast, not automatic target adjustment"; ...
 "Conditional forecast, not automatic target adjustment";"Candidate forecast and resource shape"; ...
 "Historical scoring proxy";"Historical scoring proxy";"Historical scoring proxy"; ...
 "Historical scoring proxy";"Diagnostics / predictor candidates";"Provenance / later encoding"], ...
 'VariableNames',{'Feature','Construction','Role'});
end
function publication(cfg,C,D)
root=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady');
mt=fullfile(root,'Methodology','Tables');mf=fullfile(root,'Methodology','Figures');
for p=string({mt,mf}),if ~isfolder(p),mkdir(p);end,end
writetable(D,fullfile(mt,'T_M05_ContextDefinitions.csv'));writetable(C,fullfile(mt,'T_M06_ContextSupport.csv'));
writetable(D,fullfile(root,'09_02_PublicationTables.xlsx'),'Sheet','Definitions');
writetable(C,fullfile(root,'09_02_PublicationTables.xlsx'),'Sheet','Support');
fig=figure('Color','w','Position',[100 100 1200 760],'Visible','off');cleanup=onCleanup(@()close(fig)); %#ok<NASGU>
tiledlayout(2,2,'TileSpacing','compact','Padding','compact');
fields={'NoBattingHistory','NoOpponentHistory','NoVenueHistory','NoEventHistory'};
labels={'Batting team','Opponent','Venue','Event'};
for k=1:4
 nexttile;values=100*C.(fields{k})./max(C.States,1);bar(values,'FaceColor',[0.15 .4 .65]);
 xticks(1:height(C));xticklabels(C.Format+" "+C.Split);xtickangle(30);ylim([0 100]);
 ylabel('States without matched history (%)');title(sprintf('(%c) %s',64+k,labels{k}));
 set(gca,'FontName','Times New Roman','FontSize',10,'Box','off');grid on;
end
file=fullfile(mf,'F_M03_ContextSupport');exportgraphics(fig,[file '.png'],'Resolution',600);
exportgraphics(fig,[file '.pdf'],'ContentType','vector');savefig(fig,[file '.fig']);
Caption=table("F_M03_ContextSupport", ...
 "Percentage of primary legal-delivery states without prior matched training history. Panels show batting team, opponent, venue and event. Earlier calendar dates only; validation, test and reserved cases never update histories. Unsupported groups use format-level shrinkage, not measured group strength. Counts are state weighted and not independent matches.", ...
 'VariableNames',{'File','Caption'});writetable(Caption,fullfile(root,'09_02_PublicationIndex.csv'));
end
function d=stamp(p)
f=dir(p);d=struct('Path',string(p),'Bytes',f.bytes,'Modified',f.datenum);
end
function selfTest
% Illegal runs and current-delivery runs must not enter their own predictor.
S=table(["initial";"delivery";"delivery";"delivery";"delivery";"terminal"], ...
 [0;0;0;1;2;3],[0;0;2;6;7;10],[0;0;1;1;1;0],[0;2;4;1;3;0], ...
 'VariableNames',{'StateType','LegalBallsBowled','DeliveryScoreBefore','CorrectedIsLegalBall','DeliveryRuns'});
[r,b]=recentRuns(S,2);assert(isequal(r,[0;0;2;6;7;4])&&isequal(b,[0;0;0;1;2;2]),'Recent-window self-test failed.');
d=datetime(2022,1,[1;1;2]);assert(nnz(d<d(3))==2 && nnz(d<d(1))==0,'Date isolation self-test failed.');
fprintf('Context preflight passed.\n');
end
