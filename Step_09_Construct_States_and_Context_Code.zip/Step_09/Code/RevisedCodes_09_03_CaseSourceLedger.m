function Cases=RevisedCodes_09_03_CaseSourceLedger(settings)
% Register supplied cases, source review, interruptions and contradictions.
% Does NOT invent interruptions, fetch scorecards, fit models or score targets.
% Blank source evidence stays unresolved. Outputs are usable for Step20 only
% when their documented source-review and consistency gates pass.
if nargin<1,settings=struct;end
cfg=RevisedCodes_09_00_Config;U=RevisedCodes_09_Utils;
root=fullfile(cfg.OutputRoot,'case_ledger');input=fullfile(root,'inputs');U.Ensure(input);
o=U.Options(struct('CandidateCSV',fullfile(input,'09_03_Candidates.csv'), ...
 'EventCSV',fullfile(input,'09_03_Events.csv'),'SourceCSV',fullfile(input,'09_03_Sources.csv'), ...
 'EvidenceCSV',fullfile(input,'09_03_CaseEvidence.csv'),'ForceRebuild',false),settings);
prereq=fullfile(cfg.PrerequisiteRoot,'RevisedCodes_Step8A_Result.mat');
assert(isfile(prereq),'Step8A prerequisite manifest missing.');
z=load(prereq,'Check');M=z.Check.Manifest;M.MatchID=string(M.MatchID);
[I,source]=U.Inventory(cfg);z=load(source,'Result');R=z.Result;
createInputs(o,M,cfg,U);
paths=[string(prereq);string(source);R.Partitions.Path; ...
 string(R.Signature.Delivery.Path);string(R.Signature.Corrections.Path); ...
 string(o.CandidateCSV);string(o.EventCSV);string(o.SourceCSV);string(o.EvidenceCSV)];
sig=U.Signature('09.03.1',o,paths,[mfilename('fullpath') '.m']);
out=fullfile(root,'RevisedCodes_09_03_Result.mat');
if ~o.ForceRebuild&&U.CacheValid(out,'Cases',sig)
 z=load(out,'Cases');Cases=z.Cases;fprintf('09_03 cache reused. Upload %s\n',Cases.ReportZIP);return;
end
[g,report]=U.Generation(root);selfTest(U);
C=loadInput(o.CandidateCSV,candidateNames,U);
E=loadInput(o.EventCSV,eventNames,U);
S=loadInput(o.SourceCSV,sourceNames,U);
V=loadInput(o.EvidenceCSV,evidenceNames,U);
assert(height(C)>0&&all(U.HasText(C.CaseID))&&numel(unique(C.CaseID))==height(C),'Empty registry or duplicate/blank CaseID.');
assert(numel(unique(S.SourceID))==height(S)&&all(U.HasText(S.SourceID)),'Duplicate/blank source IDs.');
assert(numel(unique(V.CaseID))==height(V)&&all(ismember(V.CaseID,C.CaseID)), ...
 'Evidence CaseID duplicated or not registered.');
assert(all(ismember(E.CaseID,C.CaseID)),'Event case not registered.');
% Dates are parsed only if supplied; original string values remain preserved.
U.Date(C.SuppliedDate);U.Date(V.VerifiedDate);U.Date(S.ReviewDate);
L=C;L.ResolvedMatchID=C.MatchID;L.IdentityStatus=repmat("unresolved",height(C),1);
L.SourceReviewComplete=false(height(C),1);L.TimelineValid=false(height(C),1);
L.RawInningsAvailable=zeros(height(C),1);L.RawReserved=false(height(C),1);
L.EvaluationEligible=false(height(C),1);L.Reason=strings(height(C),1);
L.VerifiedPar=nan(height(C),1);L.VerifiedWinTarget=nan(height(C),1);
L.BenchmarkMethod=strings(height(C),1);L.BenchmarkVersion=strings(height(C),1);
Issues=table(strings(0,1),strings(0,1),strings(0,1),strings(0,1), ...
 'VariableNames',{'CaseID','Level','Field','Reason'});
E.InningsIndex=number(E.InningsIndex);E.EventOrder=number(E.EventOrder);
E.LegalBallsBowled=number(E.LegalBallsBowled);E.Score=number(E.Score);
E.WicketsLost=number(E.WicketsLost);E.AllocationBefore=number(E.AllocationBefore);
E.AllocationAfter=number(E.AllocationAfter);
E.RemainingBefore=nan(height(E),1);E.RemainingAfter=nan(height(E),1);
E.SourceReviewed=U.SourceOK(E.SourceID,S)&E.VerificationStatus=="reviewed";
E.RawCheckpointStatus=repmat("not_available",height(E),1);
E.ConsistencyStatus=repmat("unresolved",height(E),1);E.Issue=strings(height(E),1);
for j=1:height(C)
 id=C.CaseID(j);vi=find(V.CaseID==id);mi=find(M.MatchID==C.MatchID(j));
 if numel(mi)>1,error('Duplicate match ID in prerequisite manifest.');end
 if isempty(mi)&&numel(vi)==1
  v=V(vi,:);date=U.Date(v.VerifiedDate);
  teams=(M.Team1==v.VerifiedTeam1&M.Team2==v.VerifiedTeam2)| ...
   (M.Team1==v.VerifiedTeam2&M.Team2==v.VerifiedTeam1);
  mi=find(teams&dateshift(M.StartDate,'start','day')==date&M.FormatFamily==v.VerifiedFormat);
  if numel(mi)>1,mi=[];end % ambiguous identity is unresolved, never picked.
  if numel(mi)==1,L.ResolvedMatchID(j)=M.MatchID(mi);end
 end
 if numel(mi)==1
  L.IdentityStatus(j)="matched_not_source_verified";L.RawReserved(j)=M.CaseStudyReserved(mi);
 end
 raw=I(I.MatchID==L.ResolvedMatchID(j)&I.InningsIndex<=2,:);
 L.RawInningsAvailable(j)=height(raw);
 if isempty(vi)
  L.Reason(j)="Independent identity, score, allocation and convention evidence required";
  Issues=issue(Issues,id,"pending","SourceEvidence",L.Reason(j));
  continue;
 end
 v=V(vi,:);date=U.Date(v.VerifiedDate);
 sourceIDs=[v.IdentitySourceID,v.ScoreSourceID,v.AllocationSourceID,v.ConventionSourceID,v.PenaltySourceID];
 reviewed=all(U.SourceOK(sourceIDs,S))&&all([v.IdentityStatus,v.FinalScoresStatus, ...
  v.AllocationStatus,v.TimelineStatus,v.ConventionStatus,v.PenaltyStatus]=="reviewed");
 identity=~isnat(date)&&U.HasText(v.VerifiedTeam1)&&U.HasText(v.VerifiedTeam2)&& ...
  ismember(v.VerifiedFormat,["ODI","T20"]);
 if numel(mi)==1
  identity=identity&&dateshift(M.StartDate(mi),'start','day')==date&& ...
   M.FormatFamily(mi)==v.VerifiedFormat&& ...
   ((M.Team1(mi)==v.VerifiedTeam1&&M.Team2(mi)==v.VerifiedTeam2)|| ...
    (M.Team1(mi)==v.VerifiedTeam2&&M.Team2(mi)==v.VerifiedTeam1));
 else
  identity=false; % newly located cases require explicit reservation upstream.
 end
 if identity&&v.IdentityStatus=="reviewed"&&U.SourceOK(v.IdentitySourceID,S)
  L.IdentityStatus(j)="source_reviewed_identity";
 end
 L.VerifiedPar(j)=number(v.PublishedPar);L.VerifiedWinTarget(j)=number(v.PublishedWinTarget);
 L.BenchmarkMethod(j)=v.BenchmarkMethod;L.BenchmarkVersion(j)=v.BenchmarkVersion;
 convention=integerOrNaN(L.VerifiedPar(j))&&integerOrNaN(L.VerifiedWinTarget(j))&& ...
  isfinite(L.VerifiedWinTarget(j))&&U.HasText(v.BenchmarkMethod)&&U.HasText(v.ConventionNotes);
 % Benchmark tie/win conventions are source-specific; no universal difference
 % of one is imposed on historical methods. Record the cited convention.
 scores=number([v.FirstInningsScore,v.SecondInningsScore]);
 penalties=number([v.PenaltyPre1,v.PenaltyPost1,v.PenaltyPre2,v.PenaltyPost2]);
 scoreOK=all(isfinite(scores)&scores>=0&scores==floor(scores))&& ...
  all(isfinite(penalties)&penalties>=0&penalties==floor(penalties));
 allocations=number([v.InitialAllocation1,v.InitialAllocation2]);
 horizon=120;if v.VerifiedFormat=="ODI",horizon=300;end
 allocationOK=all(isfinite(allocations)&allocations>0&allocations<=horizon&allocations==floor(allocations));
 rawOK=true;
 for innings=1:2
  a=raw(raw.InningsIndex==innings,:);
  if isempty(a),continue;end
  if ~a.ReconstructionPassed
   rawOK=false;Issues=issue(Issues,id,"invalid","CachedIntegrity", ...
    "Cached innings reconstruction is unresolved; source reconciliation required");
  end
  expected=a.FinalScoreboard;if v.ScoreBasis=="delivery",expected=a.FinalDeliveryRuns;end
  if ~ismember(v.ScoreBasis,["scoreboard","delivery"]),rawOK=false;end
  if expected~=scores(innings)
   rawOK=false;Issues=issue(Issues,id,"invalid","FinalScore", ...
    "Verified score contradicts cached final score under the declared score basis");
  end
 end
 erows=find(E.CaseID==id);timeline=~isempty(erows);
 if timeline
  [events,eventOK]=checkTimeline(E(erows,:),allocations,U);
  for innings=1:2
   rr=find(events.InningsIndex==innings);
   if isempty(rr),eventOK=false;continue;end
   [~,p]=max(events.EventOrder(rr));last=rr(p);
   if events.Score(last)~=scores(innings)||any(events.ScoreBasis(rr)~=v.ScoreBasis)
    eventOK=false;events.ConsistencyStatus(last)="invalid";
    events.Issue(last)=events.Issue(last)+"; ending score/basis differs from verified final score";
   end
   rawEnd=raw(raw.InningsIndex==innings,:);
   if ~isempty(rawEnd)&&events.LegalBallsBowled(last)~=rawEnd.LegalBalls
    eventOK=false;events.ConsistencyStatus(last)="invalid";
    events.Issue(last)=events.Issue(last)+"; ending legal balls differ from cached innings end";
   end
  end
  % Verify event score/wicket checkpoints against all corresponding pre-state
  % and terminal rows where reconstruction is present. Missing raw coverage
  % stays visible; independent sources may still establish the event.
  for p=1:height(events)
   a=raw(raw.InningsIndex==events.InningsIndex(p),:);
   if isempty(a),continue;end
   z=load(R.Partitions.Path(a.Partition),'States');SS=z.States;
   SS=SS(a.InitialRow:a.TerminalRow,:);
   if events.ScoreBasis(p)=="scoreboard",value=SS.ScoreboardBefore;
   elseif events.ScoreBasis(p)=="delivery",value=SS.DeliveryScoreBefore;
   else,value=nan(height(SS),1);end
   hit=SS.LegalBallsBowled==events.LegalBallsBowled(p)&value==events.Score(p)& ...
    SS.GenuineWicketsLost==events.WicketsLost(p);
   if any(hit),events.RawCheckpointStatus(p)="compatible";
   else
    events.RawCheckpointStatus(p)="contradiction";eventOK=false;
    events.ConsistencyStatus(p)="invalid";
    events.Issue(p)=events.Issue(p)+"; no compatible cached checkpoint";
   end
  end
  E(erows,:)=events;timeline=eventOK;
 end
 L.SourceReviewComplete(j)=reviewed;L.TimelineValid(j)=timeline;
 L.EvaluationEligible(j)=reviewed&&identity&&convention&&scoreOK&&allocationOK&& ...
  rawOK&&timeline&&L.RawReserved(j);
 if L.EvaluationEligible(j),L.Reason(j)="Source-reviewed and computational consistency gates passed";
 else
  reasons=strings(0,1);
  if ~reviewed,reasons(end+1)="source review incomplete";end
  if ~identity,reasons(end+1)="identity unresolved or contradictory";end
  if ~L.RawReserved(j),reasons(end+1)="not reserved upstream; do not fit or evaluate";end
  if ~convention,reasons(end+1)="published target/convention incomplete";end
  if ~scoreOK,reasons(end+1)="scores/penalties incomplete";end
  if ~allocationOK,reasons(end+1)="allocations incomplete or out of scope";end
  if ~rawOK,reasons(end+1)="final-score contradiction";end
  if ~timeline,reasons(end+1)="timeline incomplete or inconsistent";end
  L.Reason(j)=join(reasons,'; ');Issues=issue(Issues,id,"pending_or_invalid","CaseGate",L.Reason(j));
 end
 supplied=[number(C.SuppliedPar(j)),number(C.SuppliedWinTarget(j))];
 verified=[L.VerifiedPar(j),L.VerifiedWinTarget(j)];fields=["Par","WinTarget"];
 for p=1:2
  if isfinite(supplied(p))&&isfinite(verified(p))&&supplied(p)~=verified(p)
   Issues=issue(Issues,id,"discrepancy",fields(p), ...
    "Supplied "+supplied(p)+"; source-reviewed "+verified(p)+". Both retained.");
  end
 end
 if U.HasText(C.SuppliedDate(j))&&U.Date(C.SuppliedDate(j))~=date
  Issues=issue(Issues,id,"discrepancy","Date","Supplied and source-reviewed dates differ");
 end
end
% All input columns, including any extra supplied notes, remain in snapshots.
writetable(C,fullfile(report,'09_03_CandidateSnapshot.csv'));
writetable(V,fullfile(report,'09_03_EvidenceSnapshot.csv'));
writetable(S,fullfile(report,'09_03_SourceRegister.csv'));
writetable(L,fullfile(report,'09_03_CaseLedger.csv'));
writetable(E,fullfile(report,'09_03_InterruptionTimeline.csv'));
writetable(Issues,fullfile(report,'09_03_DiscrepanciesAndPending.csv'));
QC=table(["RegisteredCandidates";"ExpectedSuppliedCandidates";"ReservedMatchedCandidates"; ...
 "SourceReviewedIdentities";"EvaluationEligibleCases";"UnresolvedOrInvalidCases";"RegisteredSources"], ...
 [height(C);40;nnz(L.RawReserved);nnz(L.IdentityStatus=="source_reviewed_identity"); ...
 nnz(L.EvaluationEligible);nnz(~L.EvaluationEligible);height(S)],'VariableNames',{'Metric','Value'});
writetable(QC,fullfile(report,'09_03_QC_Summary.csv'));
summary=[panel(1,["Registered","Reserved","Unreserved"],[height(C),nnz(L.RawReserved),nnz(~L.RawReserved)],"Candidate coverage"); ...
 panel(2,["Matched","Source reviewed"],[nnz(L.IdentityStatus~="unresolved"),nnz(L.IdentityStatus=="source_reviewed_identity")],"Identity evidence"); ...
 panel(3,["Eligible","Pending/invalid"],[nnz(L.EvaluationEligible),nnz(~L.EvaluationEligible)],"Case evaluation gate"); ...
 panel(4,["Events","Source reviewed","Raw contradictions"],[height(E),nnz(E.SourceReviewed),nnz(E.RawCheckpointStatus=="contradiction")],"Interruption evidence")];
tables=struct('Name',{"T_M10_CaseVerificationCoverage","T_S09_03_CaseSources","T_S09_03_InterruptionLedger", ...
 'T_S09_03_CaseDiscrepancies'},'Data',{QC,L,E,Issues},'Main',{true,false,false,false});
pub=U.Publish(cfg,"09_03",tables,summary, ...
 "Case-source readiness and interruption coverage. Identity reservation is separate from source-reviewed scores, allocations, timelines and target conventions. Pending cases are excluded from evaluation. No model targets or benchmark performance are calculated.",report);
Cases=struct('Stage',"09_03",'Status',"SOURCE_REVIEW_PENDING",'Ledger',L,'Events',E, ...
 'Sources',S,'Evidence',V,'Issues',Issues,'InputPaths',[string(o.CandidateCSV);string(o.EventCSV);string(o.SourceCSV);string(o.EvidenceCSV)]);
if all(L.EvaluationEligible),Cases.Status="ALL_REGISTERED_CASES_READY";
elseif any(L.EvaluationEligible),Cases.Status="VERIFIED_SUBSET_READY_OTHERS_PENDING";end
Cases=U.Finish(cfg,'Cases',out,sig,g,report,Cases,pub);
end

function names=candidateNames
names=["CaseID","MatchID","SuppliedDescription","SuppliedDate","SuppliedTeam1", ...
 "SuppliedTeam2","SuppliedFormat","SuppliedPar","SuppliedWinTarget","CandidateProvenance","Notes"];
end
function names=eventNames
names=["CaseID","InningsIndex","EventOrder","EventType","LegalBallsBowled","Score", ...
 "WicketsLost","AllocationBefore","AllocationAfter","ScoreBasis","SourceID","VerificationStatus","Notes"];
end
function names=sourceNames
names=["SourceID","URL","Title","Publisher","SourceType","ReviewDate","ReviewStatus","EvidenceExcerpt","Notes"];
end
function names=evidenceNames
names=["CaseID","VerifiedDate","VerifiedTeam1","VerifiedTeam2","VerifiedFormat", ...
 "FirstInningsScore","SecondInningsScore","ScoreBasis","InitialAllocation1","InitialAllocation2", ...
 "PenaltyPre1","PenaltyPost1","PenaltyPre2","PenaltyPost2","PublishedPar","PublishedWinTarget", ...
 "BenchmarkMethod","BenchmarkVersion","ConventionNotes","IdentityStatus","FinalScoresStatus", ...
 "AllocationStatus","TimelineStatus","ConventionStatus","PenaltyStatus", ...
 "IdentitySourceID","ScoreSourceID","AllocationSourceID","ConventionSourceID","PenaltySourceID","Notes"];
end
function T=blank(names,n)
T=array2table(strings(n,numel(names)),'VariableNames',cellstr(names));
end
function T=loadInput(p,names,U)
T=U.Read(p,names);assert(all(ismember(names,string(T.Properties.VariableNames))), ...
 'CSV schema incomplete: %s',p);
for n=names,T.(n)=string(T.(n));T.(n)(ismissing(T.(n)))="";end
end
function createInputs(o,M,cfg,U)
if ~isfile(o.CandidateCSV)
 a=find(M.CaseStudyReserved);C=blank(candidateNames,numel(a));
 C.CaseID="CASE_"+M.MatchID(a);C.MatchID=M.MatchID(a);
 C.SuppliedDescription=M.Team1(a)+" vs "+M.Team2(a)+"; "+M.FormatFamily(a);
 C.SuppliedDate=string(M.StartDate(a),'yyyy-MM-dd');C.SuppliedDate(isnat(M.StartDate(a)))="";
 C.SuppliedTeam1=M.Team1(a);C.SuppliedTeam2=M.Team2(a);C.SuppliedFormat=M.FormatFamily(a);
 C.CandidateProvenance(:)="Step8A reserved identity; original case-document values not yet imported";
 p=fullfile(cfg.PrerequisiteRoot,'tables','Step8A_UnmatchedCaseDescriptions.csv');
 assert(isfile(p),'Unmatched-case descriptions missing. Restore Step8A reports.');
 T=U.Read(p,["Case","Action"]);B=blank(candidateNames,height(T));
 B.CaseID="UNMATCHED_"+compose('%02d',(1:height(T))');B.SuppliedDescription=T.Case;
 B.CandidateProvenance(:)="Step8A supplied unmatched description; identity unverified";B.Notes=T.Action;
 C=[C;B];ensureParent(o.CandidateCSV,U);writetable(C,o.CandidateCSV);
end
paths={o.EventCSV,o.SourceCSV,o.EvidenceCSV};schemas={eventNames,sourceNames,evidenceNames};
for j=1:3
 if ~isfile(paths{j}),ensureParent(paths{j},U);writetable(blank(schemas{j},0),paths{j});end
end
end
function ensureParent(p,U)
parent=fileparts(p);if ~isempty(parent),U.Ensure(parent);end
end
function n=number(s)
s=string(s);n=str2double(s);bad=strlength(strtrim(s))>0&isnan(n);
assert(~any(bad),'Non-numeric supplied value; retain explanation in Notes, not numeric fields.');
end
function yes=integerOrNaN(x)
yes=isnan(x)||(isfinite(x)&&x>=0&&x==floor(x));
end
function [E,okay]=checkTimeline(E,initial,U)
okay=true;
% Validate event orders before sorting. Input event order may be interleaved.
for innings=1:2
 r=find(E.InningsIndex==innings);[~,sorter]=sort(E.EventOrder(r));r=r(sorter);
 if isempty(r),okay=false;continue;end
 orders=E.EventOrder(r);
 if ~isequal(orders,(1:numel(r))'),okay=false;E.Issue(r)="Event order must be consecutive from 1";end
 allocation=initial(innings);lastBalls=0;lastScore=0;lastWickets=0;ended=false;
 for p=1:numel(r)
  k=r(p);e=E(k,:);problem=strings(0,1);
  values=[e.LegalBallsBowled,e.Score,e.WicketsLost,e.AllocationBefore,e.AllocationAfter];
  if any(~isfinite(values)|values<0|values~=floor(values)),problem(end+1)="missing/invalid integer event values";end
  if e.WicketsLost>10,problem(end+1)="wickets exceed ten";end
  if ~ismember(e.ScoreBasis,["scoreboard","delivery"]),problem(end+1)="score basis missing";end
  if ~e.SourceReviewed,problem(end+1)="source not reviewed";end
  if ended,problem(end+1)="event after innings ending";end
  if p==1&&e.EventType~="start",problem(end+1)="first event must be start";end
  if ~isfinite(initial(innings))||initial(innings)<=0,problem(end+1)="missing initial allocation";end
  if e.AllocationBefore~=allocation,problem(end+1)="allocation chain mismatch";end
  if e.LegalBallsBowled<lastBalls||e.Score<lastScore||e.WicketsLost<lastWickets
   problem(end+1)="nonchronological balls/score/wickets";
  end
  if e.LegalBallsBowled>e.AllocationBefore,problem(end+1)="balls exceed prior allocation";end
  switch e.EventType
   case 'start'
    if p~=1||e.LegalBallsBowled~=0||e.WicketsLost~=0||e.AllocationAfter>e.AllocationBefore
     problem(end+1)="invalid start event";
    end
   case 'reduction'
    if e.AllocationAfter>e.AllocationBefore||e.AllocationAfter<e.LegalBallsBowled
     problem(end+1)="invalid allocation reduction";
    end
   case {'termination','completion'}
    if e.AllocationAfter~=e.AllocationBefore,problem(end+1)="ending event must preserve schedule; terminal capacity is separate";end
    ended=true;
   otherwise
    problem(end+1)="unknown event type";
  end
  if p>1&&e.ScoreBasis~=E.ScoreBasis(r(p-1)),problem(end+1)="mixed score bases within innings";end
  E.RemainingBefore(k)=e.AllocationBefore-e.LegalBallsBowled;
  E.RemainingAfter(k)=e.AllocationAfter-e.LegalBallsBowled;
  if e.EventType=="termination",E.RemainingAfter(k)=0;end
  if isempty(problem),E.ConsistencyStatus(k)="valid";
  else,E.ConsistencyStatus(k)="invalid";E.Issue(k)=join(problem,'; ');okay=false;end
  allocation=e.AllocationAfter;lastBalls=e.LegalBallsBowled;lastScore=e.Score;lastWickets=e.WicketsLost;
 end
 if ~ended
  okay=false;E.ConsistencyStatus(r(end))="invalid";
  E.Issue(r(end))=E.Issue(r(end))+"; missing completion/termination";
 end
end
if any(~ismember(E.InningsIndex,[1 2])),okay=false;end
if any(~U.HasText(E.CaseID)),okay=false;end
end
function T=issue(T,id,level,field,reason)
T=[T;table(id,string(level),string(field),string(reason),'VariableNames',T.Properties.VariableNames)];
end
function T=panel(p,labels,values,title)
T=table(repmat(p,numel(values),1),string(labels(:)),values(:),repmat(string(title),numel(values),1), ...
 'VariableNames',{'Panel','Label','Value','Title'});
end
function selfTest(U)
assert(isequal(U.OversToBalls(["21.3","0.0","19.5"],6),[129,0,119]),'Over conversion failed.');
failed=false;try,U.OversToBalls("21.6",6);catch,failed=true;end
assert(failed,'Invalid ball digit was accepted.');
% Complete synthetic two-innings chain, independent of real case evidence.
E=blank(eventNames,5);E.CaseID(:)="synthetic";
E.InningsIndex=[1;1;2;2;2];E.EventOrder=[1;2;1;2;3];
E.EventType=["start";"completion";"start";"reduction";"termination"];
E.LegalBallsBowled=[0;120;0;30;60];E.Score=[0;180;0;40;90];
E.WicketsLost=[0;5;0;1;2];E.AllocationBefore=[120;120;120;120;90];
E.AllocationAfter=[120;120;120;90;90];E.ScoreBasis(:)="delivery";
E.RemainingBefore=nan(5,1);E.RemainingAfter=nan(5,1);E.SourceReviewed=true(5,1);
E.RawCheckpointStatus=repmat("not_available",5,1);E.ConsistencyStatus=repmat("unresolved",5,1);E.Issue=strings(5,1);
[A,okay]=checkTimeline(E,[120,120],U);assert(okay&&A.RemainingAfter(5)==0,'Timeline self-test failed.');
E.AllocationBefore(4)=110;[~,okay]=checkTimeline(E,[120,120],U);assert(~okay,'Broken chain accepted.');
end
