function Result=RevisedCodes_09_01_BuildCorrectedStates(userConfig)
% Save BOTH 09_00 and 09_01 files in D:\VihaanProject1. Run this function.
% One streamed delivery scan; verified cached partitions reused on rerun.
% Primary data are completed first innings; auxiliary states never imply an
% uncensored future scoring response. No model fitting or test-score analysis.
% States are PRE-delivery. Initial/terminal rows are not fitting observations.
% Outcome is future delivery runs; innings-level penalties remain separate.
% For auxiliary interrupted innings, u is NaN until allocation ledgers exist.
if nargin<1, userConfig=struct; end
cfg=RevisedCodes_09_00_Config;
for name=string(fieldnames(userConfig))'
    assert(isfield(cfg,name),'Unknown configuration: %s',name);
    cfg.(name)=userConfig.(name);
end
assert(cfg.ReadSize>0 && cfg.InningsPerPartition>0,'Invalid batch settings.');
assert(isfile(cfg.DeliveryCSV),'Delivery CSV missing.');
input=fullfile(cfg.PrerequisiteRoot,'RevisedCodes_Step8A_Result.mat');
assert(isfile(input),'Run completed Step8A first.');
saved=load(input,'Check'); check=saved.Check; M=check.Manifest; A=check.InningsAudit;
assert(all(M.FirstInningsRawVerified(M.PrimaryModelEligible)), ...
    'Primary cohort is not fully raw-verified.');
assert(~any(M.CaseStudyReserved & M.Split=="train"),'Case leakage in prerequisites.');
prior=load(fullfile(check.OriginalStep8Root,'cache','Step8_DeliveryAudit.mat'),'signature');
for k=1:height(prior.signature.Source)
    source=prior.signature.Source(k,:);
    if ~source.Exists,continue;end
    d=dir(char(source.Path));
    assert(numel(d)==1 && d.bytes==source.Bytes && d.datenum==source.ModifiedDatenum, ...
        'Source changed since prerequisite verification: %s',source.Path);
end

correctionFile=fullfile(cfg.PrerequisiteRoot,'tables','Step8_DeliveryCorrections.csv');
opts=detectImportOptions(correctionFile,'Delimiter',',','VariableNamingRule','preserve');
opts.VariableNamesLine=1; opts.DataLines=[2 Inf];
opts=setvartype(opts,{'MatchID','Reason'},'string'); C=readtable(correctionFile,opts);
C.MatchID=string(C.MatchID);
assert(~any(C.NeedsReview),'Unresolved corrections need review.');
keys=string(A.MatchID)+"|"+string(A.InningsIndex);
assert(numel(unique(keys))==height(A),'Duplicate audit innings keys.');
ckeys=C.MatchID+"|"+string(C.InningsIndex)+"|"+string(C.DeliverySeqInInnings);
assert(numel(unique(ckeys))==height(C),'Duplicate correction keys.');
tab=fullfile(cfg.OutputRoot,'tables');
for p=string({cfg.OutputRoot,tab}), if ~isfolder(p),mkdir(p);end,end
code=fileread([mfilename('fullpath') '.m']);
sig=struct('Version',cfg.Version,'Delivery',fileInfo(cfg.DeliveryCSV), ...
    'Prerequisite',fileInfo(input),'Corrections',fileInfo(correctionFile), ...
    'Config',cfg,'Code',code);
completionFile=fullfile(cfg.OutputRoot,'RevisedCodes_09_Result.mat');
if ~cfg.ForceRebuild && isfile(completionFile)
    old=load(completionFile,'Result');
    if isequaln(old.Result.Signature,sig) && all(isfile(old.Result.Partitions.Path))
        Result=old.Result; fprintf('Step9 cache reused. Reports: %s\n',Result.ReportZIP);return;
    end
end
log=fullfile(cfg.OutputRoot,['RunLog_09_' char(datetime('now','Format','yyyyMMdd_HHmmss')) '.txt']);
diary(log); cleanup=onCleanup(@()diary('off')); %#ok<NASGU>
if cfg.RunSelfTests,selfTest;end
% Immutable generation folder: failed or superseded runs cannot masquerade as
% the complete cache. Completion manifest is written only after hard checks.
generation=fullfile(cfg.OutputRoot,['states_' char(datetime('now','Format','yyyyMMdd_HHmmss_SSS'))]);
mkdir(generation);
ds=tabularTextDatastore(cfg.DeliveryCSV,'Delimiter',',','TextType','string');
need={'MatchID','InningsIndex','DeliverySeqInInnings','BattingTeam','Batter', ...
    'NonStriker','Bowler','IsLegalBall','RunsOffBat','ExtrasRuns','TotalRuns','IsWicket'};
assert(all(ismember(need,ds.VariableNames)),'Required delivery columns missing.');
ds.TextscanFormats=repmat({'%q'},1,numel(ds.VariableNames));
ds.SelectedVariableNames=need;ds.ReadSize=cfg.ReadSize;
correctionsApplied=false(height(C),1); seen=false(height(A),1);
Parts=table(strings(0,1),zeros(0,1),zeros(0,1),'VariableNames',{'Path','States','Innings'});
QC=table; batch={}; pending=table; pendingKey=""; totalRows=0; skippedRows=0;
start=tic;
while hasdata(ds)
    B=read(ds); totalRows=totalRows+height(B);
    B.MatchID=strtrim(string(B.MatchID)); B.MatchID=regexprep(B.MatchID,'\.0+$','');
    bkeys=B.MatchID+"|"+string(str2double(string(B.InningsIndex)));
    starts=[1;find(bkeys(2:end)~=bkeys(1:end-1))+1]; ends=[starts(2:end)-1;height(B)];
    for g=1:numel(starts)
        rows=starts(g):ends(g); key=bkeys(starts(g));
        if strlength(pendingKey)>0 && key~=pendingKey
            [states,q,used,ai]=finish(pending,pendingKey,A,M,keys,C,ckeys);
            if ai>0
                assert(~seen(ai),'Noncontiguous innings encountered: %s',pendingKey);
                seen(ai)=true; correctionsApplied(used)=true;
                batch{end+1}=states; QC=[QC;q]; %#ok<AGROW>
            else,skippedRows=skippedRows+height(pending);end
            pending=table;
            if numel(batch)>=cfg.InningsPerPartition
                Parts=savePartition(batch,Parts,generation);batch={};
            end
        end
        pendingKey=key; pending=[pending;B(rows,:)]; %#ok<AGROW>
    end
    fprintf('Rows read %d | audited innings %d | %.1f min\n',totalRows,nnz(seen),toc(start)/60);
end
if ~isempty(pending)
    [states,q,used,ai]=finish(pending,pendingKey,A,M,keys,C,ckeys);
    if ai>0
        assert(~seen(ai),'Noncontiguous final innings.');seen(ai)=true;
        correctionsApplied(used)=true;batch{end+1}=states;QC=[QC;q];
    else,skippedRows=skippedRows+height(pending);end
end
if ~isempty(batch),Parts=savePartition(batch,Parts,generation);end
expected=M.PrimaryModelEligible(A.MatchRow)&A.InningsIndex==1;
assert(all(seen(expected)),'Some primary innings were not reconstructed.');
assert(all(QC.Passed(QC.PrimaryInnings)),'Primary reconstruction failure.');
% Corrections in excluded formats/unmatched IDs are deliberately not consumed.
caKeys=C.MatchID+"|"+string(C.InningsIndex);
[cf,ci]=ismember(caKeys,keys); required=false(height(C),1);
required(cf)=ismember(string(M.FormatFamily(A.MatchRow(ci(cf)))),["ODI","T20"]);
assert(all(correctionsApplied(required)),'Missing correction applications.');
writetable(QC,fullfile(tab,'09_InningsReconciliation.csv'));
writetable(QC(~QC.Passed,:),fullfile(tab,'09_AuxiliaryExceptions.csv'));
writetable(Parts,fullfile(tab,'09_PartitionManifest.csv'));
writetable(table(C.MatchID,C.InningsIndex,C.DeliverySeqInInnings,correctionsApplied, ...
    'VariableNames',{'MatchID','InningsIndex','DeliverySeqInInnings','Applied'}), ...
    fullfile(tab,'09_CorrectionApplications.csv'));
counts=groupsummary(QC(QC.PrimaryInnings,:),{'Format','Split'});
writetable(counts,fullfile(tab,'09_PrimaryCohortCounts.csv'));
writetable(M,fullfile(tab,'09_MatchManifest.csv'));
Summary=table(["CSVRowsRead";"StatesWritten";"InningsReconstructed"; ...
    "PrimaryInnings";"PrimaryFailures";"CorrectionsApplied"; ...
    "AuxiliaryFailedInnings";"SkippedRows";"ElapsedMinutes"], ...
    [totalRows;sum(Parts.States);height(QC);nnz(QC.PrimaryInnings); ...
    nnz(QC.PrimaryInnings & ~QC.Passed);nnz(correctionsApplied); ...
    nnz(~QC.PrimaryInnings & ~QC.Passed);skippedRows;toc(start)/60], ...
    'VariableNames',{'Metric','Value'});
writetable(Summary,fullfile(tab,'09_QC_Summary.csv'));
writetable(dictionary,fullfile(tab,'09_StateDictionary.csv'));
reportZIP=fullfile(cfg.ProjectRoot,'RevisedCodes_09_Checks.zip');
reports={'09_QC_Summary.csv','09_PrimaryCohortCounts.csv','09_InningsReconciliation.csv', ...
    '09_AuxiliaryExceptions.csv','09_CorrectionApplications.csv','09_StateDictionary.csv'};
zip(reportZIP,reports,tab);
Result=struct('Signature',sig,'Config',cfg,'Partitions',Parts,'QC',Summary, ...
    'ReportZIP',reportZIP,'StateSchemaVersion',cfg.Version);
save(completionFile,'Result','-v7.3');
disp(Summary);fprintf('STEP9 COMPLETE. Upload %s\n',reportZIP);
end

function [T,Q,used,ai]=finish(B,key,A,M,keys,C,ckeys)
[known,ai]=ismember(key,keys);T=table;Q=table;used=[];
if ~known,ai=0;return;end
a=A(ai,:);m=M(a.MatchRow,:);
if ~ismember(string(m.FormatFamily),["ODI","T20"]),ai=0;return;end
seq=str2double(string(B.DeliverySeqInInnings));
sequenceOK=isequal(seq,(1:height(B))');
assert(~a.PrimaryModelEligible || sequenceOK,'Invalid primary delivery sequence: %s',key);
legal=str2double(string(B.IsLegalBall)); runs=str2double(string(B.TotalRuns));
bat=str2double(string(B.RunsOffBat)); extras=str2double(string(B.ExtrasRuns));
genuine=str2double(string(B.IsWicket));retire=zeros(height(B),1);
dkeys=repmat(key,height(B),1)+"|"+string(seq);
[has,idx]=ismember(dkeys,ckeys);used=idx(has);
legal(has)=C.CorrectedIsLegalBall(idx(has));
genuine(has)=C.GenuineDismissalsOnDelivery(idx(has));
retire(has)=C.RetiredNotOutEvents(idx(has));
valid=sequenceOK && all(ismember(legal,[0 1])) && all(isfinite(runs)&runs>=0&runs==floor(runs)) && ...
    all(isfinite(bat)&bat>=0&bat==floor(bat)) && all(isfinite(extras)&extras>=0&extras==floor(extras)) && ...
    all(runs==bat+extras) && all(isfinite(genuine)&genuine>=0&genuine<=10&genuine==floor(genuine));
[lb,wl,sb,p]=beforeState(legal,genuine,runs);
valid=valid && all(wl>=0&wl<=10) && sum(genuine)<=10;
reconcile=valid && sum(legal)==a.LegalBalls && sum(runs)==a.DeliveryRuns && ...
    sum(genuine)==a.GenuineDismissals && sum(retire)==a.RetiredHurtEvents && height(B)==a.Rows;
primary=logical(a.PrimaryModelEligible);
assert(~primary || reconcile,'Primary innings does not reconcile: %s',key);
% u is known for verified completed standard first innings, including reserved
% cases of that type. Auxiliary allocation histories will be joined at 09B.
allocationKnown=logical(a.ResponseEligible) && a.InningsIndex==1;
u=nan(height(B),1); if allocationKnown,u=a.NominalBalls-lb;end
future=a.DeliveryRuns-sb;
observedFraction=nan(height(B),1);
if a.DeliveryRuns>0,observedFraction=future/a.DeliveryRuns;end
T=table(seq,repmat("delivery",height(B),1),strtrim(string(B.BattingTeam)), ...
    string(B.Batter),string(B.NonStriker),string(B.Bowler), ...
    legal,runs,bat,extras,genuine,retire,lb,wl,10-wl,sb, ...
    sb+a.PenaltyPre,p,wl==0,u,a.NominalBalls-lb,future,observedFraction, ...
    'VariableNames',{'DeliverySeq','StateType','RecordedBattingTeam','Batter','NonStriker', ...
    'Bowler','CorrectedIsLegalBall','DeliveryRuns','RunsOffBat','ExtrasRuns', ...
    'GenuineDismissalsOnDelivery','RetiredNotOutEvents','LegalBallsBowled', ...
    'GenuineWicketsLost','WicketsInHand','DeliveryScoreBefore','ScoreboardBefore', ...
    'LegalBallsSinceDismissal','NoDismissalYet','BallsRemaining','NominalBallsRemaining', ...
    'ObservedFutureDeliveryRuns','ObservedRemainingFraction'});
% Initial/terminal rows are explicitly outside fitting samples.
initial=T(1,:);initial.DeliverySeq=0;initial.StateType="initial";
initial.Batter="";initial.NonStriker="";initial.Bowler="";
initial.RecordedBattingTeam=string(a.BattingTeam);
initial{1,{'CorrectedIsLegalBall','DeliveryRuns','RunsOffBat','ExtrasRuns', ...
    'GenuineDismissalsOnDelivery','RetiredNotOutEvents'}}=zeros(1,6);
terminal=initial;terminal.DeliverySeq=height(B)+1;terminal.StateType="terminal";
terminal.LegalBallsBowled=sum(legal);terminal.GenuineWicketsLost=sum(genuine);
terminal.WicketsInHand=10-sum(genuine);terminal.DeliveryScoreBefore=sum(runs);
terminal.ScoreboardBefore=sum(runs)+a.PenaltyPre+a.PenaltyPost;
terminal.LegalBallsSinceDismissal=terminalPartnership(legal,genuine);
terminal.NoDismissalYet=sum(genuine)==0;terminal.NominalBallsRemaining=a.NominalBalls-sum(legal);
terminal.BallsRemaining=NaN;if allocationKnown,terminal.BallsRemaining=terminal.NominalBallsRemaining;end
terminal.ObservedFutureDeliveryRuns=0;terminal.ObservedRemainingFraction=NaN;
if a.DeliveryRuns>0,terminal.ObservedRemainingFraction=0;end
T=[initial;T;terminal];n=height(T);
T.MatchID=repmat(string(a.MatchID),n,1);T.InningsIndex=repmat(a.InningsIndex,n,1);
T.Format=repmat(string(m.FormatFamily),n,1);T.Gender=repmat(string(m.GenderCanon),n,1);
T.BattingTeam=repmat(string(a.BattingTeam),n,1);T.Team1=repmat(string(m.Team1),n,1);
T.Team2=repmat(string(m.Team2),n,1);T.Venue=repmat(string(m.Venue),n,1);
T.EventName=repmat(string(m.EventName),n,1);T.MatchDate=repmat(m.StartDate,n,1);
T.Split=repmat(string(m.Split),n,1);T.TrainingFold=repmat(m.TrainingFold,n,1);
T.CaseReserved=repmat(logical(m.CaseStudyReserved),n,1);
T.CompletionClass=repmat(string(a.CompletionClass),n,1);
T.RecordIntegrityPassed=repmat(reconcile,n,1);
T.StandardCompletedFirstInnings=repmat(allocationKnown,n,1);
T.AllocationHistoryKnown=repmat(allocationKnown,n,1);
T.PrimaryEligibleObservation=primary & reconcile & T.StateType=="delivery" & ...
    T.CorrectedIsLegalBall==1 & T.WicketsInHand>0;
T.PrimaryFitObservation=T.PrimaryEligibleObservation & T.Split=="train";
T.PrimaryRemainingRuns=nan(n,1);T.PrimaryRemainingRuns(T.PrimaryEligibleObservation)= ...
    T.ObservedFutureDeliveryRuns(T.PrimaryEligibleObservation);
% Remaining-run labels can be evaluated on validation/test, but downstream
% fitting MUST additionally require Split==train and respect fold membership.
T.FinalDeliveryRuns=repmat(a.DeliveryRuns,n,1);
T.PenaltyPre=repmat(a.PenaltyPre,n,1);T.PenaltyPost=repmat(a.PenaltyPost,n,1);
T.FinalScoreboard=repmat(a.ReconciledFinalScore,n,1);
Q=table(string(a.MatchID),a.InningsIndex,string(m.FormatFamily),string(m.Split),primary, ...
    reconcile,height(B),sum(legal),sum(runs),sum(genuine),nnz(T.PrimaryEligibleObservation), ...
    numel(used),'VariableNames',{'MatchID','InningsIndex','Format','Split','PrimaryInnings', ...
    'Passed','DeliveryRows','LegalBalls','DeliveryRuns','GenuineDismissals', ...
    'PrimaryStateObservations','CorrectionsApplied'});
end
function [b,w,s,p]=beforeState(legal,genuine,runs)
b=[0;cumsum(legal(1:end-1))];w=[0;cumsum(genuine(1:end-1))];s=[0;cumsum(runs(1:end-1))];
p=zeros(size(b));last=0;
for k=1:numel(b)
    p(k)=b(k)-last;
    if genuine(k)>0,last=b(k)+legal(k);end
end
end
function p=terminalPartnership(legal,genuine)
k=find(genuine>0,1,'last');
if isempty(k),p=sum(legal);else,p=sum(legal(k+1:end));end
end
function P=savePartition(batch,P,folder)
States=vertcat(batch{:});path=fullfile(folder,sprintf('09_States_Part%04d.mat',height(P)+1));
save(path,'States','-v7.3');
P=[P;table(string(path),height(States),numel(batch),'VariableNames',P.Properties.VariableNames)];
end
function d=fileInfo(path)
q=dir(path);assert(numel(q)==1,'Cannot fingerprint %s',path);
d=struct('Path',string(path),'Bytes',q.bytes,'Modified',q.datenum);
end
function D=dictionary
v=["BallsRemaining";"NominalBallsRemaining";"ObservedFutureDeliveryRuns"; ...
    "PrimaryRemainingRuns";"PrimaryFitObservation";"ScoreboardBefore"; ...
    "LegalBallsSinceDismissal";"initial/terminal";"AllocationHistoryKnown"];
x=["Known only for completed standard first innings; auxiliary allocation history pending"; ...
    "Nominal format horizon minus legal balls; not an interrupted-match allocation"; ...
    "Observed later delivery runs; auxiliary chase outcomes may be censored"; ...
    "Primary eligible outcome; missing elsewhere"; ...
    "Primary eligible legal-delivery state with Split=train; validation/test are never fitting samples"; ...
    "Pre-delivery score includes pre-innings penalty; terminal includes post penalty"; ...
    "Legal balls since latest genuine dismissal; retired hurt does not reset"; ...
    "Explicit audit states, never ordinary fitting samples"; ...
    "Standard completed first-innings horizon known; does not verify all case interruption ledgers"];
D=table(v,x,'VariableNames',{'Variable','Definition'});
end
function selfTest
[b,w,s,p]=beforeState([0;1;0;1],[0;1;1;0],[2;0;1;4]);
assert(isequal(b,[0;0;1;1])&&isequal(w,[0;0;1;2])&& ...
    isequal(s,[0;2;2;3])&&isequal(p,[0;0;0;0]),'Illegal-ball/dismissal reconstruction failed.');
[~,w,~,p]=beforeState([1;1;1],[0;0;0],[0;0;1]);
assert(isequal(w,[0;0;0])&&isequal(p,[0;1;2]),'Partnership reconstruction failed.');
fprintf('State reconstruction preflight passed.\n');
end
