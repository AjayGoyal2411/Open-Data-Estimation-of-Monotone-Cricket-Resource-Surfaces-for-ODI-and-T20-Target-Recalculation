function Result = RevisedCodes_09_03B_CaseEvidenceReview(settings)
% Creates/validates the source-evidence package for registered case studies.
% This code never invents match facts and never evaluates model targets.
% Run: R = RevisedCodes_09_03B_CaseEvidenceReview;
if nargin<1,settings=struct;end
cfg=RevisedCodes_09_00_Config;opt=defaults(settings,cfg);selfTest;
root=fullfile(cfg.OutputRoot,'case_source_review');ensure(root);
report=fullfile(root,'reports');ensure(report);
inputFolder=opt.InputFolder;ensure(inputFolder);

ledgerPath=resolveCSV(cfg,'09_03_CaseLedger.csv','RevisedCodes_09_03_Checks.zip',root);
Base=readtable(ledgerPath,'TextType','string','VariableNamingRule','preserve');
requireVars(Base,["CaseID","ResolvedMatchID","RawInningsAvailable","RawReserved","SuppliedDescription"]);
assert(numel(unique(string(Base.CaseID)))==height(Base),'Duplicate CaseID in Step09_03 ledger.');

[Sources,Evidence,Timeline,workbook] = loadOrCreateInputs(Base,inputFolder);
[SourceAudit,verifiedSourceIDs] = auditSources(Sources);
[EvidenceAudit,Evidence] = auditEvidence(Evidence,Base,verifiedSourceIDs);
[TimelineAudit,TimelineChecked] = auditTimeline(Timeline,Base,verifiedSourceIDs);

caseIDs=string(Base.CaseID);n=height(Base);
identity=false(n,1);scores=false(n,1);alloc=false(n,1);convention=false(n,1);penalty=false(n,1);
evidenceSources=false(n,1);timelineValid=false(n,1);timelineRows=zeros(n,1);published=false(n,1);
for j=1:n
    q=EvidenceAudit.CaseID==caseIDs(j);
    if any(q)
        identity(j)=all(EvidenceAudit.IdentityVerified(q));scores(j)=all(EvidenceAudit.ScoresVerified(q));
        alloc(j)=all(EvidenceAudit.AllocationVerified(q));convention(j)=all(EvidenceAudit.ConventionVerified(q));
        penalty(j)=all(EvidenceAudit.PenaltyResolved(q));evidenceSources(j)=all(EvidenceAudit.LinkedSourcesVerified(q));
        published(j)=all(EvidenceAudit.PublishedValueAvailable(q));
    end
    q=TimelineAudit.CaseID==caseIDs(j);timelineRows(j)=nnz(q);
    timelineValid(j)=any(q)&&all(TimelineAudit.RowValid(q))&&all(TimelineAudit.CaseSequenceValid(q));
end
rawAvailable=number(Base.RawInningsAvailable)>0;rawReserved=logicalNumber(Base.RawReserved);
fullEligible=identity&scores&alloc&convention&penalty&evidenceSources&timelineValid&rawAvailable&rawReserved;
benchmarkOnly=identity&scores&convention&penalty&evidenceSources&published&~fullEligible;

CaseDecision=table(caseIDs,identity,scores,alloc,convention,penalty,evidenceSources, ...
    timelineRows,timelineValid,rawAvailable,rawReserved,published,fullEligible,benchmarkOnly, ...
    strings(n,1),'VariableNames',{'CaseID','IdentityVerified','ScoresVerified','AllocationVerified', ...
    'ConventionVerified','PenaltyResolved','EvidenceSourcesVerified','TimelineRows','TimelineValid', ...
    'RawInningsAvailable','RawReserved','PublishedValueAvailable','EvaluationEligible', ...
    'BenchmarkOnlyEligible','DecisionReason'});
for j=1:n
    missing=strings(0,1);
    if ~identity(j),missing(end+1)="identity";end %#ok<AGROW>
    if ~scores(j),missing(end+1)="scores";end %#ok<AGROW>
    if ~alloc(j),missing(end+1)="allocations";end %#ok<AGROW>
    if ~convention(j),missing(end+1)="par_target_convention";end %#ok<AGROW>
    if ~penalty(j),missing(end+1)="penalties";end %#ok<AGROW>
    if ~evidenceSources(j),missing(end+1)="verified_sources";end %#ok<AGROW>
    if ~timelineValid(j),missing(end+1)="complete_timeline";end %#ok<AGROW>
    if ~rawAvailable(j),missing(end+1)="raw_innings";end %#ok<AGROW>
    if ~rawReserved(j),missing(end+1)="reservation";end %#ok<AGROW>
    if fullEligible(j),CaseDecision.DecisionReason(j)="verified_full_case";
    elseif benchmarkOnly(j),CaseDecision.DecisionReason(j)="benchmark_only; no full resource-accounting eligibility";
    else,CaseDecision.DecisionReason(j)="pending: "+strjoin(missing,',');end
end

UpdatedLedger=Base;
UpdatedLedger.SourceReviewComplete=identity&scores&alloc&convention&penalty&evidenceSources;
UpdatedLedger.TimelineValid=timelineValid;
UpdatedLedger.EvaluationEligible=fullEligible;
UpdatedLedger.Reason=CaseDecision.DecisionReason;
if ~ismember('BenchmarkOnlyEligible',UpdatedLedger.Properties.VariableNames)
    UpdatedLedger.BenchmarkOnlyEligible=benchmarkOnly;
else,UpdatedLedger.BenchmarkOnlyEligible=benchmarkOnly;end

Gates=table(["All registered CaseIDs are unique";"All evidence CaseIDs are registered"; ...
    "All timeline CaseIDs are registered";"Source IDs are unique"; ...
    "No case is eligible without verified linked sources"; ...
    "No case is eligible without a valid interruption timeline"; ...
    "No par value is silently treated as a win target"], ...
    [true;all(ismember(string(Evidence.CaseID),caseIDs));all(ismember(string(Timeline.CaseID),caseIDs)); ...
    SourceAudit.UniqueSourceIDGate;all(~fullEligible|evidenceSources);all(~fullEligible|timelineValid); ...
    all(~EvidenceAudit.ParTargetConflict)],'VariableNames',{'Check','Passed'});
assert(all(Gates.Passed),'Hard case-evidence integrity gate failed. Review report tables.');

status="SOURCE_REVIEW_PENDING";if all(fullEligible),status="ALL_REGISTERED_CASES_VERIFIED";
elseif any(fullEligible),status="VERIFIED_SUBSET_AVAILABLE";end
writetable(UpdatedLedger,fullfile(report,'09_03B_CaseLedger.csv'));
writetable(CaseDecision,fullfile(report,'09_03B_CaseDecisions.csv'));
writetable(SourceAudit.Table,fullfile(report,'09_03B_SourceAudit.csv'));
writetable(EvidenceAudit,fullfile(report,'09_03B_EvidenceAudit.csv'));
writetable(TimelineChecked,fullfile(report,'09_03B_InterruptionTimeline.csv'));
writetable(TimelineAudit,fullfile(report,'09_03B_TimelineAudit.csv'));
writetable(Gates,fullfile(report,'09_03B_GateChecks.csv'));
QC=table(status,n,height(Sources),nnz(SourceAudit.Table.SourceVerified),height(Evidence),height(Timeline), ...
    nnz(fullEligible),nnz(benchmarkOnly),nnz(~fullEligible), ...
    'VariableNames',{'Status','RegisteredCases','Sources','VerifiedSources','EvidenceRows', ...
    'TimelineRows','EvaluationEligibleCases','BenchmarkOnlyCases','PendingFullCases'});
writetable(QC,fullfile(report,'09_03B_QC_Summary.csv'));

fig=figure('Visible','off','Color','w','Position',[100 100 1000 500]);
bar([nnz(fullEligible),nnz(benchmarkOnly),nnz(~fullEligible&~benchmarkOnly)]);grid on;
set(gca,'XTickLabel',{'Full case','Benchmark only','Pending'});ylabel('Registered cases');
title('Case evidence eligibility; no model outputs inspected');
figPath=fullfile(report,'F_S09_03B_CaseEvidence_Preview.png');exportgraphics(fig,figPath,'Resolution',600);close(fig);
pubTable=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady','Supplementary','Tables','CaseEvidence');
pubFigure=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady','Supplementary','Figures','CaseEvidence');
ensure(pubTable);ensure(pubFigure);
for f=["09_03B_CaseDecisions.csv","09_03B_SourceAudit.csv","09_03B_EvidenceAudit.csv", ...
        "09_03B_TimelineAudit.csv","09_03B_QC_Summary.csv"]
    copyfile(fullfile(report,f),fullfile(pubTable,f));
end
copyfile(figPath,fullfile(pubFigure,'F_S09_03B_CaseEvidence.png'));
files=dir(fullfile(report,'*'));names={files(~[files.isdir]).name};
zipPath=fullfile(cfg.ProjectRoot,'RevisedCodes_09_03B_Checks.zip');zip(zipPath,names,report);
Result=struct('Status',status,'CaseDecisions',CaseDecision,'UpdatedLedger',UpdatedLedger, ...
    'Gates',Gates,'InputWorkbook',string(workbook),'InputFolder',string(inputFolder), ...
    'ReportFolder',string(report),'ReportZIP',string(zipPath));
save(fullfile(root,'RevisedCodes_09_03B_Result.mat'),'Result','-v7.3');
fprintf('09_03B COMPLETE (%s). Upload %s\n',status,zipPath);
if status=="SOURCE_REVIEW_PENDING"
    fprintf('Complete the evidence files in %s and rerun. Missing facts were not guessed.\n',inputFolder);
end
end

function opt=defaults(s,cfg)
opt=struct('InputFolder',fullfile(cfg.ProjectRoot,'CaseEvidence_Input'));
assert(isstruct(s)&&isscalar(s),'Settings must be a scalar struct.');
for f=fieldnames(s)',assert(isfield(opt,f{1}),'Unknown setting %s.',f{1});opt.(f{1})=s.(f{1});end
end

function [S,E,T,workbook]=loadOrCreateInputs(Base,inputFolder)
workbook=fullfile(inputFolder,'RevisedCodes_09_03B_EvidenceWorkbook.xlsx');
sCSV=fullfile(inputFolder,'09_03B_SourceRegister_Reviewed.csv');
eCSV=fullfile(inputFolder,'09_03B_CaseEvidence_Reviewed.csv');
tCSV=fullfile(inputFolder,'09_03B_InterruptionTimeline_Reviewed.csv');
if ~isfile(workbook)&&~isfile(sCSV)&&~isfile(eCSV)&&~isfile(tCSV)
    S=sourceTemplate;E=evidenceTemplate(string(Base.CaseID));T=timelineTemplate;
    writetable(S,sCSV);writetable(E,eCSV);writetable(T,tCSV);
    Instructions=instructionTable;writetable(Instructions,fullfile(inputFolder,'09_03B_InputInstructions.csv'));
    try
        writetable(S,workbook,'Sheet','Sources');writetable(E,workbook,'Sheet','Evidence');
        writetable(T,workbook,'Sheet','Timeline');writetable(Instructions,workbook,'Sheet','Instructions');
    catch
        workbook="CSV templates (Excel workbook could not be created)";
    end
end
useWorkbook=isfile(workbook);
if useWorkbook && all(isfile([string(sCSV),string(eCSV),string(tCSV)]))
    wd=dir(workbook);csvInfo=[dir(sCSV);dir(eCSV);dir(tCSV)];
    useWorkbook=wd.datenum>=max([csvInfo.datenum]);
end
if useWorkbook
    S=readtable(workbook,'Sheet','Sources','TextType','string','VariableNamingRule','preserve');
    E=readtable(workbook,'Sheet','Evidence','TextType','string','VariableNamingRule','preserve');
    T=readtable(workbook,'Sheet','Timeline','TextType','string','VariableNamingRule','preserve');
else
    S=readtable(sCSV,'TextType','string','VariableNamingRule','preserve');
    E=readtable(eCSV,'TextType','string','VariableNamingRule','preserve');
    T=readtable(tCSV,'TextType','string','VariableNamingRule','preserve');
end
q=sourceTemplate;requireVars(S,string(q.Properties.VariableNames));
q=evidenceTemplate(strings(0,1));requireVars(E,string(q.Properties.VariableNames));
q=timelineTemplate;requireVars(T,string(q.Properties.VariableNames));
end

function T=sourceTemplate
T=table(strings(0,1),strings(0,1),strings(0,1),strings(0,1),strings(0,1), ...
    strings(0,1),strings(0,1),strings(0,1),strings(0,1), ...
    'VariableNames',{'SourceID','URL','Title','Publisher','SourceType','ReviewDate','ReviewStatus','EvidenceExcerpt','Notes'});
end
function T=evidenceTemplate(ids)
n=numel(ids);T=table(ids,repmat("",n,1),repmat("",n,1),repmat("",n,1),repmat("",n,1), ...
    nan(n,1),nan(n,1),repmat("",n,1),nan(n,1),nan(n,1),nan(n,1),nan(n,1),nan(n,1),nan(n,1), ...
    nan(n,1),nan(n,1),repmat("",n,1),repmat("",n,1),repmat("",n,1), ...
    repmat("pending",n,1),repmat("pending",n,1),repmat("pending",n,1),repmat("pending",n,1), ...
    repmat("pending",n,1),repmat("pending",n,1),repmat("",n,1),repmat("",n,1),repmat("",n,1), ...
    repmat("",n,1),repmat("",n,1),repmat("",n,1), ...
    'VariableNames',{'CaseID','VerifiedDate','VerifiedTeam1','VerifiedTeam2','VerifiedFormat', ...
    'FirstInningsScore','SecondInningsScore','ScoreBasis','InitialAllocation1','InitialAllocation2', ...
    'PenaltyPre1','PenaltyPost1','PenaltyPre2','PenaltyPost2','PublishedPar','PublishedWinTarget', ...
    'BenchmarkMethod','BenchmarkVersion','ConventionNotes','IdentityStatus','FinalScoresStatus', ...
    'AllocationStatus','TimelineStatus','ConventionStatus','PenaltyStatus','IdentitySourceID', ...
    'ScoreSourceID','AllocationSourceID','ConventionSourceID','PenaltySourceID','Notes'});
end
function T=timelineTemplate
T=table(strings(0,1),zeros(0,1),zeros(0,1),strings(0,1),zeros(0,1),zeros(0,1),zeros(0,1), ...
    zeros(0,1),zeros(0,1),strings(0,1),strings(0,1),strings(0,1),strings(0,1), ...
    'VariableNames',{'CaseID','InningsIndex','EventOrder','EventType','LegalBallsBowled','Score','WicketsLost', ...
    'AllocationBefore','AllocationAfter','ScoreBasis','SourceID','VerificationStatus','Notes'});
end
function T=instructionTable
T=table(["SourceID";"ReviewStatus";"VerifiedDate";"Status fields";"Allocation fields"; ...
    "PublishedPar/PublishedWinTarget";"Timeline EventType";"LegalBallsBowled";"EvidenceExcerpt"], ...
    ["Unique stable ID used by evidence/timeline rows";"Use verified only after independent review"; ...
    "ISO yyyy-MM-dd preferred";"Use verified, pending, conflict, or not_applicable where permitted"; ...
    "Total allocated legal balls, not cricket decimal overs"; ...
    "Par is tie score; win target is normally par+1. Never substitute one for the other"; ...
    "pre_start_reduction, interruption, terminal_abandonment, or innings_end"; ...
    "Integer legal-ball count: 21.3 overs in six-ball cricket is 129"; ...
    "Brief factual note only; retain full citation/URL and avoid long copyrighted quotations"], ...
    'VariableNames',{'Field','Instruction'});
end

function [A,verifiedIDs]=auditSources(S)
if isempty(S)
    Q=table(strings(0,1),false(0,1),false(0,1),false(0,1),strings(0,1), ...
        'VariableNames',{'SourceID','UniqueID','CitationPresent','SourceVerified','Issue'});
    A=struct('Table',Q,'UniqueSourceIDGate',true);verifiedIDs=strings(0,1);return;
end
id=strtrim(string(S.SourceID));uniqueID=id~="" & ~duplicated(id);
citation=(strtrim(string(S.URL))~="") | (strtrim(string(S.Title))~="" & strtrim(string(S.Publisher))~="");
verified=lower(strtrim(string(S.ReviewStatus)))=="verified" & uniqueID & citation;
issue=repmat("",height(S),1);issue(id=="")="missing SourceID";issue(~uniqueID&id~="")="duplicate SourceID";
issue(~citation)="missing URL or title/publisher citation";issue(lower(strtrim(string(S.ReviewStatus)))~="verified"&issue=="")="review pending";
Q=table(id,uniqueID,citation,verified,issue,'VariableNames',{'SourceID','UniqueID','CitationPresent','SourceVerified','Issue'});
A=struct('Table',Q,'UniqueSourceIDGate',all(uniqueID));verifiedIDs=id(verified);
end

function [A,E]=auditEvidence(E,Base,verifiedIDs)
ids=string(Base.CaseID);assert(all(ismember(string(E.CaseID),ids)),'Unregistered CaseID in evidence input.');
assert(numel(unique(string(E.CaseID)))==height(E),'Duplicate CaseID in evidence input.');
n=height(E);status=@(x) lower(strtrim(string(x)));
identity=status(E.IdentityStatus)=="verified" & strtrim(string(E.VerifiedDate))~="" & ...
    strtrim(string(E.VerifiedTeam1))~="" & strtrim(string(E.VerifiedTeam2))~="" & ...
    ismember(upper(strtrim(string(E.VerifiedFormat))),["ODI","T20"]);
scores=status(E.FinalScoresStatus)=="verified" & number(E.FirstInningsScore)>=0 & number(E.SecondInningsScore)>=0 & strtrim(string(E.ScoreBasis))~="";
alloc=status(E.AllocationStatus)=="verified" & number(E.InitialAllocation1)>0 & number(E.InitialAllocation2)>0;
convention=status(E.ConventionStatus)=="verified" & strtrim(string(E.ConventionNotes))~="";
penalty=ismember(status(E.PenaltyStatus),["verified","not_applicable"]);
published=isfinite(number(E.PublishedPar))|isfinite(number(E.PublishedWinTarget));
linked=false(n,1);fields=["IdentitySourceID","ScoreSourceID","AllocationSourceID","ConventionSourceID"];
for j=1:n,linked(j)=all(ismember(strtrim(string(E{j,cellstr(fields)})),verifiedIDs));end
needPenalty=status(E.PenaltyStatus)=="verified";linked=linked & (~needPenalty | ismember(strtrim(string(E.PenaltySourceID)),verifiedIDs));
par=number(E.PublishedPar);target=number(E.PublishedWinTarget);
conflict=isfinite(par)&isfinite(target)&abs(target-(floor(par)+1))>1e-9 & strlength(strtrim(string(E.ConventionNotes)))<10;
issue=repmat("",n,1);
for j=1:n
    m=strings(0,1);if ~identity(j),m(end+1)="identity";end %#ok<AGROW>
    if ~scores(j),m(end+1)="scores";end %#ok<AGROW>
    if ~alloc(j),m(end+1)="allocation";end %#ok<AGROW>
    if ~convention(j),m(end+1)="convention";end %#ok<AGROW>
    if ~penalty(j),m(end+1)="penalty";end %#ok<AGROW>
    if ~linked(j),m(end+1)="sources";end %#ok<AGROW>
    if ~published(j),m(end+1)="published value";end %#ok<AGROW>
    if conflict(j),m(end+1)="par/target conflict";end %#ok<AGROW>
    issue(j)=strjoin(m,',');
end
A=table(string(E.CaseID),identity,scores,alloc,convention,penalty,linked,published,conflict,issue, ...
    'VariableNames',{'CaseID','IdentityVerified','ScoresVerified','AllocationVerified','ConventionVerified', ...
    'PenaltyResolved','LinkedSourcesVerified','PublishedValueAvailable','ParTargetConflict','Issue'});
end

function [A,Tout]=auditTimeline(T,Base,verifiedIDs)
ids=string(Base.CaseID);assert(all(ismember(string(T.CaseID),ids)),'Unregistered CaseID in timeline input.');
n=height(T);rowValid=false(n,1);sequenceValid=false(n,1);issue=repmat("",n,1);
remainBefore=nan(n,1);remainAfter=nan(n,1);rawStatus=repmat("pending",n,1);
allowed=["pre_start_reduction","interruption","terminal_abandonment","innings_end"];
for j=1:n
    inn=number(T.InningsIndex(j));ord=number(T.EventOrder(j));b=number(T.LegalBallsBowled(j));
    score=number(T.Score(j));w=number(T.WicketsLost(j));a0=number(T.AllocationBefore(j));a1=number(T.AllocationAfter(j));
    remainBefore(j)=a0-b;remainAfter(j)=a1-b;
    checks=[ismember(inn,[1 2]),isfinite(ord)&&ord>=1&&ord==floor(ord), ...
        ismember(lower(strtrim(string(T.EventType(j)))),allowed),isfinite(b)&&b>=0&&b==floor(b), ...
        isfinite(score)&&score>=0&&score==floor(score),isfinite(w)&&w>=0&&w<=10&&w==floor(w), ...
        isfinite(a0)&&isfinite(a1)&&a0>=a1&&a1>=b,strtrim(string(T.ScoreBasis(j)))~="", ...
        ismember(strtrim(string(T.SourceID(j))),verifiedIDs),lower(strtrim(string(T.VerificationStatus(j))))=="verified"];
    rowValid(j)=all(checks);if ~rowValid(j),issue(j)="invalid numeric/event/source/status field";end
    if rowValid(j),rawStatus(j)="verified";end
end
if n>0
    group=string(T.CaseID)+"|"+string(T.InningsIndex);[u,~,g]=unique(group,'stable');
    for k=1:numel(u)
        a=find(g==k);o=number(T.EventOrder(a));ok=numel(unique(o))==numel(o)&&all(diff(o)>=0);
        b=number(T.LegalBallsBowled(a));ok=ok&&all(diff(b)>=0);
        sequenceValid(a)=ok;if ~ok,issue(a)="duplicate/reversed event order or legal-ball chronology";end
    end
end
A=table(string(T.CaseID),number(T.InningsIndex),number(T.EventOrder),rowValid,sequenceValid,issue, ...
    'VariableNames',{'CaseID','InningsIndex','EventOrder','RowValid','CaseSequenceValid','Issue'});
Tout=T;Tout.RemainingBefore=remainBefore;Tout.RemainingAfter=remainAfter;Tout.SourceReviewed=rowValid;
Tout.RawCheckpointStatus=rawStatus;Tout.ConsistencyStatus=repmat("invalid",n,1);Tout.ConsistencyStatus(rowValid&sequenceValid)="valid";
Tout.Issue=issue;
end

function v=duplicated(x)
[~,~,g]=unique(x);c=accumarray(g,1);v=c(g)>1;
end
function y=number(x)
if isnumeric(x),y=double(x);else,y=str2double(string(x));end
end
function v=logicalNumber(x)
if islogical(x),v=x;elseif isnumeric(x),v=isfinite(x)&x~=0;else,v=ismember(lower(strtrim(string(x))),["1","true","yes"]);end
end
function requireVars(T,n)
missing=n(~ismember(n,string(T.Properties.VariableNames)));assert(isempty(missing),'Missing variables: %s',strjoin(missing,', '));
end
function ensure(p),if ~isfolder(p),mkdir(p);end,end
function p=resolveCSV(cfg,name,zipName,root)
d=dir(fullfile(cfg.OutputRoot,'**',name));if ~isempty(d),[~,k]=max([d.datenum]);p=fullfile(d(k).folder,d(k).name);return;end
z=fullfile(cfg.ProjectRoot,zipName);assert(isfile(z),'Missing %s and %s.',name,z);cache=fullfile(root,'source_reports');ensure(cache);
unzip(z,cache);p=fullfile(cache,name);assert(isfile(p),'%s absent from %s.',name,z);
end
function selfTest
assert(isequal(number([1;2]),[1;2]));assert(isequal(logicalNumber([0;1]),[false;true]));
assert(isequal(duplicated(["a";"b";"a"]),[true;false;true]));
% Cricket notation policy remains integer legal balls; decimal overs are never multiplied as decimals.
overs=[21 19 0];balls=[3 5 0];assert(isequal(overs*6+balls,[129 119 0]));
end
