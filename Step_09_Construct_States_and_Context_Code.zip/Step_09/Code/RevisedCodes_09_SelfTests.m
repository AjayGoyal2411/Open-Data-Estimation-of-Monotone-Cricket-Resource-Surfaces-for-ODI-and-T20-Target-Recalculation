function Checks=RevisedCodes_09_SelfTests
% Lightweight actual-MATLAB support tests; no Windows data needed.
U=RevisedCodes_09_Utils;
p=tempname;mkdir(p);cleanup=onCleanup(@()rmdir(p,'s')); %#ok<NASGU>
notation=["21.3","19.5","0.0"];expected=[129,119,0];actual=U.OversToBalls(notation,6);
assert(isequal(actual(:),expected(:))&&isequal(size(actual),size(notation)), ...
 'Cricket notation conversion failed: actual %s; expected %s; utility %s.', ...
 mat2str(actual),mat2str(expected),which('RevisedCodes_09_Utils'));
actual=U.OversToBalls(notation',6);
assert(isequal(actual,expected'),'Column-vector cricket notation conversion failed.');
assert(U.OversToBalls("21",6)==126,'Whole-over conversion failed.');
assert(isnan(U.OversToBalls("",6)),'Blank cricket notation must remain missing.');
mustFail(@()U.OversToBalls("21.6",6));
mustFail(@()U.OversToBalls("-1.2",6));
assert(U.OversToBalls("4.4",5)==24,'Five-ball notation conversion failed.');
mustFail(@()U.OversToBalls("4.5",5));
d=U.Date(["2024-02-29",""]);assert(~isnat(d(1))&&isnat(d(2)),'ISO date parsing failed.');
mustFail(@()U.Date("29/02/2024"));mustFail(@()U.Date("2023-02-29"));
T=table(["000123";"wi_0001"],[false;true], ...
 'VariableNames',{'MatchID','NeedsReview'});f=fullfile(p,'IDs.csv');writetable(T,f);
A=U.Read(f,"MatchID");assert(isequal(A.MatchID,T.MatchID)&&isequal(A.NeedsReview,T.NeedsReview), ...
 'ID preservation/boolean conversion failed.');
Empty=array2table(strings(0,2),'VariableNames',{'SourceID','URL'});
f=fullfile(p,'Empty.csv');writetable(Empty,f);A=U.Read(f,["SourceID","URL"]);
assert(height(A)==0&&isequal(A.Properties.VariableNames,Empty.Properties.VariableNames), ...
 'Header-only source template import failed.');
S=table(["a";"b";"c"],repmat("https://example.org/source",3,1), ...
 repmat("Synthetic test source",3,1),repmat("Test excerpt",3,1), ...
 repmat("reviewed",3,1),repmat("2026-09-16",3,1), ...
 ["official_scorecard";"user_notes";"contemporary_report"], ...
 'VariableNames',{'SourceID','URL','Title','EvidenceExcerpt','ReviewStatus','ReviewDate','SourceType'});
S.EvidenceExcerpt(3)="";
assert(isequal(U.SourceOK(["a","b","c","missing"],S),[true,false,false,false]), ...
 'Missing evidence/non-independent source accepted.');
Checks=table(["Cricket over notation";"Invalid dates/balls rejected";"Numeric-looking IDs preserved"; ...
 "Boolean CSV values";"Header-only templates";"Source review evidence gate"], ...
 true(6,1),'VariableNames',{'Check','Passed'});disp(Checks);
fprintf('Step09 support self-tests passed. Stage-specific timeline/history tests run inside their functions.\n');
end
function mustFail(action)
failed=false;try,action();catch,failed=true;end
assert(failed,'Invalid synthetic input unexpectedly accepted.');
end
