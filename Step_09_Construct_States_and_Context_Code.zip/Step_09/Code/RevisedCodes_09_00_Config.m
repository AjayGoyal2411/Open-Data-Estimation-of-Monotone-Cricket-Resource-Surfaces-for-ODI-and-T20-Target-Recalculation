function cfg=RevisedCodes_09_00_Config
% Shared reconstruction settings. Do not change eligibility/splits here.
cfg.ProjectRoot='D:\VihaanProject1';
cfg.PrerequisiteRoot=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step08_prerequisites');
cfg.DeliveryCSV=fullfile(cfg.ProjectRoot,'final_retained_dataset','ball_by_ball_all.csv');
cfg.OutputRoot=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','step09');
cfg.ReadSize=50000;
cfg.InningsPerPartition=250;
cfg.ForceRebuild=false;
cfg.RunSelfTests=true;
cfg.Version='09.1.0';
end
