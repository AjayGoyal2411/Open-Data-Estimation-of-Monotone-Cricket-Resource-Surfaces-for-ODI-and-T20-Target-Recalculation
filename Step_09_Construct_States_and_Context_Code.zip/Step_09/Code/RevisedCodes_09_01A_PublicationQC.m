function Publication=RevisedCodes_09_01A_PublicationQC
% Run AFTER successful 09_01. Uses caches, not the original delivery CSV.
% No existing code or cache is modified. Outputs are descriptive data/audit
% results, not model accuracy or evidence of target fairness.
% PublicationReady/Methodology/{Tables,Figures}
% PublicationReady/Results/{Tables,Figures}
% Tables are CSV and one consolidated XLSX. Figures are PNG(600 dpi), PDF,
% and editable MATLAB FIG, with four panels and separate caption records.
% Support plots use TRAINING legal-delivery observations only.
cfg=RevisedCodes_09_00_Config;
root=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady');
MT=fullfile(root,'Methodology','Tables'); MF=fullfile(root,'Methodology','Figures');
RT=fullfile(root,'Results','Tables'); RF=fullfile(root,'Results','Figures');
for p=string({root,MT,MF,RT,RF}),if ~isfolder(p),mkdir(p);end,end
s=load(fullfile(cfg.OutputRoot,'RevisedCodes_09_Result.mat'),'Result');result=s.Result;
assert(all(isfile(result.Partitions.Path)),'State partitions missing.');
Q=readtable(fullfile(cfg.OutputRoot,'tables','09_InningsReconciliation.csv'), ...
    'Delimiter',',','ReadVariableNames',true,'TextType','string');
M=readtable(fullfile(cfg.OutputRoot,'tables','09_MatchManifest.csv'), ...
    'Delimiter',',','ReadVariableNames',true,'TextType','string');
Q.MatchID=string(Q.MatchID); M.MatchID=string(M.MatchID);
assert(~any(Q.PrimaryInnings & ~Q.Passed),'Primary reconciliation failures.');
Workbook=fullfile(root,'09_PublicationTables.xlsx');
if isfile(Workbook),delete(Workbook);end
Index=table(strings(0,1),strings(0,1),strings(0,1),strings(0,1), ...
    'VariableNames',{'File','Section','Caption','Source'});
%% Concise methodology population table
Population=table(strings(0,1),strings(0,1),zeros(0,1),zeros(0,1),zeros(0,1), ...
    zeros(0,1),zeros(0,1),'VariableNames',{'Format','Split','Matches', ...
    'EligibleStateObservations','EarlyAllOutMatches','MedianLegalBalls','IQRLegalBalls'});
for f=["ODI","T20"]
 for split=["train","validation","test"]
    q=Q(Q.PrimaryInnings==1 & Q.Format==f & Q.Split==split,:);
    [found,mi]=ismember(q.MatchID,M.MatchID);assert(all(found),'Missing match metadata.');
    early=nnz(M.FirstInningsClass(mi)=="completed_early_all_out");
    vals=q.LegalBalls;
    if isempty(vals),med=NaN;iq=NaN;else,med=median(vals);iq=prctile(vals,75)-prctile(vals,25);end
    Population=[Population;table(f,split,height(q),sum(q.PrimaryStateObservations), ...
        early,med,iq,'VariableNames',Population.Properties.VariableNames)]; %#ok<AGROW>
 end
end
caption="Primary men's ODI/T20 cohorts after raw-data audit and reservation of identified cases. State observations are correlated within matches. Train precedes 2023; validation is 2023; test starts in 2024. Initial and terminal audit rows are excluded from observation counts.";
Index=writeTable(Population,MT,'T_M01_PrimaryCohorts.csv','PrimaryCohorts',Workbook,Index,'Methodology',caption,'09_InningsReconciliation + 09_MatchManifest');
%% Fields and scientific definitions
Fields=table(["u";"w";"D";"Y";"p";"Retirement";"Penalty credits";"Split";"Auxiliary outcomes"], ...
    ["legal balls";"wickets";"runs";"runs";"legal balls";"event count";"runs";"match group";"runs"], ...
    ["Balls remaining at a verified completed standard first-innings state"; ...
    "10 minus genuine dismissals before delivery; retired hurt is not a dismissal"; ...
    "Cumulative delivery runs before state, including delivery extras"; ...
    "Final delivery runs minus D; excludes innings-level penalty credits"; ...
    "Legal balls since last genuine dismissal; illegal-ball dismissals reset the clock"; ...
    "Retired hurt/not-out events preserved separately; availability requires separate interpretation"; ...
    "Pre/post innings penalties reconciled separately from the stochastic delivery-run response"; ...
    "All states in a match share one split; cases excluded from fitting"; ...
    "Observed follow-up scoring may be censored; not a completed-innings response by default"], ...
    'VariableNames',{'Variable','Unit','Definition'});
Index=writeTable(Fields,MT,'T_M02_StateDefinitions.csv','StateDefinitions',Workbook,Index,'Methodology', ...
    'State variables and response definitions used in corrected reconstruction.','09 reconstruction code and dictionary');
%% Results table is an AUDIT result, not predictive performance
Audit=readtable(fullfile(cfg.OutputRoot,'tables','09_QC_Summary.csv'),'Delimiter',',','TextType','string');
Audit=Audit(ismember(Audit.Metric,["StatesWritten","InningsReconstructed","PrimaryInnings", ...
    "PrimaryFailures","CorrectionsApplied","AuxiliaryFailedInnings"]),:);
Index=writeTable(Audit,RT,'T_R01_ReconstructionAudit.csv','ReconstructionAudit',Workbook,Index,'Results', ...
    'Corrected-state reconstruction audit. Passing reconciliation establishes aggregate agreement, not predictive accuracy or target fairness. Corrections outside ODI/T20 are not applied.', ...
    '09_QC_Summary');
%% Training support and partnership summaries; one pass over cached partitions
CountODI=zeros(301,11);CountT20=zeros(121,11);PartODI=zeros(301,1);PartT20=zeros(301,1);
Example=table; start=tic;
for k=1:height(result.Partitions)
    d=load(char(result.Partitions.Path(k)),'States');T=d.States;
    train=T.PrimaryEligibleObservation & T.Split=="train";
    for f=["ODI","T20"]
        t=T(train & T.Format==f,:);if isempty(t),continue;end
        u=t.BallsRemaining;w=t.WicketsInHand;
        U=300;if f=="T20",U=120;end
        assert(all(isfinite(u)&u>=0&u<=U&u==floor(u)),'Invalid training u.');
        c=accumarray([u+1,w+1],1,[U+1,11]);
        p=t.LegalBallsSinceDismissal;assert(all(p>=0&p<=300&p==floor(p)),'Invalid partnership duration.');
        pc=accumarray(p+1,1,[301,1]);
        if f=="ODI",CountODI=CountODI+c;PartODI=PartODI+pc;
        else,CountT20=CountT20+c;PartT20=PartT20+pc;end
    end
    if isempty(Example) && any(train)
        candidate=find(train,1);id=T.MatchID(candidate);inn=T.InningsIndex(candidate);
        rows=find(T.MatchID==id & T.InningsIndex==inn & T.StateType=="delivery");
        rows=rows(1:min(8,numel(rows)));
        Example=T(rows,{'MatchID','InningsIndex','DeliverySeq','CorrectedIsLegalBall', ...
            'LegalBallsBowled','BallsRemaining','WicketsInHand','DeliveryScoreBefore', ...
            'LegalBallsSinceDismissal','ObservedFutureDeliveryRuns'});
    end
    fprintf('Publication cache read %d / %d | %.1f min\n',k,height(result.Partitions),toc(start)/60);
end
assert(sum(CountODI,'all')==sum(Population.EligibleStateObservations(Population.Format=="ODI" & Population.Split=="train")), ...
    'ODI support count disagreement.');
assert(sum(CountT20,'all')==sum(Population.EligibleStateObservations(Population.Format=="T20" & Population.Split=="train")), ...
    'T20 support count disagreement.');
Index=writeTable(Example,MT,'T_M03_StateExample.csv','StateExample',Workbook,Index,'Methodology', ...
    'Eight pre-delivery states from the first encountered training innings, selected independently of performance. Future-run labels are retrospective outcomes, not inputs.','09 cached states');
Support=table(["ODI";"T20"],[sum(CountODI,'all');sum(CountT20,'all')], ...
    [nnz(CountODI);nnz(CountT20)], ...
    [nnz(CountODI>=30);nnz(CountT20>=30)], ...
    'VariableNames',{'Format','TrainingObservations','ObservedCells','CellsWithAtLeast30Observations'});
Index=writeTable(Support,MT,'T_M04_TrainingSupport.csv','TrainingSupport',Workbook,Index,'Methodology', ...
    'Observed training support before smoothing. Cells count legal-delivery observations, not independent matches; 30 is reported descriptively, not imposed as the final threshold.','09 cached training states');
save(fullfile(root,'09_TrainingSupportData.mat'),'CountODI','CountT20','PartODI','PartT20','-v7');
%% Four-panel cohort/length figure
F=figure('Visible','off','Color','w','Position',[100,100,1100,780]);
tiledlayout(2,2,'TileSpacing','compact','Padding','compact');
nexttile; B=zeros(2,3);
for j=1:2
    f=["ODI","T20"];f=f(j);
    for l=1:3,sp=["train","validation","test"];B(j,l)=Population.Matches(Population.Format==f & Population.Split==sp(l));end
end
bar(categorical({'ODI','T20'}),B);ylabel('Matches');title('(A) Primary split sizes');legend({'Training','Validation','Test'},'Location','northwest');grid on;
nexttile;
training=M.PrimaryModelEligible==1 & M.Split=="train";
full=zeros(2,1);early=full;
for j=1:2
    fs=["ODI","T20"];sel=training & M.FormatFamily==fs(j);
    full(j)=nnz(sel & M.FirstInningsClass=="completed_full_length");
    early(j)=nnz(sel & M.FirstInningsClass=="completed_early_all_out");
end
bar(categorical({'ODI','T20'}),[full,early],'stacked');ylabel('Training matches');title('(B) First-innings completion');legend({'Full length','Early all out'},'Location','northwest');grid on;
nexttile;histogram(Q.LegalBalls(Q.PrimaryInnings==1 & Q.Format=="ODI" & Q.Split=="train"),0:12:312);
xlabel('Legal balls delivered');ylabel('Training innings');title('(C) ODI innings length');grid on;
nexttile;histogram(Q.LegalBalls(Q.PrimaryInnings==1 & Q.Format=="T20" & Q.Split=="train"),0:6:126);
xlabel('Legal balls delivered');ylabel('Training innings');title('(D) T20 innings length');grid on;
style(F);exportFigure(F,MF,'F_M01_CohortsAndLengths');close(F);
Index=[Index;table("F_M01_CohortsAndLengths", "Methodology", ...
    "Primary split counts (A), training completion classes (B), and training legal-ball lengths (C-D). Early all-out innings are retained without a minimum-ball cutoff.", ...
    "09 manifests and innings reconciliation",'VariableNames',Index.Properties.VariableNames)];
%% Four-panel training-support figure
F=figure('Visible','off','Color','w','Position',[100,100,1100,780]);
tiledlayout(2,2,'TileSpacing','compact','Padding','compact');
nexttile;supportPlot(CountODI,300);title('(A) ODI training-state support');
nexttile;supportPlot(CountT20,120);title('(B) T20 training-state support');
nexttile;bar(0:300,PartODI/max(sum(PartODI),1),1);xlim([0,300]);
xlabel('Legal balls since dismissal');ylabel('Proportion of states');title('(C) ODI partnership duration');grid on;
nexttile;bar(0:300,PartT20/max(sum(PartT20),1),1);xlim([0,120]);
xlabel('Legal balls since dismissal');ylabel('Proportion of states');title('(D) T20 partnership duration');grid on;
style(F);exportFigure(F,MF,'F_M02_TrainingSupportAndPartnership');close(F);
Index=[Index;table("F_M02_TrainingSupportAndPartnership","Methodology", ...
    "Training observation counts by balls remaining and wickets in hand (A-B), shown as log10(n+1); white cells are unobserved. Partnership-duration distributions (C-D) describe states, not independent innings. These are support maps, not resource estimates.", ...
    "09 cached training legal-delivery states",'VariableNames',Index.Properties.VariableNames)];
writetable(Index,fullfile(root,'09_PublicationIndex.csv'));
writetable(Index,Workbook,'Sheet','CaptionsAndSources');
zipFile=fullfile(cfg.ProjectRoot,'RevisedCodes_09_Publication.zip');
zip(zipFile,{'Methodology','Results','09_PublicationTables.xlsx','09_PublicationIndex.csv'},root);
Publication=struct('Root',root,'Workbook',Workbook,'Index',Index,'ZIP',zipFile);
fprintf('\nPublication exports complete. Upload: %s\n',zipFile);
end
function I=writeTable(T,folder,name,sheet,book,I,section,caption,source)
writetable(T,fullfile(folder,name));writetable(T,book,'Sheet',sheet);
I=[I;table(string(name),string(section),string(caption),string(source),'VariableNames',I.Properties.VariableNames)];
end
function supportPlot(C,U)
Z=log10(C+1);Z(C==0)=NaN;
H=imagesc(0:10,0:U,Z);H.AlphaData=isfinite(Z);set(gca,'YDir','normal','Color','w');
xlabel('Wickets in hand');ylabel('Balls remaining');xticks(0:2:10);
cb=colorbar;cb.Label.String='log_{10}(n+1)';
end
function style(F)
set(findall(F,'Type','axes'),'FontName','Times New Roman','FontSize',11,'LineWidth',0.8);
set(findall(F,'Type','text'),'FontName','Times New Roman');
end
function exportFigure(F,folder,name)
exportgraphics(F,fullfile(folder,[name '.png']),'Resolution',600);
exportgraphics(F,fullfile(folder,[name '.pdf']),'ContentType','vector');
savefig(F,fullfile(folder,[name '.fig']));
end
