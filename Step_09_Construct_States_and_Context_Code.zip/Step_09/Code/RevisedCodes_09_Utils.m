function U=RevisedCodes_09_Utils
% Shared support for 09_03--09_05; no changes to source caches/configuration.
U.Options=@options;U.Stamp=@stamp;U.Stamps=@stamps;U.Read=@read;
U.Inventory=@inventory;U.Ensure=@ensure;U.Generation=@generation;
U.Signature=@signature;U.Publish=@publish;U.Finish=@finish;
U.Key=@key;U.HasText=@hasText;U.SourceOK=@sourceOK;U.Date=@parseDate;
U.OversToBalls=@oversToBalls;U.CacheValid=@cacheValid;
U.SHA256=@sha256;
end
function o=options(o,s)
assert(isstruct(s)&&isscalar(s),'Settings must be a scalar struct.');
for n=fieldnames(s)'
 assert(isfield(o,n{1}),'Unknown setting %s.',n{1});o.(n{1})=s.(n{1});
end
end
function ensure(p)
if ~isfolder(p),mkdir(p);end
end
function [g,r]=generation(root)
ensure(root);uuid=javaMethod('randomUUID','java.util.UUID');uid=char(uuid.toString);uid=uid(1:8);
g=fullfile(root,['generation_' char(datetime('now','Format','yyyyMMdd_HHmmss_SSS')) '_' uid]);
ensure(g);r=fullfile(g,'reports');ensure(r);
end
function s=stamp(p)
if ~isfile(p),s=struct('Path',string(p),'Exists',false,'Bytes',0,'Modified',0);return;end
d=dir(p);s=struct('Path',string(p),'Exists',true,'Bytes',d.bytes,'Modified',d.datenum);
end
function T=stamps(paths)
T=table;
for p=string(paths(:))'
 s=stamp(p);T=[T;struct2table(s)]; %#ok<AGROW>
end
end
function s=signature(version,opt,paths,code)
U=which('RevisedCodes_09_Utils');
s=struct('Version',version,'Options',opt,'Sources',stamps(paths),'CodePath',string(code), ...
 'Code',fileread(code),'UtilityCode',fileread(U));
end
function h=sha256(text)
md=java.security.MessageDigest.getInstance('SHA-256');md.update(unicode2native(text,'UTF-8'));
b=typecast(md.digest(),'uint8');h=lower(reshape(dec2hex(b,2)',1,[]));
end
function yes=cacheValid(out,var,sig)
yes=false;if ~isfile(out),return;end
z=load(out,var);if ~isfield(z,var),return;end
D=z.(var);
yes=isfield(D,'Signature')&&isequaln(D.Signature,sig)&& ...
 isfield(D,'ArtifactPaths')&&all(isfile(D.ArtifactPaths))&&isfile(D.ReportZIP);
end
function T=read(p,stringsRequired)
% Force numeric-looking IDs and dates to text; preserve missing text as ''.
if nargin<2,stringsRequired=strings(0,1);end
assert(isfile(p),'Required CSV missing: %s',p);
o=detectImportOptions(p,'Delimiter',',','VariableNamingRule','preserve');
o.VariableNamesLine=1;o.DataLines=[2 Inf];
text=unique([intersect(string(o.VariableNames),string(stringsRequired)), ...
 string(o.VariableNames(ismember(string(o.VariableTypes),["char","string"])))]);
if ~isempty(text),o=setvartype(o,cellstr(text),'string');end
T=readtable(p,o);
for n=string(T.Properties.VariableNames)
 if isstring(T.(n)),v=T.(n);v(ismissing(v))="";T.(n)=v;end
end
for n=intersect(string(T.Properties.VariableNames),["NeedsReview","InvalidRawValues"])
 v=lower(strtrim(string(T.(n))));
 assert(all(ismember(v,["true","false","1","0"])), ...
  'Invalid boolean values in %s, column %s.',p,n);
 T.(n)=ismember(v,["true","1"]);
end
end
function k=key(T)
k=string(T.MatchID)+"|"+string(T.InningsIndex);
end
function v=hasText(s)
v=~ismissing(string(s))&strlength(strtrim(string(s)))>0;
end
function v=sourceOK(id,S)
% Source registration is not automatic independent factual verification.
v=false(size(id));
for j=1:numel(id)
 a=find(S.SourceID==id(j));
 if numel(a)==1
  permitted=["official_scorecard","official_report","published_rules", ...
   "peer_reviewed_method","scorecard_archive","contemporary_report"];
  url=~isempty(regexp(char(S.URL(a)),'^https?://[^\s/]+','once'));
  v(j)=url&&hasText(S.Title(a))&&hasText(S.EvidenceExcerpt(a))&& ...
   ismember(S.SourceType(a),permitted)&&S.ReviewStatus(a)=="reviewed"&& ...
   ~isnat(parseDate(S.ReviewDate(a)));
 end
end
end
function d=parseDate(s)
% Require unambiguous ISO dates. Blank dates stay NaT, never guessed.
s=string(s);d=NaT(size(s));
for j=1:numel(s)
 if ~hasText(s(j)),continue;end
 assert(~isempty(regexp(char(s(j)),'^\d{4}-\d{2}-\d{2}$','once')), ...
  'Use YYYY-MM-DD dates, found %s.',s(j));
 try,d(j)=datetime(s(j),'InputFormat','yyyy-MM-dd');
 catch,error('Invalid calendar date %s.',s(j));end
 assert(string(d(j),'yyyy-MM-dd')==s(j),'Invalid calendar date %s.',s(j));
end
end
function b=oversToBalls(s,bpo)
% Parse literal components, preserve input shape, reject invalid ball digits.
% No dependence on optional regexp capture-token behavior.
s=string(s);b=nan(size(s));
validateattributes(bpo,{'numeric'},{'scalar','finite','positive','integer'});
for j=1:numel(s)
 if ~hasText(s(j)),continue;end
 text=strtrim(s(j));
 assert(~isempty(regexp(char(text),'^[0-9]+([.][0-9]+)?$','once')), ...
  'Invalid cricket notation %s.',s(j));
 parts=split(text,".");overs=str2double(parts(1));balls=0;
 if numel(parts)==2,balls=str2double(parts(2));end
 assert(isfinite(overs)&&isfinite(balls),'Nonfinite cricket notation %s.',s(j));
 assert(balls>=0&&balls<bpo,'Ball digit invalid for %d-ball overs: %s.',bpo,s(j));
 b(j)=overs*bpo+balls;
end
end
function [I,source]=inventory(cfg)
% A cached, one-row-per-innings inventory shared by both new audit stages.
source=fullfile(cfg.OutputRoot,'RevisedCodes_09_Result.mat');
assert(isfile(source),'09_01 manifest missing.');z=load(source,'Result');R=z.Result;
assert(all(isfile(R.Partitions.Path)),'Missing corrected partition.');
legacyPaths=strings(0,1);
for n=["Delivery","Prerequisite","Corrections"]
 a=R.Signature.(n);b=stamp(a.Path);
 assert(b.Exists&&a.Bytes==b.Bytes&&a.Modified==b.Modified, ...
  '09_01 %s source changed; stop and reconcile provenance before proceeding.',n);
 legacyPaths(end+1,1)=a.Path; %#ok<AGROW>
end
root=fullfile(cfg.OutputRoot,'support09');ensure(root);
out=fullfile(root,'09_InningsInventory.mat');
sig=signature('09.inventory.1',struct, [string(source);R.Partitions.Path;legacyPaths],mfilename('fullpath')+".m");
if isfile(out)
 z=load(out,'I','InventorySignature');
 if isequaln(z.InventorySignature,sig),I=z.I;return;end
end
I=table;
for k=1:height(R.Partitions)
 z=load(R.Partitions.Path(k),'States');S=z.States;
 assert(height(S)==R.Partitions.States(k),'Partition row count differs.');
 a=find(S.StateType=="initial");b=find(S.StateType=="terminal");
 assert(numel(a)==numel(b)&&all(a<b),'Invalid initial/terminal pairing.');
 for j=1:numel(a)
  x=a(j);y=b(j);rows=x:y;d=rows(S.StateType(rows)=="delivery");
  assert(all(S.MatchID(rows)==S.MatchID(x)&S.InningsIndex(rows)==S.InningsIndex(x)), ...
   'Noncontiguous innings block.');
  primary=any(S.PrimaryEligibleObservation(rows));
  reconstruct=all(S.RecordIntegrityPassed(rows))&& ...
   sum(S.DeliveryRuns(d))==S.FinalDeliveryRuns(y)&& ...
   sum(S.CorrectedIsLegalBall(d))==S.LegalBallsBowled(y)&& ...
   sum(S.GenuineDismissalsOnDelivery(d))==S.GenuineWicketsLost(y)&& ...
   isequal(S.DeliverySeq(d),(1:numel(d))');
  assert(~primary||reconstruct,'Primary innings reconstruction failed.');
  assert(~primary||~S.CaseReserved(x),'Reserved case in primary cohort.');
  B=table(S.MatchID(x),S.InningsIndex(x),S.Format(x),S.Gender(x), ...
   dateshift(S.MatchDate(x),'start','day'),S.Split(x),S.CaseReserved(x), ...
   S.BattingTeam(x),S.Team1(x),S.Team2(x),S.Venue(x),S.EventName(x), ...
   S.CompletionClass(x),S.BallsRemaining(x),S.LegalBallsBowled(y), ...
   S.GenuineWicketsLost(y),S.FinalDeliveryRuns(y),S.ScoreboardBefore(y), ...
   sum(S.RetiredNotOutEvents(d)),numel(rows),nnz(S.PrimaryEligibleObservation(rows)), ...
   primary,reconstruct,k,x,y, ...
   'VariableNames',{'MatchID','InningsIndex','Format','Gender','Date','Split','CaseReserved', ...
   'BattingTeam','Team1','Team2','Venue','EventName','CompletionClass','InitialBallsRemaining', ...
   'LegalBalls','GenuineDismissals','FinalDeliveryRuns','FinalScoreboard','RetiredNotOutEvents', ...
   'StateRows','PrimaryStates','Primary','ReconstructionPassed','Partition','InitialRow','TerminalRow'});
  I=[I;B]; %#ok<AGROW>
 end
 fprintf('Shared innings inventory %d/%d\n',k,height(R.Partitions));
end
assert(numel(unique(key(I)))==height(I),'Duplicate cached innings keys.');
assert(sum(I.StateRows)==sum(R.Partitions.States),'Inventory row totals differ.');
assert(isequal(sig.Sources,stamps([string(source);R.Partitions.Path;legacyPaths])), ...
 'State sources changed during inventory creation.');
InventorySignature=sig;save(out,'I','InventorySignature','-v7.3');
end
function paths=publish(cfg,stage,Tables,summary,caption,report)
% Descriptive audit figures only; no scoring/target performance claims.
pub=fullfile(cfg.ProjectRoot,'paper_outputs_revisedcodes','PublicationReady');
mt=fullfile(pub,'Methodology','Tables');mf=fullfile(pub,'Methodology','Figures');
st=fullfile(pub,'Supplementary','Tables');sd=fullfile(pub,'SourceData');ci=fullfile(pub,'CaptionsAndIndex');
for p=string({mt,mf,st,sd,ci}),ensure(p);end
paths=strings(0,1);
for j=1:numel(Tables)
 t=Tables(j);folder=st;if t.Main,folder=mt;end
 p=fullfile(folder,char(string(t.Name)+".csv"));writetable(t.Data,p);paths(end+1,1)=p; %#ok<AGROW>
 % One workbook per asset avoids sheet limits in exhaustive ledgers.
 p=fullfile(folder,char(string(t.Name)+".xlsx"));writetable(t.Data,p);paths(end+1,1)=p; %#ok<AGROW>
end
fig=figure('Visible','off','Color','w','Position',[100 100 1100 750]);
cleanup=onCleanup(@()close(fig)); %#ok<NASGU>
tiledlayout(2,2,'TileSpacing','compact','Padding','compact');
for j=1:4
 nexttile;v=summary(summary.Panel==j,:);
 if isempty(v),axis off;text(.1,.5,'No audited observations');continue;end
 bar(v.Value,'FaceColor',[.15 .4 .65]);xticks(1:height(v));xticklabels(v.Label);xtickangle(25);
 ylabel('Count');title(sprintf('(%c) %s',64+j,v.Title(1)));
 set(gca,'FontName','Times New Roman','FontSize',10,'Box','off');grid on;
end
base=fullfile(mf,char('F_M_'+stage+'_Audit'));
exportgraphics(fig,[base '.png'],'Resolution',600);exportgraphics(fig,[base '.pdf'],'ContentType','vector');
savefig(fig,[base '.fig']);exportgraphics(fig,fullfile(report,'Preview.png'),'Resolution',100);
paths=[paths;string([base '.png']);string([base '.pdf']);string([base '.fig'])];
p=fullfile(sd,char('F_M_'+stage+'_Audit.csv'));writetable(summary,p);paths(end+1,1)=p;
p=fullfile(ci,char(stage+'_PublicationIndex.csv'));
writetable(table("F_M_"+stage+"_Audit",string(caption),stage, ...
 'VariableNames',{'Asset','Caption','ProducingStage'}),p);paths(end+1,1)=p;
end
function D=finish(cfg,var,out,sig,g,report,D,pub)
assert(isequal(sig.Sources,stamps(sig.Sources.Path)),'Source changed during this stage.');
assert(strcmp(sig.Code,fileread(sig.CodePath))&& ...
 strcmp(sig.UtilityCode,fileread(which('RevisedCodes_09_Utils'))),'Stage code changed during execution.');
files=dir(fullfile(report,'*'));files=files(~[files.isdir]);names={files.name};
zipfile=fullfile(cfg.ProjectRoot,char('RevisedCodes_'+D.Stage+'_Checks.zip'));
zip(zipfile,names,report);
D.Signature=sig;D.Generation=string(g);D.ReportZIP=string(zipfile);
D.ArtifactPaths=[string(fullfile(report,names))';string(pub(:))];
container=struct;container.(var)=D;save(out,'-struct','container','-v7.3');
fprintf('%s COMPLETE (%s). Upload %s\n',D.Stage,D.Status,zipfile);
end
